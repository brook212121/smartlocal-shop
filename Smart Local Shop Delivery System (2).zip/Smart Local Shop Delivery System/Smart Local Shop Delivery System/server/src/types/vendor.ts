import { Request } from 'express';
import { IUser } from '../models/User';

// Extended Request interface for vendor middleware
export interface VendorRequest extends Request {
  user?: IUser;
  product?: any;
}
