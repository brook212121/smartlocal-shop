import fs from 'fs';
import path from 'path';

export class ImageUploadHelper {
  private static uploadsDir = path.join(process.cwd(), 'uploads');

  /**
   * Convert base64 string to uploaded file and return public URL
   */
  static async convertBase64ToImage(base64Data: string, filename?: string): Promise<string> {
    try {
      console.log('DEBUG: Starting base64 to image conversion...');
      
      // Ensure uploads directory exists
      if (!fs.existsSync(this.uploadsDir)) {
        console.log('DEBUG: Creating uploads directory...');
        fs.mkdirSync(this.uploadsDir, { recursive: true });
      }

      // Extract the base64 data (remove data:image/...;base64, prefix)
      const matches = base64Data.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
      if (!matches || matches.length !== 3) {
        console.error('DEBUG: Invalid base64 image format:', base64Data.substring(0, 100));
        throw new Error('Invalid base64 image format');
      }

      const imageType = matches[1];
      const base64Content = matches[2];
      console.log('DEBUG: Image type:', imageType);
      console.log('DEBUG: Base64 content length:', base64Content.length);
      
      // Get file extension from image type
      const extension = imageType.split('/')[1] || 'jpg';
      
      // Generate unique filename using timestamp
      const timestamp = Date.now();
      const random = Math.floor(Math.random() * 1000);
      const uniqueFilename = filename || `delivery-${timestamp}-${random}.${extension}`;
      const filePath = path.join(this.uploadsDir, uniqueFilename);
      
      console.log('DEBUG: File path:', filePath);
      console.log('DEBUG: Unique filename:', uniqueFilename);

      // Convert base64 to buffer and write to file
      const buffer = Buffer.from(base64Content, 'base64');
      fs.writeFileSync(filePath, buffer);
      
      console.log('DEBUG: File written successfully');

      // Return public URL (adjust based on your server configuration)
      const baseUrl = process.env.NGROK_URL || process.env.BASE_URL || 'http://localhost:5000';
      const publicUrl = `${baseUrl}/uploads/${uniqueFilename}`;
      
      console.log(`DEBUG: Base64 image converted and saved: ${publicUrl}`);
      console.log('DEBUG: File exists:', fs.existsSync(filePath));
      
      return publicUrl;
    } catch (error) {
      console.error('DEBUG: Error converting base64 to image:', error);
      throw error;
    }
  }

  /**
   * Check if a string is a base64 image
   */
  static isBase64Image(data: string): boolean {
    return data.startsWith('data:image/') && data.includes('base64,');
  }
}
