import nodemailer from 'nodemailer';

interface EmailConfig {
  email: string;
  appPassword: string;
}

const createEmailTransporter = () => {
  const config: EmailConfig = {
    email: process.env.GMAIL_EMAIL || '',
    appPassword: process.env.GMAIL_APP_PASSWORD || ''
  };
  
  // Enhanced logging for debugging
  console.log('🔧 Email Configuration:', {
    email: config.email,
    passwordLength: config.appPassword.length,
    passwordSet: !!config.appPassword,
    hasSpaces: config.appPassword.includes(' '),
    isEmpty: !config.email || !config.appPassword
  });

  if (!config.email || !config.appPassword) {
    console.warn('Email configuration not found in environment variables');
    return null;
  }

  return nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: config.email,
      pass: config.appPassword
    }
  });
};

export const testEmailConfig = async () => {
  const transporter = createEmailTransporter();
  
  if (!transporter) {
    console.error('❌ Email transporter not configured');
    return { success: false, error: 'Transporter not configured' };
  }

  try {
    // Simple test email
    const testMailOptions = {
      from: process.env.GMAIL_EMAIL,
      to: process.env.GMAIL_EMAIL, // Test sending to self
      subject: 'Gmail Configuration Test',
      html: `
        <div style="max-width: 600px; margin: 0 auto; padding: 20px; font-family: Arial, sans-serif;">
          <h2 style="color: #10b981;">Gmail Test</h2>
          <p style="color: #374151;">This is a test email to verify Gmail configuration.</p>
        </div>
      `
    };

    await transporter.sendMail(testMailOptions);
    console.log('✅ Test email sent successfully');
    return { success: true, message: 'Email configuration test successful' };
  } catch (error: any) {
    console.error('❌ Test email failed:', error);
    return { success: false, error: error.message };
  }
};

export const sendPasswordResetEmail = async (email: string, resetToken: string, frontendUrl?: string) => {
  const transporter = createEmailTransporter();
  
  if (!transporter) {
    throw new Error('Email service not configured');
  }

  // Use provided frontendUrl or resolve from environment
  const finalFrontendUrl = frontendUrl || 
                           process.env.FRONTEND_URL || 
                           process.env.NGROK_URL || 
                           'http://localhost:3000';
  
  const resetUrl = `${finalFrontendUrl}/reset-password?token=${resetToken}`;
  
  // Log URL for debugging
  console.log('🔧 Password Reset Email Configuration:');
  console.log('  Provided Frontend URL:', frontendUrl);
  console.log('  FRONTEND_URL:', process.env.FRONTEND_URL);
  console.log('  NGROK_URL:', process.env.NGROK_URL);
  console.log('  Final Reset URL:', resetUrl);
  console.log('  Email recipient:', email);

  const mailOptions = {
    from: process.env.GMAIL_EMAIL,
    to: email,
    subject: 'Password Reset - Smart Local Shop Delivery',
    html: `
      <div style="max-width: 600px; margin: 0 auto; padding: 20px; font-family: Arial, sans-serif;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #10b981; margin-bottom: 10px;">Smart Local Shop Delivery</h1>
          <h2 style="color: #374151; font-size: 24px;">Password Reset Request</h2>
        </div>
        
        <div style="background-color: #f9fafb; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
          <p style="color: #374151; line-height: 1.6; margin-bottom: 20px;">
            Hello,
          </p>
          <p style="color: #374151; line-height: 1.6; margin-bottom: 20px;">
            We received a request to reset your password for your Smart Local Shop Delivery account. 
            Click the button below to reset your password:
          </p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${resetUrl}" 
               style="background-color: #10b981; color: white; padding: 12px 30px; 
                      text-decoration: none; border-radius: 6px; font-weight: bold; 
                      display: inline-block;">
              Reset Password
            </a>
          </div>
          
          <p style="color: #6b7280; font-size: 14px; margin-top: 20px;">
            Or copy and paste this link in your browser:
          </p>
          <p style="color: #6b7280; font-size: 12px; word-break: break-all; background-color: #f3f4f6; padding: 10px; border-radius: 4px;">
            ${resetUrl}
          </p>
        </div>
        
        <div style="background-color: #fef3c7; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
          <p style="color: #92400e; font-size: 14px; margin: 0;">
            <strong>Important:</strong> This link will expire in 15 minutes for security reasons. 
            If you didn't request this password reset, please ignore this email.
          </p>
        </div>
        
        <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
          <p style="color: #6b7280; font-size: 12px; margin: 0;">
            This is an automated message from Smart Local Shop Delivery. Please do not reply to this email.
          </p>
        </div>
      </div>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(`Password reset email sent to ${email}`);
  } catch (error: any) {
    console.error('Error sending password reset email:', error);
    console.error('Gmail Error Details:', {
      code: error.code,
      message: error.message,
      response: error.response,
      command: error.command
    });
    throw new Error('Failed to send password reset email');
  }
};

export const sendVerificationEmail = async (email: string, verificationToken: string) => {
  const transporter = createEmailTransporter();
  
  if (!transporter) {
    throw new Error('Email service not configured');
  }

  const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';
  const verificationUrl = `${frontendUrl}/verify-email?token=${verificationToken}`;

  const mailOptions = {
    from: process.env.GMAIL_EMAIL,
    to: email,
    subject: 'Verify Your Email - Smart Local Shop Delivery',
    html: `
      <div style="max-width: 600px; margin: 0 auto; padding: 20px; font-family: Arial, sans-serif;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #10b981; margin-bottom: 10px;">Smart Local Shop Delivery</h1>
          <h2 style="color: #374151; font-size: 24px;">Verify Your Email Address</h2>
        </div>
        
        <div style="background-color: #f9fafb; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
          <p style="color: #374151; line-height: 1.6; margin-bottom: 20px;">
            Welcome to Smart Local Shop Delivery!
          </p>
          <p style="color: #374151; line-height: 1.6; margin-bottom: 20px;">
            Thank you for registering with us. To complete your registration and activate your account, 
            please verify your email address by clicking the button below:
          </p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${verificationUrl}" 
               style="background-color: #10b981; color: white; padding: 12px 30px; 
                      text-decoration: none; border-radius: 6px; font-weight: bold; 
                      display: inline-block;">
              Verify Email Address
            </a>
          </div>
          
          <p style="color: #6b7280; font-size: 14px; margin-top: 20px;">
            Or copy and paste this link in your browser:
          </p>
          <p style="color: #6b7280; font-size: 12px; word-break: break-all; background-color: #f3f4f6; padding: 10px; border-radius: 4px;">
            ${verificationUrl}
          </p>
        </div>
        
        <div style="background-color: #dcfce7; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
          <p style="color: #166534; font-size: 14px; margin: 0;">
            <strong>Next Steps:</strong> After verifying your email, you can log in to your account and start using our services.
          </p>
        </div>
        
        <div style="background-color: #fef3c7; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
          <p style="color: #92400e; font-size: 14px; margin: 0;">
            <strong>Important:</strong> This verification link will expire in 24 hours for security reasons. 
            If you didn't create an account with us, please ignore this email.
          </p>
        </div>
        
        <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
          <p style="color: #6b7280; font-size: 12px; margin: 0;">
            This is an automated message from Smart Local Shop Delivery. Please do not reply to this email.
          </p>
        </div>
      </div>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Error sending verification email:', error);
    throw new Error('Failed to send verification email');
  }
};

export default createEmailTransporter;
