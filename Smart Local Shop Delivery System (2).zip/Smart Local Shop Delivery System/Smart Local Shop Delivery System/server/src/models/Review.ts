import mongoose, { Document, Schema, Types } from 'mongoose';

export interface IReview extends Document<Types.ObjectId> {
  _id: Types.ObjectId;
  reviewer: Types.ObjectId; // Reference to User
  target: Types.ObjectId; // Reference to User, Product, or Order
  targetType: 'USER' | 'PRODUCT' | 'ORDER' | 'DELIVERY';
  rating: number; // 1-5 stars
  title?: string;
  comment: string;
  images?: string[]; // Review images
  helpful: {
    count: number;
    users: Types.ObjectId[];
  };
  verification: {
    isVerified: boolean;
    verifiedAt?: Date;
    verifiedBy?: Types.ObjectId;
    verificationNotes?: string;
    isGenuine: boolean; // AI/Manual verification of review authenticity
  };
  response?: {
    content: string;
    respondedBy: Types.ObjectId;
    respondedAt: Date;
    isPublic: boolean;
  };
  moderation: {
    status: 'APPROVED' | 'PENDING' | 'REJECTED' | 'FLAGGED';
    moderatedBy?: Types.ObjectId;
    moderatedAt?: Date;
    reason?: string;
    flags?: string[];
  };
  metadata: {
    order?: Types.ObjectId; // Reference to Order if review is order-specific
    product?: Types.ObjectId; // Reference to Product if review is product-specific
    delivery?: Types.ObjectId; // Reference to Delivery if review is delivery-specific
    purchaseVerified: boolean; // Whether the reviewer actually made the purchase
    reviewType: 'PUBLIC' | 'PRIVATE';
    sentiment?: 'POSITIVE' | 'NEUTRAL' | 'NEGATIVE'; // AI-analyzed sentiment
    topics?: string[]; // AI-extracted topics from review
  };
  visibility: {
    isVisible: boolean;
    hiddenBy?: Types.ObjectId;
    hiddenAt?: Date;
    hideReason?: string;
  };
  edits: Array<{
    content: string;
    editedAt: Date;
    reason?: string;
  }>;
  reports: Array<{
    reportedBy: Types.ObjectId;
    reason: string;
    description: string;
    reportedAt: Date;
    status: 'PENDING' | 'REVIEWED' | 'RESOLVED' | 'DISMISSED';
    reviewedBy?: Types.ObjectId;
    reviewedAt?: Date;
    resolution?: string;
  }>;
  createdAt: Date;
  updatedAt: Date;
}

const reviewSchema = new Schema<IReview>({
  reviewer: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Reviewer is required']
  },
  target: {
    type: Schema.Types.ObjectId,
    required: [true, 'Review target is required']
  },
  targetType: {
    type: String,
    enum: ['USER', 'PRODUCT', 'ORDER', 'DELIVERY'],
    required: [true, 'Review target type is required']
  },
  rating: {
    type: Number,
    required: [true, 'Rating is required'],
    min: [1, 'Rating must be at least 1'],
    max: [5, 'Rating cannot exceed 5']
  },
  title: {
    type: String,
    maxlength: [200, 'Review title cannot exceed 200 characters']
  },
  comment: {
    type: String,
    required: [true, 'Review comment is required'],
    minlength: [10, 'Review comment must be at least 10 characters'],
    maxlength: [2000, 'Review comment cannot exceed 2000 characters']
  },
  images: [String],
  helpful: {
    count: {
      type: Number,
      default: 0,
      min: [0, 'Helpful count cannot be negative']
    },
    users: [{
      type: Schema.Types.ObjectId,
      ref: 'User'
    }]
  },
  verification: {
    isVerified: {
      type: Boolean,
      default: false
    },
    verifiedAt: Date,
    verifiedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User'
    },
    verificationNotes: String,
    isGenuine: {
      type: Boolean,
      default: false
    }
  },
  response: {
    content: String,
    respondedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User'
    },
    respondedAt: Date,
    isPublic: {
      type: Boolean,
      default: true
    }
  },
  moderation: {
    status: {
      type: String,
      enum: ['APPROVED', 'PENDING', 'REJECTED', 'FLAGGED'],
      default: 'PENDING'
    },
    moderatedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User'
    },
    moderatedAt: Date,
    reason: String,
    flags: [String]
  },
  metadata: {
    order: {
      type: Schema.Types.ObjectId,
      ref: 'Order'
    },
    product: {
      type: Schema.Types.ObjectId,
      ref: 'Product'
    },
    delivery: {
      type: Schema.Types.ObjectId,
      ref: 'Delivery'
    },
    purchaseVerified: {
      type: Boolean,
      default: false
    },
    reviewType: {
      type: String,
      enum: ['PUBLIC', 'PRIVATE'],
      default: 'PUBLIC'
    },
    sentiment: {
      type: String,
      enum: ['POSITIVE', 'NEUTRAL', 'NEGATIVE']
    },
    topics: [String]
  },
  visibility: {
    isVisible: {
      type: Boolean,
      default: true
    },
    hiddenBy: {
      type: Schema.Types.ObjectId,
      ref: 'User'
    },
    hiddenAt: Date,
    hideReason: String
  },
  edits: [{
    content: String,
    editedAt: {
      type: Date,
      default: Date.now
    },
    reason: String
  }],
  reports: [{
    reportedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Report reporter is required']
    },
    reason: {
      type: String,
      required: [true, 'Report reason is required'],
      enum: ['INAPPROPRIATE_CONTENT', 'FAKE_REVIEW', 'SPAM', 'HARASSMENT', 'OTHER']
    },
    description: {
      type: String,
      required: [true, 'Report description is required'],
      minlength: [10, 'Report description must be at least 10 characters']
    },
    reportedAt: {
      type: Date,
      default: Date.now
    },
    status: {
      type: String,
      enum: ['PENDING', 'REVIEWED', 'RESOLVED', 'DISMISSED'],
      default: 'PENDING'
    },
    reviewedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User'
    },
    reviewedAt: Date,
    resolution: String
  }]
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Indexes
reviewSchema.index({ reviewer: 1 });
reviewSchema.index({ target: 1, targetType: 1 });
reviewSchema.index({ rating: 1 });
reviewSchema.index({ 'moderation.status': 1 });
reviewSchema.index({ createdAt: -1 });

// Compound index for unique reviews
reviewSchema.index(
  { reviewer: 1, target: 1, targetType: 1 },
  { unique: true, partialFilterExpression: { 'metadata.purchaseVerified': true } }
);

// Virtual for review age in days
reviewSchema.virtual('ageInDays').get(function(this: IReview) {
  return Math.floor((Date.now() - this.createdAt.getTime()) / (1000 * 60 * 60 * 24));
});

// Virtual for is recent (within last 30 days)
reviewSchema.virtual('isRecent').get(function(this: IReview) {
  const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);
  return this.createdAt.getTime() > thirtyDaysAgo;
});

// Pre-save middleware to prevent duplicate reviews
reviewSchema.pre('save', async function(next) {
  if (this.isNew && this.metadata.purchaseVerified) {
    const Review = mongoose.model('Review');
    const existingReview = await Review.findOne({
      reviewer: this.reviewer,
      target: this.target,
      targetType: this.targetType,
      'metadata.purchaseVerified': true
    });
    
    if (existingReview) {
      const error = new Error('You have already reviewed this item') as any;
      error.code = 11000;
      return next(error);
    }
  }
  next();
});

const Review = mongoose.model<IReview>('Review', reviewSchema);

export default Review;
