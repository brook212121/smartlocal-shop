import mongoose, { Schema, Document } from 'mongoose';

export interface IVendorResponse extends Document {
  quickOrderId: mongoose.Types.ObjectId;
  vendorId: mongoose.Types.ObjectId;
  message: string;
  price: number;
  status: 'PENDING' | 'ACCEPTED' | 'REJECTED';
  createdAt: Date;
  updatedAt: Date;
}

const vendorResponseSchema = new Schema<IVendorResponse>({
  quickOrderId: {
    type: Schema.Types.ObjectId,
    ref: 'QuickOrder',
    required: [true, 'Quick Order ID is required']
  },
  vendorId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Vendor ID is required']
  },
  message: {
    type: String,
    required: [true, 'Message is required'],
    minlength: [5, 'Message must be at least 5 characters long'],
    maxlength: [1000, 'Message cannot exceed 1000 characters'],
    trim: true
  },
  price: {
    type: Number,
    required: [true, 'Price is required'],
    min: [0, 'Price must be at least 0'],
    max: [999999, 'Price cannot exceed 999,999']
  },
  status: {
    type: String,
    enum: ['PENDING', 'ACCEPTED', 'REJECTED'],
    default: 'PENDING'
  }
}, {
  timestamps: true
});

// Index for efficient queries
vendorResponseSchema.index({ quickOrderId: 1, createdAt: -1 });
vendorResponseSchema.index({ vendorId: 1, createdAt: -1 });
vendorResponseSchema.index({ quickOrderId: 1, vendorId: 1 }, { unique: true });

const VendorResponse = mongoose.model<IVendorResponse>('VendorResponse', vendorResponseSchema);

export default VendorResponse;
