import mongoose, { Schema, Document } from 'mongoose';

export interface IWithdrawal extends Document {
  _id: mongoose.Types.ObjectId;
  vendorId: mongoose.Types.ObjectId;
  amount: number;
  status: 'PENDING' | 'PROCESSING' | 'APPROVED' | 'PAID_OUT' | 'REJECTED';
  withdrawalMethod: {
    type: 'BANK_TRANSFER' | 'MOBILE_MONEY';
    bankName?: string;
    accountNumber?: string;
    phoneNumber?: string;
    accountHolderName: string;
  };
  fee: number;
  netAmount: number;
  rejectionReason?: string;
  processedAt?: Date;
  paidOutAt?: Date;
  createdAt: Date;
  updatedAt: Date;
  // Auto-approval flags
  autoApproved: boolean;
  approvalRules: {
    sufficientBalance: boolean;
    verifiedMethod: boolean;
    withinLimits: boolean;
  };
  // Manual settlement tracking (for real-world bank transfers)
  settlementReference?: string;
  settledAt?: Date;
  notes?: string;
}

const withdrawalSchema = new Schema<IWithdrawal>({
  vendorId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Vendor ID is required']
  },
  amount: {
    type: Number,
    required: [true, 'Withdrawal amount is required'],
    min: [50, 'Minimum withdrawal amount is 50 ETB']
  },
  status: {
    type: String,
    enum: ['PENDING', 'PROCESSING', 'APPROVED', 'PAID_OUT', 'REJECTED'],
    default: 'PENDING'
  },
  withdrawalMethod: {
    type: {
      type: String,
      enum: ['BANK_TRANSFER', 'MOBILE_MONEY'],
      required: true
    },
    bankName: {
      type: String,
      required: function(this: any) {
        return this.type === 'BANK_TRANSFER';
      }
    },
    accountNumber: {
      type: String,
      required: function(this: any) {
        return this.type === 'BANK_TRANSFER';
      }
    },
    phoneNumber: {
      type: String,
      required: function(this: any) {
        return this.type === 'MOBILE_MONEY';
      }
    },
    accountHolderName: {
      type: String,
      required: true
    }
  },
  fee: {
    type: Number,
    default: 0,
    min: 0
  },
  netAmount: {
    type: Number,
    required: true
  },
  rejectionReason: {
    type: String
  },
  processedAt: {
    type: Date
  },
  paidOutAt: {
    type: Date
  },
  autoApproved: {
    type: Boolean,
    default: false
  },
  approvalRules: {
    sufficientBalance: {
      type: Boolean,
      default: false
    },
    verifiedMethod: {
      type: Boolean,
      default: false
    },
    withinLimits: {
      type: Boolean,
      default: false
    }
  },
  settlementReference: {
    type: String // Reference for manual bank transfer settlement
  },
  settledAt: {
    type: Date
  },
  notes: {
    type: String // Internal notes about the withdrawal
  }
}, {
  timestamps: true
});

// Indexes for efficient queries
withdrawalSchema.index({ vendorId: 1, createdAt: -1 });
withdrawalSchema.index({ status: 1 });
withdrawalSchema.index({ autoApproved: 1 });

const Withdrawal = mongoose.model<IWithdrawal>('Withdrawal', withdrawalSchema);

export default Withdrawal;
