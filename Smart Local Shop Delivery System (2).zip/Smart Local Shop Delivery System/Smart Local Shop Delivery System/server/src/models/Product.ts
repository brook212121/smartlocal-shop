import mongoose, { Document, Schema, Types } from 'mongoose';

export interface IProduct extends Document<Types.ObjectId> {
  _id: Types.ObjectId;
  name: string;
  description: string;
  category: string;
  subcategory?: string;
  price: number;
  originalPrice?: number;
  discount?: number;
  currency: string;
  images: string[];
  vendor: Types.ObjectId; // Reference to User (VENDOR)
  sku: string;
  barcode?: string;
  brand?: string;
  manufacturer?: string;
  weight?: number;
  dimensions?: {
    length: number;
    width: number;
    height: number;
    unit: string;
  };
  stock: {
    quantity: number;
    lowStockThreshold: number;
    trackQuantity: boolean;
  };
  quantity: number; // Simple quantity field for easier frontend access
  variants?: Array<{
    name: string;
    value: string;
    price?: number;
    sku?: string;
  }>;
  tags: string[];
  seo: {
    title?: string;
    description?: string;
    keywords?: string[];
  };
  attributes?: Map<string, any>;
  isActive: boolean;
  isFeatured: boolean;
  isVerified: boolean; // AI verification status
  verificationDetails?: {
    isAuthentic: boolean;
    confidence: number;
    verifiedAt: Date;
    verifiedBy: 'AI' | 'ADMIN';
    issues?: string[];
  };
  averageRating: number;
  totalReviews: number;
  salesCount: number;
  viewCount: number;
  createdAt: Date;
  updatedAt: Date;
}

const productSchema = new Schema<IProduct>({
  name: {
    type: String,
    required: [true, 'Product name is required'],
    trim: true,
    maxlength: [200, 'Product name cannot exceed 200 characters']
  },
  description: {
    type: String,
    required: [true, 'Product description is required'],
    maxlength: [2000, 'Product description cannot exceed 2000 characters']
  },
  category: {
    type: String,
    required: [true, 'Product category is required'],
    enum: [
      'ELECTRONICS',
      'CLOTHING',
      'FOOD_BEVERAGES',
      'HOME_GARDEN',
      'HEALTH_BEAUTY',
      'SPORTS_OUTDOORS',
      'BOOKS_MEDIA',
      'TOYS_GAMES',
      'AUTOMOTIVE',
      'GROCERIES',
      'PHARMACY',
      'OTHER'
    ]
  },
  subcategory: String,
  price: {
    type: Number,
    required: [true, 'Product price is required'],
    min: [0, 'Price cannot be negative']
  },
  originalPrice: {
    type: Number,
    min: [0, 'Original price cannot be negative']
  },
  discount: {
    type: Number,
    min: [0, 'Discount cannot be negative'],
    max: [100, 'Discount cannot exceed 100%']
  },
  currency: {
    type: String,
    required: true,
    default: 'KES',
    enum: ['KES', 'USD', 'EUR', 'GBP']
  },
  images: [{
    type: String,
    required: true
  }],
  vendor: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Product vendor is required']
  },
  sku: {
    type: String,
    required: [true, 'SKU is required'],
    unique: true,
    uppercase: true,
    trim: true
  },
  barcode: String,
  brand: String,
  manufacturer: String,
  weight: {
    type: Number,
    min: [0, 'Weight cannot be negative']
  },
  dimensions: {
    length: {
      type: Number,
      min: [0, 'Length cannot be negative']
    },
    width: {
      type: Number,
      min: [0, 'Width cannot be negative']
    },
    height: {
      type: Number,
      min: [0, 'Height cannot be negative']
    },
    unit: {
      type: String,
      enum: ['cm', 'inches'],
      default: 'cm'
    }
  },
  stock: {
    quantity: {
      type: Number,
      required: true,
      min: [0, 'Stock quantity cannot be negative'],
      default: 0
    },
    lowStockThreshold: {
      type: Number,
      min: [0, 'Low stock threshold cannot be negative'],
      default: 5
    },
    trackQuantity: {
      type: Boolean,
      default: true
    }
  },
  quantity: {
    type: Number,
    required: true,
    min: [0, 'Quantity cannot be negative'],
    default: 0
  },
  variants: [{
    name: String,
    value: String,
    price: Number,
    sku: String
  }],
  tags: [String],
  seo: {
    title: String,
    description: String,
    keywords: [String]
  },
  attributes: {
    type: Map,
    of: Schema.Types.Mixed
  },
  isActive: {
    type: Boolean,
    default: true
  },
  isFeatured: {
    type: Boolean,
    default: false
  },
  isVerified: {
    type: Boolean,
    default: false
  },
  verificationDetails: {
    isAuthentic: {
      type: Boolean,
      default: false
    },
    confidence: {
      type: Number,
      min: 0,
      max: 100
    },
    verifiedAt: Date,
    verifiedBy: {
      type: String,
      enum: ['AI', 'ADMIN']
    },
    issues: [String]
  },
  averageRating: {
    type: Number,
    default: 0,
    min: 0,
    max: 5
  },
  totalReviews: {
    type: Number,
    default: 0,
    min: 0
  },
  salesCount: {
    type: Number,
    default: 0,
    min: 0
  },
  viewCount: {
    type: Number,
    default: 0,
    min: 0
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Indexes
productSchema.index({ name: 'text', description: 'text', tags: 'text' });
productSchema.index({ vendor: 1 });
productSchema.index({ category: 1 });
productSchema.index({ price: 1 });
productSchema.index({ averageRating: -1 });
productSchema.index({ salesCount: -1 });
productSchema.index({ isActive: 1, isVerified: 1 });
productSchema.index({ createdAt: -1 });

// Virtual for discounted price
productSchema.virtual('currentPrice').get(function(this: IProduct) {
  if (this.discount && this.originalPrice) {
    return this.originalPrice * (1 - this.discount / 100);
  }
  return this.price;
});

// Virtual for in stock status
productSchema.virtual('inStock').get(function(this: IProduct) {
  return this.stock.quantity > 0;
});

// Virtual for low stock warning
productSchema.virtual('isLowStock').get(function(this: IProduct) {
  return this.stock.quantity <= this.stock.lowStockThreshold;
});

const Product = mongoose.model<IProduct>('Product', productSchema);

export default Product;
