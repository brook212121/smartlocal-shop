import mongoose, { Document, Schema, Types } from 'mongoose';

export interface IPayment extends Document<Types.ObjectId> {
  _id: Types.ObjectId;
  reference: string; // Unique payment reference
  order: Types.ObjectId; // Reference to Order
  customer: Types.ObjectId; // Reference to User (CUSTOMER)
  vendor: Types.ObjectId; // Reference to User (VENDOR)
  amount: {
    subtotal: number;
    deliveryFee: number;
    serviceFee: number;
    tax: number;
    discount?: number;
    total: number;
    currency: string;
  };
  method: 'CHAPA';
  status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'PAID' | 'FAILED' | 'REFUNDED' | 'PARTIALLY_REFUNDED';
  gateway: {
    provider: 'CHAPA';
    transactionId?: string;
    gatewayResponse?: any;
    gatewayFee?: number;
  };
  chapa?: {
    tx_ref: string;
    checkout_url: string;
    flw_ref?: string;
    customer_email: string;
    customer_name: string;
    callback_url: string;
    return_url: string;
    customization?: {
      title?: string;
      description?: string;
      logo?: string;
    };
  };
  refund: {
    amount?: number;
    reason?: string;
    status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED';
    initiatedAt?: Date;
    completedAt?: Date;
    refundTransactionId?: string;
  };
  verification: {
    isVerified: boolean;
    verifiedAt?: Date;
    verifiedBy?: Types.ObjectId;
    verificationMethod?: 'MANUAL' | 'AUTOMATIC' | 'CHAPA';
    notes?: string;
  };
  metadata: {
    ipAddress?: string;
    userAgent?: string;
    device?: string;
    location?: {
      country?: string;
      city?: string;
      coordinates?: {
        latitude: number;
        longitude: number;
      };
    };
    riskScore?: number;
    fraudFlags?: string[];
  };
  timeline: Array<{
    status: string;
    timestamp: Date;
    note?: string;
    amount?: number;
    updatedBy?: Types.ObjectId;
  }>;
  notes?: string;
  internalNotes?: string; // Admin only notes
  createdAt: Date;
  updatedAt: Date;
}

const paymentSchema = new Schema<IPayment>({
  reference: {
    type: String,
    required: true,
    unique: true,
    default: function() {
      return 'PAY' + Date.now() + Math.random().toString(36).substr(2, 9).toUpperCase();
    }
  },
  order: {
    type: Schema.Types.ObjectId,
    ref: 'Order',
    required: [true, 'Order is required']
  },
  customer: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Customer is required']
  },
  vendor: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Vendor is required']
  },
  amount: {
    subtotal: {
      type: Number,
      required: true,
      min: [0, 'Subtotal cannot be negative']
    },
    deliveryFee: {
      type: Number,
      required: true,
      min: [0, 'Delivery fee cannot be negative']
    },
    serviceFee: {
      type: Number,
      required: true,
      min: [0, 'Service fee cannot be negative']
    },
    tax: {
      type: Number,
      required: true,
      min: [0, 'Tax cannot be negative']
    },
    discount: {
      type: Number,
      min: [0, 'Discount cannot be negative']
    },
    total: {
      type: Number,
      required: true,
      min: [0, 'Total cannot be negative']
    },
    currency: {
      type: String,
      required: true,
      default: 'ETB',
      enum: ['KES', 'USD', 'EUR', 'GBP', 'ETB']
    }
  },
  method: {
    type: String,
    enum: ['CHAPA'],
    required: [true, 'Payment method is required']
  },
  status: {
    type: String,
    enum: ['PENDING', 'PROCESSING', 'COMPLETED', 'PAID', 'FAILED', 'REFUNDED', 'PARTIALLY_REFUNDED'],
    default: 'PENDING'
  },
  gateway: {
    provider: {
      type: String,
      enum: ['CHAPA'],
      required: [true, 'Gateway provider is required']
    },
    transactionId: String,
    gatewayResponse: Schema.Types.Mixed,
    gatewayFee: {
      type: Number,
      min: [0, 'Gateway fee cannot be negative']
    }
  },
  chapa: {
    tx_ref: {
      type: String,
      required: function(this: IPayment) { return this.gateway.provider === 'CHAPA'; }
    },
    checkout_url: String,
    flw_ref: String,
    customer_email: String,
    customer_name: String,
    callback_url: String,
    return_url: String,
    customization: {
      title: String,
      description: String,
      logo: String
    }
  },
  refund: {
    amount: {
      type: Number,
      min: [0, 'Refund amount cannot be negative']
    },
    reason: String,
    status: {
      type: String,
      enum: ['PENDING', 'PROCESSING', 'COMPLETED', 'FAILED']
    },
    initiatedAt: Date,
    completedAt: Date,
    refundTransactionId: String
  },
  verification: {
    isVerified: {
      type: Boolean,
      default: false
    },
    verifiedAt: Date,
    verifiedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User'
    },
    verificationMethod: {
      type: String,
      enum: ['MANUAL', 'AUTOMATIC', 'CHAPA']
    },
    notes: String
  },
  metadata: {
    ipAddress: String,
    userAgent: String,
    device: String,
    location: {
      country: String,
      city: String,
      coordinates: {
        latitude: Number,
        longitude: Number
      }
    },
    riskScore: {
      type: Number,
      min: [0, 'Risk score cannot be negative'],
      max: [100, 'Risk score cannot exceed 100']
    },
    fraudFlags: [String]
  },
  timeline: [{
    status: String,
    timestamp: {
      type: Date,
      default: Date.now
    },
    note: String,
    amount: Number,
    updatedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User'
    }
  }],
  notes: String,
  internalNotes: String
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Indexes
paymentSchema.index({ order: 1 });
paymentSchema.index({ customer: 1 });
paymentSchema.index({ vendor: 1 });
paymentSchema.index({ status: 1 });
paymentSchema.index({ method: 1 });
paymentSchema.index({ createdAt: -1 });
paymentSchema.index({ 'gateway.transactionId': 1 });

// Virtual for payment completion time
paymentSchema.virtual('processingTime').get(function(this: IPayment) {
  const completedEntry = this.timeline.find(entry => entry.status === 'COMPLETED');
  const pendingEntry = this.timeline.find(entry => entry.status === 'PENDING');
  
  if (completedEntry && pendingEntry) {
    return completedEntry.timestamp.getTime() - pendingEntry.timestamp.getTime();
  }
  return null;
});

// Virtual for refund status
paymentSchema.virtual('hasRefund').get(function(this: IPayment) {
  return this.refund && this.refund.amount && this.refund.amount > 0;
});

const Payment = mongoose.model<IPayment>('Payment', paymentSchema);

export default Payment;
