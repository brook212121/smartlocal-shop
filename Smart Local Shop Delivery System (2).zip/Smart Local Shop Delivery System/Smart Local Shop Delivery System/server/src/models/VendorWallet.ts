import mongoose, { Schema, Document } from 'mongoose';

export interface IVendorWallet extends Document {
  _id: mongoose.Types.ObjectId;
  vendorId: mongoose.Types.ObjectId;
  totalEarned: number;
  availableBalance: number;
  pendingBalance: number; // Funds in holding period
  totalWithdrawn: number;
  lastUpdated: Date;
  holdingPeriodMinutes: number;
  transactionHistory: Array<{
    type: 'CUSTOMER_PAYMENT' | 'FUNDS_PENDING' | 'FUNDS_RELEASED' | 'WITHDRAWAL_REQUESTED' | 'PLATFORM_FEE_DEDUCTED' | 'VENDOR_PAYOUT' | 'HELD' | 'EARNED';
    amount: number;
    description: string;
    referenceId?: string; // Order ID or Withdrawal ID
    orderId?: mongoose.Types.ObjectId;
    withdrawalId?: mongoose.Types.ObjectId;
    isReleased?: boolean; // Track if funds have been released from holding
    createdAt: Date;
  }>;
  withdrawalMethods: Array<{
    type: 'BANK_TRANSFER' | 'MOBILE_MONEY';
    bankName?: string;
    accountNumber?: string;
    phoneNumber?: string;
    accountHolderName: string;
    isVerified: boolean;
    isDefault: boolean;
    createdAt: Date;
  }>;
}

const vendorWalletSchema = new Schema<IVendorWallet>({
  vendorId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Vendor ID is required'],
    unique: true
  },
  totalEarned: {
    type: Number,
    default: 0,
    min: 0
  },
  availableBalance: {
    type: Number,
    default: 0,
    min: 0
  },
  pendingBalance: {
    type: Number,
    default: 0,
    min: 0
  },
  totalWithdrawn: {
    type: Number,
    default: 0,
    min: 0
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  },
  holdingPeriodMinutes: {
    type: Number,
    default: 10080, // 1 week in minutes (7 days × 24 hours × 60 minutes)
    min: 1
  },
  transactionHistory: [{
    type: {
      type: String,
      enum: ['CUSTOMER_PAYMENT', 'FUNDS_PENDING', 'FUNDS_RELEASED', 'WITHDRAWAL_REQUESTED', 'PLATFORM_FEE_DEDUCTED', 'VENDOR_PAYOUT', 'HELD', 'EARNED'],
      required: true
    },
    amount: {
      type: Number,
      required: true,
      min: 0
    },
    description: {
      type: String,
      required: true
    },
    referenceId: {
      type: String
    },
    orderId: {
      type: Schema.Types.ObjectId,
      ref: 'Order'
    },
    withdrawalId: {
      type: Schema.Types.ObjectId,
      ref: 'Withdrawal'
    },
    isReleased: {
      type: Boolean,
      default: false
    },
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  withdrawalMethods: [{
    type: {
      type: String,
      enum: ['BANK_TRANSFER', 'MOBILE_MONEY'],
      required: true
    },
    bankName: {
      type: String,
      required: function(this: any) {
        return this.type === 'BANK_TRANSFER';
      }
    },
    accountNumber: {
      type: String,
      required: function(this: any) {
        return this.type === 'BANK_TRANSFER';
      }
    },
    phoneNumber: {
      type: String,
      required: function(this: any) {
        return this.type === 'MOBILE_MONEY';
      }
    },
    accountHolderName: {
      type: String,
      required: true
    },
    isVerified: {
      type: Boolean,
      default: false
    },
    isDescription: {
      type: String,
      required: true
    },
    isReleased: {
      type: Boolean,
      default: false
    },
    isDefault: {
      type: Boolean,
      default: false
    },
    createdAt: {
      type: Date,
      default: Date.now
    }
  }]
}, {
  timestamps: true
});

// Indexes for efficient queries
vendorWalletSchema.index({ 'transactionHistory.createdAt': -1 });
vendorWalletSchema.index({ 'transactionHistory.type': 1 });
vendorWalletSchema.index({ 'withdrawalMethods.isDefault': 1 });

const VendorWallet = mongoose.model<IVendorWallet>('VendorWallet', vendorWalletSchema);

export default VendorWallet;
