import mongoose, { Schema, Document } from 'mongoose';

export interface IChatMessage extends Document {
  quickOrderId: mongoose.Types.ObjectId;
  senderId: mongoose.Types.ObjectId;
  senderType: 'CUSTOMER' | 'VENDOR';
  message: string;
  price?: number;
  createdAt: Date;
  updatedAt: Date;
}

const chatMessageSchema = new Schema<IChatMessage>({
  quickOrderId: {
    type: Schema.Types.ObjectId,
    ref: 'QuickOrder',
    required: [true, 'Quick Order ID is required']
  },
  senderId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Sender ID is required']
  },
  senderType: {
    type: String,
    enum: ['CUSTOMER', 'VENDOR'],
    required: [true, 'Sender type is required']
  },
  message: {
    type: String,
    required: [true, 'Message is required'],
    minlength: [1, 'Message cannot be empty'],
    maxlength: [1000, 'Message cannot exceed 1000 characters'],
    trim: true
  },
  price: {
    type: Number,
    min: [0, 'Price must be at least 0'],
    max: [999999, 'Price cannot exceed 999,999'],
    default: null
  }
}, {
  timestamps: true
});

// Index for efficient queries
chatMessageSchema.index({ quickOrderId: 1, createdAt: 1 });
chatMessageSchema.index({ senderId: 1, createdAt: -1 });
chatMessageSchema.index({ quickOrderId: 1, senderId: 1 });

const ChatMessage = mongoose.model<IChatMessage>('ChatMessage', chatMessageSchema);

export default ChatMessage;
