import mongoose, { Schema, Document, Types } from 'mongoose';

export interface IProductLike extends Document {
  userId: Types.ObjectId;
  productId: Types.ObjectId;
  createdAt: Date;
}

const ProductLikeSchema: Schema = new Schema({
  userId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  productId: {
    type: Schema.Types.ObjectId,
    ref: 'Product',
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Compound unique index to ensure a user can like a product only once
ProductLikeSchema.index({ userId: 1, productId: 1 }, { unique: true });

// Index for efficient queries
ProductLikeSchema.index({ productId: 1 });
ProductLikeSchema.index({ userId: 1 });

export const ProductLike = mongoose.model<IProductLike>('ProductLike', ProductLikeSchema);
