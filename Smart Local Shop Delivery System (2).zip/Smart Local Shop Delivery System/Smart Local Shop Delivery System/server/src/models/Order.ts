import mongoose, { Document, Schema, Types } from 'mongoose';

export interface IOrderItem {
  product: Types.ObjectId; // Reference to Product
  quantity: number;
  price: number; // Price at time of order
  variant?: string; // Product variant if applicable
  notes?: string;
}

export interface IOrder extends Document<Types.ObjectId> {
  _id: Types.ObjectId;
  orderNumber: string;
  customer: Types.ObjectId; // Reference to User (CUSTOMER)
  vendor: Types.ObjectId; // Reference to User (VENDOR)
  items: IOrderItem[];
  status: 'PENDING' | 'CONFIRMED' | 'PREPARING' | 'READY_FOR_PICKUP' | 'OUT_FOR_DELIVERY' | 'DELIVERED' | 'CANCELLED' | 'REFUNDED' | 'PAID';
  deliveryStatus?: 'ASSIGNED' | 'PICKED_UP' | 'DELIVERED';
  priority: 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT';
  delivery: {
    address: {
      street: string;
      city: string;
      county: string;
      coordinates?: {
        latitude: number;
        longitude: number;
      };
      landmark?: string;
      instructions?: string;
    };
    estimatedTime: Date;
    actualTime?: Date;
    distance?: number; // in kilometers
    deliveryFee: number;
    tip?: number;
    deliveryAgent?: Types.ObjectId; // Reference to User (DELIVERY)
    // Real-time location tracking
    currentLocation?: {
      type: 'Point';
      coordinates: [number, number]; // [longitude, latitude]
    };
    lastLocationUpdate?: Date;
    locationHistory?: Array<{
      timestamp: Date;
      location: {
        type: 'Point';
        coordinates: [number, number];
      };
    }>;
  };
  pricing: {
    subtotal: number;
    deliveryFee: number;
    serviceFee: number;
    tax: number;
    discount?: number;
    total: number;
    currency: string;
  };
  payment: {
    method: 'MPESA' | 'CARD' | 'CASH' | 'BANK_TRANSFER';
    status: 'PENDING' | 'PAID' | 'FAILED' | 'REFUNDED' | 'PARTIALLY_REFUNDED';
    transactionId?: string;
    paidAt?: Date;
    refundAmount?: number;
    refundReason?: string;
  };
  deliveryRequired: boolean;
  deliveryOTP?: string;
  otpGeneratedAt?: Date;
  otpSent?: boolean;
  otpVerified?: boolean;
  timeline: Array<{
    status: string;
    timestamp: Date;
    note?: string;
    updatedBy?: Types.ObjectId;
  }>;
  notes?: string;
  specialInstructions?: string;
  estimatedDeliveryTime: Date;
  actualDeliveryTime?: Date;
  cancellationReason?: string;
  cancelledAt?: Date;
  cancelledBy?: Types.ObjectId;
  deliveryValidation?: {
    validated: boolean;
    match: boolean;
    confidence: number;
    reason: string;
    validatedAt: Date;
    deliveryImage?: string;
  };
  isWalletProcessed?: boolean; // Flag to prevent duplicate wallet updates
  createdAt: Date;
  updatedAt: Date;
}

const orderSchema = new Schema<IOrder>({
  orderNumber: {
    type: String,
    required: true,
    unique: true,
    default: function() {
      return 'ORD' + Date.now() + Math.random().toString(36).substr(2, 9).toUpperCase();
    }
  },
  customer: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Customer is required']
  },
  vendor: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Vendor is required']
  },
  items: [{
    product: {
      type: Schema.Types.ObjectId,
      ref: 'Product',
      required: [true, 'Product is required']
    },
    quantity: {
      type: Number,
      required: [true, 'Quantity is required'],
      min: [1, 'Quantity must be at least 1']
    },
    price: {
      type: Number,
      required: [true, 'Price is required'],
      min: [0, 'Price cannot be negative']
    },
    variant: String,
    notes: String
  }],
  status: {
    type: String,
    enum: ['PENDING', 'CONFIRMED', 'PREPARING', 'READY_FOR_PICKUP', 'OUT_FOR_DELIVERY', 'DELIVERED', 'CANCELLED', 'REFUNDED', 'PAID'],
    default: 'PENDING'
  },
  deliveryStatus: {
    type: String,
    enum: ['ASSIGNED', 'PICKED_UP', 'DELIVERED'],
    default: undefined
  },
  priority: {
    type: String,
    enum: ['LOW', 'NORMAL', 'HIGH', 'URGENT'],
    default: 'NORMAL'
  },
  delivery: {
    address: {
      street: {
        type: String,
        required: [true, 'Delivery street is required']
      },
      city: {
        type: String,
        required: false
      },
      county: {
        type: String,
        required: false
      },
      coordinates: {
        latitude: Number,
        longitude: Number
      },
      landmark: String,
      instructions: String
    },
    estimatedTime: {
      type: Date,
      required: [true, 'Estimated delivery time is required']
    },
    actualTime: Date,
    distance: {
      type: Number,
      min: [0, 'Distance cannot be negative']
    },
    deliveryFee: {
      type: Number,
      required: true,
      min: [0, 'Delivery fee cannot be negative']
    },
    tip: {
      type: Number,
      min: [0, 'Tip cannot be negative']
    },
    deliveryAgent: {
      type: Schema.Types.ObjectId,
      ref: 'User'
    },
    // Real-time location tracking
    currentLocation: {
      type: {
        type: String,
        enum: ['Point']
      },
      coordinates: {
        type: [Number],
        validate: {
          validator: function(coordinates: number[]) {
            if (!coordinates) return true; // Allow undefined for new orders
            return coordinates.length === 2 && 
                   coordinates[0] >= -180 && coordinates[0] <= 180 && // longitude
                   coordinates[1] >= -90 && coordinates[1] <= 90;     // latitude
          },
          message: 'Invalid coordinates. Must be [longitude, latitude]'
        }
      }
    },
    lastLocationUpdate: Date,
    locationHistory: [{
      timestamp: {
        type: Date,
        default: Date.now
      },
      location: {
        type: {
          type: String,
          enum: ['Point'],
          default: 'Point'
        },
        coordinates: {
          type: [Number],
          required: true,
          validate: {
            validator: function(coordinates: number[]) {
              return coordinates.length === 2 && 
                     coordinates[0] >= -180 && coordinates[0] <= 180 && // longitude
                     coordinates[1] >= -90 && coordinates[1] <= 90;     // latitude
            },
            message: 'Invalid coordinates. Must be [longitude, latitude]'
          }
        }
      }
    }]
  },
  pricing: {
    subtotal: {
      type: Number,
      required: true,
      min: [0, 'Subtotal cannot be negative']
    },
    deliveryFee: {
      type: Number,
      required: true,
      min: [0, 'Delivery fee cannot be negative']
    },
    serviceFee: {
      type: Number,
      required: true,
      min: [0, 'Service fee cannot be negative']
    },
    tax: {
      type: Number,
      required: true,
      min: [0, 'Tax cannot be negative']
    },
    discount: {
      type: Number,
      min: [0, 'Discount cannot be negative']
    },
    total: {
      type: Number,
      required: true,
      min: [0, 'Total cannot be negative']
    },
    currency: {
      type: String,
      required: true,
      default: 'ETB',
      enum: ['KES', 'USD', 'EUR', 'GBP', 'ETB']
    }
  },
  payment: {
    method: {
      type: String,
      enum: ['MPESA', 'CARD', 'CASH', 'BANK_TRANSFER'],
      required: [true, 'Payment method is required']
    },
    status: {
      type: String,
      enum: ['PENDING', 'PAID', 'FAILED', 'REFUNDED', 'PARTIALLY_REFUNDED'],
      default: 'PENDING'
    },
    transactionId: String,
    paidAt: Date,
    refundAmount: {
      type: Number,
      min: [0, 'Refund amount cannot be negative']
    },
    refundReason: String
  },
  deliveryRequired: {
    type: Boolean,
    required: true,
    default: false
  },
  deliveryOTP: String,
  otpGeneratedAt: Date,
  otpSent: {
    type: Boolean,
    default: false
  },
  otpVerified: {
    type: Boolean,
    default: false
  },
  timeline: [{
    status: String,
    timestamp: {
      type: Date,
      default: Date.now
    },
    note: String,
    updatedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User'
    }
  }],
  notes: String,
  specialInstructions: String,
  estimatedDeliveryTime: Date,
  actualDeliveryTime: Date,
  cancellationReason: String,
  cancelledAt: Date,
  cancelledBy: {
    type: Schema.Types.ObjectId,
    ref: 'User'
  },
  deliveryValidation: {
    validated: {
      type: Boolean,
      default: false
    },
    match: {
      type: Boolean,
      default: false
    },
    confidence: {
      type: Number,
      min: 0,
      max: 100,
      default: 0
    },
    reason: String,
    validatedAt: Date,
    deliveryImage: String
  },
  isWalletProcessed: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Indexes
orderSchema.index({ customer: 1 });
orderSchema.index({ vendor: 1 });
orderSchema.index({ status: 1 });
orderSchema.index({ createdAt: -1 });
orderSchema.index({ 'delivery.deliveryAgent': 1 });
orderSchema.index({ 'payment.status': 1 });

// 🔧 PERFORMANCE FIX: Compound indexes for common query patterns
orderSchema.index({ vendor: 1, createdAt: -1 }); // For vendor order lists with sorting
orderSchema.index({ customer: 1, createdAt: -1 }); // For customer order lists with sorting
orderSchema.index({ status: 1, createdAt: -1 }); // For status filtering with sorting
orderSchema.index({ vendor: 1, status: 1, createdAt: -1 }); // For vendor status filtering with sorting

// Virtual for order total items
orderSchema.virtual('totalItems').get(function(this: IOrder) {
  return this.items.reduce((total: number, item: IOrderItem) => total + item.quantity, 0);
});

// Virtual for order duration
orderSchema.virtual('deliveryDuration').get(function(this: IOrder) {
  if (this.actualDeliveryTime && this.createdAt) {
    return this.actualDeliveryTime.getTime() - this.createdAt.getTime();
  }
  return null;
});

// Pre-save middleware to add initial timeline entry
orderSchema.pre('save', function(next) {
  if (this.isNew) {
    this.timeline.push({
      status: this.status,
      timestamp: new Date(),
      note: 'Order created'
    });
  }
  next();
});

// Add GeoJSON index for location queries
orderSchema.index({ 'delivery.currentLocation': '2dsphere' });

const Order = mongoose.model<IOrder>('Order', orderSchema);

export default Order;
