import mongoose, { Document, Schema, Types } from 'mongoose';

export interface IUser extends Document<Types.ObjectId> {
  _id: Types.ObjectId;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  password: string;
  role: 'CUSTOMER' | 'VENDOR' | 'DELIVERY' | 'ADMIN';
  isCustomer: boolean;
  isVendor: boolean;
  isDelivery: boolean;
  isOnline: boolean;
  profileImage?: string;
  isEmailVerified: boolean;
  isPhoneVerified: boolean;
  isActive: boolean;
  status: 'active' | 'suspended' | 'banned';
  complaintCount: number;
  lastLogin?: Date;
  createdAt: Date;
  updatedAt: Date;
  
  // Bank information
  bankName?: string;
  accountNumber?: string;
  
  // Password reset fields
  passwordResetToken?: string;
  passwordResetExpires?: Date;
  passwordResetUsed?: boolean;
  passwordResetRequestedAt?: Date;
  
  // Vendor specific fields
  shopName?: string;
  shopDescription?: string;
  businessLicense?: string;
  shopCategory?: string;
  
  // Simple coordinates for easy access
  coordinates?: {
    lat: number;
    lng: number;
  };
  
  // GeoJSON format for MongoDB geospatial queries
  vendorLocation?: {
    type: string;
    coordinates: [number, number]; // [longitude, latitude]
  };
  
  // Delivery agent specific fields
  vehicleType?: 'BICYCLE' | 'MOTORCYCLE' | 'CAR' | 'VAN';
  vehicleNumber?: string;
  idNumber?: string;
  isAvailable?: boolean;
  deliveryRadius?: number;
  averageRating?: number;
  totalDeliveries?: number;
  
  // Customer specific fields
  defaultAddress?: {
    coordinates?: {
      lat: number;
      lng: number;
    };
  };
  
  // Location tracking for dynamic updates
  lastLocationUpdate?: Date;
  locationHistory?: Array<{
    timestamp: Date;
    coordinates: {
      lat: number;
      lng: number;
    };
  }>;
  preferences?: {
    notifications: boolean;
    emailUpdates: boolean;
    smsUpdates: boolean;
  };
}

const userSchema = new Schema<IUser>({
  firstName: {
    type: String,
    required: [true, 'First name is required'],
    trim: true,
    maxlength: [50, 'First name cannot exceed 50 characters']
  },
  lastName: {
    type: String,
    required: [true, 'Last name is required'],
    trim: true,
    maxlength: [50, 'Last name cannot exceed 50 characters']
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    lowercase: true,
    trim: true,
    match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please enter a valid email']
  },
  phone: {
    type: String,
    required: [true, 'Phone number is required'],
    unique: true,
    match: [/^(?:\+251|0)?[97]\d{8}$/, 'Please enter a valid Ethiopian phone number']
  },
  password: {
    type: String,
    required: [true, 'Password is required'],
    minlength: [8, 'Password must be at least 8 characters long'],
    select: false
  },
  bankName: {
    type: String,
    required: [true, 'Bank name is required'],
    enum: {
      values: ['Commercial Bank of Ethiopia', 'Bank of Abyssinia', 'Awash Bank', 'Cooperative Bank of Oromia'],
      message: 'Please select a valid bank from the list'
    }
  },
  accountNumber: {
    type: String,
    required: [true, 'Account number is required'],
    match: [/^\d+$/, 'Account number can only contain numbers']
  },
  role: {
    type: String,
    enum: ['CUSTOMER', 'VENDOR', 'DELIVERY', 'ADMIN'],
    default: 'VENDOR',
    required: true
  },
  isCustomer: {
    type: Boolean,
    default: false,
    required: true
  },
  isVendor: {
    type: Boolean,
    default: true,
    required: true
  },
  isDelivery: {
    type: Boolean,
    default: false,
    required: true
  },
  profileImage: {
    type: String,
    default: ''
  },
  isEmailVerified: {
    type: Boolean,
    default: false
  },
  isPhoneVerified: {
    type: Boolean,
    default: false
  },
  isActive: {
    type: Boolean,
    default: true
  },
  status: {
    type: String,
    enum: ['active', 'suspended', 'banned'],
    default: 'active'
  },
  complaintCount: {
    type: Number,
    default: 0
  },
  lastLogin: Date,
  
  // Password reset fields
  passwordResetToken: String,
  passwordResetExpires: Date,
  passwordResetUsed: Boolean,
  passwordResetRequestedAt: Date,
  
  // Vendor specific fields
  shopName: String,
  shopDescription: {
    type: String,
    maxlength: [500, 'Shop description cannot exceed 500 characters']
  },
  businessLicense: String,
  shopCategory: String,
  
  // Simple coordinates for easy access
  coordinates: {
    lat: {
      type: Number,
      required: false,
      validate: {
        validator: (v: number) => v >= -90 && v <= 90,
        message: 'Latitude must be between -90 and 90'
      }
    },
    lng: {
      type: Number,
      required: false,
      validate: {
        validator: (v: number) => v >= -180 && v <= 180,
        message: 'Longitude must be between -180 and 180'
      }
    }
  },
  
  // GeoJSON format for MongoDB geospatial queries
  vendorLocation: {
    type: {
      type: String,
      enum: ['Point'],
      default: 'Point'
    },
    coordinates: {
      type: [Number], // [lng, lat]
      required: false,
      validate: {
        validator: (v: number[]) => v.length === 2,
        message: 'Coordinates must be [longitude, latitude]'
      }
    }
  },
  
  // Delivery agent specific fields
  vehicleType: {
    type: String,
    enum: ['BICYCLE', 'MOTORCYCLE', 'CAR', 'VAN']
  },
  vehicleNumber: String,
  idNumber: String,
  isAvailable: {
    type: Boolean,
    default: false
  },
  deliveryRadius: {
    type: Number,
    default: 10 // kilometers
  },
  averageRating: {
    type: Number,
    default: 0,
    min: 0,
    max: 5
  },
  totalDeliveries: {
    type: Number,
    default: 0
  },
  
  // Customer specific fields
  defaultAddress: {
    coordinates: {
      lat: Number,
      lng: Number
    }
  },
  
  // Location tracking for dynamic updates
  lastLocationUpdate: Date,
  locationHistory: [{
    timestamp: {
      type: Date,
      default: Date.now
    },
    coordinates: {
      lat: Number,
      lng: Number
    }
  }],
  preferences: {
    notifications: {
      type: Boolean,
      default: true
    },
    emailUpdates: {
      type: Boolean,
      default: true
    },
    smsUpdates: {
      type: Boolean,
      default: false
    }
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Indexes
userSchema.index({ role: 1 });
userSchema.index({ isCustomer: 1 });
userSchema.index({ isVendor: 1 });
userSchema.index({ 'coordinates.lat': 1, 'coordinates.lng': 1 }); // For coordinate queries
userSchema.index({ vendorLocation: '2dsphere' }); // For geospatial queries

// Performance indexes for admin user management
userSchema.index({ role: 1, createdAt: -1 }); // For role-based queries with sorting
userSchema.index({ firstName: 'text', lastName: 'text', email: 'text' }); // For text search
userSchema.index({ createdAt: -1 }); // For sorting by creation date
userSchema.index({ isActive: 1 }); // For active/inactive filtering

// Pre-save middleware to sync coordinates and vendorLocation fields
userSchema.pre('save', function(next) {
  const user = this as any;
  
  // If coordinates exist, ensure vendorLocation field is synced
  if (user.coordinates && user.coordinates.lat !== undefined && user.coordinates.lng !== undefined) {
    user.vendorLocation = {
      type: 'Point',
      coordinates: [user.coordinates.lng, user.coordinates.lat]
    };
  }
  
  // If vendorLocation exists but coordinates don't, sync from vendorLocation
  if (user.vendorLocation && user.vendorLocation.coordinates && (!user.coordinates || user.coordinates.lat === undefined || user.coordinates.lng === undefined)) {
    user.coordinates = {
      lat: user.vendorLocation.coordinates[1],
      lng: user.vendorLocation.coordinates[0]
    };
  }
  
  // Remove incomplete vendorLocation field
  if (user.vendorLocation && !user.vendorLocation.coordinates) {
    user.vendorLocation = undefined;
  }
  
  next();
});

// Virtual for full name
userSchema.virtual('fullName').get(function(this: IUser) {
  return `${this.firstName} ${this.lastName}`;
});

// Pre-save middleware for password hashing and role-based boolean fields
userSchema.pre('save', async function(next) {
  const user = this as any;
  
  // Only hash the password if it has been modified (or is new)
  if (!user.isModified('password')) return next();
  
  // Hash password with cost of 12
  const bcrypt = require('bcryptjs');
  user.password = await bcrypt.hash(user.password, 12);
  
  // Set boolean fields based on role
  if (user.isModified('role') || user.isNew) {
    user.isCustomer = user.role === 'CUSTOMER' || user.role === 'ADMIN';
    user.isVendor = user.role === 'VENDOR' || user.role === 'ADMIN';
  }
  
  next();
});

const User = mongoose.model<IUser>('User', userSchema);

export default User;
