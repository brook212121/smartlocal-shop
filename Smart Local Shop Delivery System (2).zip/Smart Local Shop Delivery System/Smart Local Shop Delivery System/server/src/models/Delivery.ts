import mongoose, { Document, Schema, Types } from 'mongoose';

export interface IDelivery extends Document<Types.ObjectId> {
  _id: Types.ObjectId;
  order: Types.ObjectId; // Reference to Order
  deliveryAgent: Types.ObjectId; // Reference to User (DELIVERY)
  vendor: Types.ObjectId; // Reference to User (VENDOR)
  customer: Types.ObjectId; // Reference to User (CUSTOMER)
  status: 'ASSIGNED' | 'ACCEPTED' | 'PICKED_UP' | 'IN_TRANSIT' | 'DELIVERED' | 'FAILED' | 'CANCELLED';
  priority: 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT';
  route: {
    pickup: {
      address: {
        street: string;
        city: string;
        county: string;
        coordinates: {
          latitude: number;
          longitude: number;
        };
      };
      contactPerson: string;
      contactPhone: string;
      pickupInstructions?: string;
      estimatedPickupTime: Date;
      actualPickupTime?: Date;
    };
    delivery: {
      address: {
        street: string;
        city: string;
        county: string;
        coordinates: {
          latitude: number;
          longitude: number;
        };
        landmark?: string;
      };
      contactPerson: string;
      contactPhone: string;
      deliveryInstructions?: string;
      estimatedDeliveryTime: Date;
      actualDeliveryTime?: Date;
    };
    waypoints?: Array<{
      address: string;
      coordinates: {
        latitude: number;
        longitude: number;
      };
      estimatedArrival: Date;
      actualArrival?: Date;
    }>;
  };
  tracking: {
    currentLocation?: {
      latitude: number;
      longitude: number;
      timestamp: Date;
    };
    locationHistory: Array<{
      latitude: number;
      longitude: number;
      timestamp: Date;
      speed?: number;
      heading?: number;
    }>;
    estimatedArrivalTime: Date;
    distance: {
      total: number; // Total distance in km
      traveled: number; // Distance traveled in km
      remaining: number; // Remaining distance in km
    };
    duration: {
      estimated: number; // Estimated duration in minutes
      elapsed: number; // Elapsed time in minutes
      remaining: number; // Remaining time in minutes
    };
  };
  payment: {
    deliveryFee: number;
    tip?: number;
    commission: number;
    totalEarnings: number;
    paymentStatus: 'PENDING' | 'PAID' | 'FAILED';
    paidAt?: Date;
  };
  verification: {
    pickupPhoto?: string;
    deliveryPhoto?: string;
    customerSignature?: string;
    notes?: string;
    verifiedAt?: Date;
  };
  issues: Array<{
    type: 'TRAFFIC' | 'ADDRESS_NOT_FOUND' | 'CUSTOMER_UNAVAILABLE' | 'WEATHER' | 'VEHICLE_BREAKDOWN' | 'OTHER';
    description: string;
    reportedAt: Date;
    resolvedAt?: Date;
    resolution?: string;
  }>;
  rating: {
    customerRating?: number; // 1-5 stars
    customerReview?: string;
    vendorRating?: number; // 1-5 stars
    vendorReview?: string;
    platformRating?: number; // Internal performance rating
    ratedAt?: Date;
  };
  metadata: {
    vehicleType: 'BICYCLE' | 'MOTORCYCLE' | 'CAR' | 'VAN';
    vehicleNumber: string;
    weatherConditions?: string;
    trafficConditions?: string;
    deliveryRadius: number;
    estimatedTime: number; // minutes
    actualTime?: number; // minutes
  };
  timeline: Array<{
    status: string;
    timestamp: Date;
    location?: {
      latitude: number;
      longitude: number;
    };
    note?: string;
    updatedBy?: Types.ObjectId;
  }>;
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

const deliverySchema = new Schema<IDelivery>({
  order: {
    type: Schema.Types.ObjectId,
    ref: 'Order',
    required: [true, 'Order is required'],
    unique: true
  },
  deliveryAgent: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Delivery agent is required']
  },
  vendor: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Vendor is required']
  },
  customer: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Customer is required']
  },
  status: {
    type: String,
    enum: ['ASSIGNED', 'ACCEPTED', 'PICKED_UP', 'IN_TRANSIT', 'DELIVERED', 'FAILED', 'CANCELLED'],
    default: 'ASSIGNED'
  },
  priority: {
    type: String,
    enum: ['LOW', 'NORMAL', 'HIGH', 'URGENT'],
    default: 'NORMAL'
  },
  route: {
    pickup: {
      address: {
        street: {
          type: String,
          required: [true, 'Pickup street is required']
        },
        city: {
          type: String,
          required: [true, 'Pickup city is required']
        },
        county: {
          type: String,
          required: [true, 'Pickup county is required']
        },
        coordinates: {
          latitude: {
            type: Number,
            required: [true, 'Pickup latitude is required']
          },
          longitude: {
            type: Number,
            required: [true, 'Pickup longitude is required']
          }
        },
        landmark: String,
        pickupInstructions: String,
        estimatedPickupTime: {
          type: Date,
          required: [true, 'Estimated pickup time is required']
        },
        actualPickupTime: Date
      },
      delivery: {
        address: {
          street: {
            type: String,
            required: [true, 'Delivery street is required']
          },
          city: {
            type: String,
            required: [true, 'Delivery city is required']
          },
          county: {
            type: String,
            required: [true, 'Delivery county is required']
          },
          coordinates: {
            latitude: {
              type: Number,
              required: [true, 'Delivery latitude is required']
            },
            longitude: {
              type: Number,
              required: [true, 'Delivery longitude is required']
            }
          },
          landmark: String,
          deliveryInstructions: String
        },
        contactPerson: {
          type: String,
          required: [true, 'Delivery contact person is required']
        },
        contactPhone: {
          type: String,
          required: [true, 'Delivery contact phone is required']
        },
        deliveryInstructions: String,
        estimatedDeliveryTime: {
          type: Date,
          required: [true, 'Estimated delivery time is required']
        },
        actualDeliveryTime: Date
      },
      waypoints: [{
        address: String,
        coordinates: {
          latitude: {
            type: Number,
            required: [true, 'Waypoint latitude is required']
          },
          longitude: {
            type: Number,
            required: [true, 'Waypoint longitude is required']
          }
        },
        estimatedArrival: Date,
        actualArrival: Date
      }]
    }
  },
  tracking: {
    currentLocation: {
      latitude: Number,
      longitude: Number,
      timestamp: Date
    },
    locationHistory: [{
      latitude: {
        type: Number,
        required: [true, 'Location latitude is required']
      },
      longitude: {
        type: Number,
        required: [true, 'Location longitude is required']
      },
      timestamp: {
        type: Date,
        default: Date.now
      },
      speed: Number,
      heading: Number
    }],
    estimatedArrivalTime: {
      type: Date,
      required: [true, 'Estimated arrival time is required']
    },
    distance: {
      total: {
        type: Number,
        required: true,
        min: [0, 'Total distance cannot be negative']
      },
      traveled: {
        type: Number,
        default: 0,
        min: [0, 'Traveled distance cannot be negative']
      },
      remaining: {
        type: Number,
        required: true,
        min: [0, 'Remaining distance cannot be negative']
      }
    },
    duration: {
      estimated: {
        type: Number,
        required: true,
        min: [0, 'Estimated duration cannot be negative']
      },
      elapsed: {
        type: Number,
        default: 0,
        min: [0, 'Elapsed duration cannot be negative']
      },
      remaining: {
        type: Number,
        required: true,
        min: [0, 'Remaining duration cannot be negative']
      }
    }
  },
  payment: {
    deliveryFee: {
      type: Number,
      required: true,
      min: [0, 'Delivery fee cannot be negative']
    },
    tip: {
      type: Number,
      min: [0, 'Tip cannot be negative']
    },
    commission: {
      type: Number,
      required: true,
      min: [0, 'Commission cannot be negative']
    },
    totalEarnings: {
      type: Number,
      required: true,
      min: [0, 'Total earnings cannot be negative']
    },
    paymentStatus: {
      type: String,
      enum: ['PENDING', 'PAID', 'FAILED'],
      default: 'PENDING'
    },
    paidAt: Date
  },
  verification: {
    pickupPhoto: String,
    deliveryPhoto: String,
    customerSignature: String,
    notes: String,
    verifiedAt: Date
  },
  issues: [{
    type: {
      type: String,
      enum: ['TRAFFIC', 'ADDRESS_NOT_FOUND', 'CUSTOMER_UNAVAILABLE', 'WEATHER', 'VEHICLE_BREAKDOWN', 'OTHER'],
      required: [true, 'Issue type is required']
    },
    description: {
      type: String,
      required: [true, 'Issue description is required']
    },
    reportedAt: {
      type: Date,
      default: Date.now
    },
    resolvedAt: Date,
    resolution: String
  }],
  rating: {
    customerRating: {
      type: Number,
      min: [1, 'Customer rating must be at least 1'],
      max: [5, 'Customer rating cannot exceed 5']
    },
    customerReview: String,
    vendorRating: {
      type: Number,
      min: [1, 'Vendor rating must be at least 1'],
      max: [5, 'Vendor rating cannot exceed 5']
    },
    vendorReview: String,
    platformRating: {
      type: Number,
      min: [1, 'Platform rating must be at least 1'],
      max: [5, 'Platform rating cannot exceed 5']
    },
    ratedAt: Date
  },
  metadata: {
    vehicleType: {
      type: String,
      enum: ['BICYCLE', 'MOTORCYCLE', 'CAR', 'VAN'],
      required: [true, 'Vehicle type is required']
    },
    vehicleNumber: {
      type: String,
      required: [true, 'Vehicle number is required']
    },
    weatherConditions: String,
    trafficConditions: String,
    deliveryRadius: {
      type: Number,
      required: true,
      min: [0, 'Delivery radius cannot be negative']
    },
    estimatedTime: {
      type: Number,
      required: true,
      min: [0, 'Estimated time cannot be negative']
    },
    actualTime: {
      type: Number,
      min: [0, 'Actual time cannot be negative']
    }
  },
  timeline: [{
    status: String,
    timestamp: {
      type: Date,
      default: Date.now
    },
    location: {
      latitude: Number,
      longitude: Number
    },
    note: String,
    updatedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User'
    }
  }],
  notes: String
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Indexes
deliverySchema.index({ order: 1 });
deliverySchema.index({ deliveryAgent: 1 });
deliverySchema.index({ vendor: 1 });
deliverySchema.index({ customer: 1 });
deliverySchema.index({ status: 1 });
deliverySchema.index({ createdAt: -1 });
deliverySchema.index({ 'tracking.currentLocation': '2dsphere' });

// Virtual for delivery progress percentage
deliverySchema.virtual('progressPercentage').get(function(this: IDelivery) {
  if (this.tracking.distance.total > 0) {
    return (this.tracking.distance.traveled / this.tracking.distance.total) * 100;
  }
  return 0;
});

// Virtual for on-time status
deliverySchema.virtual('isOnTime').get(function(this: IDelivery) {
  if (this.route.delivery.actualDeliveryTime && this.route.delivery.estimatedDeliveryTime) {
    return this.route.delivery.actualDeliveryTime <= this.route.delivery.estimatedDeliveryTime;
  }
  return null;
});

const Delivery = mongoose.model<IDelivery>('Delivery', deliverySchema);

export default Delivery;
