import mongoose, { Schema, Document } from 'mongoose';

export interface IQuickOrder extends Document {
  customerId: mongoose.Types.ObjectId;
  assignedVendorId?: mongoose.Types.ObjectId;
  assignmentDistance?: number;
  description: string;
  image?: string;
  quantity?: number;
  status: 'OPEN' | 'CLOSED' | 'FULFILLED';
  createdAt: Date;
  updatedAt: Date;
}

const quickOrderSchema = new Schema<IQuickOrder>({
  customerId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Customer ID is required']
  },
  assignedVendorId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  assignmentDistance: {
    type: Number,
    default: null
  },
  description: {
    type: String,
    required: [true, 'Description is required'],
    minlength: [5, 'Description must be at least 5 characters long'],
    maxlength: [500, 'Description cannot exceed 500 characters'],
    trim: true
  },
  image: {
    type: String,
    default: null
  },
  quantity: {
    type: Number,
    min: [1, 'Quantity must be at least 1'],
    max: [999, 'Quantity cannot exceed 999'],
    default: null
  },
  status: {
    type: String,
    enum: ['OPEN', 'CLOSED', 'FULFILLED'],
    default: 'OPEN'
  }
}, {
  timestamps: true
});

// Index for efficient queries
quickOrderSchema.index({ customerId: 1, createdAt: -1 });
quickOrderSchema.index({ status: 1, createdAt: -1 });
quickOrderSchema.index({ assignedVendorId: 1, status: 1, createdAt: -1 });

const QuickOrder = mongoose.model<IQuickOrder>('QuickOrder', quickOrderSchema);

export default QuickOrder;
