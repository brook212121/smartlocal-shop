import mongoose, { Schema, Document } from 'mongoose';

export interface IUserActivity extends Document {
  userId: mongoose.Types.ObjectId;
  productId: mongoose.Types.ObjectId;
  productName: string;
  category: string;
  shopId: mongoose.Types.ObjectId;
  action: 'search_product' | 'view_product' | 'like_product' | 'add_to_cart' | 'place_order' | 'view_category';
  keyword?: string;
  viewDuration?: number;
  createdAt: Date;
}

const UserActivitySchema: Schema = new Schema({
  userId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  productId: {
    type: Schema.Types.ObjectId,
    ref: 'Product',
    required: false,
    index: true
  },
  productName: {
    type: String,
    required: false,
    trim: true
  },
  category: {
    type: String,
    required: false,
    trim: true,
    index: true
  },
  shopId: {
    type: Schema.Types.ObjectId,
    ref: 'Vendor',
    required: false,
    index: true
  },
  action: {
    type: String,
    required: true,
    enum: ['search_product', 'view_product', 'like_product', 'add_to_cart', 'place_order', 'view_category'],
    index: true
  },
  keyword: {
    type: String,
    required: false,
    trim: true
  },
  viewDuration: {
    type: Number,
    required: false,
    min: 0
  }
}, {
  timestamps: true,
  collection: 'user_activities'
});

// Compound indexes for better query performance
UserActivitySchema.index({ userId: 1, action: 1, createdAt: -1 });
UserActivitySchema.index({ userId: 1, productId: 1, action: 1 });
UserActivitySchema.index({ userId: 1, category: 1, createdAt: -1 });

export const UserActivity = mongoose.model<IUserActivity>('UserActivity', UserActivitySchema);
