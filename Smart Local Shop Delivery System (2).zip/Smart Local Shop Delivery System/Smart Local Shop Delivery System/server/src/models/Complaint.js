const mongoose = require('mongoose');

const complaintSchema = new mongoose.Schema({
  orderId: {
    type: String,
    required: true,
    trim: true
  },
  vendorId: {
    type: String,
    required: true,
    trim: true
  },
  productName: {
    type: String,
    required: true,
    trim: true
  },
  originalProductImage: {
    type: String,
    required: true,
    trim: true
  },
  deliveryPhoto: {
    type: String,
    required: true,
    trim: true
  },
  confidence: {
    type: Number,
    required: true,
    min: 0,
    max: 100
  },
  rejectionMessage: {
    type: String,
    required: true,
    trim: true
  },
  status: {
    type: String,
    enum: ['pending', 'under_review', 'resolved', 'dismissed'],
    default: 'resolved' // Auto-resolved since system is fully automated
  },
  // Vendor notification fields
  customerName: {
    type: String,
    trim: true
  },
  customerPhone: {
    type: String,
    trim: true
  },
  isRead: {
    type: Boolean,
    default: false
  },
  actionTaken: {
    type: String,
    enum: ['none', 'warning', 'suspended', 'banned'],
    default: 'none'
  },
  complaintCount: {
    type: Number,
    default: 0
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Complaint', complaintSchema);
