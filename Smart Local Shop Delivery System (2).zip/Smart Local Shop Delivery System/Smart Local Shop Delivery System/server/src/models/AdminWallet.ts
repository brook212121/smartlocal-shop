import mongoose, { Schema, Document } from 'mongoose';

export interface IAdminWallet extends Document {
  _id: mongoose.Types.ObjectId;
  totalBalance: number;
  totalReceived: number;
  totalPaidOut: number;
  pendingPayouts: number;
  lastUpdated: Date;
  transactionHistory: Array<{
    type: 'PAYMENT_RECEIVED' | 'VENDOR_WITHDRAWAL' | 'SYSTEM_FEE' | 'REFUND';
    amount: number;
    description: string;
    referenceId?: string; // Order ID or Withdrawal ID
    vendorId?: mongoose.Types.ObjectId;
    createdAt: Date;
  }>;
}

const adminWalletSchema = new Schema<IAdminWallet>({
  totalBalance: {
    type: Number,
    default: 0,
    min: 0
  },
  totalReceived: {
    type: Number,
    default: 0,
    min: 0
  },
  totalPaidOut: {
    type: Number,
    default: 0,
    min: 0
  },
  pendingPayouts: {
    type: Number,
    default: 0,
    min: 0
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  },
  transactionHistory: [{
    type: {
      type: String,
      enum: ['PAYMENT_RECEIVED', 'VENDOR_WITHDRAWAL', 'SYSTEM_FEE', 'REFUND'],
      required: true
    },
    amount: {
      type: Number,
      required: true,
      min: 0
    },
    description: {
      type: String,
      required: true
    },
    referenceId: {
      type: String
    },
    vendorId: {
      type: Schema.Types.ObjectId,
      ref: 'User'
    },
    createdAt: {
      type: Date,
      default: Date.now
    }
  }]
}, {
  timestamps: true
});

// Indexes for efficient queries
adminWalletSchema.index({ 'transactionHistory.createdAt': -1 });
adminWalletSchema.index({ 'transactionHistory.type': 1 });

const AdminWallet = mongoose.model<IAdminWallet>('AdminWallet', adminWalletSchema);

export default AdminWallet;
