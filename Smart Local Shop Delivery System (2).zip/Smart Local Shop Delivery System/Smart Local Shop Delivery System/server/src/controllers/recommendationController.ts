import { Request, Response, NextFunction } from 'express';
import Product, { IProduct } from '../models/Product';
import mongoose from 'mongoose';
import axios from 'axios';

interface RecommendationRequest {
  userId: string;
  location?: {
    latitude: number;
    longitude: number;
  };
  radius?: number; // in kilometers
  limit?: number; // maximum number of products
}

interface MLServiceResponse {
  recommended: string[];
  nearby: string[];
  trending: string[];
  similar: string[];
}

export const getRecommendations = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = (req as any).user?.id;
    
    if (!userId) {
      res.status(401).json({ 
        success: false, 
        message: 'User authentication required' 
      });
      return;
    }

    const { location, radius = 10, limit = 50 } = req.body as RecommendationRequest;

    console.log('🔍 Getting recommendations for user:', userId, 'location:', location);

    // Get nearby products using geospatial query (direct from database)
    let nearbyProducts: any[] = [];
    if (location) {
      try {
        nearbyProducts = await getNearbyProducts(location, radius, limit);
        console.log('🔍 Found nearby products:', nearbyProducts.length);
      } catch (error) {
        console.error('Error getting nearby products:', error);
      }
    }

    // Try to get other recommendations from ML service
    let mlResponse: MLServiceResponse;
    try {
      const mlServiceUrl = process.env.ML_SERVICE_URL || 'http://localhost:8000';
      console.log('🔍 Calling ML service at:', mlServiceUrl);
      
      const response = await axios.post(`${mlServiceUrl}/recommend`, {
        userId,
        location
      }, {
        timeout: 3000, // 3 second timeout
        headers: {
          'Content-Type': 'application/json'
        }
      });
      mlResponse = response.data;
      console.log('🔍 ML service response:', mlResponse);
    } catch (error: any) {
      console.error('❌ ML service error:', error.message);
      // Fallback to empty recommendations if ML service is unavailable
      mlResponse = {
        recommended: [],
        nearby: [], // We'll use our geospatial results instead
        trending: [],
        similar: []
      };
    }

    // Fetch full product data for ML service recommendations (excluding nearby)
    const allProductIds = [
      ...mlResponse.recommended,
      ...mlResponse.trending,
      ...mlResponse.similar
    ].filter((id, index, arr) => arr.indexOf(id) === index); // Remove duplicates

    let mlProducts: any[] = [];
    if (allProductIds.length > 0) {
      try {
        const productObjects = allProductIds.map(id => new mongoose.Types.ObjectId(id));
        mlProducts = await Product.find({
          _id: { $in: productObjects },
          isActive: true
        }).populate('vendor', 'firstName lastName email businessName shopName shopAddress shopCategory rating')
          .lean();
      } catch (error) {
        console.error('Error fetching ML products:', error);
      }
    }

    // Helper function to get products by IDs
    const getProductsByIds = (ids: string[]) => {
      return mlProducts.filter((product: IProduct) => 
        ids.includes(product._id.toString())
      );
    };

    // Build response with full product data
    const response = {
      success: true,
      data: {
        recommended: getProductsByIds(mlResponse.recommended),
        nearby: nearbyProducts, // Use our geospatial results
        trending: getProductsByIds(mlResponse.trending),
        similar: getProductsByIds(mlResponse.similar)
      },
      metadata: {
        nearbyCount: nearbyProducts.length,
        mlServiceAvailable: mlResponse.recommended.length > 0 || mlResponse.trending.length > 0
      }
    };

    console.log('✅ Sending recommendations response:', {
      nearby: response.data.nearby.length,
      recommended: response.data.recommended.length,
      trending: response.data.trending.length,
      similar: response.data.similar.length
    });

    res.status(200).json(response);

  } catch (error) {
    console.error('❌ Error getting recommendations:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Internal server error' 
    });
  }
};

// Get nearby products using geospatial query
const getNearbyProducts = async (location: { latitude: number; longitude: number }, radiusKm: number = 10, limit: number = 50) => {
  console.log('🌍 NEARBY PRODUCTS REQUEST:');
  console.log('� User Location:', location);
  console.log('📍 Search Radius:', radiusKm, 'km');
  console.log('📍 Radius in Meters:', radiusKm * 1000);
  
  try {
    console.log('🔍 STARTING GEOSPATIAL QUERY...');
    
    const radiusInMeters = radiusKm * 1000;
    console.log('🔍 GEOSPATIAL PARAMETERS:');
    console.log('📍 Near Point:', {
      type: 'Point',
      coordinates: [location.longitude, location.latitude]
    });
    console.log('📍 Distance Field:', 'distance');
    console.log('📍 Max Distance:', radiusInMeters, 'meters');
    console.log('📍 Spherical:', true);
    console.log('📍 Key Field:', 'vendorLocation');

    const pipeline: any[] = [
      {
        $geoNear: {
          near: {
            type: 'Point',
            coordinates: [location.longitude, location.latitude]
          },
          distanceField: 'distance',
          maxDistance: radiusInMeters,
          spherical: true,
          key: 'vendorLocation',
          query: {
            isActive: true,
            isVendor: true,
            'vendorLocation.coordinates': { 
              $exists: true,
              $not: { $size: 0 }
            }
          }
        }
      },
      {
        $project: {
          _id: 1,
          firstName: 1,
          lastName: 1,
          email: 1,
          businessName: 1,
          coordinates: 1,
          vendorLocation: 1,
          distance: 1
        }
      },
      {
        $sort: {
          distance: 1,
          'rating.average': -1
        }
      },
      {
        $limit: 50
      }
    ];

    console.log('🔍 EXECUTING MONGODB AGGREGATION...');
    console.log('📊 Pipeline:', JSON.stringify(pipeline, null, 2));

    // Get nearby vendors with proper error handling
    const nearbyVendors = await mongoose.connection.db!.collection('users').aggregate(pipeline).toArray();
    console.log('✅ FOUND NEARBY VENDORS:');
    console.log('📊 Total Vendors Found:', nearbyVendors.length);
    console.log('📊 Raw Vendor Data:', nearbyVendors);

    if (nearbyVendors.length === 0) {
      console.log('ℹ️ NO NEARBY VENDORS FOUND');
      console.log('🔍 Possible Reasons:');
      console.log('   - No vendors within radius');
      console.log('   - Vendors missing coordinates');
      console.log('   - Geospatial index issues');
      return [];
    }

    console.log('🔍 VALIDATING VENDOR COORDINATES...');
    console.log('📊 Validation Criteria:');
    console.log('   - vendorLocation exists');
    console.log('   - vendorLocation.coordinates exists');
    console.log('   - coordinates is array');
    console.log('   - coordinates.length === 2');

    // Validate vendor coordinates
    const validVendors = nearbyVendors.filter(vendor => {
      const isValid = vendor.vendorLocation && 
                     vendor.vendorLocation.coordinates && 
                     Array.isArray(vendor.vendorLocation.coordinates) && 
                     vendor.vendorLocation.coordinates.length === 2;
      
      if (!isValid) {
        console.log('❌ INVALID VENDOR:', {
          id: vendor._id,
          name: vendor.businessName || vendor.firstName,
          vendorLocation: vendor.vendorLocation,
          coordinates: vendor.vendorLocation?.coordinates
        });
      }
      
      return isValid;
    });

    console.log('✅ VALID VENDORS WITH COORDINATES:', validVendors.length);
    console.log('🔍 DETAILED VENDOR INFO:');
    validVendors.forEach((vendor, index) => {
      console.log(`📦 Vendor ${index + 1}:`);
      console.log('   ID:', vendor._id);
      console.log('   Name:', vendor.businessName || vendor.firstName);
      console.log('   Email:', vendor.email);
      console.log('   Old Coordinates:', vendor.coordinates);
      console.log('   VendorLocation:', vendor.vendorLocation);
      console.log('   Distance:', vendor.distance, 'meters');
      console.log('   Distance (km):', (vendor.distance / 1000).toFixed(2), 'km');
      console.log('   Coordinates Type:', typeof vendor.vendorLocation?.coordinates);
      console.log('   Coordinates Array:', Array.isArray(vendor.vendorLocation?.coordinates));
      console.log('   ---');
    });

    if (validVendors.length === 0) {
      console.log('⚠️ No vendors with valid coordinates found');
      return [];
    }

    // Get vendor IDs from valid vendors only
    const vendorIds = validVendors.map(vendor => vendor._id);
    console.log('🔍 VENDOR IDs FOR PRODUCT QUERY:');
    console.log('📊 Vendor IDs:', vendorIds.map(id => ({ id: id.toString(), type: typeof id })));
    console.log('📊 Total Vendor IDs:', vendorIds.length);

    console.log('🔍 STARTING PRODUCT QUERY...');
    console.log('📊 Query Parameters:');
    console.log('   - vendor: { $in: vendorIds }');
    console.log('   - isActive: true');
    console.log('📊 Selected Fields:', 'name price description images vendor category stock rating createdAt updatedAt');
    console.log('📊 Populate Fields:', 'firstName lastName businessName coordinates vendorLocation rating');

    // Optimized product query with proper indexing
    const products = await Product.find({
      vendor: { $in: vendorIds },
      isActive: true
      // Temporarily removed stock filters for debugging
      // 'stock.isActive': true,
      // 'stock.quantity': { $gt: 0 }
    })
    .select('name price description images vendor category stock rating createdAt updatedAt')
    .populate('vendor', 'firstName lastName businessName coordinates vendorLocation rating')
    .lean();

    console.log('✅ FOUND PRODUCTS FROM NEARBY VENDORS:');
    console.log('📊 Total Products Found:', products.length);
    console.log('📊 Raw Product Data:', products);
    
    // Log product vendor IDs for debugging
    if (products.length > 0) {
      console.log('🔍 DETAILED PRODUCT ANALYSIS:');
      products.forEach((product, index) => {
        console.log(`📦 Product ${index + 1}:`);
        console.log('   Product ID:', product._id);
        console.log('   Product Name:', product.name);
        console.log('   Price:', product.price);
        console.log('   Category:', product.category);
        console.log('   Vendor ID:', (product.vendor as any)._id);
        console.log('   Vendor ID Type:', typeof (product.vendor as any)._id);
        console.log('   Vendor Name:', (product.vendor as any).businessName || `${(product.vendor as any).firstName} ${(product.vendor as any).lastName}`);
        console.log('   Vendor Coordinates:', (product.vendor as any).coordinates);
        console.log('   Vendor Location:', (product.vendor as any).vendorLocation);
        console.log('   Vendor Rating:', (product.vendor as any).rating);
        console.log('   ---');
      });
    } else {
      console.log('🔍 NO PRODUCTS FOUND - DEBUGGING...');
      console.log('🔍 Possible Reasons:');
      console.log('   - No products from nearby vendors');
      console.log('   - Vendor ID mismatch');
      console.log('   - Product inactive status');
      
      console.log('🔍 CHECKING INDIVIDUAL VENDOR QUERIES...');
      // Debug: Check each vendor individually
      for (const vendorId of vendorIds.slice(0, 3)) { // Check first 3 vendors
        const count = await Product.countDocuments({ vendor: vendorId });
        const countWithString = await Product.countDocuments({ vendor: vendorId.toString() });
        console.log(`   Vendor ${vendorId.toString()}: ${count} products (ObjectId), ${countWithString} products (String)`);
      }
    }

    console.log('🔍 ASSIGNING DISTANCES TO PRODUCTS...');
    console.log('📊 Distance Assignment Process:');
    console.log('   - Match product.vendor._id with validVendors._id');
    console.log('   - Assign vendor.distance to product.distance');
    console.log('   - Create vendorInfo object with distance');

    // Add distance information and optimize product data
    const productsWithDistance = products.map((product, index) => {
      const vendor = validVendors.find(v => v._id.toString() === (product.vendor as any)._id.toString());
      
      console.log(`📦 Distance Assignment ${index + 1}:`);
      console.log('   Product Name:', product.name);
      console.log('   Product Vendor ID:', (product.vendor as any)._id);
      console.log('   Matching Vendor Found:', !!vendor);
      
      if (vendor) {
        console.log('   Vendor Distance (meters):', vendor.distance);
        console.log('   Vendor Distance (km):', (vendor.distance / 1000).toFixed(2));
        console.log('   Vendor Name:', vendor.businessName || vendor.firstName);
      } else {
        console.log('   ⚠️ NO MATCHING VENDOR FOUND FOR PRODUCT');
        console.log('   Available Vendor IDs:', validVendors.map(v => v._id.toString()));
        console.log('   Product Vendor ID:', (product.vendor as any)._id?.toString());
      }
      
      return {
        ...product,
        distance: vendor ? vendor.distance : null,
        vendorInfo: {
          _id: (product.vendor as any)._id,
          businessName: (product.vendor as any).businessName,
          coordinates: (product.vendor as any).coordinates,
          vendorLocation: (product.vendor as any).vendorLocation,
          rating: (product.vendor as any).rating,
          distance: vendor?.distance
        }
      };
    });

    console.log('✅ PRODUCTS WITH DISTANCE ASSIGNED:');
    console.log('📊 Total Products with Distance:', productsWithDistance.length);
    console.log('🔍 FINAL PRODUCT DATA:');
    productsWithDistance.forEach((product, index) => {
      console.log(`📦 Final Product ${index + 1}:`);
      console.log('   Name:', product.name);
      console.log('   Distance:', product.distance ? `${product.distance}m (${(product.distance / 1000).toFixed(2)}km)` : 'No distance');
      console.log('   Vendor:', product.vendorInfo.businessName || 'Unknown');
      console.log('   Vendor Coordinates:', product.vendorInfo.vendorLocation);
      console.log('   ---');
    });

    // Sort by distance and then by rating
    productsWithDistance.sort((a, b) => {
      if (a.distance === null && b.distance === null) return 0;
      if (a.distance === null) return 1;
      if (b.distance === null) return -1;
      if (a.distance !== b.distance) return a.distance - b.distance;
      return ((b.vendorInfo?.rating?.average || 0) - ((a.vendorInfo?.rating?.average || 0)));
    });

    console.log('🔍 Found nearby products:', productsWithDistance.length);
    return productsWithDistance.slice(0, limit);

  } catch (error) {
    console.error('❌ Error getting nearby products:', error);
    throw error;
  }
};
