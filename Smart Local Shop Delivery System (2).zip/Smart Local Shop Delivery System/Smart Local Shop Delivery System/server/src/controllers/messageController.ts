import { Request, Response, NextFunction } from 'express';
import Message from '../models/Message';
import User from '../models/User';
import { Document, Types } from 'mongoose';

// Send message from customer to vendor
export const sendMessage = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { senderId, receiverId, message } = req.body;
    
    if (!senderId || !receiverId || !message) {
      res.status(400).json({
        success: false,
        message: 'Sender ID, receiver ID, and message are required'
      });
      return;
    }

    // Verify both users exist
    const [sender, receiver] = await Promise.all([
      User.findById(senderId),
      User.findById(receiverId)
    ]);

    if (!sender || !receiver) {
      res.status(404).json({
        success: false,
        message: 'Sender or receiver not found'
      });
      return;
    }

    // Create new message
    const newMessage = new Message({
      senderId,
      receiverId,
      message: message.trim()
    });

    await newMessage.save();

    res.status(201).json({
      success: true,
      data: {
        message: newMessage
      }
    });
  } catch (error) {
    console.error('Error sending message:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while sending message'
    });
  }
};

// Get unread messages for a user
export const getUnreadMessages = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { userId } = req.params;
    
    if (!userId) {
      res.status(400).json({
        success: false,
        message: 'User ID is required'
      });
      return;
    }

    // Validate ObjectId format
    if (!Types.ObjectId.isValid(userId)) {
      res.status(400).json({
        success: false,
        message: 'Invalid user ID format'
      });
      return;
    }

    console.log('🔍 DEBUG: Fetching unread messages for user:', userId);

    // Find unread messages where user is receiver
    const unreadMessages = await Message.find({
      receiverId: new Types.ObjectId(userId),
      isRead: false
    })
    .populate({
      path: 'senderId',
      select: 'firstName lastName email'
    })
    .sort({ createdAt: -1 })
    .limit(10);

    console.log('🔍 DEBUG: Found unread messages:', unreadMessages.length);

    const notifications = unreadMessages.map(msg => {
      const sender = msg.senderId as any;
      return {
        id: msg._id,
        vendorName: sender ? `${sender.firstName} ${sender.lastName}` : 'Unknown Vendor',
        message: msg.message,
        timestamp: msg.createdAt,
        vendorId: msg.senderId
      };
    });

    res.status(200).json({
      success: true,
      data: {
        notifications: notifications,
        count: notifications.length
      }
    });
  } catch (error) {
    console.error('❌ getUnreadMessages error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching unread messages',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
};

// Get conversation between two users
export const getConversation = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { userId, senderId } = req.params;
    
    if (!userId || !senderId) {
      res.status(400).json({
        success: false,
        message: 'User ID and sender ID are required'
      });
      return;
    }

    // Find all messages between these two users
    const messages = await Message.find({
      $or: [
        { senderId: userId, receiverId: senderId },
        { senderId: senderId, receiverId: userId }
      ]
    })
    .populate('senderId', 'firstName lastName email')
    .populate('receiverId', 'firstName lastName email')
    .sort({ createdAt: 1 });

    res.status(200).json({
      success: true,
      data: messages
    });
  } catch (error) {
    console.error('❌ getConversation error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching conversation'
    });
  }
};

// Mark message as read
export const markMessageAsRead = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { messageId } = req.params;
    
    if (!messageId) {
      res.status(400).json({
        success: false,
        message: 'Message ID is required'
      });
      return;
    }

    const message = await Message.findByIdAndUpdate(
      messageId,
      { isRead: true },
      { new: true }
    );

    if (!message) {
      res.status(404).json({
        success: false,
        message: 'Message not found'
      });
      return;
    }

    res.status(200).json({
      success: true,
      data: {
        message: 'Message marked as read'
      }
    });
  } catch (error) {
    console.error('❌ markMessageAsRead error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while marking message as read'
    });
  }
};
