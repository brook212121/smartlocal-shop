import { Request, Response } from 'express';
import User from '../models/User';
import deliveryService from '../services/deliveryService';

// Get all available vendors for assignment
export const getAvailableVendors = async (req: Request, res: Response) => {
  try {
    // First, check all vendors in database
    const allVendors = await User.find({ role: 'VENDOR' });
    
    // Filter vendors who are active and have coordinates
    const vendors = allVendors.filter(vendor => 
      vendor.isActive !== false && 
      vendor.coordinates && 
      vendor.coordinates.lat !== undefined && 
      vendor.coordinates.lng !== undefined
    );

    // Transform vendor data to match frontend expectations
    const availableVendors = vendors.map(vendor => {
      const coordinates = vendor.coordinates;
      
      return {
        _id: vendor._id.toString(),
        firstName: vendor.firstName,
        lastName: vendor.lastName,
        email: vendor.email,
        phone: vendor.phone,
        coordinates: coordinates,
        vendorLocation: vendor.vendorLocation,
        shopName: vendor.shopName,
        shopDescription: vendor.shopDescription,
        shopCategory: vendor.shopCategory,
        businessLicense: vendor.businessLicense,
        averageRating: vendor.averageRating,
        totalDeliveries: vendor.totalDeliveries,
        isAvailable: vendor.isAvailable,
        deliveryRadius: vendor.deliveryRadius,
        isActive: vendor.isActive,
        isVendor: vendor.isVendor,
        isDelivery: vendor.isDelivery,
        isOnline: vendor.isOnline || true  // Add isOnline field, default to true if not set
      };
    });

    // Always return success: true, even with empty array
    res.status(200).json({
      success: true,
      message: availableVendors.length > 0 ? 
        `Found ${availableVendors.length} available vendors` : 
        'No available vendors found',
      data: {
        vendors: availableVendors,
        total: availableVendors.length
      }
    });
  } catch (error) {
    console.error('❌ ERROR: Error fetching available vendors:', error);
    
    // Even on error, try to return empty array instead of failure
    res.status(200).json({
      success: true,
      message: 'Unable to fetch vendors at this time',
      data: {
        vendors: [],
        total: 0
      }
    });
  }
};

// Get vendor by ID
export const getVendorById = async (req: Request, res: Response) => {
  try {
    const { vendorId } = req.params;

    const vendor = await User.findOne({
      _id: vendorId,
      role: 'VENDOR',
      isVendor: true
    }).select([
      '_id',
      'firstName',
      'lastName',
      'email',
      'phone',
      'coordinates', 
      'vendorLocation', 
      'shopName',
      'shopDescription',
      'shopCategory',
      'isActive',
      'createdAt'
    ]);

    if (!vendor) {
      return res.status(404).json({
        success: false,
        message: 'Vendor not found'
      });
    }

    const vendorData = {
      _id: vendor._id.toString(),
      firstName: vendor.firstName,
      lastName: vendor.lastName,
      email: vendor.email,
      phone: vendor.phone,
      coordinates: vendor.coordinates, // Use new coordinates field
      vendorLocation: vendor.vendorLocation, // Use new vendorLocation field
      shopName: vendor.shopName,
      shopDescription: vendor.shopDescription,
      shopCategory: vendor.shopCategory,
      isActive: vendor.isActive,
      isVendor: vendor.isVendor
    };

    return res.status(200).json({
      success: true,
      data: {
        vendor: vendorData
      }
    });
  } catch (error) {
    console.error('Error fetching vendor:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to fetch vendor',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
};

// Get current vendor location
export const getCurrentVendorLocation = async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user?.id;

    // Find vendor
    const vendor = await User.findOne({
      _id: userId,
      role: 'VENDOR',
      isVendor: true
    });

    if (!vendor) {
      return res.status(404).json({
        success: false,
        message: 'Vendor not found'
      });
    }

    const coordinates = vendor.coordinates; // Use new coordinates field
    
    // Check if vendor has valid coordinates
    if (coordinates && 
        typeof coordinates.lat === 'number' && 
        typeof coordinates.lng === 'number' && 
        coordinates.lat !== 0 && 
        coordinates.lng !== 0 &&
        !isNaN(coordinates.lat) && 
        !isNaN(coordinates.lng)) {
      
      return res.status(200).json({
        success: true,
        data: {
          location: {
            latitude: coordinates.lat,
            longitude: coordinates.lng
          },
          hasValidLocation: true
        }
      });
    } else {
      return res.status(200).json({
        success: true,
        data: {
          location: null,
          hasValidLocation: false
        }
      });
    }
  } catch (error) {
    console.error('Error fetching vendor location:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to fetch vendor location',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
};

// Update vendor location automatically
export const updateVendorLocation = async (req: Request, res: Response) => {
  try {
    const { location } = req.body;
    const userId = (req as any).user?.id;

    // Validate location data exists
    if (!location) {
      return res.status(400).json({
        success: false,
        message: 'Location data is required'
      });
    }

    // Validate latitude and longitude are valid numbers
    if (typeof location.latitude !== 'number' || typeof location.longitude !== 'number') {
      return res.status(400).json({
        success: false,
        message: 'Valid latitude and longitude numbers are required'
      });
    }

    // Validate coordinates are not zero or invalid
    if (location.latitude === 0 || location.longitude === 0 || 
        isNaN(location.latitude) || isNaN(location.longitude)) {
      return res.status(400).json({
        success: false,
        message: 'Valid latitude and longitude values are required (cannot be 0 or NaN)'
      });
    }

    // Find vendor (user with VENDOR role)
    const vendor = await User.findOne({
      _id: userId,
      role: 'VENDOR',
      isVendor: true
    });

    if (!vendor) {
      return res.status(404).json({
        success: false,
        message: 'Vendor not found'
      });
    }

    // Update vendor's coordinates and vendorLocation
    if (location.latitude && location.longitude) {
      vendor.coordinates = {
        lat: location.latitude,
        lng: location.longitude
      };
      
      // Update vendorLocation for geospatial queries
      vendor.vendorLocation = {
        type: 'Point',
        coordinates: [location.longitude, location.latitude]
      };
    }

    await vendor.save();

    return res.status(200).json({
      success: true,
      message: 'Vendor location updated successfully',
      data: {
        location: {
          latitude: location.latitude,
          longitude: location.longitude
        }
      }
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: 'Failed to update vendor location',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
};

// Find nearest vendor using database coordinates
export const findNearestVendor = async (req: Request, res: Response) => {
  try {
    const { customerLocation, requestingUserId } = req.body; // ✅ Get requestingUserId from request body

    // Validate customer location
    if (!customerLocation || !customerLocation.latitude || !customerLocation.longitude) {
      return res.status(400).json({
        success: false,
        message: 'Valid customer location is required'
      });
    }

    console.log('🔍 DEBUG: Requesting user ID:', requestingUserId);

    // Use deliveryService to find nearest vendor (excluding requesting user)
    const result = await (deliveryService as any).findNearestVendor(customerLocation, requestingUserId);

    if (result.vendor) {
      // Format vendor response to match frontend expectations
      const vendor = {
        _id: result.vendor._id,
        firstName: result.vendor.firstName,
        lastName: result.vendor.lastName,
        email: result.vendor.email,
        phone: result.vendor.phone,
        coordinates: result.vendor.coordinates, // ✅ Use coordinates field
        isOnline: result.vendor.isActive !== false,
        rating: result.vendor.averageRating || 0,
        totalOrders: result.vendor.totalDeliveries || 0
      };

      return res.status(200).json({
        success: true,
        message: 'Nearest vendor found',
        data: {
          vendor,
          distance: result.distance
        }
      });
    } else {
      return res.status(404).json({
        success: false,
        message: 'No vendors available within 50km radius'
      });
    }
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: 'Failed to find nearest vendor',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
};
