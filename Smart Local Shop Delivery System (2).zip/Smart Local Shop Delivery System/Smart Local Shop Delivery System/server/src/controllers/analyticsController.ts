import { Request, Response, NextFunction } from 'express';
import { catchAsync, createError } from '../middleware/errorHandler';
import Order from '../models/Order';
import User from '../models/User';
import mongoose from 'mongoose';

// Get vendor analytics data
export const getVendorAnalytics = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  console.log('🔍 Analytics endpoint hit');
  console.log('🔍 User from request:', req.user);
  
  const vendorId = req.user?._id; // Get vendor ID from authenticated user
  console.log('🔍 Vendor ID extracted:', vendorId);

  if (!vendorId) {
    console.log('❌ No vendor ID found');
    return next(createError('Vendor authentication required', 401));
  }

  // Get vendor details
  const vendor = await User.findById(vendorId);
  console.log('🔍 Vendor found:', vendor);
  
  if (!vendor || vendor.role !== 'VENDOR') {
    console.log('❌ Vendor not found or not vendor role:', { vendor, role: vendor?.role });
    return next(createError('Vendor not found or not authorized', 404));
  }

  console.log('✅ Vendor validated, proceeding with analytics...');

  try {
    console.log(`🔍 Starting analytics aggregation for vendor: ${vendorId}`);
    
    // Debug: Check if vendor has any orders at all
    const totalVendorOrders = await Order.countDocuments({ 
      vendor: new mongoose.Types.ObjectId(vendorId)
    });
    console.log('📊 Total vendor orders found:', totalVendorOrders);
    
    // Debug: Get one sample order to check structure
    const sampleOrder = await Order.findOne({ 
      vendor: new mongoose.Types.ObjectId(vendorId)
    });
    console.log('📄 Sample order structure:', sampleOrder);
    
    // Get sales orders (ALL orders where vendor is seller, regardless of status)
    const salesOrders = await Order.find({ 
      vendor: new mongoose.Types.ObjectId(vendorId)
    }).countDocuments();
    console.log('📊 Sales orders count:', salesOrders);

    // Get purchase orders (ALL orders where vendor is buyer, regardless of status)
    const purchaseOrders = await Order.find({ 
      customer: new mongoose.Types.ObjectId(vendorId)
    }).countDocuments();
    console.log('📊 Purchase orders count:', purchaseOrders);

    // Initialize with fallback data to prevent 500 errors
    let weeklyTransactions = [];

    try {
      // Get weekly transactions for the last 7 days
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      sevenDaysAgo.setHours(0, 0, 0, 0);

      console.log('🔍 Weekly revenue debug - sevenDaysAgo:', sevenDaysAgo);
      console.log('🔍 Weekly revenue debug - vendorId:', vendorId);

      // Use $dayOfWeek with %w format (0=Sunday, 1=Monday, etc.)
      weeklyTransactions = await Order.aggregate([
        {
          $match: {
            vendor: new mongoose.Types.ObjectId(vendorId),
            createdAt: { $gte: sevenDaysAgo }
          }
        },
        {
          $group: {
            _id: {
              $dayOfWeek: '$createdAt' // Use $dayOfWeek operator directly
            },
            revenue: { $sum: '$pricing.total' } // Money earned from selling items
          }
        },
        {
          $sort: { _id: 1 }
        }
      ]);
      console.log('📈 Weekly transactions aggregation successful, found:', weeklyTransactions.length);
      console.log('📈 Weekly transactions data:', weeklyTransactions);
    } catch (aggregationError) {
      console.error('❌ Weekly transactions aggregation failed:', aggregationError);
      weeklyTransactions = [];
    }

    // Map day numbers to day names manually (0=Sunday, 1=Monday, etc.)
    const daysMap = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const weeklyData = daysMap.map((dayName, index) => {
      const dayData = weeklyTransactions.find(t => t._id === index);
      return {
        name: dayName,
        revenue: dayData?.revenue || 0
      };
    });

    console.log('✅ Final analytics data prepared:', {
      salesOrders,
      purchaseOrders,
      weeklyDataPoints: weeklyData.length,
      totalWeeklyRevenue: weeklyData.reduce((sum, day) => sum + day.revenue, 0)
    });

    res.status(200).json({
      status: 'success',
      data: {
        weeklyTransactions: weeklyData,
        totalSalesOrders: salesOrders,
        totalPurchaseOrders: purchaseOrders
      }
    });

  } catch (error: any) {
    console.error('❌ Analytics controller error:', error);
    console.error('❌ Error details:', {
      message: error?.message || 'Unknown error',
      stack: error?.stack || 'No stack trace',
      name: error?.name || 'Unknown error',
      vendorId: vendorId
    });
    
    // Try to provide basic fallback data even if aggregation fails
    try {
      const basicSalesOrders = await Order.countDocuments({ 
        vendor: new mongoose.Types.ObjectId(vendorId),
        status: 'delivered' 
      });
      
      const basicPurchaseOrders = await Order.countDocuments({ 
        customer: new mongoose.Types.ObjectId(vendorId),
        status: 'delivered' 
      });

      console.log('📊 Fallback data calculated:', {
        basicSalesOrders,
        basicPurchaseOrders
      });

      return res.status(200).json({
        status: 'success',
        data: {
          weeklyTransactions: [
            { name: 'Sun', revenue: 0 },
            { name: 'Mon', revenue: 0 },
            { name: 'Tue', revenue: 0 },
            { name: 'Wed', revenue: 0 },
            { name: 'Thu', revenue: 0 },
            { name: 'Fri', revenue: 0 },
            { name: 'Sat', revenue: 0 }
          ],
          totalSalesOrders: basicSalesOrders,
          totalPurchaseOrders: basicPurchaseOrders
        }
      });
    } catch (fallbackError: any) {
      console.error('❌ Even fallback failed:', fallbackError);
      return next(createError('Analytics service temporarily unavailable', 500));
    }
    
    return next(createError('Failed to fetch analytics data', 500));
  }
});
