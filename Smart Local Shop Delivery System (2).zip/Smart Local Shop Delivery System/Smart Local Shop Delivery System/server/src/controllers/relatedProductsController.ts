import { Request, Response } from 'express';
import Product from '../models/Product';

interface RelatedProduct {
  _id: string;
  name: string;
  price: number;
  images: string[];
  category: string;
  brand?: string;
  tags?: string[];
  rating?: number;
}

export const getRelatedProducts = async (req: Request, res: Response): Promise<void> => {
  console.log('=== RELATED PRODUCTS API CALLED ===');
  console.log('Product ID:', req.params.productId);
  
  try {
    const { productId } = req.params;

    if (!productId) {
      res.status(400).json({ error: 'Product ID is required' });
      return;
    }

    // Get the current product
    const currentProduct = await Product.findById(productId);
    
    if (!currentProduct) {
      res.status(404).json({ error: 'Product not found' });
      return;
    }

    // Build query for related products
    const relatedQuery: any = {
      _id: { $ne: productId }, // Exclude current product
      $or: []
    };

    // Add similar name condition (more comprehensive regex search)
    if (currentProduct.name) {
      const nameWords = currentProduct.name.toLowerCase().split(' ').filter(word => word.length > 2);
      const namePatterns = nameWords.map(word => new RegExp(word, 'i'));
      relatedQuery.$or.push({
        name: { $regex: namePatterns.join('|'), $options: 'i' }
      });
    }

    // Add same brand condition
    if (currentProduct.brand) {
      relatedQuery.$or.push({
        brand: currentProduct.brand
      });
    }

    // Add similar tags condition
    if (currentProduct.tags && currentProduct.tags.length > 0) {
      relatedQuery.$or.push({
        tags: { $in: currentProduct.tags }
      });
    }

    // Add same category as fallback
    if (currentProduct.category) {
      relatedQuery.$or.push({
        category: currentProduct.category
      });
    }

    console.log('Related products query:', JSON.stringify(relatedQuery, null, 2));

    // Fetch related products
    const relatedProducts = await Product.find(relatedQuery)
      .limit(12) // Get more than needed for better ranking
      .lean();

    console.log('🔍 Current product:', {
      _id: currentProduct._id,
      name: currentProduct.name,
      category: currentProduct.category,
      brand: currentProduct.brand,
      tags: currentProduct.tags
    });

    console.log('🔍 Found related products:', relatedProducts.map(p => ({
      _id: p._id,
      name: p.name,
      category: p.category,
      brand: p.brand,
      tags: p.tags
    })));

    // Rank products by similarity priority
    const rankedProducts = relatedProducts.map(product => {
      let score = 0;
      let hasNameMatch = false;
      let hasBrandMatch = false;
      let hasTagMatch = false;
      
      // Priority 1: Similar name (highest priority)
      if (currentProduct.name) {
        const nameWords = currentProduct.name.toLowerCase().split(' ').filter(word => word.length > 2);
        const productNameWords = product.name.toLowerCase().split(' ').filter(word => word.length > 2);
        const commonWords = nameWords.filter(word => productNameWords.includes(word));
        
        // Also check for partial matches and related terms
        let partialMatchPoints = 0;
        for (const currentWord of nameWords) {
          for (const productWord of productNameWords) {
            // Check if words contain each other (partial matching)
            if (currentWord.includes(productWord) || productWord.includes(currentWord)) {
              if (currentWord !== productWord) {
                partialMatchPoints += 100; // Partial matches get 100 points
                console.log(`🔤 Partial match: "${currentWord}" contains "${productWord}" or vice versa`);
              }
            }
          }
        }
        
        console.log(`🔤 Name comparison: "${currentProduct.name}" vs "${product.name}"`);
        console.log(`   Current words: [${nameWords.join(', ')}]`);
        console.log(`   Product words: [${productNameWords.join(', ')}]`);
        console.log(`   Common words: [${commonWords.join(', ')}]`);
        
        if (commonWords.length > 0) {
          score += 200 * commonWords.length;
          hasNameMatch = true;
          console.log(`✅ Name match: "${currentProduct.name}" vs "${product.name}" - Common words: ${commonWords.join(', ')}, Score: ${score}`);
        } else if (partialMatchPoints > 0) {
          score += partialMatchPoints;
          hasNameMatch = true;
          console.log(`✅ Partial name match: "${currentProduct.name}" vs "${product.name}" - Score: ${score}`);
        } else {
          console.log(`❌ No name match between "${currentProduct.name}" and "${product.name}"`);
        }
      }

      // Priority 2: Same brand
      if (currentProduct.brand && product.brand === currentProduct.brand) {
        score += 100;
        hasBrandMatch = true;
        console.log(`Brand match: "${currentProduct.brand}" vs "${product.brand}" - Score: ${score}`);
      }

      // Priority 3: Similar tags
      if (currentProduct.tags && product.tags) {
        const commonTags = currentProduct.tags.filter(tag => (product.tags as string[])?.includes(tag));
        if (commonTags.length > 0) {
          score += 50 * commonTags.length;
          hasTagMatch = true;
          console.log(`Tag match: ${commonTags.join(', ')} - Score: ${score}`);
        }
      }

      // Priority 4: Same category (lowest priority) - only if no other matches
      if (currentProduct.category && product.category === currentProduct.category && !hasNameMatch && !hasBrandMatch && !hasTagMatch) {
        score += 1;
        console.log(`Category match: "${currentProduct.category}" - Score: ${score}`);
      }

      return { ...product, score };
    })
    .sort((a, b) => b.score - a.score) // Sort by score descending
    .slice(0, 6); // Limit to 6 products

    console.log('Final ranked products:', rankedProducts.map(p => ({ name: p.name, score: p.score })));

    // Transform to response format
    const relatedItems: RelatedProduct[] = rankedProducts.map(product => ({
      _id: product._id.toString(),
      name: product.name,
      price: product.price,
      images: (product.images as string[]) || [],
      category: product.category,
      brand: product.brand as string,
      tags: product.tags as string[],
      rating: (product as any).rating // Type assertion for optional rating field
    }));

    res.json(relatedItems);

  } catch (error) {
    console.error('Error fetching related products:', error);
    res.status(500).json({ error: 'Failed to fetch related products' });
  }
};
