import { Request, Response, NextFunction } from 'express';
import mongoose, { Types } from 'mongoose';
import QuickOrder from '../models/QuickOrder';
import VendorResponse from '../models/VendorResponse';
import ChatMessage from '../models/ChatMessage';
import Order from '../models/Order';
import Delivery from '../models/Delivery';
import User from '../models/User';
import { catchAsync, createError } from '../middleware/errorHandler';
import EmailService from '../services/emailService';

// POST /quick-orders - Create a new quick order
export const createQuickOrder = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { description, quantity, assignedVendorId, assignmentDistance, assignmentMetadata } = req.body;
  const image = req.file ? `/uploads/${req.file.filename}` : null;

  // Validate required fields
  if (!description || description.trim().length < 5) {
    return next(createError('Description must be at least 5 characters long', 400));
  }

  // Get customer ID from authenticated user
  const customerId = req.user?._id;
  if (!customerId) {
    return next(createError('User not authenticated', 401));
  }

  // Parse assignment metadata if provided
  let parsedAssignmentMetadata = null;
  if (assignmentMetadata) {
    try {
      parsedAssignmentMetadata = JSON.parse(assignmentMetadata);
      console.log('🎯 DEBUG: Assignment metadata parsed:', parsedAssignmentMetadata);
    } catch (error) {
      console.warn('⚠️ Failed to parse assignment metadata:', error);
    }
  }

  console.log('🔍 DEBUG: Creating quick order with vendor assignment:', {
    customerId,
    assignedVendorId,
    assignmentDistance,
    parsedAssignmentMetadata
  });

  // Create quick order with vendor assignment
  const quickOrder = await QuickOrder.create({
    customerId,
    description: description.trim(),
    image,
    quantity: quantity ? parseInt(quantity) : null,
    assignedVendorId: assignedVendorId ? new Types.ObjectId(assignedVendorId) : null,
    assignmentDistance: assignmentDistance ? parseFloat(assignmentDistance) : null
  });

  // Log successful assignment
  if (assignedVendorId && parsedAssignmentMetadata) {
    console.log('✅ Quick order assigned to vendor:', {
      orderId: quickOrder._id,
      vendorId: assignedVendorId,
      vendorName: parsedAssignmentMetadata.vendorName,
      distance: assignmentDistance,
      assignmentTime: parsedAssignmentMetadata.assignmentTime
    });
  }

  // Populate customer and vendor details for response
  const populatedOrder = await QuickOrder.findById(quickOrder._id)
    .populate('customerId', 'firstName lastName email phone')
    .populate('assignedVendorId', 'firstName lastName email')
    .exec() as any;

  // Send email notification to assigned vendor
  if (assignedVendorId && parsedAssignmentMetadata && populatedOrder.assignedVendorId) {
    try {
      console.log('?? Sending quick order email to assigned vendor...');
      
      const assignedVendor = populatedOrder.assignedVendorId;
      const customer = populatedOrder.customerId;
      
      // Get customer phone from populated data first, then fallback to req.user
      const customerPhone = customer?.phone || req.user?.phone || parsedAssignmentMetadata.customerPhone || 'Not provided';
      
      await EmailService.sendQuickOrderNotification({
        vendorEmail: assignedVendor.email,
        vendorName: `${assignedVendor.firstName} ${assignedVendor.lastName}`,
        customerName: `${customer.firstName} ${customer.lastName}`,
        customerEmail: customer.email,
        customerPhone: customerPhone,
        description: description.trim(),
        quantity: quantity ? parseInt(quantity) : undefined,
        imageUrl: image ? `${process.env.SERVER_URL || 'http://localhost:3000'}${image}` : undefined
      });
      
      console.log('?? Quick order email sent successfully to vendor:', assignedVendor.email);
    } catch (emailError) {
      console.error('?? Failed to send quick order email:', emailError);
      // Don't fail the request if email fails, just log it
    }
  }

  return res.status(201).json({
    status: 'success',
    message: 'Quick order posted successfully',
    data: {
      quickOrder: populatedOrder,
      assignmentInfo: parsedAssignmentMetadata
    }
  });
});

// GET /quick-orders - Get all quick orders for the authenticated customer
export const getCustomerQuickOrders = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const customerId = req.user?._id;
  if (!customerId) {
    return next(createError('User not authenticated', 401));
  }

  const quickOrders = await QuickOrder.find({ customerId })
    .populate('customerId', 'firstName lastName email')
    .sort({ createdAt: -1 });

  return res.status(200).json({
    status: 'success',
    results: quickOrders.length,
    data: {
      quickOrders
    }
  });
});

// GET /quick-orders/all - Get all quick orders (for admin to see)
export const getAllQuickOrders = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const quickOrders = await QuickOrder.find({})
    .populate('customerId', 'firstName lastName email')
    .populate('assignedVendor', 'firstName lastName email')
    .sort({ createdAt: -1 });

  return res.status(200).json({
    status: 'success',
    results: quickOrders.length,
    data: {
      quickOrders
    }
  });
});

// GET /quick-orders/vendor - Get quick orders assigned to current vendor
export const getVendorQuickOrders = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const vendorId = req.user?._id;
  
  if (!vendorId) {
    return next(createError('Vendor authentication required', 401));
  }

  const quickOrders = await QuickOrder.find({ 
    assignedVendorId: vendorId,
    status: { $in: ['OPEN', 'ASSIGNED'] }
  })
    .populate('customerId', 'firstName lastName email phone')
    .populate('assignedVendorId', 'firstName lastName email phone')
    .sort({ createdAt: -1 });

  // Transform to add explicit id field and frontend compatibility
  const transformedOrders = quickOrders.map(order => ({
    ...order.toObject(),
    id: order._id.toString(),
    orderNumber: order._id.toString().slice(-8), // Last 8 chars as order number
    isQuickOrder: true, // Mark as Quick Order
    customer: order.customerId,
    assignedVendor: order.assignedVendorId || null,
    assignmentDistance: order.assignmentDistance || 0,
    items: [{
      product: {
        name: order.description || 'Quick Order Item',
        price: 0, // Quick orders may not have fixed pricing
        images: order.image ? [order.image] : []
      },
      quantity: order.quantity || 1,
      price: 0
    }],
    pricing: {
      total: 0, // Quick orders may not have fixed pricing
      currency: 'ETB'
    }
  }));

  return res.status(200).json({
    status: 'success',
    results: transformedOrders.length,
    data: transformedOrders
  });
});

// GET /quick-orders/open - Get all open quick orders (for vendors) - exclude user's own
export const getOpenQuickOrders = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const customerId = req.user?._id;
  
  const quickOrders = await QuickOrder.find({ 
    status: 'OPEN',
    customerId: { $ne: customerId } // Exclude user's own requests
  })
    .populate('customerId', 'firstName lastName email phone')
    .sort({ createdAt: -1 });

  // Transform to add explicit id field for frontend compatibility
  const transformedOrders = quickOrders.map(order => ({
    ...order.toObject(),
    id: order._id.toString() // Add explicit id field
  }));

  return res.status(200).json({
    status: 'success',
    results: transformedOrders.length,
    data: {
      quickOrders: transformedOrders
    }
  });
});

// GET /quick-orders/mine - Get user's own quick orders
export const getMyQuickOrders = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const customerId = req.user?._id;
  if (!customerId) {
    return next(createError('User not authenticated', 401));
  }

  const quickOrders = await QuickOrder.find({ customerId })
    .populate('customerId', 'firstName lastName email')
    .populate('assignedVendorId', 'firstName lastName email phone')
    .sort({ createdAt: -1 });

  console.log('🔍 DEBUG: Quick orders found:', quickOrders.length);
  quickOrders.forEach((order, index) => {
    console.log(`🔍 DEBUG: Order ${index + 1}:`, {
      id: order._id,
      description: order.description,
      assignedVendorId: order.assignedVendorId,
      assignedVendor: order.assignedVendorId
    });
  });

  // Transform to add explicit id field for frontend compatibility
  const transformedOrders = quickOrders.map(order => {
    const orderObj = order.toObject();
    const vendor = order.assignedVendorId as any; // Type cast to access populated fields
    
    return {
      ...orderObj,
      id: order._id.toString(), // Add explicit id field
      assignedVendor: vendor ? {
        _id: vendor._id?.toString() || vendor._id,
        firstName: vendor.firstName || '',
        lastName: vendor.lastName || '',
        email: vendor.email || '',
        phone: vendor.phone || ''
      } : null
    };
  });

  return res.status(200).json({
    status: 'success',
    results: transformedOrders.length,
    data: {
      quickOrders: transformedOrders
    }
  });
});

// PUT /quick-orders/:id - Update quick order status
export const updateQuickOrderStatus = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { id } = req.params;
  const { status } = req.body;

  if (!['OPEN', 'CLOSED', 'FULFILLED'].includes(status)) {
    return next(createError('Invalid status', 400));
  }

  const quickOrder = await QuickOrder.findById(id);
  if (!quickOrder) {
    return next(createError('Quick order not found', 404));
  }

  // Check if the user owns this quick order or is admin/vendor
  if (quickOrder.customerId.toString() !== req.user?._id?.toString() && !req.user?.isVendor && req.user?.role !== 'ADMIN') {
    return next(createError('Not authorized to update this quick order', 403));
  }

  quickOrder.status = status;
  await quickOrder.save();

  const updatedOrder = await QuickOrder.findById(id)
    .populate('customerId', 'firstName lastName email')
    .exec();

  return res.status(200).json({
    status: 'success',
    message: 'Quick order status updated successfully',
    data: {
      quickOrder: updatedOrder
    }
  });
});

// DELETE /quick-orders/:id - Delete a quick order and all related data
export const deleteQuickOrder = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { id } = req.params;

  const quickOrder = await QuickOrder.findById(id);
  if (!quickOrder) {
    return next(createError('Quick order not found', 404));
  }

  // Check if the user owns this quick order
  if (quickOrder.customerId.toString() !== req.user?._id?.toString()) {
    return next(createError('Not authorized to delete this quick order', 403));
  }

  // ✅ Delete all related data in proper order to avoid foreign key constraints
  
  // 1. Delete all vendor responses for this quick order
  await VendorResponse.deleteMany({ quickOrderId: id });
  
  // 2. Delete all chat messages for this quick order
  await ChatMessage.deleteMany({ quickOrderId: id });
  
  // 3. Delete any orders created from this quick order
  const relatedOrders = await Order.find({ quickOrderId: id });
  const orderIds = relatedOrders.map(order => order._id);
  
  // 4. Delete any deliveries related to these orders
  if (orderIds.length > 0) {
    await Delivery.deleteMany({ order: { $in: orderIds } });
  }
  
  // 5. Delete the orders themselves
  await Order.deleteMany({ quickOrderId: id });
  
  // 6. Finally delete the quick order itself
  await QuickOrder.findByIdAndDelete(id);

  return res.status(200).json({
    status: 'success',
    message: 'Quick order and all related data deleted successfully'
  });
});

// POST /quick-orders/:id/respond - Vendor responds with message and price
export const respondToQuickOrder = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { message, price } = req.body;
  const quickOrderId = req.params.id;

  // Validate required fields
  if (!message || message.trim().length < 5) {
    return next(createError('Message must be at least 5 characters long', 400));
  }
  if (!price || isNaN(price) || parseFloat(price) < 0) {
    return next(createError('Valid price is required', 400));
  }

  // Get vendor ID from authenticated user
  const vendorId = req.user?._id;
  if (!vendorId) {
    return next(createError('User not authenticated', 401));
  }

  // Check if quick order exists
  const quickOrder = await QuickOrder.findById(quickOrderId);
  if (!quickOrder) {
    return next(createError('Quick order not found', 404));
  }

  // Check if vendor has already responded
  const existingResponse = await VendorResponse.findOne({
    quickOrderId,
    vendorId
  });

  if (existingResponse) {
    // Update existing response
    existingResponse.message = message.trim();
    existingResponse.price = parseFloat(price);
    existingResponse.status = 'PENDING';
    await existingResponse.save();
  } else {
    // Create new response
    await VendorResponse.create({
      quickOrderId,
      vendorId,
      message: message.trim(),
      price: parseFloat(price),
      status: 'PENDING'
    });
  }

  // Create chat message
  await ChatMessage.create({
    quickOrderId,
    senderId: vendorId,
    senderType: 'VENDOR',
    message: message.trim(),
    price: parseFloat(price)
  });

  return res.status(201).json({
    status: 'success',
    message: 'Response sent successfully'
  });
});

// GET /quick-orders/:id/chat - Get chat messages for a quick order
export const getChatMessages = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const quickOrderId = req.params.id;

  // Check if quick order exists
  const quickOrder = await QuickOrder.findById(quickOrderId);
  if (!quickOrder) {
    return next(createError('Quick order not found', 404));
  }

  // Check if user is authorized (customer or assigned vendor)
  const userId = req.user?._id;
  const isCustomer = quickOrder.customerId.toString() === userId?.toString();
  const isVendor = quickOrder.assignedVendorId?.toString() === userId?.toString();

  if (!isCustomer && !isVendor) {
    return next(createError('Not authorized to view chat messages', 403));
  }

  // Get chat messages with populated sender info
  const messages = await ChatMessage.find({ quickOrderId })
    .populate('senderId', 'firstName lastName email')
    .sort({ createdAt: 1 });

  return res.status(200).json({
    status: 'success',
    data: messages
  });
});

// POST /quick-orders/:id/chat - Send chat message
export const sendChatMessage = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const quickOrderId = req.params.id;
  const { message } = req.body;

  // Validate input
  if (!message?.trim()) {
    return next(createError('Message is required', 400));
  }

  // Check if quick order exists
  const quickOrder = await QuickOrder.findById(quickOrderId);
  if (!quickOrder) {
    return next(createError('Quick order not found', 404));
  }

  // Check if user is authorized (customer or assigned vendor)
  const userId = req.user?._id;
  const isCustomer = quickOrder.customerId.toString() === userId?.toString();
  const isVendor = quickOrder.assignedVendorId?.toString() === userId?.toString();

  if (!isCustomer && !isVendor) {
    return next(createError('Not authorized to send chat messages', 403));
  }

  // Determine sender type
  const senderType = isCustomer ? 'CUSTOMER' : 'VENDOR';

  // Create chat message
  const chatMessage = await ChatMessage.create({
    quickOrderId,
    senderId: userId,
    senderType,
    message: message.trim()
  });

  // Populate sender info for response
  const populatedMessage = await ChatMessage.findById(chatMessage._id)
    .populate('senderId', 'firstName lastName email');

  return res.status(201).json({
    status: 'success',
    data: populatedMessage
  });
});

// GET /quick-orders/:id/responses - Get vendor responses for a quick order
export const getVendorResponses = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const quickOrderId = req.params.id;

  // Check if quick order exists
  const quickOrder = await QuickOrder.findById(quickOrderId);
  if (!quickOrder) {
    return next(createError('Quick order not found', 404));
  }

  // Check if user is authorized (customer or assigned vendor)
  const userId = req.user?._id;
  const isCustomer = quickOrder.customerId.toString() === userId?.toString();
  const isVendor = quickOrder.assignedVendorId?.toString() === userId?.toString();

  if (!isCustomer && !isVendor) {
    return next(createError('Not authorized to view vendor responses', 403));
  }

  // Get vendor responses with populated vendor info
  const responses = await VendorResponse.find({ quickOrderId })
    .populate('vendorId', 'firstName lastName email phone')
    .sort({ createdAt: -1 });

  return res.status(200).json({
    status: 'success',
    data: responses
  });
});
