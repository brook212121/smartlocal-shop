import { Request, Response, NextFunction } from 'express';
import Order from '../models/Order';
import User from '../models/User';
import AdminWallet from '../models/AdminWallet';
import { IUser } from '../models/User';

declare global {
  namespace Express {
    interface Request {
      user?: IUser;
    }
  }
}

// Get admin dashboard summary
export const getDashboardSummary = async (req: Request, res: Response, next: NextFunction) => {
  try {
    console.log('🔍 getDashboardSummary - Admin request:', {
      userId: req.user?._id,
      role: req.user?.role,
      email: req.user?.email
    });

    // Calculate total revenue from paid orders
    const paidOrders = await Order.find({ 'payment.status': 'PAID' });
    const totalRevenue = paidOrders.reduce((sum, order) => sum + (order.pricing?.total || 0), 0);

    // Count total orders
    const totalOrders = await Order.countDocuments();

    // Count paid orders
    const paidOrdersCount = await Order.countDocuments({ 'payment.status': 'PAID' });

    // Count total vendors
    const totalVendors = await User.countDocuments({ role: 'VENDOR' });

    // Count total customers
    const totalCustomers = await User.countDocuments({ role: 'CUSTOMER' });

    // Count total delivery agents
    const totalDelivery = await User.countDocuments({ role: 'DELIVERY' });

    // Get admin wallet balance
    let adminWalletBalance = 0;
    try {
      const adminWallet = await AdminWallet.findOne();
      adminWalletBalance = adminWallet?.totalBalance || 0;
    } catch (error) {
      console.error('Error fetching admin wallet:', error);
    }

    const summary = {
      totalRevenue,
      totalOrders,
      paidOrders: paidOrdersCount,
      totalVendors,
      totalCustomers,
      totalDelivery,
      adminWalletBalance,
      revenueMetrics: {
        averageOrderValue: totalOrders > 0 ? totalRevenue / totalOrders : 0,
        conversionRate: totalOrders > 0 ? (paidOrdersCount / totalOrders) * 100 : 0
      }
    };

    console.log('✅ getDashboardSummary success:', {
      totalRevenue,
      totalOrders,
      paidOrders: paidOrdersCount,
      totalVendors,
      totalCustomers,
      totalDelivery,
      adminWalletBalance
    });

    res.status(200).json({
      success: true,
      data: summary
    });
  } catch (error) {
    console.error('❌ getDashboardSummary error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching dashboard summary'
    });
  }
};

// Get revenue data for chart
export const getRevenueData = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { range = '7' } = req.query;
    const days = parseInt(range as string);
    
    console.log('🔍 getRevenueData - Admin request:', {
      userId: req.user?._id,
      range: days,
      role: req.user?.role
    });

    // Calculate date range
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(endDate.getDate() - days + 1);

    // Aggregate paid orders by day
    const revenueData = await Order.aggregate([
      {
        $match: {
          'payment.status': 'PAID',
          createdAt: {
            $gte: startDate,
            $lte: endDate
          }
        }
      },
      {
        $group: {
          _id: {
            $dateToString: {
              format: '%Y-%m-%d',
              date: '$createdAt'
            }
          },
          dailyRevenue: {
            $sum: '$pricing.total'
          },
          orderCount: {
            $sum: 1
          }
        }
      },
      {
        $sort: {
          _id: 1
        }
      }
    ]);

    // Fill missing dates with zero revenue
    const filledData = [];
    const currentDate = new Date(startDate);
    
    for (let i = 0; i < days; i++) {
      const dateStr = currentDate.toISOString().split('T')[0];
      const dayData = revenueData.find(item => item._id === dateStr);
      
      filledData.push({
        date: dateStr,
        revenue: dayData?.dailyRevenue || 0,
        orders: dayData?.orderCount || 0
      });
      
      currentDate.setDate(currentDate.getDate() + 1);
    }

    console.log('✅ getRevenueData success:', {
      range: days,
      dataPoints: filledData.length,
      totalRevenue: filledData.reduce((sum, day) => sum + day.revenue, 0)
    });

    res.status(200).json({
      success: true,
      data: {
        range: days,
        data: filledData
      }
    });
  } catch (error) {
    console.error('❌ getRevenueData error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching revenue data'
    });
  }
};
