import { Request, Response, NextFunction } from 'express';
import Product, { IProduct } from '../models/Product';
import { IUser } from '../models/User';

declare global {
  namespace Express {
    interface Request {
      user?: IUser;
      product?: any;
    }
  }
}

type VendorRequest = Request;

// Get all public products (for browsing)
export const getPublicProducts = async (req: Request, res: Response, next: NextFunction) => {
  try {
    console.log('🔍 getPublicProducts called with query:', req.query);
    const { page = 1, limit = 20, category, search, minPrice, maxPrice } = req.query;
    
    // Build query
    const query: any = {};
    
    // Exclude products owned by the current user
    if (req.user) {
      query.vendor = { $ne: req.user.id };
    }
    
    // Filter by category if provided
    if (category && category !== 'all') {
      query.category = category;
      console.log('🔍 Query building - category filter added:', JSON.stringify(query));
    }
    
    // Search by name if provided
    if (search) {
      console.log('🔍 Query building - search term:', search);
      query.name = { $regex: search, $options: 'i' };
      console.log('🔍 Query building - search filter added:', JSON.stringify(query));
    }
    
    // Price range filtering
    if (minPrice || maxPrice) {
      query.price = {};
      if (minPrice) {
        query.price.$gte = parseFloat(minPrice as string);
      }
      if (maxPrice) {
        query.price.$lte = parseFloat(maxPrice as string);
      }
      console.log('🔍 Query building - price filter added:', JSON.stringify(query));
    }
    
    console.log('🔍 Final query to execute:', JSON.stringify(query));
    
    // Pagination
    const pageNum = parseInt(page as string);
    const limitNum = parseInt(limit as string);
    const skip = (pageNum - 1) * limitNum;
    
    // Get products with vendor info
    const products = await Product.find(query)
      .populate('vendor', 'firstName lastName email businessName coordinates vendorLocation rating')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limitNum);
    
    console.log('🔍 Database results:', {
      productsFound: products.length,
      sampleProducts: products.slice(0, 3).map(p => ({
        id: p._id,
        name: p.name,
        category: p.category,
        price: p.price
      }))
    });
    
    // Get total count for pagination
    const total = await Product.countDocuments(query);
    
    // Calculate price range for current search
    const priceRangeQuery: any = {};
    if (req.user) {
      priceRangeQuery.vendor = { $ne: req.user.id };
    }
    if (category && category !== 'all') {
      priceRangeQuery.category = category;
    }
    if (search) {
      priceRangeQuery.name = { $regex: search, $options: 'i' };
    }
    
    const priceStats = await Product.aggregate([
      { $match: priceRangeQuery },
      {
        $group: {
          _id: null,
          minPrice: { $min: '$price' },
          maxPrice: { $max: '$price' }
        }
      }
    ]);
    
    const priceRange = priceStats.length > 0 ? priceStats[0] : { minPrice: 0, maxPrice: 0 };
    
    // Add comprehensive cache-control headers to prevent caching
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    res.setHeader('Last-Modified', new Date().toUTCString());
    res.setHeader('ETag', Date.now().toString());
    
    res.status(200).json({
      success: true,
      data: {
        products,
        priceRange,
        pagination: {
          currentPage: pageNum,
          totalPages: Math.ceil(total / limitNum),
          totalProducts: total,
          hasNext: pageNum < Math.ceil(total / limitNum),
          hasPrev: pageNum > 1
        },
        timestamp: Date.now() // Add timestamp for cache busting
      }
    });
  } catch (error) {
    console.error('❌ getPublicProducts error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching products'
    });
  }
};

// Get single public product (for product details page)
export const getPublicProduct = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const product = await Product.findOne({ _id: req.params.id })
      .populate('vendor', 'firstName lastName email phone');

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    return res.status(200).json({
      success: true,
      data: { product }
    });
  } catch (error) {
    console.error('Error fetching public product:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while fetching product'
    });
  }
};

// Get vendor's products
export const getVendorProducts = async (req: VendorRequest, res: Response, next: NextFunction) => {
  try {
    const vendorId = req.user?.id;

    // Check if user is authenticated
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }

    // Check if user is a vendor
    if (req.user.role !== 'VENDOR') {
      return res.status(403).json({
        success: false,
        message: 'Access denied. Only vendors can access their products.'
      });
    }

    const { page = 1, limit = 20, category, search } = req.query;
    
    // Build query for vendor's products using req.user._id
    const query: any = { vendor: req.user._id };
    
    // Filter by category if provided
    if (category && category !== 'all') {
      query.category = category;
    }
    
    // Search by name if provided
    if (search) {
      query.name = { $regex: search, $options: 'i' };
    }
    
    // Pagination
    const pageNum = parseInt(page as string);
    const limitNum = parseInt(limit as string);
    const skip = (pageNum - 1) * limitNum;
    
    // Get vendor's products
    const products = await Product.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limitNum);
    
    const total = await Product.countDocuments(query);
    
    return res.status(200).json({
      success: true,
      data: {
        products,
        pagination: {
          current: pageNum,
          pages: Math.ceil(total / limitNum),
          total
        }
      }
    });
  } catch (error) {
    console.error('❌ getVendorProducts error:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while fetching vendor products'
    });
  }
}

// Get single vendor product
export const getVendorProduct = async (req: VendorRequest, res: Response, next: NextFunction) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }

    const product = await Product.findOne({ 
      _id: req.params.id, 
      vendor: req.user.id 
    });

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    return res.status(200).json({
      success: true,
      data: { product }
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: 'Server error while fetching product'
    });
  }
}

// Create new product
export const createProduct = async (req: VendorRequest, res: Response, next: NextFunction) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }

    const { name, description, category, price, stock, quantity } = req.body;

    // Validate required fields
    if (!name || !description || !category || !price) {
      return res.status(400).json({
        success: false,
        message: 'Name, description, category, and price are required'
      });
    }

    // Validate quantity
    if (req.body.quantity !== undefined && req.body.quantity < 0) {
      return res.status(400).json({
        success: false,
        message: 'Quantity cannot be negative'
      });
    }

    // Generate SKU if not provided
    const generateSKU = (name: string, category: string) => {
      const categoryCode = category.split('_')[0] || 'PRD';
      const nameCode = name.replace(/[^a-zA-Z0-9]/g, '').toUpperCase().substring(0, 8);
      const randomCode = Math.random().toString(36).substring(2, 6).toUpperCase();
      return `PRD-${categoryCode}-${nameCode}-${randomCode}`;
    };

    const sku = req.body.sku || generateSKU(name, category);

    // Handle image upload
    let images = [];
    if (req.file) {
      images = [`/uploads/${req.file.filename}`];
    } else if (req.body.images && Array.isArray(req.body.images)) {
      images = req.body.images;
    }

    // Create product
    const product = await Product.create({
      name,
      description,
      category,
      price: parseFloat(price),
      sku, // Add generated SKU
      quantity: req.body.quantity || 0, // Use req.body.quantity directly
      stock: { 
        quantity: req.body.quantity || 0, 
        lowStockThreshold: 10, 
        trackQuantity: true 
      }, // Keep stock.quantity in sync
      images,
      vendor: req.user.id
    });

    return res.status(201).json({
      success: true,
      message: 'Product created successfully',
      data: { product }
    });
  } catch (error) {
    console.error('Error in createProduct:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return res.status(500).json({
      success: false,
      message: 'Server error while creating product',
      error: process.env.NODE_ENV === 'development' ? errorMessage : undefined
    });
  }
};

// Update product
export const updateProduct = async (req: VendorRequest, res: Response, next: NextFunction) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }

    const { name, description, category, price, stock, quantity } = req.body;

    // Find product
    const product = await Product.findOne({ 
      _id: req.params.id, 
      vendor: req.user.id 
    });

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    // Update fields
    if (name) product.name = name;
    if (description) product.description = description;
    if (category) product.category = category;
    if (price) product.price = parseFloat(price);
    if (req.body.quantity !== undefined) {
      if (req.body.quantity < 0) {
        return res.status(400).json({
          success: false,
          message: 'Quantity cannot be negative'
        });
      }
      product.quantity = req.body.quantity; // Use req.body.quantity directly
      product.stock.quantity = req.body.quantity; // Keep stock.quantity in sync
    }

    // Always validate and fix existing stock to prevent negative values
    if (product.stock && product.stock.quantity < 0) {
      product.stock.quantity = 0;
    }

    // Handle image upload
    if (req.file) {
      product.images = [`/uploads/${req.file.filename}`];
    } else if (req.body.images && Array.isArray(req.body.images)) {
      product.images = req.body.images;
    }

    await product.save();

    return res.status(200).json({
      success: true,
      message: 'Product updated successfully',
      data: { product }
    });
  } catch (error) {
    console.error('Error in updateProduct:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while updating product'
    });
  }
};

// Delete product
export const deleteProduct = async (req: VendorRequest, res: Response, next: NextFunction) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }

    // Find and delete product
    const product = await Product.findOneAndDelete({ 
      _id: req.params.id, 
      vendor: req.user.id 
    });

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Product deleted successfully'
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: 'Server error while deleting product'
    });
  }
}

// Public endpoint to get vendor products by vendor ID
export const getVendorProductsPublic = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { vendorId } = req.params;
    const { page = 1, limit = 20, category, search } = req.query;
    
    if (!vendorId) {
      res.status(400).json({
        success: false,
        message: 'Vendor ID is required'
      });
      return;
    }
    
    // Build query for vendor's products
    const query: any = { vendor: vendorId };
    
    // Filter by category if provided
    if (category) {
      query.category = category;
    }
    
    // Search functionality
    if (search) {
      query.name = { $regex: search, $options: 'i' };
    }
    
    // Only show active products
    query.isActive = true;
    
    // Pagination
    const pageNum = parseInt(page as string);
    const limitNum = parseInt(limit as string);
    const skip = (pageNum - 1) * limitNum;
    
    // Get vendor's products
    const products = await Product.find(query)
      .populate('vendor', 'firstName lastName email phone')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limitNum);
    
    const total = await Product.countDocuments(query);
    
    res.status(200).json({
      success: true,
      data: {
        products,
        pagination: {
          currentPage: pageNum,
          totalPages: Math.ceil(total / limitNum),
          totalProducts: total,
          hasNext: pageNum < Math.ceil(total / limitNum),
          hasPrev: pageNum > 1
        }
      }
    });
  } catch (error) {
    console.error('❌ getVendorProductsPublic error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching vendor products'
    });
  }
};

// Search products for suggestions
export const searchProducts = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { q } = req.query;
    
    if (!q) {
      res.status(200).json([]);
      return;
    }
    
    // Search for products by name (case-insensitive)
    const products = await Product.find({
      name: { $regex: q, $options: 'i' }
    })
    .select('name')
    .limit(10)
    .lean();
    
    // Extract just the names
    const productNames = products.map(product => product.name);
    
    res.status(200).json(productNames);
  } catch (error) {
    console.error('❌ searchProducts error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while searching products'
    });
  }
};
