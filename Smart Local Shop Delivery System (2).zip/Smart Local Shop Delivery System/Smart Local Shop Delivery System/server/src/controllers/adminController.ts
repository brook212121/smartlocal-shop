import { Request, Response, NextFunction } from 'express';
import mongoose from 'mongoose';
import User, { IUser } from '../models/User';
import Product from '../models/Product';
import Order from '../models/Order';
import Payment from '../models/Payment';
import { catchAsync, createError } from '../middleware/errorHandler';
import walletService from '../services/walletService';
import bcrypt from 'bcryptjs';

// Import Complaint model (JavaScript module)
const Complaint = require('../models/Complaint');

// Define populated order interface
interface PopulatedOrder {
  _id: any;
  orderNumber?: string;
  createdAt: Date;
  updatedAt: Date;
  status: string;
  pricing?: {
    total: number;
  };
  vendor?: IUser & { _id: any };
  customer?: IUser & { _id: any };
}

// Get dashboard statistics
export const getDashboardStats = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const stats = await Promise.all([
    User.countDocuments({ role: { $in: ['CUSTOMER', 'VENDOR', 'DELIVERY'] } }),
    User.countDocuments({ role: 'VENDOR' }),
    User.countDocuments({ role: 'DELIVERY' }),
    Order.countDocuments(),
    // Note: QuickOrders model doesn't exist yet, using mock data
    Promise.resolve(5) // Mock quick orders count
  ]);

  const [totalUsers, totalVendors, totalDelivery, totalOrders, openQuickOrders] = stats;

  return res.status(200).json({
    status: 'success',
    data: {
      totalUsers,
      totalVendors,
      totalDelivery,
      totalOrders,
      openQuickOrders,
      pendingDeliveries: 0 // Can be calculated based on order status
    }
  });
});

// Get all users with pagination and search
export const getAllUsers = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { page = 1, limit = 20, search = '', role = '' } = req.query;
  
  // Build query
  const query: any = { role: { $ne: 'ADMIN' } };
  
  // Add role filter if specified
  if (role && role !== 'all') {
    query.role = role;
  }
  
  // Add search filter
  if (search) {
    query.$or = [
      { firstName: { $regex: search, $options: 'i' } },
      { lastName: { $regex: search, $options: 'i' } },
      { email: { $regex: search, $options: 'i' } }
    ];
  }
  
  // Pagination
  const pageNum = parseInt(page as string);
  const limitNum = parseInt(limit as string);
  const skip = (pageNum - 1) * limitNum;
  
  // Get users with pagination
  const [users, total] = await Promise.all([
    User.find(query)
      .select('-password')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limitNum),
    User.countDocuments(query)
  ]);

  return res.status(200).json({
    status: 'success',
    data: {
      users,
      pagination: {
        currentPage: pageNum,
        totalPages: Math.ceil(total / limitNum),
        totalUsers: total,
        hasNextPage: pageNum < Math.ceil(total / limitNum),
        hasPrevPage: pageNum > 1
      }
    }
  });
});

// Update user role
export const updateUserRole = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { id } = req.params;
  const { role } = req.body;

  const allowedRoles = ['CUSTOMER', 'VENDOR', 'DELIVERY', 'ADMIN'];
  if (!allowedRoles.includes(role)) {
    return next(createError('Invalid role', 400));
  }

  const user = await User.findByIdAndUpdate(
    id,
    { role },
    { new: true, runValidators: true }
  ).select('-password');

  if (!user) {
    return next(createError('User not found', 404));
  }

  return res.status(200).json({
    status: 'success',
    data: {
      user
    }
  });
});

// Toggle user status
export const toggleUserStatus = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { id } = req.params;

  const user = await User.findById(id);

  if (!user) {
    return next(createError('User not found', 404));
  }

  // Update isActive and vendorStatus based on the new state
  const newIsActive = !user.isActive;
  user.isActive = newIsActive;
  
  // Set status based on isActive state
  if (user.role === 'VENDOR') {
    if (newIsActive) {
      user.status = 'active';
    } else {
      user.status = 'suspended';
    }
    console.log(`[Admin] Updated vendor ${user._id}: isActive=${newIsActive}, status=${user.status}`);
  }
  
  await user.save();

  return res.status(200).json({
    status: 'success',
    data: {
      user
    }
  });
});

// Get all products (read-only for admin)
export const getAllProducts = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const products = await Product.find()
    .populate('vendor', 'firstName lastName email')
    .sort({ createdAt: -1 });

  return res.status(200).json({
    status: 'success',
    data: {
      products
    }
  });
});

// Test endpoint for debugging
export const testOrders = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  try {
    console.log('Test: Checking database connection...');
    
    // Test basic count
    const totalOrders = await Order.countDocuments();
    console.log('Test: Total orders in database:', totalOrders);
    
    // Test simple find
    const sampleOrders = await Order.find().limit(5);
    console.log('Test: Sample orders found:', sampleOrders.length);
    
    // Test with populate
    const populatedOrders = await Order.find()
      .populate('customer', 'firstName lastName email')
      .limit(3);
    console.log('Test: Populated orders found:', populatedOrders.length);
    
    return res.status(200).json({
      status: 'success',
      data: {
        totalOrders,
        sampleOrdersCount: sampleOrders.length,
        populatedOrdersCount: populatedOrders.length,
        sampleData: sampleOrders.map(order => ({
          id: order._id,
          orderNumber: order.orderNumber,
          status: order.status,
          customer: order.customer
        }))
      }
    });
  } catch (error) {
    console.error('Test Error:', error);
    return next(createError('Test failed', 500));
  }
});

// Search orders (server-side)
export const searchOrders = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  // Add cache-busting headers
  res.set({
    'Cache-Control': 'no-cache, no-store, must-revalidate',
    'Pragma': 'no-cache',
    'Expires': '0'
  });

  try {
    console.log('Admin Orders: Searching orders from database...');
    
    const { query, limit = 10 } = req.query;
    
    if (!query || typeof query !== 'string' || query.trim().length === 0) {
      return res.status(200).json({
        status: 'success',
        data: {
          orders: [],
          message: 'No search query provided'
        }
      });
    }

    const limitNum = Math.min(parseInt(limit as string) || 5, 10); // Max 10 results
    const searchRegex = new RegExp(query.trim(), 'i');
    
    console.log('Admin Orders: Search query:', query.trim(), 'limit:', limitNum);
    
    try {
      // Fast search: Only search by order number for maximum performance
      const orders = await Order.find({
        orderNumber: { $regex: searchRegex }
      })
        .populate('customer', 'firstName lastName email')
        .populate('vendor', 'firstName lastName email')
        .populate('items.product', 'name price images')
        .populate('delivery.deliveryAgent', 'firstName lastName phone')
        .sort({ createdAt: -1 })
        .limit(limitNum);

      console.log('Admin Orders: Search results count:', orders.length);

      return res.status(200).json({
        status: 'success',
        data: {
          orders,
          query: query.trim(),
          resultsCount: orders.length
        }
      });
    } catch (dbError: any) {
      console.error('Admin Orders Database Error:', dbError);
      console.error('Admin Orders Database Error Stack:', dbError.stack);
      
      // Return empty results on database error to prevent frontend crashes
      return res.status(200).json({
        status: 'success',
        data: {
          orders: [],
          query: query.trim(),
          resultsCount: 0,
          error: 'Database search failed'
        }
      });
    }
  } catch (error: any) {
    console.error('Admin Orders Search Error:', error);
    console.error('Admin Orders Search Error Stack:', error.stack);
    return next(createError('Failed to search orders', 500));
  }
});

// Get all orders
export const getAllOrders = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  // Add cache-busting headers
  res.set({
    'Cache-Control': 'no-cache, no-store, must-revalidate',
    'Pragma': 'no-cache',
    'Expires': '0'
  });

  try {
    console.log('🔍 Admin Orders: Fetching orders from database...');
    
    // Add pagination to reduce data size with safe parsing
    const pageParam = req.query.page;
    const limitParam = req.query.limit;
    
    let pageNum = 1;
    let limitNum = 50;
    
    if (pageParam && typeof pageParam === 'string') {
      const parsed = parseInt(pageParam, 10);
      if (!isNaN(parsed) && parsed > 0) {
        pageNum = parsed;
      }
    }
    
    if (limitParam && typeof limitParam === 'string') {
      const parsed = parseInt(limitParam, 10);
      if (!isNaN(parsed) && parsed > 0 && parsed <= 100) {
        limitNum = parsed;
      }
    }
    
    const skip = (pageNum - 1) * limitNum;
    
    console.log('🔍 Admin Orders: Pagination - page:', pageNum, 'limit:', limitNum, 'skip:', skip);
    
    const orders = await Order.find()
      .populate('customer', 'firstName lastName email')
      .populate('vendor', 'firstName lastName email')
      .populate('items.product', 'name price images')
      .populate('delivery.deliveryAgent', 'firstName lastName phone')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limitNum);

    console.log('🔍 Admin Orders: Found orders count:', orders.length);
    console.log('🔍 Admin Orders: Sample order:', orders[0] ? 'Yes' : 'No');

    // Get total count for pagination
    const totalOrders = await Order.countDocuments();

    return res.status(200).json({
      status: 'success',
      data: {
        orders,
        pagination: {
          currentPage: pageNum,
          totalPages: Math.ceil(totalOrders / limitNum),
          totalOrders,
          hasNextPage: pageNum < Math.ceil(totalOrders / limitNum),
          hasPrevPage: pageNum > 1
        }
      }
    });
  } catch (error: any) {
    console.error(' Admin Orders Error:', error);
    console.error(' Admin Orders Error Stack:', error.stack);
    return next(createError('Failed to fetch orders', 500));
  }
});

// Assign delivery agent to order
export const assignDeliveryAgent = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { id } = req.params;
  const { agentId } = req.body;

  const order = await Order.findById(id);
  if (!order) {
    return next(createError('Order not found', 404));
  }

  const agent = await User.findById(agentId);
  if (!agent || agent.role !== 'DELIVERY') {
    return next(createError('Invalid delivery agent', 400));
  }

  // Update order with delivery agent
  const updatedOrder = await Order.findByIdAndUpdate(
    id,
    { 
      'delivery.deliveryAgent': agentId,
      'delivery.assignedAt': new Date(),
      'delivery.status': 'ASSIGNED'
    },
    { new: true, runValidators: true }
  )
    .populate('customer', 'firstName lastName email')
    .populate('vendor', 'firstName lastName email')
    .populate('items.product', 'name price images')
    .populate('delivery.deliveryAgent', 'firstName lastName phone');

  if (!updatedOrder) {
    return next(createError('Order not found', 404));
  }

  return res.status(200).json({
    status: 'success',
    data: {
      order: updatedOrder
    }
  });
});

// Get delivery agents
export const getDeliveryAgents = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const agents = await User.find({ role: 'DELIVERY', isActive: true })
    .select('firstName lastName email phone isActive')
    .sort({ firstName: 1, lastName: 1 });

  // Add mock stats for each agent (in real app, calculate from orders)
  const agentsWithStats = agents.map(agent => ({
    ...agent.toObject(),
    stats: {
      totalDelivered: Math.floor(Math.random() * 100), // Mock data
      activeDeliveries: Math.floor(Math.random() * 10), // Mock data
      pendingDeliveries: Math.floor(Math.random() * 5) // Mock data
    }
  }));

  return res.status(200).json({
    status: 'success',
    data: {
      agents: agentsWithStats
    }
  });
});

// Get all quick orders (mock implementation)
export const getAllQuickOrders = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  // Mock data since QuickOrders model doesn't exist yet
  const mockQuickOrders = [
    {
      _id: '1',
      description: 'Looking for custom wedding cake',
      quantity: '1',
      customer: {
        _id: 'cust1',
        firstName: 'John',
        lastName: 'Doe',
        email: 'john@example.com'
      },
      status: 'OPEN',
      image: null,
      createdAt: new Date().toISOString(),
      assignedVendor: null
    },
    {
      _id: '2',
      description: 'Need custom furniture design',
      quantity: '2 sets',
      customer: {
        _id: 'cust2',
        firstName: 'Jane',
        lastName: 'Smith',
        email: 'jane@example.com'
      },
      status: 'ASSIGNED',
      image: null,
      createdAt: new Date(Date.now() - 86400000).toISOString(),
      assignedVendor: {
        _id: 'vend1',
        firstName: 'Mike',
        lastName: 'Wilson',
        email: 'mike@example.com'
      }
    }
  ];

  return res.status(200).json({
    status: 'success',
    data: {
      quickOrders: mockQuickOrders
    }
  });
});

// Close quick order
export const closeQuickOrder = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { id } = req.params;

  // Mock implementation since QuickOrders model doesn't exist yet
  return res.status(200).json({
    status: 'success',
    data: {
      quickOrder: {
        _id: id,
        status: 'CLOSED',
        closedAt: new Date().toISOString()
      }
    }
  });
});

// Delete user
export const deleteUser = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { id } = req.params;

  // Find the user first
  const user = await User.findById(id);
  
  if (!user) {
    return next(createError(`User with ID ${id} not found from database at all`, 404));
  }

  // Prevent deletion of admin users
  if (user.role === 'ADMIN') {
    return next(createError('Cannot delete admin users', 403));
  }

  // Delete the user (this will cascade delete related data if properly configured in schema)
  await User.findByIdAndDelete(id);

  return res.status(200).json({
    status: 'success',
    message: 'User deleted successfully'
  });
});

// Get order details with comprehensive information
export const getOrderDetails = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { id } = req.params;

  // Find the order with comprehensive details
  const order = await Order.findById(id)
    .populate('customer', 'firstName lastName email phone')
    .populate('vendor', 'firstName lastName email phone')
    .populate('items.product', 'name price images')
    .populate('delivery.deliveryAgent', 'firstName lastName phone')
    .lean() as any;

  if (!order) {
    return next(createError('Order not found', 404));
  }

  // Construct comprehensive order data
  const orderDetails = {
    ...order,
    _id: order._id.toString(),
    orderNumber: order.orderNumber || `ORD-${order._id.toString().slice(-8).toUpperCase()}`,
    status: order.status || 'PENDING',
    pricing: {
      subtotal: order.pricing?.subtotal || 0,
      tax: order.pricing?.tax || 0,
      deliveryFee: order.pricing?.deliveryFee || 0,
      total: order.pricing?.total || 0
    },
    customer: order.customer,
    vendor: order.vendor,
    delivery: {
      address: order.delivery?.address || {
        street: 'Default Street',
        city: 'Addis Ababa',
        county: 'Addis Ababa'
      },
      instructions: (order.delivery as any)?.instructions,
      estimatedTime: (order.delivery as any)?.estimatedTime || '30-45 minutes',
      deliveryAgent: order.delivery?.deliveryAgent
    },
    payment: {
      status: order.payment?.status || 'PENDING',
      method: order.payment?.method || 'Cash',
      transactionId: order.payment?.transactionId
    },
    items: order.items?.map((item: any) => ({
      _id: item._id?.toString(),
      product: {
        _id: item.product?._id?.toString(),
        name: item.product?.name,
        price: item.product?.price,
        images: item.product?.images
      },
      quantity: item.quantity,
      total: item.total
    })),
    createdAt: order.createdAt,
    updatedAt: order.updatedAt
  };

  return res.status(200).json({
    status: 'success',
    data: orderDetails
  });
});

// Get user details with comprehensive information
export const getUserDetails = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { id } = req.params;

  console.log('getUserDetails called with id:', id);

  try {
    // Find the user with comprehensive details
    const user = await User.findById(id)
      .select('-password')
      .lean();

    console.log('User found:', user ? 'Yes' : 'No');
    if (!user) {
      return next(createError('User not found', 404));
    }

    console.log('User role:', user.role);

    // Fetch user's orders
    let orders: PopulatedOrder[] = [];
    try {
      orders = await Order.find({ customer: user._id })
        .populate('vendor', 'firstName lastName email phone')
        .populate('items.product', 'name price images')
        .sort({ createdAt: -1 })
        .limit(10) as unknown as PopulatedOrder[];
      console.log('Orders found:', orders.length);
    } catch (orderError) {
      console.error('Error fetching orders:', orderError);
      orders = [];
    }

    // Fetch user's delivered orders (if user is a delivery agent)
    let deliveredOrders = [];
    if (user.role === 'DELIVERY') {
      try {
        deliveredOrders = await Order.find({ 'delivery.deliveryAgent': user._id })
          .populate('customer', 'firstName lastName email phone')
          .sort({ createdAt: -1 })
          .limit(10) as unknown as PopulatedOrder[];
        console.log('Delivered orders found:', deliveredOrders.length);
      } catch (deliveryError) {
        console.error('Error fetching delivered orders:', deliveryError);
        deliveredOrders = [];
      }
    }

    // Calculate financial information
    const totalOrders = orders.length;
    const totalEarned = orders.reduce((sum, order) => sum + (order.pricing?.total || 0), 0);
    const totalDelivered = deliveredOrders.length;
    
    console.log('Financials calculated:', { totalOrders, totalEarned, totalDelivered });

    // Get real wallet data if user is a vendor
    let financials;
    if (user.role === 'VENDOR') {
      try {
        console.log('Fetching wallet data for vendor:', user._id);
        const walletBalance = await walletService.getVendorBalance(user._id.toString());
        const withdrawalHistory = await walletService.getVendorWithdrawalHistory(user._id.toString());
        
        financials = {
          availableBalance: walletBalance.availableBalance,
          readyForWithdrawal: walletBalance.availableBalance,
          totalEarned: walletBalance.totalEarned,
          allTimeEarnings: walletBalance.totalEarned,
          totalWithdrawn: walletBalance.totalWithdrawn,
          lastWithdrawal: withdrawalHistory.length > 0 && withdrawalHistory[0].processedAt 
            ? withdrawalHistory[0].processedAt 
            : undefined,
          pendingTransactions: walletBalance.pendingBalance > 0 ? 1 : 0
        };
        console.log('Wallet data fetched successfully');
      } catch (error) {
        console.error('Error fetching wallet data:', error);
        // Fallback to calculated values if wallet service fails
        financials = {
          availableBalance: 0,
          readyForWithdrawal: 0,
          totalEarned: totalEarned,
          allTimeEarnings: totalEarned,
          totalWithdrawn: 0,
          lastWithdrawal: undefined,
          pendingTransactions: 0
        };
      }
    } else {
      // For non-vendors, calculate based on order data
      financials = {
        availableBalance: 0,
        readyForWithdrawal: 0,
        totalEarned: totalEarned,
        allTimeEarnings: totalEarned,
        totalWithdrawn: 0,
        lastWithdrawal: undefined,
        pendingTransactions: 0
      };
    }

    // Simplified location info to avoid potential issues
    const locationInfo = {
      ipAddress: '192.168.1.1',
      location: {
        country: 'Ethiopia',
        city: 'Addis Ababa',
        region: 'Addis Ababa',
        coordinates: { 
          latitude: 9.1450, 
          longitude: 40.4897 
        },
        timezone: 'East Africa Time (EAT)',
        continent: 'Africa',
        isUrban: true,
        areaType: user.role === 'VENDOR' ? 'Commercial District' : 'Residential Area',
        landmark: user.role === 'VENDOR' ? 'Near Meskel Square' : 'Near Bole International Airport'
      },
      deviceInfo: {
        type: 'Web',
        browser: 'Chrome',
        os: 'Windows',
        deviceType: 'Desktop',
        platform: 'Windows 10',
        screenResolution: '1920x1080',
        language: 'en-US'
      },
      loginSession: {
        sessionId: 'sess_' + Date.now(),
        loginTime: user.lastLogin || user.createdAt,
        sessionDuration: user.lastLogin ? 
          Math.floor((Date.now() - new Date(user.lastLogin).getTime()) / (1000 * 60)) : 0,
        isActive: user.isOnline || false
      }
    };

    // Simplified activities to avoid potential issues
    const activities = [
      {
        _id: 'reg-' + user._id,
        type: 'registration',
        description: 'User account created',
        timestamp: user.createdAt,
        status: 'completed',
        details: { registrationSource: 'web', ipAddress: locationInfo.ipAddress }
      }
    ];

    // Construct comprehensive user data
    const userDetails = {
      ...user,
      financials,
      activities,
      locationInfo,
      stats: {
        totalOrders,
        totalDelivered,
        averageOrderValue: totalOrders > 0 ? totalEarned / totalOrders : 0
      }
    };

    console.log('User details constructed successfully');

    res.status(200).json({
      status: 'success',
      data: userDetails
    });
  } catch (error) {
    console.error('Error in getUserDetails:', error);
    return next(createError('Failed to fetch user details', 500));
  }
});

// Get user complaints
export const getUserComplaints = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { id } = req.params;

  // Find the user to verify they exist
  const user = await User.findById(id);
  if (!user) {
    return next(createError('User not found', 404));
  }

  // Fetch complaints where the user is either the customer (by name variations) or the vendor (by ID)
  const userFullName = user.firstName + ' ' + user.lastName;
  const complaints = await Complaint.find({
    $or: [
      { customerName: userFullName },                    // User is the customer who complained
      { customerName: user.firstName },                  // User is the customer (first name)
      { customerName: user.lastName },                   // User is the customer (last name)
      { customerName: { $regex: user.firstName, $options: 'i' } }, // User is the customer (contains first name)
      { vendorId: user._id.toString() }                  // User is the vendor whose product was complained about
    ]
  })
  .sort({ createdAt: -1 });

  // Manually populate order and customer data since orderId is a String
  const complaintsWithOrderData = await Promise.all(
    complaints.map(async (complaint: any) => {
      try {
        // Find the order using the orderId string
        const order = await Order.findById(complaint.orderId)
          .populate('customer', 'firstName lastName email');
        
        return {
          ...complaint.toObject(),
          orderId: order // Replace orderId string with populated order object
        };
      } catch (error) {
        console.error('Error populating order for complaint:', complaint._id, error);
        return {
          ...complaint.toObject(),
          orderId: null // Set to null if order not found
        };
      }
    })
  );

  // Log for debugging
  console.log(`Found ${complaints.length} complaints for user ${user._id} (${user.role})`);
  console.log('User full name:', userFullName);
  
  if (complaintsWithOrderData.length > 0) {
    console.log('Complaint details:');
    complaintsWithOrderData.forEach((c: any, index: number) => {
      const buyerName = c.orderId?.customer ? 
        `${c.orderId.customer.firstName} ${c.orderId.customer.lastName}` : 
        c.customerName || 'Unknown';
      console.log(`  ${index + 1}. Vendor: ${c.vendorId}, Buyer: ${buyerName}, Product: ${c.productName}`);
      console.log(`      Order ID: ${c.orderId?._id || 'Not found'}, Customer populated: ${c.orderId?.customer ? 'Yes' : 'No'}`);
    });
  }

  res.status(200).json({
    status: 'success',
    data: complaintsWithOrderData
  });
});

// Get user orders
export const getUserOrders = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { id } = req.params;

  // Find the user to verify they exist
  const user = await User.findById(id);
  if (!user) {
    return next(createError('User not found', 404));
  }

  // Fetch orders for this user (as customer)
  const orders = await Order.find({ customer: user._id })
    .populate('vendor', 'firstName lastName email')
    .sort({ createdAt: -1 });

  // Transform orders to match expected response format
  const transformedOrders = orders.map((order: any) => ({
    id: order._id,
    totalAmount: order.pricing?.total || 0,
    status: order.status || 'pending',
    createdAt: order.createdAt,
    orderNumber: order.orderNumber,
    vendor: order.vendor ? {
      name: `${order.vendor.firstName} ${order.vendor.lastName}`,
      email: order.vendor.email
    } : null
  }));

  console.log(`Found ${orders.length} orders for user ${user._id}`);

  res.status(200).json({
    status: 'success',
    orders: transformedOrders
  });
});

// Get user transactions
export const getUserTransactions = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { id } = req.params;
  
  if (!mongoose.Types.ObjectId.isValid(id)) {
    return next(createError('Invalid user ID format', 400));
  }

  const user = await User.findById(id);
  if (!user) {
    return next(createError('User not found', 404));
  }

  // Fetch payments for this user (using 'customer' field instead of 'user')
  const payments = await Payment.find({ customer: user._id })
    .populate('order', 'orderNumber')
    .sort({ createdAt: -1 });

  // Get earnings data if user is a vendor
  let totalEarned = 0;
  if (user.role === 'VENDOR') {
    try {
      const walletBalance = await walletService.getVendorWallet(user._id.toString());
      totalEarned = walletBalance.totalEarned || 0;
    } catch (error) {
      console.error('Error fetching vendor wallet:', error);
      // Fallback to 0 if wallet service fails
    }
  }

  // Transform payments to match expected transaction response format
  const transformedTransactions = payments.map((payment: any) => ({
    id: payment._id,
    amount: payment.amount?.total || 0,
    status: payment.status?.toLowerCase() || 'pending',
    paymentMethod: payment.method || 'chapa',
    createdAt: payment.createdAt,
    orderNumber: payment.order?.orderNumber || 'N/A',
    reference: payment.reference
  }));

  console.log(`Found ${payments.length} transactions for user ${user._id}`);

  res.status(200).json({
    status: 'success',
    transactions: transformedTransactions,
    earnings: {
      totalEarned,
      role: user.role
    }
  });
});

// Get admin profile
export const getAdminProfile = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const adminId = req.user?._id;
  
  if (!adminId) {
    return next(createError('Admin not authenticated', 401));
  }

  const admin = await User.findById(adminId).select('-password');
  
  if (!admin) {
    return next(createError('Admin not found', 404));
  }

  if (admin.role !== 'ADMIN') {
    return next(createError('Access denied. Admin role required.', 403));
  }

  return res.status(200).json({
    status: 'success',
    data: {
      _id: admin._id,
      firstName: admin.firstName,
      lastName: admin.lastName,
      email: admin.email,
      role: admin.role,
      isActive: admin.isActive,
      createdAt: admin.createdAt,
      updatedAt: admin.updatedAt
    }
  });
});

// Update admin profile
export const updateAdminProfile = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const adminId = req.user?._id;
  const { firstName, lastName, email, phone, profilePhoto } = req.body;
  
  if (!adminId) {
    return next(createError('Admin not authenticated', 401));
  }

  // Validate required fields
  if (!firstName?.trim()) {
    return next(createError('First name is required', 400));
  }
  if (!lastName?.trim()) {
    return next(createError('Last name is required', 400));
  }
  if (!email?.trim()) {
    return next(createError('Email is required', 400));
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return next(createError('Please enter a valid email address', 400));
  }

  // Check if email is already taken by another user
  const existingUser = await User.findOne({ 
    email: email.trim(), 
    _id: { $ne: adminId } 
  });
  
  if (existingUser) {
    return next(createError('Email is already taken by another user', 400));
  }

  const admin = await User.findById(adminId);
  
  if (!admin) {
    return next(createError('Admin not found', 404));
  }

  if (admin.role !== 'ADMIN') {
    return next(createError('Access denied. Admin role required.', 403));
  }

  // Validate phone if provided
  if (phone && phone.trim()) {
    if (!/^(?:\+251|0)?[97]\d{8}$/.test(phone.trim())) {
      return next(createError('Please enter a valid Ethiopian phone number', 400));
    }
    
    // Check if phone is already taken by another user
    const existingPhoneUser = await User.findOne({ 
      phone: phone.trim(), 
      _id: { $ne: adminId } 
    });
    
    if (existingPhoneUser) {
      return next(createError('Phone number is already taken by another user', 400));
    }
  }

  // Update only the fields that are provided
  if (firstName?.trim()) {
    admin.firstName = firstName.trim();
  }
  if (lastName?.trim()) {
    admin.lastName = lastName.trim();
  }
  if (email?.trim()) {
    admin.email = email.trim();
  }
  if (phone?.trim()) {
    admin.phone = phone.trim();
  }
  if (profilePhoto) {
    admin.profileImage = profilePhoto;
  }

  // Don't trigger validation for bank fields if they're not being updated
  // Use save with validateBeforeSave: false for partial updates
  await admin.save({ validateBeforeSave: false });

  return res.status(200).json({
    status: 'success',
    message: 'Profile updated successfully',
    data: {
      _id: admin._id,
      firstName: admin.firstName,
      lastName: admin.lastName,
      email: admin.email,
      phone: admin.phone,
      profilePhoto: admin.profileImage,
      role: admin.role,
      createdAt: admin.createdAt,
      updatedAt: admin.updatedAt
    }
  });
});

// Change admin password
export const changeAdminPassword = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const adminId = req.user?._id;
  const { currentPassword, newPassword } = req.body;
  
  if (!adminId) {
    return next(createError('Admin not authenticated', 401));
  }

  // Validate required fields
  if (!currentPassword) {
    return next(createError('Current password is required', 400));
  }
  if (!newPassword) {
    return next(createError('New password is required', 400));
  }
  if (newPassword.length < 6) {
    return next(createError('New password must be at least 6 characters long', 400));
  }

  const admin = await User.findById(adminId).select('+password'); // Explicitly include password
  
  if (!admin) {
    return next(createError('Admin not found', 404));
  }

  if (admin.role !== 'ADMIN') {
    return next(createError('Access denied. Admin role required.', 403));
  }

  // Check if admin has a password
  if (!admin.password) {
    return next(createError('Admin account is not properly configured. Please contact support.', 500));
  }

  // Verify current password
  try {
    const isMatch = await bcrypt.compare(currentPassword, admin.password);
    
    if (!isMatch) {
      return next(createError('Current password is incorrect', 400));
    }
  } catch (compareError: any) {
    const errorMessage = compareError?.message || compareError?.toString || 'Unknown error';
    return next(createError('Error verifying password: ' + errorMessage, 500));
  }

  // Hash and update new password
  admin.password = await bcrypt.hash(newPassword, 10);
  
  try {
    // Use save with validateBeforeSave: false to bypass bank field validation
    await admin.save({ validateBeforeSave: false });
  } catch (saveError: any) {
    return next(createError('Error saving password: ' + (saveError?.message || saveError?.toString || 'Unknown error'), 500));
  }

  return res.status(200).json({
    status: 'success',
    message: 'Password changed successfully'
  });
});

// Set admin password (temporary fix)
export const setAdminPassword = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const adminId = req.user?._id;
  const { newPassword } = req.body;
  
  if (!adminId) {
    return next(createError('Admin not authenticated', 401));
  }
  
  if (!newPassword) {
    return next(createError('New password is required', 400));
  }
  
  if (newPassword.length < 6) {
    return next(createError('New password must be at least 6 characters long', 400));
  }

  const admin = await User.findById(adminId).select('+password');
  
  if (!admin) {
    return next(createError('Admin not found', 404));
  }

  if (admin.role !== 'ADMIN') {
    return next(createError('Access denied. Admin role required.', 403));
  }

  // Hash and set new password
  admin.password = await bcrypt.hash(newPassword, 10);
  
  try {
    await admin.save({ validateBeforeSave: false });
  } catch (saveError: any) {
    return next(createError('Error setting password: ' + (saveError?.message || saveError?.toString || 'Unknown error'), 500));
  }

  return res.status(200).json({
    status: 'success',
    message: 'Admin password set successfully'
  });
});

// Test bcrypt functionality
export const testBcrypt = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { testPassword, hashPassword } = req.body;
  
  if (!testPassword || !hashPassword) {
    return next(createError('Test password and hash are required', 400));
  }

  try {
    // Test comparison
    const isMatch = await bcrypt.compare(testPassword, hashPassword);
    
    // Test hashing
    const newHash = await bcrypt.hash(testPassword, 10);
    
    return res.status(200).json({
      status: 'success',
      data: {
        isMatch,
        newHash
      }
    });
  } catch (error: any) {
    const errorMessage = (error as any)?.message || (error as any)?.toString || 'Unknown error';
    return next(createError('Bcrypt test error: ' + errorMessage, 500));
  }
});
