import { Request, Response, NextFunction } from 'express';
import Order, { IOrder } from '../models/Order';
import Product from '../models/Product';
import User, { IUser } from '../models/User';
import QuickOrder from '../models/QuickOrder';

// Geocoding helper function
const geocodeAddress = async (address: any): Promise<{ latitude: number; longitude: number } | null> => {
  try {
    // For production, implement Google Maps Geocoding API
    // For now, return dummy coordinates for Addis Ababa
    if (address?.city?.toLowerCase().includes('addis')) {
      return {
        latitude: 9.1450,
        longitude: 40.4897
      };
    }
    
    // TODO: Implement actual geocoding service
    // This should use Google Maps Geocoding API or similar service
    // to convert address to lat/lng coordinates
    console.warn('Geocoding not implemented for address:', address);
    return null;
  } catch (error) {
    console.error('Geocoding error:', error);
    return null;
  }
};

declare global {
  namespace Express {
    interface Request {
      user?: IUser;
    }
  }
}

// Create new order
export const createOrder = async (req: Request, res: Response, next: NextFunction) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }

    const { productId, quantity, deliveryAddress, orderNotes, paymentStatus, requiresDelivery, deliveryFee, subtotal, totalAmount } = req.body;

    // Validate required fields
    if (!productId || !quantity) {
      return res.status(400).json({
        success: false,
        message: 'Product ID and quantity are required'
      });
    }

    // CRITICAL: Validate delivery address for geocoding
    if (requiresDelivery && (!deliveryAddress?.street || !deliveryAddress?.city)) {
      return res.status(400).json({
        success: false,
        message: 'Street and city are required for delivery orders'
      });
    }

    // Allow order creation before payment (for Chapa integration)
    // Payment will be processed after order is created

    // Get product details
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    // Stock validation - prevent overselling
    if (product.quantity < parseInt(quantity)) {
      return res.status(400).json({
        success: false,
        message: "Product out of stock",
        availableStock: product.quantity,
        requestedQuantity: parseInt(quantity)
      });
    }

    // GEOCODING: Convert delivery address to coordinates
    let coordinates = null;
    if (requiresDelivery && deliveryAddress) {
      try {
        // For this implementation, we'll use a simple geocoding approach
        // In production, you should use Google Maps Geocoding API or similar service
        coordinates = await geocodeAddress(deliveryAddress);
        
        if (!coordinates) {
          return res.status(400).json({
            success: false,
            message: 'Unable to geocode delivery address. Please provide a valid address.'
          });
        }
      } catch (geocodeError) {
        console.error('Geocoding error:', geocodeError);
        return res.status(400).json({
          success: false,
          message: 'Failed to geocode delivery address'
        });
      }
    }

    // Create order with proper schema structure
    const order = await Order.create({
      orderNumber: 'ORD' + Date.now() + Math.random().toString(36).substr(2, 9).toUpperCase(),
      customer: req.user.id,
      vendor: product.vendor,
      items: [{
        product: productId,
        quantity: parseInt(quantity),
        price: product.price,
        notes: orderNotes || `Order for ${product.name}`
      }],
      status: 'PENDING',
      priority: 'NORMAL',
      delivery: {
        address: {
          street: deliveryAddress?.street || 'Default Address',
          city: deliveryAddress?.city || 'Addis Ababa',
          county: deliveryAddress?.county || 'Addis Ababa',
          landmark: deliveryAddress?.landmark || '',
          instructions: deliveryAddress?.instructions || '',
          coordinates: coordinates // ✅ SAVED COORDINATES
        },
        estimatedTime: new Date(Date.now() + 24 * 60 * 60 * 1000), //24 hours from now
        deliveryFee: deliveryFee || 0,
        distance: 0 // Will be calculated later
      },
      pricing: {
        subtotal: subtotal || (product.price * parseInt(quantity)),
        deliveryFee: deliveryFee || 0,
        serviceFee: 0, // Set to 0 to match frontend calculation
        tax: 0, // Set to 0 to match frontend calculation
        total: totalAmount || ((product.price * parseInt(quantity)) + (deliveryFee || 0)),
        currency: 'ETB'
      },
      payment: {
        method: 'BANK_TRANSFER', // Default to bank transfer
        status: paymentStatus || 'PENDING' // Default to pending status
      },
      deliveryRequired: requiresDelivery || false,
      notes: orderNotes,
      specialInstructions: deliveryAddress?.instructions || '',
      estimatedDeliveryTime: new Date(Date.now() + 24 * 60 * 60 * 1000)
    });

    // Update product stock
    await Product.findByIdAndUpdate(productId, {
      $inc: { 'stock.quantity': -parseInt(quantity) }
    });
    
    // Also update the simple quantity field
    await Product.findByIdAndUpdate(productId, {
      $inc: { quantity: -parseInt(quantity) }
    });

    // Populate order details for response
    const populatedOrder = await Order.findById(order._id)
      .populate('customer', 'firstName lastName email')
      .populate('vendor', 'firstName lastName email')
      .populate('items.product', 'name price images');

    return res.status(201).json({
      success: true,
      message: 'Order created successfully',
      data: { order: populatedOrder }
    });
  } catch (error: any) {
    console.error('Error creating order:', error);
    
    // Log detailed error information
    if (error.name === 'ValidationError') {
      console.error('Validation errors:', error.errors);
    }
    
    return res.status(500).json({
      success: false,
      message: error.message || 'Failed to create order',
      error: process.env.NODE_ENV === 'development' ? error.errors : undefined
    });
  }
};
