import { Request, Response, NextFunction } from 'express';
import { UserActivity } from '../models/UserActivity';
import mongoose from 'mongoose';

interface ActivityPayload {
  action: 'search_product' | 'view_product' | 'like_product' | 'add_to_cart' | 'place_order' | 'view_category';
  productId?: string;
  productName?: string;
  category?: string;
  shopId?: string;
  keyword?: string;
  viewDuration?: number;
}

export const trackActivity = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = (req as any).user?.id;
    
    if (!userId) {
      res.status(401).json({ 
        success: false, 
        message: 'User authentication required' 
      });
      return;
    }

    const payload: ActivityPayload = req.body;

    // Validate required fields based on action type
    const { action, productId, productName, category, shopId, keyword, viewDuration } = payload;

    // Basic validation
    if (!action || !['search_product', 'view_product', 'like_product', 'add_to_cart', 'place_order', 'view_category'].includes(action)) {
      res.status(400).json({ 
        success: false, 
        message: 'Invalid action type' 
      });
      return;
    }

    // Action-specific validations
    if (['view_product', 'like_product', 'add_to_cart', 'place_order'].includes(action) && !productId) {
      res.status(400).json({ 
        success: false, 
        message: 'Product ID is required for this action' 
      });
      return;
    }

    if (action === 'search_product' && !keyword) {
      res.status(400).json({ 
        success: false, 
        message: 'Keyword is required for search_product action' 
      });
      return;
    }

    if (action === 'view_category' && !category) {
      res.status(400).json({ 
        success: false, 
        message: 'Category is required for view_category action' 
      });
      return;
    }

    // Create activity record
    const activityData: any = {
      userId: new mongoose.Types.ObjectId(userId),
      action,
      createdAt: new Date()
    };

    // Add optional fields if provided
    if (productId) activityData.productId = new mongoose.Types.ObjectId(productId);
    if (productName) activityData.productName = productName;
    if (category) activityData.category = category;
    if (shopId) activityData.shopId = new mongoose.Types.ObjectId(shopId);
    if (keyword) activityData.keyword = keyword;
    if (viewDuration !== undefined) activityData.viewDuration = viewDuration;

    const activity = new UserActivity(activityData);
    await activity.save();

    res.status(201).json({ 
      success: true, 
      message: 'Activity tracked successfully',
      data: activity
    });

  } catch (error) {
    console.error('Error tracking activity:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Internal server error' 
    });
  }
};
