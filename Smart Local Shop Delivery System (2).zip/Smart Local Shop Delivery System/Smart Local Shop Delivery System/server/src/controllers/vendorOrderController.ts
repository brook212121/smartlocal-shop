import { Request, Response, NextFunction } from 'express';
import Order from '../models/Order';
import QuickOrder from '../models/QuickOrder';
import VendorResponse from '../models/VendorResponse';
import User from '../models/User';
import { catchAsync, createError } from '../middleware/errorHandler';

// GET /vendor/orders - Get vendor's orders
export const getVendorOrders = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const vendorId = req.user?._id;
  if (!vendorId) {
    return next(createError('Vendor not authenticated', 401));
  }

  const orders = await Order.find({ vendorId })
    .populate({
      path: 'customer',
      select: 'firstName lastName email',
      model: User
    })
    .populate('items.product', 'name price')
    .sort({ createdAt: -1 });

  res.status(200).json({
    status: 'success',
    results: orders.length,
    data: {
      orders
    }
  });
});

// PUT /orders/:id/accept - Vendor accepts order
export const acceptOrder = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { id } = req.params;
  const vendorId = req.user?._id;

  if (!vendorId) {
    return next(createError('Vendor not authenticated', 401));
  }

  const order = await Order.findById(id);
  if (!order) {
    return next(createError('Order not found', 404));
  }

  // Check if order belongs to this vendor
  if (order.vendor.toString() !== vendorId.toString()) {
    return next(createError('Not authorized to accept this order', 403));
  }

  // Update order status
  order.status = 'CONFIRMED';
  await order.save();

  const populatedOrder = await Order.findById(id)
    .populate({
      path: 'customer',
      select: 'firstName lastName email',
      model: User
    })
    .populate('items.product', 'name price')
    .exec();

  res.status(200).json({
    status: 'success',
    message: 'Order accepted successfully',
    data: {
      order: populatedOrder
    }
  });
});

// POST /orders/from-quick-order - Create order from quick order with selected vendor
export const createOrderFromQuickOrder = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { quickOrderId, vendorId, agreedPrice, customerLocation } = req.body;

  // Validate required fields
  if (!quickOrderId || !vendorId || !agreedPrice) {
    return next(createError('Quick order ID, vendor ID, and agreed price are required', 400));
  }

  // Get customer ID from authenticated user
  const customerId = req.user?._id;
  if (!customerId) {
    return next(createError('User not authenticated', 401));
  }

  // Fetch customer data to get default address
  const customer = await User.findById(customerId);
  if (!customer) {
    return next(createError('Customer not found', 404));
  }

  // Check if quick order exists and belongs to customer
  const quickOrder = await QuickOrder.findById(quickOrderId);
  if (!quickOrder) {
    return next(createError('Quick order not found', 404));
  }

  if (quickOrder.customerId.toString() !== customerId.toString()) {
    return next(createError('Not authorized to create order from this quick order', 403));
  }

  // Check if vendor response exists
  const vendorResponse = await VendorResponse.findOne({
    quickOrderId,
    vendorId
  });

  if (!vendorResponse) {
    return next(createError('Vendor response not found', 404));
  }

  // Update vendor response status
  vendorResponse.status = 'ACCEPTED';
  await vendorResponse.save();

  // Create order from quick order and vendor response
  const order = await Order.create({
    orderNumber: `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
    customer: customerId,
    vendor: vendorId,
    quickOrderId: quickOrderId,
    productName: `Quick Order: ${quickOrder.description.substring(0, 50)}...`,
    quantity: quickOrder.quantity || 1,
    price: parseFloat(agreedPrice),
    status: 'PENDING',
    customerName: `${customer.firstName} ${customer.lastName}`,
    customerPhone: customer.phone,
    customerAddress: customer.defaultAddress ? 
      `Customer location: ${customer.defaultAddress.coordinates?.lat || 'N/A'}, ${customer.defaultAddress.coordinates?.lng || 'N/A'}` : 
      'Customer address not provided',
    deliveryAddress: customerLocation ? {
      coordinates: {
        latitude: customerLocation.latitude,
        longitude: customerLocation.longitude
      }
    } : customer.defaultAddress ? {
      coordinates: customer.defaultAddress.coordinates
    } : '', // Use customer location or default address for delivery
    totalAmount: parseFloat(agreedPrice) * (quickOrder.quantity || 1),
    items: [{
      product: null, // Will be updated when product is linked
      quantity: quickOrder.quantity || 1,
      price: parseFloat(agreedPrice)
    }]
  });

  // Update quick order status to FULFILLED
  quickOrder.status = 'FULFILLED';
  await quickOrder.save();

  const populatedOrder = await Order.findById(order._id)
    .populate('customer', 'firstName lastName email phone')
    .populate('vendor', 'firstName lastName email phone')
    .populate('items.product', 'name price')
    .exec();

  res.status(201).json({
    status: 'success',
    message: 'Order created successfully from quick order',
    data: populatedOrder
  });
});
