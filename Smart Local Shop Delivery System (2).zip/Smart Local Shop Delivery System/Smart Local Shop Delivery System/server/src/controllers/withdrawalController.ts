import { Request, Response, NextFunction } from 'express';
import walletService from '../services/walletService';
import Withdrawal from '../models/Withdrawal';
import VendorWallet from '../models/VendorWallet';

// Create withdrawal request
export const createWithdrawalRequest = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { amount, withdrawalMethod } = req.body;
    const vendorId = req.user?.id;

    if (!amount || !withdrawalMethod) {
      return res.status(400).json({
        status: 'error',
        message: 'Amount and withdrawal method are required'
      });
    }

    // Validate withdrawal method
    const { type, bankName, accountNumber, phoneNumber, accountHolderName } = withdrawalMethod;
    
    if (!type || !accountHolderName) {
      return res.status(400).json({
        status: 'error',
        message: 'Withdrawal method type and account holder name are required'
      });
    }

    if (type === 'BANK_TRANSFER' && (!bankName || !accountNumber)) {
      return res.status(400).json({
        status: 'error',
        message: 'Bank name and account number are required for bank transfer'
      });
    }

    if (type === 'MOBILE_MONEY' && !phoneNumber) {
      return res.status(400).json({
        status: 'error',
        message: 'Phone number is required for mobile money'
      });
    }

    // Get vendor wallet
    const vendorWallet = await walletService.getVendorWallet(vendorId);
    
    // Check available balance
    if (vendorWallet.availableBalance < amount) {
      return res.status(400).json({
        status: 'error',
        message: 'Insufficient available balance'
      });
    }

    // Calculate withdrawal fee (2% for bank transfer, 1% for mobile money)
    const feePercentage = type === 'BANK_TRANSFER' ? 0.02 : 0.01;
    const fee = amount * feePercentage;
    const netAmount = amount - fee;

    // Create withdrawal request
    const withdrawal = await Withdrawal.create({
      vendorId,
      amount,
      withdrawalMethod: {
        type,
        bankName,
        accountNumber,
        phoneNumber,
        accountHolderName
      },
      fee,
      netAmount
    });

    // Process withdrawal (auto-approval)
    const processedWithdrawal = await walletService.processWithdrawal(withdrawal._id.toString());

    res.status(201).json({
      status: 'success',
      message: processedWithdrawal.status === 'PAID_OUT' 
        ? 'Withdrawal processed successfully' 
        : 'Withdrawal request submitted',
      data: {
        withdrawal_id: processedWithdrawal._id,
        amount: processedWithdrawal.amount,
        fee: processedWithdrawal.fee,
        net_amount: processedWithdrawal.netAmount,
        status: processedWithdrawal.status,
        auto_approved: processedWithdrawal.autoApproved,
        rejection_reason: processedWithdrawal.rejectionReason
      }
    });

    return;

  } catch (error: any) {
    console.error('Create withdrawal request error:', error);
    return res.status(500).json({
      status: 'error',
      message: error.message || 'Failed to create withdrawal request'
    });
  }
};

// Get vendor withdrawal history
export const getVendorWithdrawalHistory = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const vendorId = req.user?.id;
    
    const withdrawals = await walletService.getVendorWithdrawalHistory(vendorId);

    res.status(200).json({
      status: 'success',
      data: withdrawals.map(withdrawal => ({
        withdrawal_id: withdrawal._id,
        amount: withdrawal.amount,
        fee: withdrawal.fee,
        net_amount: withdrawal.netAmount,
        status: withdrawal.status,
        withdrawal_method: withdrawal.withdrawalMethod,
        auto_approved: withdrawal.autoApproved,
        rejection_reason: withdrawal.rejectionReason,
        created_at: withdrawal.createdAt,
        processed_at: withdrawal.processedAt,
        paid_out_at: withdrawal.paidOutAt,
        settlement_reference: withdrawal.settlementReference
      }))
    });

  } catch (error: any) {
    console.error('Get withdrawal history error:', error);
    res.status(500).json({
      status: 'error',
      message: error.message || 'Failed to get withdrawal history'
    });
  }
};

// Get vendor wallet balance
export const getVendorWalletBalance = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    console.log(`🔍 CONTROLLER DEBUG: Starting wallet balance request`);
    
    const vendorId = req.user?.id;
    console.log(`🔍 CONTROLLER DEBUG: Getting wallet balance for vendor ${vendorId}`);
    
    if (!vendorId) {
      console.log(`🔍 CONTROLLER ERROR: No vendorId found in request`);
      res.status(401).json({
        status: 'error',
        message: 'Vendor ID required'
      });
      return;
    }
    
    console.log(`🔍 CONTROLLER DEBUG: About to call walletService.getVendorBalance`);
    const balance = await walletService.getVendorBalance(vendorId);
    console.log(`🔍 CONTROLLER DEBUG: Balance retrieved successfully:`, balance);

    console.log(`🔍 CONTROLLER DEBUG: Sending response`);
    res.status(200).json({
      status: 'success',
      data: balance
    });
    console.log(`🔍 CONTROLLER DEBUG: Response sent successfully`);

  } catch (error: any) {
    console.error('🔍 CONTROLLER ERROR: Get wallet balance error:', error);
    console.error('🔍 CONTROLLER ERROR: Error stack:', error.stack);
    console.error('🔍 CONTROLLER ERROR: Error message:', error.message);
    console.error('🔍 CONTROLLER ERROR: Error name:', error.name);
    
    res.status(500).json({
      status: 'error',
      message: error.message || 'Failed to get wallet balance'
    });
  }
};

// Get all withdrawals (admin only)
export const getAllWithdrawals = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const withdrawals = await walletService.getAllWithdrawals();

    res.status(200).json({
      status: 'success',
      data: withdrawals.map(withdrawal => ({
        withdrawal_id: withdrawal._id,
        vendor: {
          id: withdrawal.vendorId,
          name: 'Vendor', // Safe fallback since vendorId is ObjectId
          email: 'vendor@example.com' // Safe fallback since vendorId is ObjectId
        },
        amount: withdrawal.amount,
        fee: withdrawal.fee,
        net_amount: withdrawal.netAmount,
        status: withdrawal.status,
        withdrawal_method: withdrawal.withdrawalMethod,
        auto_approved: withdrawal.autoApproved,
        approval_rules: withdrawal.approvalRules,
        rejection_reason: withdrawal.rejectionReason,
        created_at: withdrawal.createdAt,
        processed_at: withdrawal.processedAt,
        paid_out_at: withdrawal.paidOutAt,
        settlement_reference: withdrawal.settlementReference,
        notes: withdrawal.notes
      }))
    });

    return;

  } catch (error: any) {
    console.error('Get all withdrawals error:', error);
    return res.status(500).json({
      status: 'error',
      message: error.message || 'Failed to get withdrawals'
    });
  }
};

// Get admin wallet balance (admin only)
export const getAdminWalletBalance = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const balance = await walletService.getAdminBalance();

    res.status(200).json({
      status: 'success',
      data: balance
    });

  } catch (error: any) {
    console.error('Get admin wallet balance error:', error);
    res.status(500).json({
      status: 'error',
      message: error.message || 'Failed to get admin wallet balance'
    });
  }
};

// Release held funds (scheduled job)
export const releaseHeldFunds = async (req: Request, res: Response, next: NextFunction) => {
  try {
    // This would typically be called by a cron job
    // For now, we'll allow manual triggering for testing
    const vendorId = req.body.vendorId;
    
    if (vendorId) {
      // Release funds for specific vendor
      await walletService.releaseHeldFunds(vendorId);
      res.status(200).json({
        status: 'success',
        message: 'Held funds released for vendor'
      });
    } else {
      // Release funds for all vendors (admin only)
      // This would require getting all vendors and releasing funds for each
      res.status(400).json({
        status: 'error',
        message: 'Vendor ID is required'
      });
    }

  } catch (error: any) {
    console.error('Release held funds error:', error);
    res.status(500).json({
      status: 'error',
      message: error.message || 'Failed to release held funds'
    });
  }
};
