import { Request, Response, NextFunction } from 'express';
import Order from '../models/Order';
import User from '../models/User';
import { catchAsync, createError } from '../middleware/errorHandler';

// Get orders assigned to delivery agent
export const getDeliveryOrders = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  console.log("🚚 Delivery orders route hit - fetching assigned orders");
  const deliveryAgentId = req.user?._id;
  
  console.log("🔍 Delivery agent ID:", deliveryAgentId);
  
  if (!deliveryAgentId) {
    console.log("❌ Delivery agent not authenticated");
    return next(createError('Delivery agent not authenticated', 401));
  }

  // Find orders assigned to this delivery agent
  const orders = await Order.find({ 
    'delivery.deliveryAgent': deliveryAgentId,
    deliveryStatus: { $in: ['ASSIGNED', 'PICKED_UP', 'OUT_FOR_DELIVERY', 'DELIVERED'] }
  })
    .populate('customer', 'firstName lastName email phone')
    .populate('vendor', 'firstName lastName email phone')
    .populate({
      path: 'items.product',
      model: 'Product',
      select: 'name price images'
    })
    .sort({ createdAt: -1 });

  console.log('🔍 Debug - Found orders:', orders.length);
  
  if (orders.length > 0) {
    const sampleOrder = orders[0];
    console.log('🔍 Debug - Sample order structure:', {
      id: sampleOrder._id,
      orderNumber: sampleOrder.orderNumber,
      deliveryStatus: sampleOrder.deliveryStatus,
      itemCount: sampleOrder.items?.length || 0,
      hasItems: !!sampleOrder.items,
      firstItem: sampleOrder.items?.[0] ? {
        quantity: sampleOrder.items[0].quantity,
        hasProduct: !!sampleOrder.items[0].product,
        productId: (sampleOrder.items[0].product as any)?._id,
        productName: (sampleOrder.items[0].product as any)?.name,
        productPrice: (sampleOrder.items[0].product as any)?.price,
        productImages: (sampleOrder.items[0].product as any)?.images,
        imageCount: ((sampleOrder.items[0].product as any)?.images?.length) || 0
      } : null
    });
  }

  res.status(200).json({
    success: true,
    results: orders.length,
    data: {
      orders
    }
  });
});

// Update delivery status
export const updateDeliveryStatus = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { deliveryStatus } = req.body;
  const deliveryAgentId = req.user?._id;
  const orderId = req.params.id;

  if (!deliveryAgentId) {
    return next(createError('Delivery agent not authenticated', 401));
  }

  if (!['PICKED_UP', 'DELIVERED'].includes(deliveryStatus)) {
    return next(createError('Invalid delivery status', 400));
  }

  // Find the order assigned to this delivery agent
  const order = await Order.findOne({ 
    _id: orderId,
    'delivery.deliveryAgent': deliveryAgentId
  });

  if (!order) {
    return next(createError('Order not found or not assigned to you', 404));
  }

  // Update delivery status and order status
  order.deliveryStatus = deliveryStatus;
  
  if (deliveryStatus === 'PICKED_UP') {
    order.status = 'OUT_FOR_DELIVERY';
  } else if (deliveryStatus === 'DELIVERED') {
    order.status = 'DELIVERED';
  }

  await order.save();

  res.status(200).json({
    success: true,
    message: 'Delivery status updated successfully',
    data: {
      order
    }
  });
});

// Get single delivery order by ID
export const getDeliveryOrderById = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { id } = req.params;
  const deliveryAgentId = req.user?._id;
  
  if (!deliveryAgentId) {
    return next(createError('Delivery agent not authenticated', 401));
  }

  // Find order assigned to this delivery agent
  const order = await Order.findOne({ 
    _id: id,
    'delivery.deliveryAgent': deliveryAgentId
  })
  .populate('customer', 'firstName lastName email phone')
  .populate('vendor', 'firstName lastName email phone')
  .populate({
    path: 'items.product',
    model: 'Product',
    select: 'name price images'
  });

  if (!order) {
    return res.status(404).json({
      success: false,
      message: 'Order not found or not assigned to this delivery agent'
    });
  }

  res.status(200).json({
    success: true,
    data: order
  });
});

// Get delivery statistics
export const getDeliveryStats = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const deliveryAgentId = req.user?._id;
  
  if (!deliveryAgentId) {
    return next(createError('Delivery agent not authenticated', 401));
  }

  // Get all orders for this delivery agent
  const allOrders = await Order.find({ 'delivery.deliveryAgent': deliveryAgentId });
  
  // Calculate statistics
  const assignedOrders = allOrders.filter(order => 
    ['READY_FOR_PICKUP', 'OUT_FOR_DELIVERY'].includes(order.status)
  ).length;
  
  const deliveredOrders = allOrders.filter(order => 
    order.status === 'DELIVERED'
  ).length;

  res.status(200).json({
    success: true,
    data: {
      assignedOrders,
      deliveredOrders,
      totalOrders: allOrders.length
    }
  });
});
