import { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import mongoose, { Types } from 'mongoose';
import User, { IUser } from '../models/User';
import { catchAsync, createError } from '../middleware/errorHandler';
import { sendPasswordResetEmail, sendVerificationEmail } from '../config/email';

// Generate JWT token
const generateToken = (id: string): string => {
  return jwt.sign({ id }, process.env.JWT_SECRET!, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  } as jwt.SignOptions);
};

// Register user
export const register = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { firstName, lastName, email, phone, password, bankName, accountNumber, role, termsAccepted } = req.body;

  // Trim all string inputs to remove extra spaces
  const trimmedData = {
    firstName: firstName?.trim(),
    lastName: lastName?.trim(),
    email: email?.trim(),
    phone: phone?.trim(),
    password: password?.trim(),
    bankName: bankName?.trim(),
    accountNumber: accountNumber?.trim(),
    role: role?.trim(),
    termsAccepted
  };

  // Validation errors array
  const errors: string[] = [];

  // 1. Full Name Validation
  if (!trimmedData.firstName || !trimmedData.lastName) {
    errors.push('First name and last name are required');
  } else {
    // First name validation
    if (trimmedData.firstName.length < 3) {
      errors.push('First name must be at least 3 characters long');
    }
    if (!/^[a-zA-Z\s]+$/.test(trimmedData.firstName)) {
      errors.push('First name can only contain letters and spaces');
    }
    
    // Last name validation
    if (trimmedData.lastName.length < 3) {
      errors.push('Last name must be at least 3 characters long');
    }
    if (!/^[a-zA-Z\s]+$/.test(trimmedData.lastName)) {
      errors.push('Last name can only contain letters and spaces');
    }
  }

  // 2. Email Validation
  if (!trimmedData.email) {
    errors.push('Email address is required');
  } else {
    const trimmedEmail = trimmedData.email.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(trimmedEmail)) {
      errors.push('Please provide a valid email address');
    }
    req.body.email = trimmedEmail; // Update with trimmed email
  }

  // 3. Phone Number Validation (Ethiopia Only)
  if (!trimmedData.phone) {
    errors.push('Phone number is required');
  } else {
    const phoneRegex = /^(?:\+251|0)?[97]\d{8}$/;
    if (!phoneRegex.test(trimmedData.phone)) {
      errors.push('Phone number must be a valid Ethiopian number (09XXXXXXXX, 07XXXXXXXX, +2519XXXXXXXX, or +2517XXXXXXXX)');
    }
  }

  // 4. Password Validation
  if (!trimmedData.password) {
    errors.push('Password is required');
  } else {
    if (trimmedData.password.length < 8) {
      errors.push('Password must be at least 8 characters long');
    }
    if (!/[A-Z]/.test(trimmedData.password)) {
      errors.push('Password must contain at least one uppercase letter');
    }
    if (!/[a-z]/.test(trimmedData.password)) {
      errors.push('Password must contain at least one lowercase letter');
    }
    if (!/\d/.test(trimmedData.password)) {
      errors.push('Password must contain at least one number');
    }
    if (/\s/.test(trimmedData.password)) {
      errors.push('Password cannot contain spaces');
    }
  }

  // 5. Role Selection Validation
  const allowedRoles = ['VENDOR', 'DELIVERY'];
  
  if (!trimmedData.role) {
    errors.push('Role selection is required');
  } else if (!allowedRoles.includes(trimmedData.role)) {
    errors.push('Please select a valid role (Vendor or Delivery Agent)');
  }

  // 6. Bank Selection Validation
  const allowedBanks = [
    'Commercial Bank of Ethiopia',
    'Bank of Abyssinia',
    'Awash Bank',
    'Cooperative Bank of Oromia'
  ];
  
  if (!trimmedData.bankName) {
    errors.push('Bank selection is required');
  } else if (!allowedBanks.includes(trimmedData.bankName)) {
    errors.push('Please select a valid bank from the list');
  }

  // 6. Bank Account Number Validation
  if (!trimmedData.accountNumber) {
    errors.push('Bank account number is required');
  } else {
    const accountNumStr = trimmedData.accountNumber.toString();
    if (!/^\d+$/.test(accountNumStr)) {
      errors.push('Bank account number can only contain numbers');
    } else {
      // Bank-specific validation
      switch (trimmedData.bankName) {
        case 'Commercial Bank of Ethiopia':
          if (accountNumStr.length !== 13) {
            errors.push('Commercial Bank of Ethiopia account number must be exactly 13 digits');
          }
          break;
        case 'Bank of Abyssinia':
          if (accountNumStr.length < 8 || accountNumStr.length > 10) {
            errors.push('Bank of Abyssinia account number must be 8-10 digits');
          }
          break;
        case 'Awash Bank':
          if (accountNumStr.length !== 13) {
            errors.push('Awash Bank account number must be exactly 13 digits');
          }
          break;
        case 'Cooperative Bank of Oromia':
          if (accountNumStr.length !== 13) {
            errors.push('Cooperative Bank of Oromia account number must be exactly 13 digits');
          }
          break;
      }
    }
  }

  // 7. Terms & Conditions Validation
  if (!trimmedData.termsAccepted || trimmedData.termsAccepted !== true) {
    errors.push('You must accept the Terms & Conditions to register');
  }

  // If there are validation errors, return them
  if (errors.length > 0) {
    return next(createError(errors.join('; '), 400));
  }

  // Check if user already exists
  const existingUser = await User.findOne({
    $or: [{ email: trimmedData.email }, { phone: trimmedData.phone }]
  });

  if (existingUser) {
    if (existingUser.email === trimmedData.email) {
      return next(createError('Email already registered', 400));
    }
    if (existingUser.phone === trimmedData.phone) {
      return next(createError('Phone number already registered', 400));
    }
  }

  // Create new user with appropriate role and flags (password will be hashed by pre-save middleware)
  const newUser = await User.create({
    firstName: trimmedData.firstName,
    lastName: trimmedData.lastName,
    email: trimmedData.email,
    phone: trimmedData.phone,
    password: trimmedData.password, // Plain password - pre-save middleware will hash it
    bankName: trimmedData.bankName,
    accountNumber: trimmedData.accountNumber,
    role: trimmedData.role,
    isCustomer: trimmedData.role === 'CUSTOMER',
    isVendor: trimmedData.role === 'VENDOR',
    isDelivery: trimmedData.role === 'DELIVERY',
    isActive: true,
    isEmailVerified: true // Auto-verify for now (disabled email verification)
  });

  // Remove password from output
  newUser.password = undefined as any;

  res.status(201).json({
    status: 'success',
    message: 'Registration successful! You can now log in.',
    data: {
      user: {
        id: newUser._id,
        firstName: newUser.firstName,
        lastName: newUser.lastName,
        email: newUser.email,
        role: newUser.role,
        isEmailVerified: newUser.isEmailVerified
      },
      token: generateToken(newUser._id.toString())
    }
  });
});

// Verify email
export const verifyEmail = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { token } = req.params;

  if (!token) {
    return next(createError('Verification token is required', 400));
  }

  // Find user with verification token
  const user = await User.findOne({
    passwordResetToken: token,
    passwordResetExpires: { $gt: Date.now() }
  });

  if (!user) {
    return next(createError('Invalid or expired verification token', 400));
  }

  // Mark email as verified
  user.isEmailVerified = true;
  user.passwordResetToken = undefined;
  user.passwordResetExpires = undefined;
  await user.save({ validateBeforeSave: false });

  res.status(200).json({
    status: 'success',
    message: 'Email verified successfully! You can now log in.',
    data: {
      user: {
        id: user._id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        role: user.role,
        isEmailVerified: user.isEmailVerified
      }
    }
  });
});

// Login user
export const login = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { email, password } = req.body;

  // Trim email and password to remove extra spaces
  const trimmedEmail = email?.trim();
  const trimmedPassword = password?.trim();

  if (!trimmedEmail || !trimmedPassword) {
    return next(createError('Please provide email and password', 400));
  }

  // Get most recently created user with password field
  const searchEmail = trimmedEmail.toLowerCase().trim();
  
  // Find all users with this email and sort by creation date
  const allUsers = await User.find({ email: searchEmail })
    .select('+password')
    .sort({ createdAt: -1 });
  
  if (allUsers.length === 0) {
    return next(createError('Invalid email or password', 401));
  }
  
  // Get the most recent user (first in the sorted array)
  const user = allUsers[0];

  // Check password
  const isPasswordValid = await bcrypt.compare(trimmedPassword, user.password);
  
  if (!isPasswordValid) {
    return next(createError('Invalid email or password', 401));
  }

  // Check if email is verified
  if (!user.isEmailVerified) {
    return next(createError('Please verify your email address before logging in. Check your inbox for the verification link.', 401));
  }

  // Update last login
  user.lastLogin = new Date();
  await user.save({ validateBeforeSave: false });

  // Generate token
  const token = generateToken(user._id.toString());
  
  // Debug: Log token info in development
  if (process.env.NODE_ENV === 'development') {
    console.log('Login - Generated token length:', token.length);
    console.log('Login - Token preview:', token.substring(0, 20) + '...');
    console.log('Login - User ID:', user._id);
  }

  // Remove password from output
  user.password = undefined as any;

  // Optimize login response - return only essential fields
  const optimizedUser = {
    _id: user._id,
    email: user.email,
    firstName: user.firstName,
    lastName: user.lastName,
    role: user.role,
    isCustomer: user.isCustomer,
    isVendor: user.isVendor,
    isDelivery: user.isDelivery,
    isEmailVerified: user.isEmailVerified,
    isActive: user.isActive,
    // Remove heavy fields for faster login
    // locationHistory, preferences, vehicle, etc. moved to separate endpoints
  };

  res.status(200).json({
    status: 'success',
    message: 'Login successful',
    data: {
      user: optimizedUser,
      token
    }
  });
});

// Get current user
export const getMe = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  // User is already attached to req from auth middleware
  const user = (req as any).user;

  if (!user) {
    return next(createError('User not found', 404));
  }

  res.status(200).json({
    status: 'success',
    data: {
      user
    }
  });
});

// Update password
export const updatePassword = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { currentPassword, newPassword } = req.body;

  // Get user with password
  const user = await User.findById((req as any).user?.id).select('+password');

  if (!user) {
    return next(createError('User not found', 404));
  }

  // Check current password
  if (!(await bcrypt.compare(currentPassword, user.password))) {
    return next(createError('Current password is incorrect', 400));
  }

  // Update password
  user.password = newPassword;
  await user.save();

  res.status(200).json({
    status: 'success',
    message: 'Password updated successfully'
  });
});

// Logout (client-side token removal)
export const logout = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  res.status(200).json({
    status: 'success',
    message: 'Logout successful. Please remove token from client storage.'
  });
});

// Forgot password
export const forgotPassword = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { email } = req.body;

  // Find user by email
  const user = await User.findOne({ email });

  if (!user) {
    return next(createError('No user found with that email address', 404));
  }

  // Generate reset token with enhanced security
  const resetToken = crypto.randomBytes(32).toString('hex');
  const resetTokenExpiry = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes for better security
  const resetTokenUsed = false; // Track if token has been used

  // Save reset token to user with additional security fields
  user.passwordResetToken = resetToken;
  user.passwordResetExpires = resetTokenExpiry;
  user.passwordResetUsed = resetTokenUsed; // Add usage tracking
  user.passwordResetRequestedAt = new Date(); // Track when token was requested
  await user.save({ validateBeforeSave: false });

  // Dynamic frontend URL resolution
  const frontendUrl = process.env.FRONTEND_URL || 
                     process.env.NGROK_URL || 
                     req.headers.origin || 
                     'http://localhost:3000';
  
  console.log('🔧 Dynamic Frontend URL Resolution:');
  console.log('  FRONTEND_URL:', process.env.FRONTEND_URL);
  console.log('  NGROK_URL:', process.env.NGROK_URL);
  console.log('  Request Origin:', req.headers.origin);
  console.log('  Final Frontend URL:', frontendUrl);

  try {
    // Send reset email with dynamic URL
    await sendPasswordResetEmail(email, resetToken, frontendUrl);

    res.status(200).json({
      status: 'success',
      message: 'Password reset link sent to your email'
    });
  } catch (error) {
    // If email fails, clear the reset token
    user.passwordResetToken = undefined;
    user.passwordResetExpires = undefined;
    await user.save({ validateBeforeSave: false });

    return next(createError('Failed to send password reset email', 500));
  }
});

// Reset password
export const resetPassword = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  const { token } = req.query;
  const { password } = req.body;

  if (!token) {
    return next(createError('Reset token is required', 400));
  }

  // Find user with valid reset token
  // Find user by reset token with enhanced security validation
  const user = await User.findOne({
    passwordResetToken: token,
    passwordResetExpires: { $gt: Date.now() },
    passwordResetUsed: false // Ensure token hasn't been used
  });

  if (!user) {
    return next(createError('Invalid or expired reset token', 400));
  }

  // Additional security checks
  const now = new Date();
  const requestedAt = user.passwordResetRequestedAt;
  const tokenAge = requestedAt ? now.getTime() - requestedAt.getTime() : 0;
  const maxAge = 5 * 60 * 1000; // 5 minutes

  if (tokenAge > maxAge) {
    return next(createError('Reset token has expired', 400));
  }

  // Mark token as used before updating password
  user.passwordResetUsed = true;
  await user.save({ validateBeforeSave: false });

  // Hash the new password
  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(password, salt);

  // Update only password field without triggering full validation
  await User.findByIdAndUpdate(user._id, {
    password: hashedPassword,
    passwordResetToken: undefined,
    passwordResetExpires: undefined
  }, { 
    new: true, 
    runValidators: false // Skip validation for other fields
  });

  res.status(200).json({
    status: 'success',
    message: 'Password reset successfully'
  });
});

// Upgrade user to vendor status
export const upgradeToVendor = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  // Check if user is authenticated
  if (!req.user) {
    return res.status(401).json({
      success: false,
      message: 'Authentication required'
    });
  }

  // Get user and update to vendor
  const user = await User.findById(req.user.id);
  if (!user) {
    return res.status(404).json({
      success: false,
      message: 'User not found'
    });
  }

  // Update user to vendor status
  user.isVendor = true;
  user.role = 'VENDOR';
  await user.save();

  return res.status(200).json({
    success: true,
    message: 'Account upgraded to vendor status successfully',
    data: {
      user: {
        id: user._id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        role: user.role,
        isVendor: user.isVendor
      }
    }
  });
});

export { generateToken };
