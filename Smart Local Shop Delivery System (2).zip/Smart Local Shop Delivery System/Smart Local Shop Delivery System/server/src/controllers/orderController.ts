import { Request, Response, NextFunction } from 'express';
import Order, { IOrder } from '../models/Order';
import Product from '../models/Product';
import User, { IUser } from '../models/User';
import QuickOrder from '../models/QuickOrder';

declare global {
  namespace Express {
    interface Request {
      user?: IUser;
    }
  }
}

// Create new order
export const createOrder = async (req: Request, res: Response, next: NextFunction) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }

    const { productId, quantity, deliveryAddress, orderNotes, paymentStatus, requiresDelivery, deliveryFee, subtotal, totalAmount } = req.body;

    // Validate required fields
    if (!productId || !quantity) {
      return res.status(400).json({
        success: false,
        message: 'Product ID and quantity are required'
      });
    }

    // CRITICAL: Validate delivery address for geocoding
    if (requiresDelivery && (!deliveryAddress?.street || !deliveryAddress?.city)) {
      return res.status(400).json({
        success: false,
        message: 'Street and city are required for delivery orders'
      });
    }

    // CRITICAL: Validate coordinates exist in request
    if (requiresDelivery && (!deliveryAddress?.coordinates?.latitude || !deliveryAddress?.coordinates?.longitude)) {
      return res.status(400).json({
        success: false,
        message: 'Valid coordinates are required for delivery orders'
      });
    }

    // DEBUG LOG: Log received coordinates
    console.log('Received coordinates:', deliveryAddress?.coordinates);

    // VALIDATE COORDINATES BEFORE SAVE
    const { latitude, longitude } = deliveryAddress?.coordinates || {};
    if (!latitude || !longitude) {
      return res.status(400).json({
        success: false,
        message: 'Invalid coordinates'
      });
    }

    // Allow order creation before payment (for Chapa integration)
    // Payment will be processed after order is created

    // Get product details
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    // Stock validation - prevent overselling
    if (product.quantity < parseInt(quantity)) {
      return res.status(400).json({
        success: false,
        message: "Product out of stock",
        availableStock: product.quantity,
        requestedQuantity: parseInt(quantity)
      });
    }

    // Create order with proper schema structure
    const order = await Order.create({
      orderNumber: 'ORD' + Date.now() + Math.random().toString(36).substr(2, 9).toUpperCase(),
      customer: req.user.id,
      vendor: product.vendor,
      items: [{
        product: productId,
        quantity: parseInt(quantity),
        price: product.price,
        notes: orderNotes || `Order for ${product.name}`
      }],
      status: 'PENDING',
      priority: 'NORMAL',
      delivery: {
        address: {
          street: deliveryAddress?.street || 'Default Address',
          city: deliveryAddress?.city || 'Addis Ababa',
          county: deliveryAddress?.county || 'Addis Ababa',
          landmark: deliveryAddress?.landmark || '',
          instructions: deliveryAddress?.instructions || '',
          coordinates: deliveryAddress?.coordinates // ✅ USE REAL USER COORDINATES
        },
        estimatedTime: new Date(Date.now() + 24 * 60 * 60 * 1000), //24 hours from now
        deliveryFee: deliveryFee || 0,
        distance: 0 // Will be calculated later
      },
      pricing: {
        subtotal: subtotal || (product.price * parseInt(quantity)),
        deliveryFee: deliveryFee || 0,
        serviceFee: 0, // Set to 0 to match frontend calculation
        tax: 0, // Set to 0 to match frontend calculation
        total: totalAmount || ((product.price * parseInt(quantity)) + (deliveryFee || 0)),
        currency: 'ETB'
      },
      payment: {
        method: 'BANK_TRANSFER', // Default to bank transfer
        status: paymentStatus || 'PENDING' // Default to pending status
      },
      deliveryRequired: requiresDelivery || false,
      notes: orderNotes,
      specialInstructions: deliveryAddress?.instructions || '',
      estimatedDeliveryTime: new Date(Date.now() + 24 * 60 * 60 * 1000)
    });

    // Update product stock
    await Product.findByIdAndUpdate(productId, {
      $inc: { 'stock.quantity': -parseInt(quantity) }
    });
    
    // Also update the simple quantity field
    await Product.findByIdAndUpdate(productId, {
      $inc: { quantity: -parseInt(quantity) }
    });

    // Populate order details for response
    const populatedOrder = await Order.findById(order._id)
      .populate('customer', 'firstName lastName email')
      .populate('vendor', 'firstName lastName email phone')
      .populate('items.product', 'name price images');

    return res.status(201).json({
      success: true,
      message: 'Order created successfully',
      data: { order: populatedOrder }
    });
  } catch (error: any) {
    console.error('Error creating order:', error);
    
    // Log detailed error information
    if (error.name === 'ValidationError') {
      console.error('Validation errors:', error.errors);
    }
    
    return res.status(500).json({
      success: false,
      message: error.message || 'Failed to create order',
      error: process.env.NODE_ENV === 'development' ? error.errors : undefined
    });
  }
};

// Get customer's orders
export const getCustomerOrders = async (req: Request, res: Response, next: NextFunction) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }

    const { page = 1, limit = 20, status } = req.query;
    
    // Build query
    const query: any = { customer: req.user.id };
    if (status && status !== 'all') {
      query.status = status;
    }

    // Pagination
    const pageNum = parseInt(page as string);
    const limitNum = parseInt(limit as string);
    const skip = (pageNum - 1) * limitNum;

    // Get orders
    const orders = await Order.find(query)
      .populate('vendor', 'firstName lastName email phone')
      .populate('items.product', 'name price images')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limitNum);

    console.log(`[Orders] Found ${orders.length} orders for customer ${req.user.id}`);
    if (orders.length > 0) {
      console.log(`[Orders] Sample order OTP data:`, {
        orderId: orders[0]._id,
        deliveryOTP: orders[0].deliveryOTP,
        otpSent: orders[0].otpSent,
        otpVerified: orders[0].otpVerified,
        status: orders[0].status
      });
    }

    const total = await Order.countDocuments(query);

    return res.status(200).json({
      success: true,
      data: {
        orders,
        pagination: {
          current: pageNum,
          pages: Math.ceil(total / limitNum),
          total
        }
      }
    });
  } catch (error) {
    console.error('Error fetching customer orders:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while fetching orders'
    });
  }
};

// Get vendor's orders (orders for their products)
export const getVendorOrders = async (req: Request, res: Response, next: NextFunction) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }

    const { page = 1, limit = 20, status } = req.query;
    
    // Build query
    const query: any = { vendor: req.user.id };
    if (status && status !== 'all') {
      query.status = status;
    }

    // Pagination
    const pageNum = parseInt(page as string);
    const limitNum = parseInt(limit as string);
    const skip = (pageNum - 1) * limitNum;

    // Get orders
    const orders = await Order.find(query)
      .populate('customer', 'firstName lastName email phone')
      .populate('items.product', 'name price images')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limitNum);

    const total = await Order.countDocuments(query);

    return res.status(200).json({
      success: true,
      data: {
        orders,
        pagination: {
          current: pageNum,
          pages: Math.ceil(total / limitNum),
          total
        }
      }
    });
  } catch (error) {
    console.error('Error fetching vendor orders:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while fetching orders'
    });
  }
};

// Update order status (for vendors)
export const updateOrderStatus = async (req: Request, res: Response, next: NextFunction) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }

    const { orderId, status } = req.body;

    if (!orderId || !status) {
      return res.status(400).json({
        success: false,
        message: 'Order ID and status are required'
      });
    }

    // Find order that belongs to this vendor
    const order = await Order.findOne({ 
      _id: orderId, 
      vendor: req.user.id 
    });

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found or access denied'
      });
    }

    // Update order status
    order.status = status;
    await order.save();

    // Populate order details for response
    const updatedOrder = await Order.findById(orderId)
      .populate('customer', 'firstName lastName email phone')
      .populate('vendor', 'firstName lastName email phone')
      .populate('product', 'name price images');

    return res.status(200).json({
      success: true,
      message: 'Order status updated successfully',
      data: { order: updatedOrder }
    });
  } catch (error) {
    console.error('Error updating order status:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while updating order status'
    });
  }
};

// Get single order details
export const getOrder = async (req: Request, res: Response, next: NextFunction) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }

    const order = await Order.findById(req.params.id)
      .populate('customer', 'firstName lastName email phone')
      .populate('vendor', 'firstName lastName email phone')
      .populate('delivery.deliveryAgent', 'firstName lastName email phone')
      .populate('items.product', 'name price images description');

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    // Check if user has access to this order
    if (order.customer._id.toString() !== req.user.id && 
        order.vendor._id.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Access denied'
      });
    }

    return res.status(200).json({
      success: true,
      data: { order }
    });
  } catch (error) {
    console.error('Error fetching order:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while fetching order'
    });
  }
};

// Create order from quick order with payment options
export const createOrderFromQuickOrder = async (req: Request, res: Response, next: NextFunction) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }

    const { 
      quickOrderId, 
      vendorId, 
      agreedPrice, 
      quantity, 
      unitPrice, 
      deliverySelected, 
      deliveryFee 
    } = req.body;

    // Validate required fields
    if (!quickOrderId || !vendorId || !agreedPrice) {
      return res.status(400).json({
        success: false,
        message: 'Quick order ID, vendor ID, and agreed price are required'
      });
    }

    // Get quick order details
    const quickOrder = await QuickOrder.findById(quickOrderId);
    if (!quickOrder) {
      return res.status(404).json({
        success: false,
        message: 'Quick order not found'
      });
    }

    // Get vendor details
    const vendor = await User.findById(vendorId);
    if (!vendor) {
      return res.status(404).json({
        success: false,
        message: 'Vendor not found'
      });
    }

    // Create order items
    const orderItems = [{
      product: quickOrder._id,
      quantity: quantity || 1,
      price: unitPrice || agreedPrice // ✅ Ensure price is provided
    }];

    // Calculate pricing
    const subtotal = (unitPrice || agreedPrice) * (quantity || 1);
    const finalDeliveryFee = deliverySelected ? (deliveryFee || (subtotal * 0.02)) : 0;
    const totalAmount = subtotal + finalDeliveryFee;

    // Create order
    const order = new Order({
      customer: req.user._id,
      vendor: vendorId,
      items: orderItems,
      totalAmount,
      status: 'PENDING',
      deliveryAddress: {
        street: 'Not specified',
        city: 'Not specified', 
        county: 'Not specified',
        instructions: 'Not specified'
      },
      delivery: {
        address: {
          street: 'Not specified',
          city: 'Not specified',
          county: 'Not specified',
          instructions: 'Not specified'
        },
        estimatedTime: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours from now
        deliveryFee: finalDeliveryFee
      },
      pricing: {
        subtotal,
        deliveryFee: finalDeliveryFee,
        serviceFee: 0,
        tax: 0,
        total: totalAmount,
        currency: 'ETB'
      },
      payment: {
        method: 'CARD', // ✅ Use valid enum value instead of 'CHAPA'
        status: 'PENDING'
      },
      estimatedDeliveryTime: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours from now
      orderNotes: `Created from Quick Order: ${quickOrderId}`,
      requiresDelivery: deliverySelected || false,
      // Store quick order reference for tracking
      quickOrderReference: quickOrderId
    });

    const savedOrder = await order.save();

    // Update quick order status if needed
    if (savedOrder) {
      await QuickOrder.findByIdAndUpdate(quickOrderId, { 
        status: 'FULFILLED' 
      });
    }

    return res.status(201).json({
      success: true,
      message: 'Order created successfully from quick order',
      data: savedOrder
    });

  } catch (error) {
    console.error('Error creating order from quick order:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while creating order from quick order'
    });
  }
};

// Generate OTP for delivery confirmation
export const generateDeliveryOTP = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { orderId } = req.body;

    if (!orderId) {
      return res.status(400).json({
        success: false,
        message: 'Order ID is required'
      });
    }

    // Find order
    const order = await Order.findById(orderId);
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    // Check if already delivered
    if (order.status === 'DELIVERED') {
      return res.status(400).json({
        success: false,
        message: 'Order already delivered'
      });
    }

    // Check if OTP already exists and not expired
    if (order.deliveryOTP && order.otpGeneratedAt) {
      const otpAge = Date.now() - new Date(order.otpGeneratedAt).getTime();
      const tenMinutes = 10 * 60 * 1000; // 10 minutes in milliseconds
      
      if (otpAge < tenMinutes) {
        return res.status(400).json({
          success: false,
          message: 'OTP already generated. Please wait for it to expire.'
        });
      }
    }

    // Generate 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    // Update order with OTP
    order.deliveryOTP = otp;
    order.otpGeneratedAt = new Date();
    order.otpSent = false;
    order.otpVerified = false;
    await order.save();

    console.log(`[OTP] Generated for Order ${orderId}: ${otp}`);

    return res.status(200).json({
      success: true,
      message: 'OTP generated successfully',
      data: {
        orderId: order._id,
        otpGenerated: true
      }
    });

  } catch (error) {
    console.error('Error generating delivery OTP:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while generating OTP'
    });
  }
};

// Send OTP to buyer
export const sendDeliveryOTP = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { orderId } = req.body;

    if (!orderId) {
      return res.status(400).json({
        success: false,
        message: 'Order ID is required'
      });
    }

    // Find order
    const order = await Order.findById(orderId).populate('customer', 'email phone');
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    // Check if OTP exists
    if (!order.deliveryOTP) {
      return res.status(400).json({
        success: false,
        message: 'OTP not generated. Please generate OTP first.'
      });
    }

    // Check if already sent
    if (order.otpSent === true) {
      return res.status(400).json({
        success: false,
        message: 'OTP already sent'
      });
    }

    // TODO: Send OTP via email/SMS to customer
    // For now, just mark as sent
    order.otpSent = true;
    await order.save();

    console.log(`[OTP] Buyer clicked Send OTP for Order ${orderId}`);

    return res.status(200).json({
      success: true,
      message: 'OTP sent successfully',
      data: {
        orderId: order._id,
        otpSent: true
      }
    });

  } catch (error) {
    console.error('Error sending delivery OTP:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while sending OTP'
    });
  }
};

// Confirm delivery with OTP validation
export const confirmDelivery = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { orderId } = req.body;
    const currentUserId = req.user?.id;

    if (!orderId) {
      return res.status(400).json({
        success: false,
        message: 'Order ID is required'
      });
    }

    console.log(`[Delivery] Attempting confirmation for Order ${orderId} by User ${currentUserId}`);

    // Find order with populated delivery agent
    const order: any = await Order.findById(orderId).populate('delivery.deliveryAgent');
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    // Debug logging
    console.log(`[Delivery] DEBUG - Order ID: ${orderId}`);
    console.log(`[Delivery] DEBUG - Current User ID: ${currentUserId}`);
    console.log(`[Delivery] DEBUG - Order deliveryAgent:`, order.delivery?.deliveryAgent);
    console.log(`[Delivery] DEBUG - Order deliveryAgent ID:`, order.delivery?.deliveryAgent?._id);
    console.log(`[Delivery] DEBUG - Order deliveryStatus: ${order.deliveryStatus}`);
    console.log(`[Delivery] DEBUG - Order status: ${order.status}`);
    console.log(`[Delivery] DEBUG - Order otpVerified: ${order.otpVerified}`);

    // Auto-delivery logic: If OTP is verified, automatically mark as delivered
    if (order.otpVerified === true && order.deliveryStatus === 'PICKED_UP') {
      console.log(`[Delivery] Auto-delivery triggered - OTP verified for order: ${orderId}`);
      order.status = 'DELIVERED';
      order.deliveryStatus = 'DELIVERED';
      order.actualDeliveryTime = new Date();
      await order.save();
      console.log(`[Delivery] Auto-delivery completed - Order DELIVERED: ${orderId}`);
      return res.status(200).json({
        success: true,
        message: 'Order automatically marked as delivered (OTP verified)',
        data: {
          orderId: order._id,
          status: 'DELIVERED',
          deliveredAt: order.actualDeliveryTime
        }
      });
    }

    // 1. Check if already delivered (check both status fields for consistency)
    if (order.status === 'DELIVERED' && order.deliveryStatus !== 'DELIVERED') {
      console.log(`[Delivery] Fixing inconsistent state - status: ${order.status}, deliveryStatus: ${order.deliveryStatus}`);
      // Fix the inconsistent state
      order.deliveryStatus = 'DELIVERED';
      order.otpVerified = true;
      order.actualDeliveryTime = new Date();
      await order.save();
      console.log(`[Delivery] Fixed inconsistent state for order: ${orderId}`);
      return res.status(400).json({
        success: false,
        message: 'Order status was inconsistent and has been fixed. Please try again.'
      });
    }
    
    if (order.status === 'DELIVERED' || order.deliveryStatus === 'DELIVERED') {
      console.log(`[Delivery] Blocked - Already delivered: ${orderId}`);
      console.log(`[Delivery] DEBUG - status: ${order.status}, deliveryStatus: ${order.deliveryStatus}`);
      return res.status(400).json({
        success: false,
        message: 'Order already delivered'
      });
    }

    // 2. Check if OTP was sent by buyer
    if (order.otpSent !== true) {
      console.log(`[Delivery] Blocked → OTP not sent: ${orderId}`);
      return res.status(400).json({
        success: false,
        message: 'OTP not sent by buyer'
      });
    }

    // 3. Check if already verified
    if (order.otpVerified === true) {
      console.log(`[Delivery] Blocked → Already verified: ${orderId}`);
      return res.status(400).json({
        success: false,
        message: 'Delivery already confirmed'
      });
    }

    // 4. Check if current user is the assigned delivery agent
    if (!order.delivery?.deliveryAgent) {
      console.log(`[Delivery] Blocked - No delivery agent assigned: ${orderId}`);
      return res.status(403).json({
        success: false,
        message: 'No delivery agent assigned to this order'
      });
    }

    const deliveryAgentId = order.delivery.deliveryAgent._id.toString();
    const currentUserIdStr = currentUserId.toString();
    
    console.log(`[Delivery] DEBUG - Delivery Agent ID (from order): ${deliveryAgentId}`);
    console.log(`[Delivery] DEBUG - Current User ID (from token): ${currentUserIdStr}`);
    console.log(`[Delivery] DEBUG - IDs match: ${deliveryAgentId === currentUserIdStr}`);
    
    if (deliveryAgentId !== currentUserIdStr) {
      console.log(`[Delivery] Blocked - Unauthorized: ${orderId}`);
      console.log(`[Delivery] DEBUG - Expected: ${deliveryAgentId}, Got: ${currentUserIdStr}`);
      return res.status(403).json({
        success: false,
        message: 'Unauthorized. Only assigned delivery agent can confirm delivery.'
      });
    }

    // 5. Check if OTP expired (5 minutes)
    if (order.otpGeneratedAt) {
      const otpAge = Date.now() - new Date(order.otpGeneratedAt).getTime();
      const fiveMinutes = 5 * 60 * 1000; // 5 minutes in milliseconds
      
      if (otpAge > fiveMinutes) {
        console.log(`[Delivery] Blocked → OTP expired: ${orderId}`);
        return res.status(400).json({
          success: false,
          message: 'OTP expired. Please generate new OTP.'
        });
      }
    }

    // 6. SUCCESS - Confirm delivery
    order.status = 'DELIVERED';
    order.deliveryStatus = 'DELIVERED';
    order.otpVerified = true;
    order.actualDeliveryTime = new Date();
    await order.save();

    console.log(`[Delivery] Success → Order DELIVERED: ${orderId}`);

    return res.status(200).json({
      success: true,
      message: 'Delivery confirmed successfully',
      data: {
        orderId: order._id,
        status: 'DELIVERED',
        deliveredAt: order.actualDeliveryTime
      }
    });

  } catch (error) {
    console.error('Error confirming delivery:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error while confirming delivery'
    });
  }
};
