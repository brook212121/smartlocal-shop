import { Request, Response, NextFunction } from 'express';
import chapaService from '../services/chapaService';
import walletService from '../services/walletService';
import Order from '../models/Order';
import Payment from '../models/Payment';
import User from '../models/User';
import deliveryService from '../services/deliveryService';

// Initialize payment with Chapa
export const initializePayment = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { orderId } = req.body;
    const userId = req.user?.id;

    if (!orderId) {
      return res.status(400).json({
        status: 'error',
        message: 'Order ID is required'
      });
    }

    // Get order details
    const order = await Order.findById(orderId).populate('customer vendor');
    if (!order) {
      return res.status(404).json({
        status: 'error',
        message: 'Order not found'
      });
    }

    // Verify order belongs to the user
    if (order.customer._id.toString() !== userId) {
      return res.status(403).json({
        status: 'error',
        message: 'Unauthorized access to this order'
      });
    }

    // Check if order is already paid
    if (order.payment.status === 'PAID') {
      return res.status(400).json({
        status: 'error',
        message: 'Order is already paid'
      });
    }

    // Get customer details
    const customer = order.customer as any;
    const vendor = order.vendor as any;

    // Generate unique transaction reference
    const txRef = chapaService.generateTransactionReference();
    
    // Prepare payment data for Chapa
    // Get the frontend URL from request origin or fallback to FRONTEND_URL
    const frontendUrl = req.headers.origin || process.env.FRONTEND_URL || 'http://localhost:3000';

    const paymentData = {
      amount: order.pricing.total,
      currency: 'ETB',
      email: customer.email,
      first_name: customer.firstName,
      last_name: customer.lastName,
      phone_number: customer.phone,
      tx_ref: txRef,
      callback_url: `${frontendUrl}/payment/callback`,
      return_url: `${frontendUrl}/payment/return?tx_ref=${txRef}`,
      customization: {
        title: 'Smart Local Shop', // Max 16 characters
        description: `Order ${order.orderNumber}` // Max 50 characters
      }
    };

    // Initialize payment with Chapa
    const chapaResponse = await chapaService.initializePayment(paymentData);

    // Create Payment record
    const payment = await Payment.create({
      reference: txRef,
      order: order._id,
      customer: customer._id,
      vendor: vendor._id,
      amount: {
        subtotal: order.pricing.subtotal,
        deliveryFee: order.pricing.deliveryFee,
        serviceFee: order.pricing.serviceFee,
        tax: order.pricing.tax,
        total: order.pricing.total,
        currency: 'ETB'
      },
      method: 'CHAPA',
      status: 'PENDING',
      chapa: {
        tx_ref: txRef,
        checkout_url: chapaResponse.data?.checkout_url,
        customer_email: customer.email,
        customer_name: `${customer.firstName} ${customer.lastName}`,
        callback_url: `${frontendUrl}/payment/callback`,
        return_url: `${frontendUrl}/payment/return?tx_ref=${txRef}`,
        customization: {
          title: 'Smart Local Shop',
          description: `Order ${order.orderNumber}`
        }
      },
      gateway: {
        provider: 'CHAPA',
        transactionId: txRef,
        gatewayResponse: chapaResponse
      },
      verification: {
        isVerified: false,
        verificationMethod: 'CHAPA'
      },
      metadata: {
        source: 'web',
        userAgent: req.get('User-Agent'),
        ipAddress: req.ip
      },
      timeline: [{
        status: 'PENDING',
        timestamp: new Date(),
        note: 'Payment initiated via Chapa',
        updatedBy: customer._id
      }]
    });

    // Update order with payment reference
    order.payment.transactionId = txRef;
    order.payment.status = 'PENDING';
    await order.save();

    res.status(200).json({
      status: 'success',
      message: 'Payment initialized successfully',
      data: {
        checkout_url: chapaResponse.data.checkout_url,
        tx_ref: txRef, // Use our generated tx_ref
        order_number: order.orderNumber,
        amount: order.pricing.total,
        payment_id: payment._id
      }
    });

    return;

  } catch (error: any) {
    console.error('Payment initialization error:', error);
    return res.status(500).json({
      status: 'error',
      message: error.message || 'Failed to initialize payment'
    });
  }
};

// Verify payment callback from Chapa
export const verifyPayment = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { tx_ref } = req.body;

    if (!tx_ref) {
      return res.status(400).json({
        status: 'error',
        message: 'Transaction reference is required'
      });
    }

    // Verify transaction with Chapa
    const verificationData = await chapaService.verifyTransaction(tx_ref);

    if (!chapaService.isTransactionSuccessful(verificationData)) {
      return res.status(400).json({
        status: 'error',
        message: 'Payment was not successful',
        data: verificationData
      });
    }

    // Get payment record
    const payment = await Payment.findOne({ 'chapa.tx_ref': tx_ref }).populate('order customer vendor');
    if (!payment) {
      return res.status(404).json({
        status: 'error',
        message: 'Payment not found for this transaction'
      });
    }

    // Check if payment is already processed
    if (payment.status === 'COMPLETED') {
      return res.status(200).json({
        status: 'success',
        message: 'Payment already processed'
      });
    }

    // Get payment amount
    const amount = chapaService.getPaymentAmount(verificationData);

    // Update payment record
    payment.status = 'COMPLETED';
    payment.gateway.transactionId = verificationData.data.flw_ref;
    payment.gateway.gatewayResponse = verificationData;
    payment.verification.isVerified = true;
    payment.verification.verifiedAt = new Date();
    payment.timeline.push({
      status: 'COMPLETED',
      timestamp: new Date(),
      note: 'Payment verified and completed via Chapa',
      amount: amount
    });
    await payment.save();

    // Process payment through wallet service
    await walletService.processPaymentReceived(
      payment.order._id.toString(),
      amount,
      tx_ref
    );

    // 🚀 STRICT DELIVERY ASSIGNMENT AFTER PAYMENT
    try {
      console.log('🚀 Triggering strict delivery assignment for order:', payment.order._id);
      
      // Get order details for delivery assignment
      const order = await Order.findById(payment.order._id).populate('customer vendor');
      if (!order) {
        console.error('❌ Order not found for delivery assignment:', payment.order._id);
        throw new Error('Order not found for delivery assignment');
      }

      console.log('🔍 Delivery Required Check:', order.deliveryRequired);

      // STRICT LOGIC: Check if delivery is required
      if (order.deliveryRequired === true) {
        console.log('✅ Delivery required - proceeding with agent assignment');
        
        // Get vendor location for delivery assignment (NOT customer location)
        const vendorLocation = {
          latitude: (order.vendor as any).coordinates?.lat || 0,
          longitude: (order.vendor as any).coordinates?.lng || 0
        };

        // PREVENT DUPLICATE ASSIGNMENT: Check if order already has delivery agent
        if ((order.delivery as any).deliveryAgent) {
          console.log('⚠️ Order already has delivery agent - STOPPING assignment');
          return; // Stop assignment
        }

        // Find nearest available delivery agent based on vendor location
        console.log('=== DEBUG: Finding delivery agent for vendor location ===');
        console.log('Vendor location:', vendorLocation);
        const nearestAgent = await deliveryService.findNearestDeliveryAgent(vendorLocation);
        
        console.log('=== DEBUG: Delivery agent search result ===');
        console.log('Nearest agent found:', nearestAgent.agent ? 'YES' : 'NO');
        if (nearestAgent.agent) {
          console.log('Agent details:', {
            name: nearestAgent.agent.firstName + ' ' + nearestAgent.agent.lastName,
            phone: nearestAgent.agent.phone,
            distance: (nearestAgent as any).distance,
            isAvailable: (nearestAgent.agent as any).isAvailable
          });
        }

        if (nearestAgent.agent && (nearestAgent.agent as any).isAvailable !== false) {
          console.log('✅ Found available delivery agent:', nearestAgent.agent.firstName, (nearestAgent as any).distance, 'km away');
          
          // Assign delivery agent automatically
          const assignment = await deliveryService.assignDeliveryAgent(
            payment.order._id.toString(),
            nearestAgent.agent._id.toString(),
            vendorLocation,
            { latitude: 0, longitude: 0 } // Customer location not needed for assignment
          );

          console.log('📦 Delivery assignment result:', assignment);

          // Update Order:
          (order.delivery as any).deliveryAgent = nearestAgent.agent._id;
          (order as any).status = 'ASSIGNED';
          await order.save();

          // Update Delivery Agent: Set isAvailable = false
          await User.findByIdAndUpdate(nearestAgent.agent._id, {
            isAvailable: false
          });

          console.log('🎯 Order status updated to ASSIGNED after automatic assignment');
          console.log('🚫 Delivery agent marked as unavailable:', nearestAgent.agent._id);
        } else {
          console.log('⚠️ No available delivery agents found for order:', payment.order._id);
          
          // Set order status to indicate no agents available
          (order as any).status = 'PENDING_ASSIGNMENT';
          await order.save();

          console.log('📍 Order status updated to PENDING_ASSIGNMENT (no agents available)');
        }
      } else {
        console.log('❌ Delivery NOT required - skipping agent assignment');
        
        // Mark order as ready for pickup (customer will pick up)
        (order as any).status = 'READY_FOR_PICKUP';
        await order.save();

        console.log('🎯 Order status updated to READY_FOR_PICKUP (no delivery required)');
      }
    } catch (assignmentError: any) {
      console.error('❌ Strict delivery assignment failed:', assignmentError);
      // Don't fail payment - just log the error
      console.log('⚠️ Payment successful but delivery assignment failed - will be handled manually');
    }

    res.status(200).json({
      status: 'success',
      message: 'Payment verified and processed successfully',
      data: {
        payment_id: payment._id,
        order_number: (payment.order as any).orderNumber,
        amount: amount,
        tx_ref: tx_ref
      }
    });

    return;

  } catch (error: any) {
    console.error('Payment verification error:', error);
    return res.status(500).json({
      status: 'error',
      message: error.message || 'Failed to verify payment'
    });
  }
};

// Payment return handler (for frontend redirect)
export const paymentReturn = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { tx_ref } = req.query;

    if (!tx_ref) {
      return res.status(400).json({
        status: 'error',
        message: 'Transaction reference is required'
      });
    }

    // Verify transaction
    const verificationData = await chapaService.verifyTransaction(tx_ref as string);

    if (chapaService.isTransactionSuccessful(verificationData)) {
      // Payment successful
      return res.status(200).json({
        status: 'success',
        message: 'Payment successful',
        data: verificationData
      });
    } else {
      // Payment failed or pending
      return res.status(400).json({
        status: 'error',
        message: 'Payment not successful',
        data: verificationData
      });
    }

  } catch (error: any) {
    console.error('Payment return error:', error);
    return res.status(500).json({
      status: 'error',
      message: error.message || 'Failed to process payment return'
    });
  }
};

// Get payment status
export const getPaymentStatus = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { orderId } = req.params;
    const userId = req.user?.id;

    const order = await Order.findById(orderId);
    if (!order) {
      return res.status(404).json({
        status: 'error',
        message: 'Order not found'
      });
    }

    // Verify user owns this order
    if (order.customer.toString() !== userId) {
      return res.status(403).json({
        status: 'error',
        message: 'Unauthorized access to this order'
      });
    }

    // Get payment record
    const payment = await Payment.findOne({ order: orderId });

    return res.status(200).json({
      status: 'success',
      data: {
        order_number: order.orderNumber,
        payment_status: order.payment.status,
        payment_reference: order.payment.transactionId,
        total_amount: order.pricing.total,
        payment_id: payment?._id,
        payment_status_detailed: payment?.status,
        gateway_provider: payment?.gateway.provider,
        verification_status: payment?.verification.isVerified
      }
    });

  } catch (error: any) {
    console.error('Get payment status error:', error);
    return res.status(500).json({
      status: 'error',
      message: error.message || 'Failed to get payment status'
    });
  }
};
