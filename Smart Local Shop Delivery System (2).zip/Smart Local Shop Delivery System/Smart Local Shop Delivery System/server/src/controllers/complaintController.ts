import { Request, Response } from 'express';
const Complaint = require('../models/Complaint');
import User from '../models/User';
import VendorEmailService from '../services/vendorEmailService';

// POST /api/complain
// Create a new complain (fully automated - no admin review needed)
export const createComplain = async (req: Request, res: Response) => {
  try {
    const {
      orderId,
      vendorId,
      productName,
      originalProductImage,
      deliveryPhoto,
      confidence,
      rejectionMessage,
      customerName,
      customerPhone
    } = req.body;

    // Validate required fields
    if (!orderId || !vendorId || !productName || !deliveryPhoto || !confidence || !rejectionMessage) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields: orderId, vendorId, productName, deliveryPhoto, confidence, rejectionMessage'
      });
    }

    // SEND EMAIL TO VENDOR - Prepare customer data first
    let finalCustomerName = customerName;
    let finalCustomerPhone = customerPhone;
    
    // Fetch complete user data if phone number is missing
    if (!customerPhone || customerPhone === 'Not provided') {
      try {
        const jwt = require('jsonwebtoken');
        const authHeader = req.headers.authorization;
        
        if (authHeader) {
          const token = authHeader.split(' ')[1];
          
          if (token) {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            const user = await User.findById(decoded.id);
            
            if (user && user.phone) {
              finalCustomerPhone = user.phone;
            }
          }
        }
      } catch (error) {
        // Continue with existing phone if fetch fails
      }
    }

    // Create new complain
    const complain = new Complaint({
      orderId,
      vendorId,
      productName,
      originalProductImage,
      deliveryPhoto,
      confidence: parseFloat(confidence),
      rejectionMessage,
      status: 'resolved', // Auto-resolved since system is fully automated
      customerName: finalCustomerName,
      customerPhone: finalCustomerPhone
    });

    // Save to database
    await complain.save();

    // VENDOR STATUS LOGIC - PROGRESSIVE DISCIPLINE WITH CONFIDENCE THRESHOLD
    const vendor = await User.findById(vendorId);
    if (!vendor) {
      return res.status(404).json({
        success: false,
        message: 'Vendor not found'
      });
    }

    // Increment complaint count
    vendor.complaintCount += 1;

    // CONFIDENCE THRESHOLD - Only count complaints with high confidence
    const confidenceThreshold = 70; // 70% confidence threshold
    const isHighConfidence = confidence >= confidenceThreshold;
    
    // PROGRESSIVE DISCIPLINE SYSTEM
    let actionTaken = 'none';
    
    if (!isHighConfidence) {
      // Low confidence complaints are recorded but don't count toward discipline
      actionTaken = 'none';
    } else {
      // WARNING SYSTEM (1-2 complaints)
      if (vendor.complaintCount === 1 || vendor.complaintCount === 2) {
        actionTaken = 'warning';
        // Vendor remains active but receives warning emails
      }
      
      // SUSPENSION (5 complaints)
      if (vendor.complaintCount === 5) {
        vendor.status = 'suspended';
        vendor.isActive = false;
        actionTaken = 'suspended';
      }
      
      // BAN (10 complaints)
      if (vendor.complaintCount >= 10) {
        vendor.status = 'banned';
        vendor.isActive = false;
        actionTaken = 'banned';
      }
    }

    // Save vendor updates
    await vendor.save();

    // Update complaint with action taken
    complain.actionTaken = actionTaken;
    complain.complaintCount = vendor.complaintCount;
    await complain.save();

    const emailService = new VendorEmailService();
    await emailService.sendComplaintNotification({
      vendorId,
      orderId,
      productName,
      originalProductImage,
      deliveredProductImage: deliveryPhoto,
      confidence: parseFloat(confidence),
      rejectionMessage,
      vendorStatus: vendor.status,
      customerName: finalCustomerName,
      customerPhone: finalCustomerPhone
    });

    // Return success response - no admin notification needed
    let responseMessage = 'Complaint processed successfully. Vendor status updated automatically.';
    
    if (actionTaken === 'warning') {
      responseMessage = `Warning issued to vendor (${vendor.complaintCount}/5 complaints). Vendor remains active.`;
    } else if (actionTaken === 'suspended') {
      responseMessage = `Vendor suspended automatically after ${vendor.complaintCount} high-confidence complaints.`;
    } else if (actionTaken === 'banned') {
      responseMessage = `Vendor banned permanently after ${vendor.complaintCount} high-confidence complaints.`;
    }
    
    return res.status(201).json({
      success: true,
      message: responseMessage,
      complainId: complain._id,
      vendorStatus: vendor.status,
      isAutoResolved: true,
      actionTaken: actionTaken,
      complaintCount: vendor.complaintCount
    });

  } catch (error: any) {
    return res.status(500).json({
      success: false,
      message: 'Failed to process complaint. Please try again later.'
    });
  }
};

// GET /api/complain/vendor
// Get all complaints for the current vendor
export const getVendorComplaints = async (req: Request, res: Response) => {
  try {
    const vendorId = req.user?.id; // Get vendor ID from authenticated user
    
    if (!vendorId) {
      return res.status(401).json({
        success: false,
        message: 'Vendor authentication required'
      });
    }

    const complaints = await Complaint.find({ vendorId })
      .sort({ createdAt: -1 })
      .limit(50); // Limit to last 50 complaints

    return res.status(200).json({
      success: true,
      data: complaints,
      count: complaints.length
    });

  } catch (error: any) {
    return res.status(500).json({
      success: false,
      message: 'Failed to fetch complaints'
    });
  }
};

// GET /api/complain/vendor/notifications
// Get unread complaint notifications for the vendor
export const getVendorComplaintNotifications = async (req: Request, res: Response) => {
  try {
    const vendorId = req.user?.id;
    
    if (!vendorId) {
      return res.status(401).json({
        success: false,
        message: 'Vendor authentication required'
      });
    }

    // Get complaints from the last 7 days that haven't been read
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const complaints = await Complaint.find({ 
      vendorId,
      createdAt: { $gte: sevenDaysAgo },
      isRead: { $ne: true } // Not marked as read
    })
    .sort({ createdAt: -1 })
    .limit(20);

    // Transform into notification format
    const notifications = complaints.map((complaint: any) => {
      return {
        _id: complaint._id,
        complaintId: complaint._id,
        vendorId: complaint.vendorId,
        orderId: complaint.orderId,
        productName: complaint.productName,
        confidence: complaint.confidence,
        rejectionMessage: complaint.rejectionMessage,
        customerName: complaint.customerName,
        customerPhone: complaint.customerPhone,
        createdAt: complaint.createdAt,
        isRead: complaint.isRead || false,
        actionTaken: complaint.actionTaken || 'none',
        complaintCount: complaint.complaintCount
      };
    });

    return res.status(200).json({
      success: true,
      data: notifications,
      count: notifications.length
    });

  } catch (error: any) {
    return res.status(500).json({
      success: false,
      message: 'Failed to fetch notifications'
    });
  }
};

// PUT /api/complain/vendor/notifications/:id/read
// Mark a specific notification as read
export const markNotificationAsRead = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const vendorId = req.user?.id;
    
    if (!vendorId) {
      return res.status(401).json({
        success: false,
        message: 'Vendor authentication required'
      });
    }

    const complaint = await Complaint.findOneAndUpdate(
      { _id: id, vendorId }, // Ensure vendor can only mark their own complaints
      { isRead: true },
      { new: true }
    );

    if (!complaint) {
      return res.status(404).json({
        success: false,
        message: 'Complaint not found or access denied'
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Notification marked as read'
    });

  } catch (error: any) {
    return res.status(500).json({
      success: false,
      message: 'Failed to mark notification as read'
    });
  }
};

// PUT /api/complain/vendor/notifications/read-all
// Mark all notifications as read for the vendor
export const markAllNotificationsAsRead = async (req: Request, res: Response) => {
  try {
    const vendorId = req.user?.id;
    
    if (!vendorId) {
      return res.status(401).json({
        success: false,
        message: 'Vendor authentication required'
      });
    }

    await Complaint.updateMany(
      { vendorId, isRead: { $ne: true } },
      { isRead: true }
    );

    return res.status(200).json({
      success: true,
      message: 'All notifications marked as read'
    });

  } catch (error: any) {
    return res.status(500).json({
      success: false,
      message: 'Failed to mark all notifications as read'
    });
  }
};

// GET /api/complain/vendor/:id
// Get specific complaint details for vendor
export const getVendorComplaintDetails = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const vendorId = req.user?.id;
    
    if (!vendorId) {
      return res.status(401).json({
        success: false,
        message: 'Vendor authentication required'
      });
    }

    const complaint = await Complaint.findOne({ _id: id, vendorId });

    if (!complaint) {
      return res.status(404).json({
        success: false,
        message: 'Complaint not found or access denied'
      });
    }

    return res.status(200).json({
      success: true,
      data: complaint
    });

  } catch (error: any) {
    return res.status(500).json({
      success: false,
      message: 'Failed to fetch complaint details'
    });
  }
};
