import { Request, Response } from 'express';

// Coordinate validation function
function validateCoordinates(coord: string): string {
  if (!coord || typeof coord !== 'string') {
    throw new Error('Coordinates must be a non-empty string');
  }

  const parts = coord.split(',');
  if (parts.length !== 2) {
    throw new Error('Coordinates must be in format "latitude,longitude"');
  }

  const [lat, lng] = parts.map(Number);

  if (isNaN(lat) || lat < -90 || lat > 90) {
    throw new Error(`Invalid latitude: ${lat}. Must be between -90 and 90`);
  }

  if (isNaN(lng) || lng < -180 || lng > 180) {
    throw new Error(`Invalid longitude: ${lng}. Must be between -180 and 180`);
  }

  // Format coordinates to 6 decimal places for consistency
  return `${lat.toFixed(6)},${lng.toFixed(6)}`;
}

// Google Distance Matrix API endpoint
export const getDistanceMatrix = async (req: Request, res: Response): Promise<void> => {
  const startTime = Date.now();
  
  try {
    const { origins, destinations } = req.body;
    
    // Validate request body
    if (!origins || !destinations) {
      res.status(400).json({
        success: false,
        message: 'Origins and destinations are required',
        error: 'MISSING_PARAMETERS'
      });
      return;
    }

    // Validate API key
    const apiKey = process.env.GOOGLE_MAPS_API_KEY || process.env.REACT_APP_GOOGLE_MAPS_API_KEY;
    
    if (!apiKey) {
      res.status(500).json({
        success: false,
        message: 'Google Maps API key not configured',
        error: 'API_KEY_MISSING'
      });
      return;
    }

    // Handle coordinate parsing and validation
    let originCoords: string;
    let destCoords: string;

    try {
      if (Array.isArray(origins)) {
        if (origins.length === 0) {
          throw new Error('Origins array cannot be empty');
        }
        originCoords = validateCoordinates(origins[0]);
      } else {
        originCoords = validateCoordinates(origins);
      }

      if (Array.isArray(destinations)) {
        if (destinations.length === 0) {
          throw new Error('Destinations array cannot be empty');
        }
        destCoords = validateCoordinates(destinations[0]);
      } else {
        destCoords = validateCoordinates(destinations);
      }
    } catch (validationError) {
      console.error('❌ Coordinate validation error:', validationError);
      res.status(400).json({
        success: false,
        message: validationError instanceof Error ? validationError.message : 'Invalid coordinates',
        error: 'INVALID_COORDINATES'
      });
      return;
    }

    // Build Google Maps API URL
    const url = `https://maps.googleapis.com/maps/api/distancematrix/json?` +
      `origins=${encodeURIComponent(originCoords)}&` +
      `destinations=${encodeURIComponent(destCoords)}&` +
      `key=${apiKey}`;

    // Make API call with timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000); // 15 second timeout

    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'Kala-Epidemiological-System/1.0'
      }
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ Google Maps API HTTP error:', response.status, errorText);
      res.status(response.status).json({
        success: false,
        message: 'Google Maps API error',
        error: 'HTTP_ERROR',
        status: response.status,
        details: errorText
      });
      return;
    }

    const data = await response.json() as any;

    // Validate Google Maps API response
    if (data.status !== 'OK') {
      console.error('❌ Distance Matrix API status error:', data.status);
      res.status(400).json({
        success: false,
        message: `Distance Matrix API error: ${data.status}`,
        error: 'API_STATUS_ERROR',
        details: data
      });
      return;
    }

    if (!data.rows || !Array.isArray(data.rows) || data.rows.length === 0) {
      console.error('❌ Invalid distance matrix response structure: missing rows');
      res.status(400).json({
        success: false,
        message: 'Invalid distance matrix response structure',
        error: 'INVALID_RESPONSE_STRUCTURE'
      });
      return;
    }

    const firstRow = data.rows[0];
    if (!firstRow.elements || !Array.isArray(firstRow.elements) || firstRow.elements.length === 0) {
      console.error('❌ Invalid distance matrix response structure: missing elements');
      res.status(400).json({
        success: false,
        message: 'Invalid distance matrix response structure',
        error: 'INVALID_RESPONSE_STRUCTURE'
      });
      return;
    }

    const element = firstRow.elements[0];
    
    if (element.status !== 'OK') {
      console.error('❌ Distance calculation failed:', element.status);
      res.status(400).json({
        success: false,
        message: `Distance calculation failed: ${element.status}`,
        error: 'CALCULATION_FAILED',
        details: element
      });
      return;
    }

    // Validate distance and duration values
    const distance = element.distance?.value || 0;
    const duration = element.duration?.value || 0;

    if (typeof distance !== 'number' || distance < 0 || distance > 10000000) { // Max 10,000km
      console.error('❌ Invalid distance value:', distance);
      res.status(400).json({
        success: false,
        message: 'Invalid distance value received',
        error: 'INVALID_DISTANCE',
        details: { distance, duration }
      });
      return;
    }

    if (typeof duration !== 'number' || duration < 0 || duration > 86400) { // Max 24 hours
      console.error('❌ Invalid duration value:', duration);
      res.status(400).json({
        success: false,
        message: 'Invalid duration value received',
        error: 'INVALID_DURATION',
        details: { distance, duration }
      });
      return;
    }

    res.status(200).json({
      success: true,
      data: {
        distance: distance,
        distanceKm: Math.round(distance / 1000 * 100) / 100,
        duration: duration,
        durationMinutes: Math.round(duration / 60),
        status: data.rows[0].elements[0].status
      }
    });

  } catch (error) {
    const processingTime = Date.now() - startTime;
    console.error('❌ Distance matrix calculation error:', error);
    
    if (error instanceof Error && error.name === 'AbortError') {
      res.status(408).json({
        success: false,
        message: 'Request timeout',
        error: 'TIMEOUT',
        metadata: {
          processingTimeMs: processingTime
        }
      });
    } else {
      res.status(500).json({
        success: false,
        message: 'Failed to calculate distance matrix',
        error: 'INTERNAL_ERROR',
        details: error instanceof Error ? error.message : 'Unknown error',
        metadata: {
          processingTimeMs: processingTime
        }
      });
    }
  }
};
