import { Request, Response, NextFunction } from 'express';
import Order from '../models/Order';
import Product from '../models/Product';
import { GoogleGenerativeAI } from '@google/generative-ai';
import fs from 'fs';
import path from 'path';

// Initialize Gemini API
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || '');

// Test function to try different model names
async function testModel(modelName: string) {
  try {
    if (process.env.NODE_ENV === 'development') {
      console.log(`🔍 Testing model: ${modelName}`);
    }
    const testModel = genAI.getGenerativeModel({ model: modelName });
    const result = await testModel.generateContent("Hello, respond with just 'working'");
    const response = await result.response;
    const text = response.text();
    if (process.env.NODE_ENV === 'development') {
      console.log(`✅ Model ${modelName} works:`, text);
    }
    return true;
  } catch (error: any) {
    if (process.env.NODE_ENV === 'development') {
      console.log(`❌ Model ${modelName} failed:`, error.message);
    }
    return false;
  }
}

// Test common model names
async function findWorkingModel() {
  const commonModels = [
    'gemini-1.5-flash',
    'gemini-1.5-pro',
    'gemini-pro',
    'gemini-pro-vision',
    'gemini-3-flash',
    'gemini-3.5-flash'
  ];

  for (const modelName of commonModels) {
    const works = await testModel(modelName);
    if (works) {
      if (process.env.NODE_ENV === 'development') {
        console.log(`Found working model: ${modelName}`);
      }
      return modelName;
    }
  }
  
  if (process.env.NODE_ENV === 'development') {
    console.log('No working model found');
  }
  return null;
}

export const validateDelivery = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { orderId } = req.params;
    const { uploadedDeliveryImage } = req.body;
    
    if (!orderId) {
      res.status(400).json({
        success: false,
        message: 'Order ID is required'
      });
      return;
    }
    
    if (!uploadedDeliveryImage) {
      res.status(400).json({
        success: false,
        message: 'Uploaded delivery image is required'
      });
      return;
    }

    // Fetch the order from database and populate product details
    const order = await Order.findById(orderId).populate('items.product');
    
    if (!order) {
      res.status(404).json({
        success: false,
        message: 'Order not found'
      });
      return;
    }

    // 🔒 CRITICAL: Check if order is already validated
    if (order.deliveryValidation?.validated) {
      res.status(400).json({
        success: false,
        message: 'Order already validated',
        alreadyValidated: true,
        validatedAt: order.deliveryValidation.validatedAt,
        previousResult: {
          match: order.deliveryValidation.match,
          confidence: order.deliveryValidation.confidence,
          reason: order.deliveryValidation.reason
        }
      });
      return;
    }

    // Get the first product from the order
    const firstItem = (order as any).items[0];
    if (!firstItem || !firstItem.product) {
      res.status(404).json({
        success: false,
        message: 'Product not found in order'
      });
      return;
    }

    const product = firstItem.product;
    if (!product.images || product.images.length === 0) {
      res.status(404).json({
        success: false,
        message: 'Product images not found'
      });
      return;
    }

    // Get the first image from the product images array
    const productImageUrl = product.images[0];

    // Check if Gemini API key is available
    if (!process.env.GEMINI_API_KEY) {
      res.status(500).json({
        success: false,
        message: 'Gemini API key not configured'
      });
      return;
    }

    try {
      // Initialize Gemini Vision model with a known working model
      if (!process.env.GEMINI_API_KEY) {
        throw new Error('Gemini API key is missing');
      }
      
      const model = genAI.getGenerativeModel({ model: 'gemini-2.5-flash' });

      // Test basic Gemini API call first
      try {
        const testResult = await model.generateContent("Hello, can you respond with just 'API working'?");
        const testResponse = await testResult.response;
        const testText = testResponse.text();
        
        if (!testText.includes('API working')) {
          throw new Error('Gemini API test failed - unexpected response');
        }
      } catch (apiError: any) {
        console.error('Gemini API test failed:', apiError);
        throw new Error(`Gemini API test failed: ${apiError.message}`);
      }

      // Prepare the comparison prompt
      const prompt = `You are validating delivery proof for an ecommerce order.

Image 1: Product image from the store.
Image 2: Photo uploaded by the delivery person.

Determine if the product in both images is the same item.

Return JSON:
{
  "match": true/false,
  "confidence": percentage (0-100),
  "reason": "short explanation"
}`;

      console.log('🔍 validateDelivery: Sending images to Gemini for comparison...');

      // Convert product image file path to base64 if needed
      let productImageBase64: string;
      if (productImageUrl.startsWith('/uploads/') || productImageUrl.startsWith('uploads/')) {
        // Read image file from disk and convert to base64
        const imagePath = path.join(__dirname, '..', '..', productImageUrl.startsWith('/') ? productImageUrl : '/' + productImageUrl);
        
        if (fs.existsSync(imagePath)) {
          const imageBuffer = fs.readFileSync(imagePath);
          productImageBase64 = imageBuffer.toString('base64');
        } else {
          throw new Error('Product image file not found');
        }
      } else if (productImageUrl.includes('data:image')) {
        // Already base64 encoded
        productImageBase64 = productImageUrl.split(',')[1];
      } else {
        // Assume it's base64
        productImageBase64 = productImageUrl;
      }
      
      const deliveryImageBase64 = uploadedDeliveryImage.includes('data:image') 
        ? uploadedDeliveryImage.split(',')[1] 
        : uploadedDeliveryImage;

      // Create image parts for Gemini
      const imageParts = [
        {
          inlineData: {
            data: productImageBase64,
            mimeType: 'image/jpeg'
          }
        },
        {
          inlineData: {
            data: deliveryImageBase64,
            mimeType: 'image/jpeg'
          }
        }
      ];

      // Send to Gemini API
      const result = await model.generateContent([prompt, ...imageParts]);
      const response = await result.response;
      const text = response.text();

      // Parse the JSON response safely using regex
      let validationResult;
      try {
        // Extract JSON from response using regex
        const jsonMatch = text.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          const jsonText = jsonMatch[0];
          validationResult = JSON.parse(jsonText);
        } else {
          throw new Error('No JSON found in Gemini response');
        }
      } catch (parseError) {
        validationResult = {
          match: false,
          confidence: 0,
          reason: 'Failed to analyze images - parsing error'
        };
      }

      // Only approve if confidence > 0.8 AND match = true
      const isApproved = validationResult.match && validationResult.confidence > 80;

      // Update order with validation result
      (order as any).deliveryValidation = {
        validated: true,
        match: validationResult.match,
        confidence: validationResult.confidence,
        reason: validationResult.reason,
        validatedAt: new Date(),
        deliveryImage: uploadedDeliveryImage
      };

      await order.save();

      // Return the validation result
      res.status(200).json({
        success: true,
        data: {
          match: validationResult.match,
          confidence: validationResult.confidence,
          message: validationResult.reason,
          approved: isApproved
        }
      });

    } catch (geminiError: any) {
      console.error('Gemini API error:', geminiError);
      res.status(500).json({
        success: false,
        message: 'Failed to validate delivery with AI service',
        error: process.env.NODE_ENV === 'development' ? geminiError.message : 'AI service error'
      });
    }

  } catch (error: any) {
    console.error('Delivery validation error:', error);
    
    // Send more specific error message
    let errorMessage = 'Server error while validating delivery';
    
    if (error.message.includes('Product image file not found')) {
      errorMessage = 'Product image file not found on server';
    } else if (error.message.includes('Gemini API')) {
      errorMessage = 'AI service error during validation';
    } else if (error.message.includes('ENOENT')) {
      errorMessage = 'File not found error';
    } else if (error.message.includes('JSON')) {
      errorMessage = 'Response parsing error';
    }
    
    res.status(500).json({
      success: false,
      message: errorMessage
    });
  }
};
