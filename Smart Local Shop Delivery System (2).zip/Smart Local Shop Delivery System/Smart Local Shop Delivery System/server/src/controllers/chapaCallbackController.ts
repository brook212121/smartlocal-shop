import { Request, Response, NextFunction } from 'express';
import Payment from '../models/Payment';
import Order from '../models/Order';
import User from '../models/User';
import chapaService from '../services/chapaService';
import walletService from '../services/walletService';
import deliveryService from '../services/deliveryService';

// Test endpoint to manually trigger Chapa verification
export const testChapaVerification = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { tx_ref } = req.query;

    if (!tx_ref) {
      res.status(400).json({
        status: 'error',
        message: 'Missing tx_ref parameter'
      });
      return;
    }

    // Find payment by tx_ref
    const payment = await Payment.findOne({ 
      'chapa.tx_ref': tx_ref 
    }).populate('order customer vendor');

    if (!payment) {
      res.status(404).json({
        status: 'error',
        message: 'Payment not found'
      });
      return;
    }

    // Verify payment with Chapa API
    const verificationData = await chapaService.verifyTransaction(tx_ref as string);
    
    if (chapaService.isTransactionSuccessful(verificationData)) {
      // Update payment status to COMPLETED
      payment.status = 'COMPLETED';
      payment.verification.isVerified = true;
      payment.verification.verifiedAt = new Date();
      payment.verification.verificationMethod = 'CHAPA';
      payment.gateway.gatewayResponse = verificationData;
      
      await payment.save();

      // Update order status to PAID
      const order = await Order.findById(payment.order);
      if (order) {
        order.payment.status = 'PAID';
        order.payment.paidAt = new Date();
        order.status = 'CONFIRMED';
        await order.save();
      }

      // Credit wallets
      if (order) {
        await walletService.processPaymentReceived(
          order._id.toString(),
          order.pricing.total,
          tx_ref as string
        );
      }

      // Assign delivery agent if delivery was selected
      if (order && order.pricing.deliveryFee > 0) {
        try {
          // Get vendor location from their database profile
          const vendor = await User.findById(order.vendor);
          const vendorLocation = vendor && vendor.vendorLocation && vendor.vendorLocation.coordinates
            ? {
                latitude: vendor.vendorLocation.coordinates[1],
                longitude: vendor.vendorLocation.coordinates[0]
              }
            : { latitude: 7.689013, longitude: 36.819906 }; // Default Addis Ababa

          // Validate vendor location
          if (!vendorLocation || !vendorLocation.latitude || !vendorLocation.longitude) {
            if (process.env.NODE_ENV === 'development') {
              console.log('⚠️ Vendor location not available, using default location');
            }
          }

          // Get customer location from order delivery address
          const customerLocation = order.delivery.address.coordinates 
            ? {
                latitude: order.delivery.address.coordinates.latitude,
                longitude: order.delivery.address.coordinates.longitude
              }
            : { latitude: 7.689013, longitude: 36.819906 }; // Default Addis Ababa

          // Find nearest delivery agent
          const nearestAgent = await deliveryService.findNearestDeliveryAgentGeoJSON(vendorLocation);
          
          if (nearestAgent.agent) {
            // Assign delivery agent to order
            const assignment = await deliveryService.assignDeliveryAgent(
              order._id.toString(),
              nearestAgent.agent._id,
              vendorLocation,
              customerLocation
            );
            
            if (process.env.NODE_ENV === 'development') {
              console.log('🚚 Delivery agent assigned successfully:', {
                orderId: order.orderNumber,
                agentName: assignment.deliveryAgentName,
                agentPhone: assignment.deliveryAgentPhone,
                status: assignment.status
              });
            }
          } else {
            if (process.env.NODE_ENV === 'development') {
              console.log('🚚 No available delivery agents found for order:', order.orderNumber);
            }
          }
        } catch (deliveryError) {
          console.error('🚚 Error assigning delivery agent:', deliveryError);
        }
      }

      res.status(200).json({
        status: 'success',
        message: 'Payment verified and processed successfully',
        data: {
          tx_ref,
          payment_status: payment.status,
          order_status: order?.status,
          order_number: order?.orderNumber,
          order_id: order?._id?.toString() // Add MongoDB order ID
        }
      });

    } else {
      // Update payment status to FAILED
      payment.status = 'FAILED';
      payment.verification.isVerified = false;
      payment.verification.verifiedAt = new Date();
      payment.gateway.gatewayResponse = verificationData;
      
      await payment.save();

      res.status(400).json({
        status: 'error',
        message: 'Payment verification failed',
        data: verificationData
      });
    }

  } catch (error: any) {
   
    res.status(500).json({
      status: 'error',
      message: error.message || 'Failed to verify payment'
    });
  }
};

// Chapa callback handler
export const chapaCallback = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { tx_ref, status, transaction_id } = req.body;

    if (!tx_ref) {
      res.status(400).json({
        status: 'error',
        message: 'Missing transaction reference'
      });
      return;
    }

    // Find payment by tx_ref
    const payment = await Payment.findOne({ 
      'chapa.tx_ref': tx_ref 
    }).populate('order customer vendor');

    if (!payment) {
      res.status(404).json({
        status: 'error',
        message: 'Payment not found'
      });
      return;
    }

    // Verify payment with Chapa API
    const verificationData = await chapaService.verifyTransaction(tx_ref as string);
    
    if (chapaService.isTransactionSuccessful(verificationData)) {
      // Update payment status to COMPLETED
      payment.status = 'COMPLETED';
      payment.verification.isVerified = true;
      payment.verification.verifiedAt = new Date();
      payment.verification.verificationMethod = 'CHAPA';
      payment.gateway.gatewayResponse = verificationData;
      
      await payment.save();

      // Update order status to PAID
      const order = await Order.findById(payment.order);
      if (order) {
        order.payment.status = 'PAID';
        order.payment.paidAt = new Date();
        order.status = 'CONFIRMED';
        await order.save();
      }

      // Credit wallets
      if (order) {
        await walletService.processPaymentReceived(
          order._id.toString(),
          order.pricing.total,
          tx_ref as string
        );
      }

      // Assign delivery agent if delivery was selected
      if (order && order.pricing.deliveryFee > 0) {
        try {
          // Get vendor location from their database profile
          const vendor = await User.findById(order.vendor);
          const vendorLocation = vendor && vendor.vendorLocation && vendor.vendorLocation.coordinates
            ? {
                latitude: vendor.vendorLocation.coordinates[1],
                longitude: vendor.vendorLocation.coordinates[0]
              }
            : { latitude: 7.689013, longitude: 36.819906 }; // Default Addis Ababa

          // Validate vendor location
          if (!vendorLocation || !vendorLocation.latitude || !vendorLocation.longitude) {
            if (process.env.NODE_ENV === 'development') {
              console.log('Vendor location not available, using default location');
            }
          }

          // Get customer location from order delivery address
          const customerLocation = order.delivery.address.coordinates 
            ? {
                latitude: order.delivery.address.coordinates.latitude,
                longitude: order.delivery.address.coordinates.longitude
              }
            : { latitude: 7.689013, longitude: 36.819906 }; // Default Addis Ababa

          // Find nearest delivery agent
          const nearestAgent = await deliveryService.findNearestDeliveryAgentGeoJSON(vendorLocation);
          
          if (nearestAgent.agent) {
            // Assign delivery agent to order
            const assignment = await deliveryService.assignDeliveryAgent(
              order._id.toString(),
              nearestAgent.agent._id,
              vendorLocation,
              customerLocation
            );
            
            if (process.env.NODE_ENV === 'development') {
              console.log('Delivery agent assigned:', assignment);
            }
          } else {
            if (process.env.NODE_ENV === 'development') {
              console.log('No available delivery agents found for order:', order.orderNumber);
            }
          }
        } catch (deliveryError) {
          console.error('Error assigning delivery agent:', deliveryError);
        }
      }

      // Redirect to success page
      const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';
      res.redirect(`${frontendUrl}/payment/return?tx_ref=${tx_ref}&status=success`);

    } else {
      // Update payment status to FAILED
      payment.status = 'FAILED';
      payment.verification.isVerified = false;
      payment.verification.verifiedAt = new Date();
      payment.gateway.gatewayResponse = verificationData;
      
      await payment.save();

      // Redirect to failure page
      const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';
      res.redirect(`${frontendUrl}/payment/return?tx_ref=${tx_ref}&status=failed`);
    }

  } catch (error: any) {
    console.error('Error in Chapa callback:', error);
    const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';
    res.redirect(`${frontendUrl}/payment/return?status=error`);
  }
};

export const chapaReturn = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { tx_ref, status } = req.query;

    if (!tx_ref) {
      res.status(400).json({
        status: 'error',
        message: 'Missing transaction reference'
      });
      return;
    }

    // Find payment by tx_ref
    const payment = await Payment.findOne({ 
      'chapa.tx_ref': tx_ref 
    }).populate('order customer vendor');

    if (!payment) {
      res.status(404).json({
        status: 'error',
        message: 'Payment not found'
      });
      return;
    }

    // Verify payment with Chapa API
    const verificationData = await chapaService.verifyTransaction(tx_ref as string);
    
    if (chapaService.isTransactionSuccessful(verificationData)) {
      // Update payment and order status
      payment.status = 'COMPLETED';
      payment.verification.isVerified = true;
      payment.verification.verifiedAt = new Date();
      payment.gateway.gatewayResponse = verificationData;
      await payment.save();

      const order = await Order.findById(payment.order);
      if (order) {
        order.payment.status = 'PAID';
        order.payment.paidAt = new Date();
        order.status = 'CONFIRMED';
        await order.save();

        // Credit wallets
        await walletService.processPaymentReceived(
          order._id.toString(),
          order.pricing.total,
          tx_ref as string
        );
      }

      res.status(200).json({
        status: 'success',
        message: 'Payment verified successfully',
        data: {
          tx_ref,
          status: 'PAID',
          order_number: order?.orderNumber,
          order_id: order?._id?.toString() // Add MongoDB order ID
        }
      });
      return;
    } else {
      res.status(400).json({
        status: 'error',
        message: 'Payment not successful',
        data: verificationData
      });
      return;
    }

  } catch (error: any) {
    console.error('❌ Chapa return error:', error);
    res.status(500).json({
      status: 'error',
      message: error.message || 'Failed to process payment return'
    });
  }
};
