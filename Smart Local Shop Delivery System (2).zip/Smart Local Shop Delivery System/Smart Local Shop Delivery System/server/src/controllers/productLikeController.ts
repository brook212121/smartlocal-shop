import { Request, Response, NextFunction } from 'express';
import { ProductLike } from '../models/ProductLike';
import { UserActivity } from '../models/UserActivity';
import Product from '../models/Product';
import mongoose from 'mongoose';

export const toggleLike = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = (req as any).user?.id;
    const { productId } = req.params;

    if (!userId) {
      res.status(401).json({ 
        success: false, 
        message: 'User authentication required' 
      });
      return;
    }

    if (!productId) {
      res.status(400).json({ 
        success: false, 
        message: 'Product ID is required' 
      });
      return;
    }

    // Convert string IDs to ObjectId
    const userObjectId = new mongoose.Types.ObjectId(userId);
    const productObjectId = new mongoose.Types.ObjectId(productId);

    // Check if user already liked the product
    const existingLike = await ProductLike.findOne({
      userId: userObjectId,
      productId: productObjectId
    });

    let liked: boolean;
    
    if (existingLike) {
      // Remove like (unlike)
      await ProductLike.deleteOne({ _id: existingLike._id });
      liked = false;
    } else {
      // Add like
      await ProductLike.create({
        userId: userObjectId,
        productId: productObjectId
      });
      liked = true;
    }

    // Get total likes count
    const totalLikes = await ProductLike.countDocuments({ productId: productObjectId });

    // Track activity for recommendation system
    if (liked) {
      try {
        // Get product details for activity tracking
        const product = await Product.findById(productObjectId)
          .select('name category vendor')
          .lean();

        if (product) {
          await UserActivity.create({
            userId: userObjectId,
            productId: productObjectId,
            action: 'like_product',
            productName: product.name,
            category: product.category,
            shopId: product.vendor,
            createdAt: new Date()
          });
        }
      } catch (activityError) {
        console.error('Error tracking like activity:', activityError);
        // Don't fail the request if activity tracking fails
      }
    }

    res.status(200).json({
      success: true,
      data: {
        liked,
        totalLikes
      }
    });

  } catch (error) {
    console.error('Error toggling like:', error);
    
    // Handle duplicate key error (shouldn't happen with our check, but just in case)
    if (error instanceof Error && error.message.includes('duplicate key')) {
      res.status(200).json({
        success: true,
        data: {
          liked: false,
          totalLikes: await ProductLike.countDocuments({ 
            productId: new mongoose.Types.ObjectId(req.params.productId) 
          })
        }
      });
      return;
    }

    res.status(500).json({ 
      success: false, 
      message: 'Internal server error' 
    });
  }
};

export const getProductLikes = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = (req as any).user?.id;
    const { productId } = req.params;

    if (!productId) {
      res.status(400).json({ 
        success: false, 
        message: 'Product ID is required' 
      });
      return;
    }

    const productObjectId = new mongoose.Types.ObjectId(productId);

    // Get total likes count
    const totalLikes = await ProductLike.countDocuments({ productId: productObjectId });

    // Check if current user liked this product
    let likedByUser = false;
    if (userId) {
      const userObjectId = new mongoose.Types.ObjectId(userId);
      const userLike = await ProductLike.findOne({
        userId: userObjectId,
        productId: productObjectId
      });
      likedByUser = !!userLike;
    }

    res.status(200).json({
      success: true,
      data: {
        totalLikes,
        likedByUser
      }
    });

  } catch (error) {
    console.error('Error getting product likes:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Internal server error' 
    });
  }
};
