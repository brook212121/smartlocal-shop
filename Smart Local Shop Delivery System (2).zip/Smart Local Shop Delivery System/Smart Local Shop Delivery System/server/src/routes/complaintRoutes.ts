import { Router } from 'express';
import { protect, vendorOnly } from '../middleware/auth';
import { 
  createComplain, 
  getVendorComplaints,
  getVendorComplaintNotifications,
  markNotificationAsRead,
  markAllNotificationsAsRead,
  getVendorComplaintDetails
} from '../controllers/complaintController';

const router = Router();

// POST /api/complain - Create new complaint (fully automated)
router.post('/', createComplain);

// VENDOR-SPECIFIC ROUTES (require vendor authentication)
// GET /api/complain/vendor - Get all complaints for current vendor
router.get('/vendor', protect, vendorOnly, getVendorComplaints);

// GET /api/complain/vendor/notifications - Get unread notifications for vendor
router.get('/vendor/notifications', protect, vendorOnly, getVendorComplaintNotifications);

// PUT /api/complain/vendor/notifications/read-all - Mark all notifications as read
router.put('/vendor/notifications/read-all', protect, vendorOnly, markAllNotificationsAsRead);

// PUT /api/complain/vendor/notifications/:id/read - Mark specific notification as read
router.put('/vendor/notifications/:id/read', protect, vendorOnly, markNotificationAsRead);

// GET /api/complain/vendor/:id - Get specific complaint details for vendor
router.get('/vendor/:id', protect, vendorOnly, getVendorComplaintDetails);

export default router;
