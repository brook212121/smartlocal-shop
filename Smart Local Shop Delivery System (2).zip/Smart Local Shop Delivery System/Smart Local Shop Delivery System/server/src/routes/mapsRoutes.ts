import { Router } from 'express';
import { getDistanceMatrix } from '../controllers/mapsController';

const router = Router();

// Google Distance Matrix API
// POST /api/maps/distance-matrix
router.post('/distance-matrix', getDistanceMatrix);

export default router;
