import express from 'express';
import { sendMessage, getUnreadMessages, markMessageAsRead, getConversation } from '../controllers/messageController';
import { protect } from '../middleware/auth';

const router = express.Router();

// Send message from customer to vendor
router.post('/', protect, sendMessage);

// Get unread messages for notifications
router.get('/unread/:userId', protect, getUnreadMessages);

// Get conversation between two users
router.get('/conversation/:userId/:senderId', protect, getConversation);

// Mark message as read
router.patch('/read/:messageId', protect, markMessageAsRead);

export default router;
