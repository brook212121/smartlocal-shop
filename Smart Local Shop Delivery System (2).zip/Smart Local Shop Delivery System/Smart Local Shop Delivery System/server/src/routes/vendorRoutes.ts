import { Router } from 'express';
import { protect } from '../middleware/auth';
import { getAvailableVendors, getVendorById, getCurrentVendorLocation, updateVendorLocation, findNearestVendor } from '../controllers/vendorController';

const router = Router();

// Get all available vendors for assignment
// GET /api/vendors/available
router.get('/available', getAvailableVendors);

// Get current vendor location
// GET /api/vendors/current-location
router.get('/current-location', protect, getCurrentVendorLocation);

// Update vendor location automatically
// POST /api/vendors/location
router.post('/location', protect, updateVendorLocation);

// Find nearest vendor using database coordinates
// POST /api/vendors/nearest
router.post('/nearest', async (req, res) => {
  console.log('🔍 DEBUG: /vendors/nearest route hit!', req.body);
  try {
    await findNearestVendor(req, res);
  } catch (error) {
    console.error('❌ ERROR in /vendors/nearest:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// Get vendor by ID
// GET /api/vendors/:vendorId
router.get('/:vendorId', getVendorById);

export default router;
