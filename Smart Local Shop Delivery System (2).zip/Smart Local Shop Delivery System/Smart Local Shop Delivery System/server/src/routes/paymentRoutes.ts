import express from 'express';
import { protect } from '../middleware/auth';
import {
  initializePayment,
  verifyPayment,
  paymentReturn,
  getPaymentStatus
} from '../controllers/paymentController';

const router = express.Router();

// All payment routes require authentication
router.use(protect);

// POST /api/payments/initialize - Initialize payment with Chapa
router.post('/initialize', initializePayment);

// POST /api/payments/verify - Verify payment callback from Chapa
router.post('/verify', verifyPayment);

// GET /api/payments/return - Payment return handler (for frontend redirect)
router.get('/return', paymentReturn);

// GET /api/payments/status/:orderId - Get payment status for an order
router.get('/status/:orderId', getPaymentStatus);

export default router;
