import express from 'express';
import { protect } from '../middleware/auth';
import { restrictTo } from '../middleware/auth';
import User from '../models/User';
import { catchAsync } from '../middleware/errorHandler';

const router = express.Router();

// PUT /location/update - Update user location
router.put('/update', protect, catchAsync(async (req: any, res: any, next: any) => {
  const { latitude, longitude, address } = req.body;
  
  console.log('📍 Backend - Location update request:', {
    userId: req.user._id,
    latitude,
    longitude,
    address
  });
  
  if (!latitude || !longitude) {
    console.log('❌ Backend - Missing coordinates');
    return res.status(400).json({
      success: false,
      message: 'Latitude and longitude are required'
    });
  }

  try {
    // Update user location
    const user = await User.findById(req.user._id);
    if (!user) {
      console.log('❌ Backend - User not found');
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    console.log('📍 Backend - Updating user location for:', user.email);

    // Update coordinates using the new clean structure
    user.coordinates = {
      lat: parseFloat(latitude),
      lng: parseFloat(longitude)
    };

    // Update vendorLocation for geospatial queries
    user.vendorLocation = {
      type: "Point",
      coordinates: [parseFloat(longitude), parseFloat(latitude)]
    };

    // Add to location history
    if (!user.locationHistory) {
      user.locationHistory = [];
    }
    
    user.locationHistory.push({
      timestamp: new Date(),
      coordinates: {
        lat: parseFloat(latitude),
        lng: parseFloat(longitude)
      }
    });

    user.lastLocationUpdate = new Date();
    await user.save();

    console.log('✅ Backend - Location updated successfully:', {
      userId: user._id,
      location: user.coordinates,
      lastUpdate: user.lastLocationUpdate
    });

    res.status(200).json({
      success: true,
      message: 'Location updated successfully',
      data: {
        location: user.coordinates,
        timestamp: user.lastLocationUpdate
      }
    });
  } catch (error: any) {
    console.error('❌ Backend - Error updating location:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update location',
      error: error.message
    });
  }
}));

// GET /location/history - Get location history
router.get('/history', protect, catchAsync(async (req: any, res: any, next: any) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.status(200).json({
      success: true,
      data: {
        locationHistory: user.locationHistory || [],
        lastLocationUpdate: user.lastLocationUpdate
      }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: 'Failed to get location history',
      error: error.message
    });
  }
}));

// GET /location/current - Get current location of user
router.get('/current', protect, catchAsync(async (req: any, res: any, next: any) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.status(200).json({
      success: true,
      data: {
        location: user.coordinates,
        lastLocationUpdate: user.lastLocationUpdate
      }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: 'Failed to get current location',
      error: error.message
    });
  }
}));

export default router;
