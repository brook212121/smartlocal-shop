import express from 'express';
import { 
  getDeliveryOrders, 
  getDeliveryOrderById,
  updateDeliveryStatus, 
  getDeliveryStats 
} from '../controllers/deliveryController';
import deliveryService from '../services/deliveryService';
import { protect } from '../middleware/auth';
import { restrictTo } from '../middleware/auth';
import User from '../models/User';

const router = express.Router();

// Testing endpoint to verify delivery service
router.get('/test-agents', async (req, res) => {
  try {
    // Test getAvailableDeliveryAgents
    const agents = await deliveryService.getAvailableDeliveryAgents();

    // Test findNearestDeliveryAgent
    let nearestResult;
    try {
      const testLocation = { latitude: 7.689013, longitude: 36.819906 };
      nearestResult = await deliveryService.findNearestDeliveryAgent(testLocation);
    } catch (error: any) {
      console.error('Nearest agent test failed:', error);
    }
      
    if (nearestResult && nearestResult.agent) {
      // Found nearest agent
    } else {
      // No nearest agent found
    }

    // Test assignDeliveryAgent
    if (nearestResult && nearestResult.agent) {
      try {
        const testVendorLocation = { latitude: 7.689013, longitude: 36.819906 };
        const testCustomerLocation = { latitude: 7.690000, longitude: 36.820000 };
        
        const assignment = await deliveryService.assignDeliveryAgent(
          'test-order-id',
          nearestResult.agent._id,
          testVendorLocation,
          testCustomerLocation
        );
      } catch (error: any) {
        console.error('Test assignment failed:', error);
      }
    }

    res.status(200).json({
      success: true,
      message: 'Delivery service test completed',
      data: {
        totalAgents: agents.length,
        testResults: {
          availableAgents: agents.length,
          nearestResultAgentTest: nearestResult,
          assignmentTest: 'Check logs for assignment test result'
        }
      }
    });
  } catch (error: any) {
    console.error('❌ Delivery service test error:', error);
    res.status(500).json({
      success: false,
      message: 'Delivery service test failed',
      error: error.message || 'Unknown error'
    });
  }
});

// Public routes (no authentication required for agent assignment)
router.get('/available', async (req, res) => {
  try {
    const agents = await deliveryService.getAvailableDeliveryAgents();
    res.status(200).json({
      success: true,
      data: agents
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch delivery agents'
    });
  }
});

router.post('/nearestResult', async (req, res) => {
  try {
    const { location } = req.body;
    if (!location || !location.latitude || !location.longitude) {
      return res.status(400).json({
        success: false,
        message: 'Location is required'
      });
    }

    const result = await deliveryService.findNearestDeliveryAgent(location);
    return res.status(200).json({
      success: true,
      data: result
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      message: 'Failed to find nearestResult delivery agent'
    });
  }
});

router.post('/assign', async (req, res) => {
  try {
    const { orderId, deliveryAgentId, vendorLocation, customerLocation } = req.body;
    
    if (!orderId || !deliveryAgentId || !vendorLocation || !customerLocation) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields'
      });
    }

    const assignment = await deliveryService.assignDeliveryAgent(
      orderId,
      deliveryAgentId,
      vendorLocation,
      customerLocation
    );

    return res.status(200).json({
      success: true,
      data: assignment
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      message: error.message || 'Failed to assign delivery agent'
    });
  }
});

router.put('/status', async (req, res) => {
  try {
    const { orderId, status } = req.body;
    
    if (!orderId || !status) {
      return res.status(400).json({
        success: false,
        message: 'Order ID and status are required'
      });
    }

    await deliveryService.updateDeliveryStatus(orderId, status);
    return res.status(200).json({
      success: true,
      message: 'Delivery status updated successfully'
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      message: error.message || 'Failed to update delivery status'
    });
  }
});

// All delivery routes require authentication and delivery role
router.use(protect);
router.use(restrictTo('DELIVERY'));

// GET /delivery/orders - Get orders assigned to delivery agent
router.get('/orders', getDeliveryOrders);

// GET /delivery/orders/:id - Get single delivery order by ID
router.get('/orders/:id', getDeliveryOrderById);

// GET /delivery/stats - Get delivery statistics  
router.get('/stats', getDeliveryStats);

// PUT /delivery/orders/:id/status - Update delivery status
router.put('/orders/:id/status', updateDeliveryStatus);

// PUT /delivery-agents/location - Update delivery agent location
router.put('/delivery-agents/location', async (req: express.Request, res: express.Response) => {
  try {
    const { latitude, longitude, address } = req.body;
    const deliveryAgentId = req.user?._id;
    
    console.log('🔍 Updating delivery agent location:', {
      deliveryAgentId,
      latitude,
      longitude,
      address
    });
    
    if (!deliveryAgentId) {
      return res.status(401).json({
        success: false,
        message: 'Delivery agent not authenticated'
      });
    }
    
    if (!latitude || !longitude) {
      return res.status(400).json({
        success: false,
        message: 'Latitude and longitude are required'
      });
    }

    // Update delivery agent location in database using correct User model fields
    const updatedAgent = await User.findByIdAndUpdate(
      deliveryAgentId,
      {
        $set: {
          coordinates: {
            lat: parseFloat(latitude),
            lng: parseFloat(longitude)
          },
          lastLocationUpdate: new Date(),
          isOnline: true
        },
        $push: {
          locationHistory: {
            timestamp: new Date(),
            coordinates: {
              lat: parseFloat(latitude),
              lng: parseFloat(longitude)
            }
          }
        }
      },
      { new: true, runValidators: true }
    );

    if (!updatedAgent) {
      return res.status(404).json({
        success: false,
        message: 'Delivery agent not found'
      });
    }

    console.log('✅ Delivery agent location updated successfully:', {
      agentId: deliveryAgentId,
      coordinates: updatedAgent.coordinates,
      lastLocationUpdate: updatedAgent.lastLocationUpdate
    });

    return res.status(200).json({
      success: true,
      message: 'Delivery agent location updated successfully',
      data: {
        coordinates: updatedAgent.coordinates,
        lastLocationUpdate: updatedAgent.lastLocationUpdate
      }
    });
  } catch (error: any) {
    console.error('❌ Error updating delivery agent location:', error);
    return res.status(500).json({
      success: false,
      message: error.message || 'Failed to update delivery agent location'
    });
  }
});

export default router;
