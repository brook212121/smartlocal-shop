import express from 'express';
import { protectAdmin } from '../middleware/authMiddleware';
import { 
  getDashboardStats,
  getAllUsers,
  updateUserRole,
  getUserDetails,
  getUserComplaints,
  getUserOrders,
  getUserTransactions,
  toggleUserStatus,
  deleteUser,
  getOrderDetails,
  getAllProducts,
  getAllOrders,
  searchOrders,
  assignDeliveryAgent,
  getDeliveryAgents,
  getAllQuickOrders,
  closeQuickOrder,
  getAdminProfile,
  updateAdminProfile,
  changeAdminPassword,
  setAdminPassword,
  testBcrypt,
  testOrders
} from '../controllers/adminController';

const router = express.Router();

// Protect all admin routes
router.use(protectAdmin);

// Dashboard Stats
router.get('/stats', getDashboardStats);

// User Management
router.get('/users', getAllUsers);
router.get('/users/:id/details', getUserDetails);
router.get('/users/:id/complaints', getUserComplaints);
router.get('/users/:id/orders', getUserOrders);
router.get('/users/:id/transactions', getUserTransactions);
router.put('/users/:id/role', updateUserRole);
router.put('/users/:id/toggle-status', toggleUserStatus);
router.delete('/users/:id', deleteUser);

// Product Management (Read-only)
router.get('/products', getAllProducts);

// Order Management
router.get('/orders', getAllOrders);
router.get('/orders/search', searchOrders);
router.get('/orders/:id/details', getOrderDetails);
router.put('/orders/:id/assign-delivery', assignDeliveryAgent);
router.get('/test-orders', testOrders); // Test endpoint for debugging
router.get('/delivery-agents', getDeliveryAgents);

// Quick Order Management
router.get('/quick-orders', getAllQuickOrders);
router.put('/quick-orders/:id/close', closeQuickOrder);

// Profile Management
router.get('/profile', getAdminProfile);
router.patch('/profile', updateAdminProfile);
router.patch('/change-password', changeAdminPassword);
router.post('/set-password', setAdminPassword); // Temporary fix
router.post('/test-bcrypt', testBcrypt); // Debug endpoint

export default router;
