import express from 'express';
import { protect } from '../middleware/auth';
import {
  getVendorOrders,
  acceptOrder,
  createOrderFromQuickOrder
} from '../controllers/vendorOrderController';

const router = express.Router();

// GET /vendor/orders - Get vendor's orders
router.get('/', protect, getVendorOrders);

// PUT /orders/:id/accept - Vendor accepts order
router.put('/:id/accept', protect, acceptOrder);

// POST /orders/from-quick-order - Create order from quick order
router.post('/from-quick-order', protect, createOrderFromQuickOrder);

export default router;
