import { Router } from 'express';
import { trackActivity } from '../controllers/activityController';
import { protect } from '../middleware/auth';

const router = Router();

// POST /api/activity - Track user activity
router.post('/', protect, trackActivity);

export default router;
