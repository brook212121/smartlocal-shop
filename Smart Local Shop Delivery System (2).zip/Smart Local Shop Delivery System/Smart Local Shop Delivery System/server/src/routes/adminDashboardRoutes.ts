import express from 'express';
import { protectAdmin } from '../middleware/authMiddleware';
import {
  getDashboardSummary,
  getRevenueData
} from '../controllers/adminDashboardController';

const router = express.Router();

// All admin dashboard routes require authentication and admin role
router.use(protectAdmin);

// GET /api/admin/dashboard/summary - Get dashboard summary statistics
router.get('/summary', getDashboardSummary);

// GET /api/admin/dashboard/revenue?range=7|30 - Get revenue data for chart
router.get('/revenue', getRevenueData);

export default router;
