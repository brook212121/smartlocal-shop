import { Router } from 'express';
import authRoutes from './auth';
import productRoutes from './products';
import quickOrderRoutes from './quickOrderRoutes';
import vendorOrderRoutes from './vendorOrderRoutes';
import vendorRoutes from './vendorRoutes';
import orderRoutes from './orders';
import deliveryRoutes from './deliveryRoutes';
import adminRoutes from './adminRoutes';
import adminDashboardRoutes from './adminDashboardRoutes';
import paymentRoutes from './paymentRoutes';
import withdrawalRoutes from './withdrawalRoutes';
import chapaCallbackRoutes from './chapaCallbackRoutes';
import mapsRoutes from './mapsRoutes';
import locationRoutes from './locationRoutes';
import messageRoutes from './messages';
import deliveryValidationRoutes from './deliveryValidationRoutes';
import activityRoutes from './activityRoutes';
import recommendationRoutes from './recommendationRoutes';
import productLikeRoutes from './productLikeRoutes';
import relatedProductsRoutes from './relatedProducts';
import analyticsRoutes from './analyticsRoutes';

const router = Router();

// Health check endpoint
router.get('/health', (req, res) => {
  res.status(200).json({
    status: 'OK',
    message: 'Smart Local Shop Delivery API is running',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development',
    version: '1.0.0'
  });
});

// API info endpoint
router.get('/info', (req, res) => {
  res.status(200).json({
    name: 'Smart Local Shop Delivery API',
    version: '1.0.0',
    description: 'Backend API for Smart Local Shop Delivery System',
    endpoints: {
      health: '/api/health',
      info: '/api/info',
      auth: {
        register: '/api/auth/register',
        login: '/api/auth/login',
        me: '/api/auth/me'
      },
      products: {
        getAll: '/api/products',
        getById: '/api/products/:id',
        create: '/api/products',
        update: '/api/products/:id',
        delete: '/api/products/:id'
      }
    },
    documentation: '/api/docs' // Future: Swagger/OpenAPI docs
  });
});

// Mount auth routes
router.use('/auth', authRoutes);

// Mount product routes
router.use('/products', productRoutes);

// Mount quick order routes
router.use('/quick-orders', quickOrderRoutes);

// Mount vendor order routes
router.use('/vendor-orders', vendorOrderRoutes);

// Mount vendor routes
router.use('/vendors', vendorRoutes);

// Mount order routes
router.use('/orders', orderRoutes);

// Mount payment routes
router.use('/payments', paymentRoutes);

// Mount Chapa callback routes
router.use('/payment', chapaCallbackRoutes);

// Mount withdrawal routes
router.use('/withdrawals', withdrawalRoutes);

// Mount delivery routes
router.use('/delivery', deliveryRoutes);

// Mount admin routes
router.use('/admin', adminRoutes);

// Mount admin dashboard routes
router.use('/admin/dashboard', adminDashboardRoutes);

// Mount maps routes
router.use('/maps', mapsRoutes);

// Mount location routes
router.use('/location', locationRoutes);

// Mount message routes
router.use('/messages', messageRoutes);

// Mount delivery validation routes
router.use('/delivery-validation', deliveryValidationRoutes);

// Mount activity routes
router.use('/activity', activityRoutes);

// Mount recommendation routes
router.use('/recommendations', recommendationRoutes);

// Mount product like routes
router.use('/products', productLikeRoutes);

// Mount related products routes
router.use('/products', relatedProductsRoutes);

// Mount analytics routes
router.use('/analytics', analyticsRoutes);
export default router;
