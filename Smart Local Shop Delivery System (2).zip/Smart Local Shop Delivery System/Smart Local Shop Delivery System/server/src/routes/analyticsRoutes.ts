import express from 'express';
import { protect } from '../middleware/auth';
import { getVendorAnalytics } from '../controllers/analyticsController';

const router = express.Router();

// Apply vendor authentication middleware
router.use(protect);

// Get vendor analytics
router.get('/vendor', getVendorAnalytics);

export default router;
