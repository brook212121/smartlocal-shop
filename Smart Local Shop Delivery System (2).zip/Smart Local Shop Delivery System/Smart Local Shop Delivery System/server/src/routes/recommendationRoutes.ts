import { Router } from 'express';
import { getRecommendations } from '../controllers/recommendationController';
import { protect } from '../middleware/auth';

const router = Router();

// GET /api/recommendations - Get personalized product recommendations
router.post('/', protect, getRecommendations);

export default router;
