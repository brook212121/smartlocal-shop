import express from 'express';
import { validateDelivery } from '../controllers/deliveryValidationController';
import { protect } from '../middleware/auth';

const router = express.Router();

// Test route to verify routing is working
router.get('/test', (req, res) => {
  console.log('🔍 Delivery validation test route hit');
  res.json({ message: 'Delivery validation routes are working!' });
});

// Validate delivery proof
router.post('/:orderId/validate-delivery', protect, validateDelivery);

export default router;
