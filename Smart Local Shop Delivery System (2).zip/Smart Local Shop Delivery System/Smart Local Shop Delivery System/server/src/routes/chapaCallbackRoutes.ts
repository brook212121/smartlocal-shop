import { Router } from 'express';
import { chapaCallback, chapaReturn, testChapaVerification } from '../controllers/chapaCallbackController';

const router = Router();

// Test endpoint to manually trigger Chapa verification
router.get('/test-verification', testChapaVerification);

// Chapa callback endpoint (webhook from Chapa)
router.post('/callback', chapaCallback);

// Chapa return endpoint (manual return from checkout)
router.get('/return', chapaReturn);

export default router;
