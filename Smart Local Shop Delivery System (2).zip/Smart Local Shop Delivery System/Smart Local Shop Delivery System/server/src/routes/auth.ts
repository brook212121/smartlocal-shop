import { Router } from 'express';
import {
  register,
  login,
  verifyEmail,
  getMe,
  updatePassword,
  logout,
  forgotPassword,
  resetPassword,
  upgradeToVendor
} from '../controllers/authController';
import { protect } from '../middleware/auth';

const router = Router();

// Public routes
router.post('/register', register);
router.post('/login', login);
router.post('/forgot-password', forgotPassword);
router.post('/reset-password', resetPassword);
router.get('/verify-email/:token', verifyEmail);

// Protected routes
router.use(protect); // All routes below this require authentication

router.get('/me', getMe);
router.patch('/update-password', updatePassword);
router.post('/logout', logout);
router.post('/upgrade-to-vendor', upgradeToVendor);

export default router;
