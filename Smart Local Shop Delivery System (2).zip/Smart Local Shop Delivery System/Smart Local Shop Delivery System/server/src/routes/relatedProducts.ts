import { Router } from 'express';
import { getRelatedProducts } from '../controllers/relatedProductsController';
import { protect } from '../middleware/auth';

const router = Router();

// GET /products/related/:productId - Get related products
router.get('/related/:productId', protect, getRelatedProducts);

export default router;
