import { Router } from 'express';
import { toggleLike, getProductLikes } from '../controllers/productLikeController';
import { protect } from '../middleware/auth';

const router = Router();

// POST /api/products/:productId/like - Toggle like/unlike
router.post('/:productId/like', protect, toggleLike);

// GET /api/products/:productId/likes - Get product likes info
router.get('/:productId/likes', getProductLikes);

export default router;
