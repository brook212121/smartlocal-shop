import express from 'express';
import { protect } from '../middleware/auth';
import {
  createWithdrawalRequest,
  getVendorWithdrawalHistory,
  getVendorWalletBalance,
  getAllWithdrawals,
  getAdminWalletBalance,
  releaseHeldFunds
} from '../controllers/withdrawalController';

const router = express.Router();

// All withdrawal routes require authentication
router.use(protect);

// Vendor routes
router.post('/request', createWithdrawalRequest);
router.get('/history', getVendorWithdrawalHistory);
router.get('/balance', getVendorWalletBalance);

// Admin routes
router.get('/admin/all', getAllWithdrawals);
router.get('/admin/balance', getAdminWalletBalance);
router.post('/admin/release-funds', releaseHeldFunds);

export default router;
