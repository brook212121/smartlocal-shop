import express from 'express';
import multer from 'multer';
import path from 'path';
import { 
  createProduct, 
  updateProduct, 
  deleteProduct, 
  getVendorProducts, 
  getVendorProduct,
  getPublicProducts,
  getPublicProduct,
  getVendorProductsPublic,
  searchProducts
} from '../controllers/productController';
import { requireVendor, requireProductOwner } from '../middleware/vendorMiddleware';
import { protect } from '../middleware/auth';

const router = express.Router();

// Public routes (no authentication required)
router.get('/public', getPublicProducts);
router.get('/public/:id', getPublicProduct);

// Public vendor products route (no authentication required)
router.get('/vendor/:vendorId', getVendorProductsPublic);

// Search suggestions route (no authentication required)
router.get('/search', searchProducts);
router.get('/suggestions', searchProducts); // Alias for suggestions

// Configure multer for image upload
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  },
  fileFilter: function (req, file, cb) {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed!'));
    }
  }
});

// All product routes require authentication and vendor access
router.use(protect);
router.use(requireVendor);

// GET /api/products - Get vendor's products
router.get('/', getVendorProducts);

// GET /api/products/:id - Get single vendor product
router.get('/:id', getVendorProduct);

// POST /api/products - Create new product (vendor only)
router.post('/', upload.single('image'), createProduct);

// PUT /api/products/:id - Update product (product owner only)
router.put('/:id', requireProductOwner, upload.single('image'), updateProduct);

// DELETE /api/products/:id - Delete product (product owner only)
router.delete('/:id', requireProductOwner, deleteProduct);

export default router;
