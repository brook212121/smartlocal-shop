import express from 'express';
import { validateDelivery } from '../controllers/deliveryValidationController';
import { protect } from '../middleware/auth';

const router = express.Router();

// Validate delivery with AI
router.post('/:orderId/validate-delivery', protect, validateDelivery);

export default router;
