// Backend proxy route for Google Maps API to secure the API key
// Add this to your backend routes (e.g., in mapsController.ts)

import { Request, Response } from 'express';

/**
 * Backend Proxy Route for Google Maps Geocoding API
 * 
 * This route hides the API key from the frontend and provides a secure proxy
 * for reverse geocoding requests.
 * 
 * FRONTEND USAGE:
 * Instead of calling Google Maps directly, call:
 * fetch('/api/maps/geocode', { method: 'POST', body: JSON.stringify({ lat, lng }) })
 * 
 * BACKEND IMPLEMENTATION:
 */
export const geocodeProxy = async (req: Request, res: Response) => {
  try {
    const { lat, lng } = req.body;
    
    if (!lat || !lng) {
      return res.status(400).json({ 
        success: false, 
        message: 'Latitude and longitude are required' 
      });
    }

    // Validate coordinates
    if (typeof lat !== 'number' || typeof lng !== 'number' || 
        isNaN(lat) || isNaN(lng) || 
        lat < -90 || lat > 90 || 
        lng < -180 || lng > 180) {
      return res.status(400).json({ 
        success: false, 
        message: 'Invalid coordinates provided' 
      });
    }

    // Secure API key stored in backend environment variables
    const apiKey = process.env.GOOGLE_MAPS_API_KEY;
    
    if (!apiKey) {
      return res.status(500).json({ 
        success: false, 
        message: 'Google Maps API key not configured on server' 
      });
    }

    const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${apiKey}`;
    
    const response = await fetch(url);
    const data = await response.json() as any;
    
    if (data.status === 'OK' && data.results?.[0]) {
      // Extract address components
      const addressComponents = data.results[0].address_components;
      
      const neighborhood = addressComponents.find((comp: any) => 
        comp.types.includes('sublocality')
      )?.long_name;
      const locality = addressComponents.find((comp: any) => 
        comp.types.includes('locality')
      )?.long_name;
      const route = addressComponents.find((comp: any) => 
        comp.types.includes('route')
      )?.long_name;
      
      // Return the most specific available location
      let locationName = 'Unknown location';
      if (route && neighborhood) locationName = `${route}, ${neighborhood}`;
      else if (neighborhood) locationName = neighborhood;
      else if (locality) locationName = locality;
      else {
        locationName = data.results[0].formatted_address.split(',')[0].trim();
      }
      
      return res.json({
        success: true,
        data: {
          locationName,
          formattedAddress: data.results[0].formatted_address,
          addressComponents: data.results[0].address_components
        }
      });
    }
    
    return res.json({
      success: false,
      message: 'No valid geocoding results found'
    });
    
  } catch (error: any) {
    console.error('Geocoding proxy error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

/**
 * FRONTEND IMPLEMENTATION AFTER BACKEND PROXY:
 * 
 * Update the getLocationName function in useGoogleMaps.ts:
 * 
 * const getLocationName = useCallback(async (latitude: number, longitude: number): Promise<string> => {
 *   try {
 *     const response = await fetch('/api/maps/geocode', {
 *       method: 'POST',
 *       headers: { 'Content-Type': 'application/json' },
 *       body: JSON.stringify({ lat: latitude, lng: longitude })
 *     });
 *     
 *     const data = await response.json();
 *     
 *     if (data.success) {
 *       return data.data.locationName;
 *     }
 *     
 *     return 'Unknown location';
 *   } catch (error) {
 *     console.error('Error getting location name:', error);
 *     return 'Unknown location';
 *   }
 * }, []);
 * 
 * ENVIRONMENT VARIABLES SETUP:
 * 
 * Backend (.env):
 * GOOGLE_MAPS_API_KEY=your_actual_api_key_here
 * 
 * Frontend (.env):
 * REACT_APP_GOOGLE_MAPS_API_KEY= (remove or leave empty)
 */
