import express from 'express';
import rateLimit from 'express-rate-limit';
import { 
  createOrder, 
  getCustomerOrders, 
  getVendorOrders, 
  updateOrderStatus, 
  getOrder,
  createOrderFromQuickOrder,
  generateDeliveryOTP,
  sendDeliveryOTP,
  confirmDelivery
} from '../controllers/orderController';
import { protect } from '../middleware/auth';

const router = express.Router();

// Specific rate limiter for order creation (more restrictive)
const orderCreationLimiter = rateLimit({
  windowMs: 60000, // 1 minute
  max: 10, // 10 orders per minute per user
  message: 'Too many order creation attempts, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
});

// All routes require authentication
router.use(protect);

// POST /api/orders - Create new order (with stricter rate limiting)
router.post('/', orderCreationLimiter, createOrder);

// POST /api/orders/from-quick-order - Create order from quick order
router.post('/from-quick-order', protect, createOrderFromQuickOrder);

// GET /api/orders - Get customer's orders
router.get('/', getCustomerOrders);

// GET /api/orders/vendor - Get vendor's orders
router.get('/vendor', getVendorOrders);

// GET /api/orders/:id - Get single order
router.get('/:id', getOrder);

// PUT /api/orders/:id/status - Update order status (vendor only)
router.put('/:id/status', updateOrderStatus);

// POST /api/orders/generate-otp - Generate OTP for delivery
router.post('/generate-otp', generateDeliveryOTP);

// POST /api/orders/send-otp - Send OTP to buyer
router.post('/send-otp', sendDeliveryOTP);

// POST /api/orders/confirm-delivery - Confirm delivery
router.post('/confirm-delivery', confirmDelivery);

export default router;
