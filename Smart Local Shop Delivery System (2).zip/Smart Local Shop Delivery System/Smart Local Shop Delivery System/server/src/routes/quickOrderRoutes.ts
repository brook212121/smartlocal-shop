import express from 'express';
import { protect } from '../middleware/auth';
import {
  createQuickOrder,
  getCustomerQuickOrders,
  getAllQuickOrders,
  getOpenQuickOrders,
  getMyQuickOrders,
  getVendorQuickOrders,
  updateQuickOrderStatus,
  deleteQuickOrder,
  respondToQuickOrder,
  getChatMessages,
  sendChatMessage,
  getVendorResponses
} from '../controllers/quickOrderController';
import multer, { FileFilterCallback } from 'multer';

// Configure multer for image uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'quick-order-' + uniqueSuffix + '.' + file.originalname.split('.').pop());
  }
});

const fileFilter = (req: express.Request, file: Express.Multer.File, cb: FileFilterCallback) => {
  // Accept images only
  if (file.mimetype.startsWith('image/')) {
    cb(null, true);
  } else {
    cb(new Error('Only image files are allowed'));
  }
};

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  }
});

const router = express.Router();

// POST /quick-orders - Create a new quick order (authenticated users only)
router.post('/', protect, upload.single('image'), createQuickOrder);

// GET /quick-orders - Get customer's quick orders
router.get('/', protect, getCustomerQuickOrders);

// GET /quick-orders/open - Get all open quick orders (for vendors) - exclude user's own
router.get('/open', protect, getOpenQuickOrders);

// GET /quick-orders/mine - Get user's own quick orders
router.get('/mine', protect, getMyQuickOrders);

// GET /quick-orders/vendor - Get quick orders assigned to current vendor
router.get('/vendor', protect, getVendorQuickOrders);

// GET /quick-orders/customer - Get customer quick orders (for vendors to respond to)
router.get('/customer', protect, getCustomerQuickOrders);

// GET /quick-orders/all - Get all open quick orders (for vendors)
router.get('/all', protect, getAllQuickOrders);

// PUT /quick-orders/:id - Update quick order status
router.put('/:id', protect, updateQuickOrderStatus);

// DELETE /quick-orders/:id - Delete quick order
router.delete('/:id', protect, deleteQuickOrder);

// POST /quick-orders/:id/respond - Vendor responds with message and price
router.post('/:id/respond', protect, respondToQuickOrder);

// GET /quick-orders/:id/chat - Get chat messages for a quick order
router.get('/:id/chat', protect, getChatMessages);

// POST /quick-orders/:id/chat - Send chat message
router.post('/:id/chat', protect, sendChatMessage);

// GET /quick-orders/:id/responses - Get vendor responses for a quick order
router.get('/:id/responses', protect, getVendorResponses);

export default router;
