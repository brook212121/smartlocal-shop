import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import User, { IUser } from '../models/User';
import { catchAsync, createError } from './errorHandler';

// Extend Request interface to include user
declare global {
  namespace Express {
    interface Request {
      user?: IUser;
    }
  }
}

// Authentication middleware
export const protect = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  // 1) Getting token and check if it's there
  let token: string | undefined;
  
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (!token) {
    return next(createError('You are not logged in! Please log in to get access.', 401));
  }

  // 2) Verification token
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    
    // 3) Check if user still exists
    const currentUser = await User.findById(decoded.id);
    if (!currentUser) {
      return next(createError('The user belonging to this token no longer exists.', 401));
    }

    // 4) Check if user is active
    if (!currentUser.isActive) {
      return next(createError('Your account has been deactivated. Please contact support.', 401));
    }

    // 5) Grant access to protected route
    req.user = currentUser;
    next();
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError) {
      return next(createError('Invalid token. Please log in again.', 401));
    } else if (error instanceof jwt.TokenExpiredError) {
      return next(createError('Token expired. Please log in again.', 401));
    } else {
      return next(createError('Token verification failed. Please log in again.', 401));
    }
  }
});

// Role-based access control middleware
export const restrictTo = (...roles: string[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return next(createError('You are not logged in! Please log in to get access.', 401));
    }

    if (!roles.includes(req.user.role)) {
      return next(createError('You do not have permission to perform this action', 403));
    }

    next();
  };
};

// Optional authentication (doesn't fail if no token)
export const optionalAuth = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  let token: string | undefined;
  
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (token) {
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
      const currentUser = await User.findById(decoded.id);
      
      if (currentUser && currentUser.isActive) {
        req.user = currentUser;
      }
    } catch (error) {
      if (error instanceof jwt.JsonWebTokenError) {
        // Token is invalid, but we don't fail the request
        // Just continue without user attached
      } else if (error instanceof jwt.TokenExpiredError) {
        // Token expired, continue without user
      } else {
        // Other JWT errors, continue without user
      }
    }
  }

  next();
});

// Check if user owns resource
export const checkOwnership = (resourceField: string = 'userId') => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return next(createError('You are not logged in!', 401));
    }

    const resourceUserId = req.body[resourceField] || req.params[resourceField];
    
    // Admin can access all resources
    if (req.user.role === 'ADMIN') {
      return next();
    }

    // Check ownership
    if (req.user._id.toString() !== resourceUserId.toString()) {
      return next(createError('You do not have permission to access this resource', 403));
    }

    next();
  };
};

// Vendor-only middleware
export const vendorOnly = restrictTo('VENDOR', 'ADMIN');

// Customer-only middleware
export const customerOnly = restrictTo('CUSTOMER', 'ADMIN');

// Delivery-only middleware
export const deliveryOnly = restrictTo('DELIVERY', 'ADMIN');

// Admin-only middleware
export const adminOnly = restrictTo('ADMIN');
