import { Request, Response, NextFunction } from 'express';
import User from '../models/User';

export interface VendorRequest extends Request {
  user?: any;
}

export const checkVendorStatus = async (req: VendorRequest, res: Response, next: NextFunction) => {
  try {
    // Check if user is authenticated
    if (!req.user || !req.user._id) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }

    // Get user from database to check current status
    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Check if user is a vendor
    if (!user.isVendor) {
      return next(); // Not a vendor, allow to proceed
    }

    // BLOCK VENDOR ACTIONS IF INACTIVE
    if (!user.isActive) {
      return res.status(403).json({
        success: false,
        message: `Vendor account is ${user.status}. Access denied.`,
        status: user.status,
        reason: 'Vendor operations are blocked due to account status'
      });
    }

    // Attach updated user info to request
    req.user = user;
    next();

  } catch (error) {
    console.error('Error in vendor status middleware:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};
