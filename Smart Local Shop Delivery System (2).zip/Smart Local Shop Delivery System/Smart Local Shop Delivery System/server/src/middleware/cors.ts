import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

const corsOptions = {
  origin: function (origin: string | undefined, callback: (err: Error | null, allow?: boolean) => void) {
    // Allow requests with no origin (like mobile apps or curl requests)
    if (!origin) return callback(null, true);
    
    // In development, allow all origins including ngrok
    if (process.env.NODE_ENV === 'development') {
      return callback(null, true);
    }
    
    // Allow localhost and 127.0.0.1 on any port (HTTP/HTTPS)
    if (origin.startsWith('http://localhost:') || origin.startsWith('https://localhost:') || 
        origin.startsWith('http://127.0.0.1:') || origin.startsWith('https://127.0.0.1:')) {
      return callback(null, true);
    }
    
    // Allow ngrok domains (both free and paid)
    if (origin.includes('.ngrok.io') || origin.includes('.ngrok-free.dev')) {
      return callback(null, true);
    }
    
    // Allow LAN IPs (10.x.x.x, 192.168.x.x, 172.16.x.x-172.31.x.x) - both HTTP and HTTPS
    const lanIPPattern = /^https?:\/\/(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.)/;
    if (lanIPPattern.test(origin)) {
      return callback(null, true);
    }
    
    // Allow production origins if specified
    const allowedOrigins = process.env.ALLOWED_ORIGINS ? 
      process.env.ALLOWED_ORIGINS.split(',') : [];
    
    if (allowedOrigins.includes(origin)) {
      return callback(null, true);
    }
    
    const msg = `The CORS policy for this site does not allow access from the specified Origin: ${origin}`;
    return callback(new Error(msg), false);
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept', 'Origin'],
  exposedHeaders: ['X-Total-Count', 'X-Page-Count'],
  preflightContinue: false,
  optionsSuccessStatus: 204
};

export default corsOptions;
