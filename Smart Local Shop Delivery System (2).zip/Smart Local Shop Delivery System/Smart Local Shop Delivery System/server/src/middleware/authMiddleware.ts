import { Request, Response, NextFunction } from 'express';
import User, { IUser } from '../models/User';
import { catchAsync, createError } from './errorHandler';

// Extend Request interface to include user
declare global {
  namespace Express {
    interface Request {
      user?: IUser;
    }
  }
}

// Protect admin routes - only ADMIN role can access
export const protectAdmin = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  // Get token from header
  let token: string | undefined;
  
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (!token) {
    return next(createError('You are not logged in. Please log in to get access.', 401));
  }

  // Verify token
  const jwt = require('jsonwebtoken');
  const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;

  // Check if user still exists
  const currentUser = await User.findById(decoded.id);
  if (!currentUser) {
    return next(createError('The user belonging to this token no longer exists.', 401));
  }

  // Check if user is active
  if (!currentUser.isActive) {
    return next(createError('Your account has been deactivated. Please contact support.', 401));
  }

  // Check if user is ADMIN
  if (currentUser.role !== 'ADMIN') {
    return next(createError('Access denied. Admin privileges required.', 403));
  }

  // Grant access
  req.user = currentUser;
  next();
});

// Protect delivery routes - only DELIVERY role can access
export const protectDelivery = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  // Get token from header
  let token: string | undefined;
  
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (!token) {
    return next(createError('You are not logged in. Please log in to get access.', 401));
  }

  // Verify token
  const jwt = require('jsonwebtoken');
  const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;

  // Check if user still exists
  const currentUser = await User.findById(decoded.id);
  if (!currentUser) {
    return next(createError('The user belonging to this token no longer exists.', 401));
  }

  // Check if user is active
  if (!currentUser.isActive) {
    return next(createError('Your account has been deactivated. Please contact support.', 401));
  }

  // Check if user is DELIVERY
  if (currentUser.role !== 'DELIVERY') {
    return next(createError('Access denied. Delivery agent privileges required.', 403));
  }

  // Grant access
  req.user = currentUser;
  next();
});

// General authentication middleware (for regular users)
export const protect = catchAsync(async (req: Request, res: Response, next: NextFunction) => {
  // Get token from header
  let token: string | undefined;
  
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (!token) {
    return next(createError('You are not logged in. Please log in to get access.', 401));
  }

  // Verify token
  const jwt = require('jsonwebtoken');
  const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;

  // Check if user still exists
  const currentUser = await User.findById(decoded.id);
  if (!currentUser) {
    return next(createError('The user belonging to this token no longer exists.', 401));
  }

  // Check if user is active
  if (!currentUser.isActive) {
    return next(createError('Your account has been deactivated. Please contact support.', 401));
  }

  // Grant access
  req.user = currentUser;
  next();
});
