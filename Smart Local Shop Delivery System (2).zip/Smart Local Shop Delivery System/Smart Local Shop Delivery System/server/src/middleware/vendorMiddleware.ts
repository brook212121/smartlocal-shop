import { Request, Response, NextFunction } from 'express';
import User, { IUser } from '../models/User';
import Product from '../models/Product';

declare global {
  namespace Express {
    interface Request {
      user?: IUser;
      product?: any;
    }
  }
}

export const requireVendor = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    // Temporary logging for req.user
    console.log('🔍 requireVendor - req.user:', {
      _id: req.user?._id,
      id: req.user?.id,
      role: req.user?.role,
      isVendor: req.user?.isVendor
    });

    // Check if user is authenticated
    if (!req.user) {
      res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
      return;
    }

    // Get user with vendor status using req.user._id
    const user = await User.findById(req.user._id);
    
    if (!user) {
      res.status(401).json({
        success: false,
        message: 'User not found'
      });
      return;
    }

    // Check if user has vendor access
    if (!user.isVendor) {
      res.status(403).json({
        success: false,
        message: 'Vendor access required. Please upgrade your account to vendor status.'
      });
      return;
    }

    // Check if user is active
    if (!user.isActive) {
      res.status(403).json({
        success: false,
        message: 'Account is deactivated'
      });
      return;
    }

    console.log('✅ requireVendor success:', {
      userId: user._id,
      role: user.role,
      isVendor: user.isVendor
    });

    next();
  } catch (error) {
    console.error('❌ requireVendor error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error during vendor verification'
    });
  }
};

export const requireProductOwner = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    // Check if user is authenticated
    if (!req.user) {
      res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
      return;
    }

    const productId = req.params.id;
    
    if (!productId) {
      res.status(400).json({
        success: false,
        message: 'Product ID is required'
      });
      return;
    }

    // Find the product
    const product = await Product.findById(productId);
    
    if (!product) {
      res.status(404).json({
        success: false,
        message: 'Product not found'
      });
      return;
    }

    // Check if the authenticated user owns this product
    if (product.vendor.toString() !== req.user._id.toString()) {
      res.status(403).json({
        success: false,
        message: 'Access denied. You can only manage your own products.'
      });
      return;
    }

    // Attach product to request for use in controllers
    req.product = product;
    next();
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server error during product ownership verification'
    });
  }
};
