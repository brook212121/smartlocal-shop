import express from 'express';
import helmet from 'helmet';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import { createServer } from 'http';

// Import configurations and middleware
import connectDB from './config/database';
import corsOptions from './middleware/cors';
import { globalErrorHandler } from './middleware/errorHandler';
import apiRoutes from './routes';
import deliveryValidationRoutes from './routes/deliveryValidationRoutes';
import complaintRoutes from './routes/complaintRoutes';
import SocketService from './services/socketService';

console.log('🔍 Importing delivery validation routes...', deliveryValidationRoutes);

// Load environment variables
dotenv.config();

// Connect to MongoDB
connectDB();

const app = express();
const httpServer = createServer(app);
const PORT = parseInt(process.env.PORT || '5000', 10);

// Initialize Socket.IO
const socketService = new SocketService(httpServer);

// Export socketService for use in other modules
export { socketService };

// Trust proxy for ngrok and other reverse proxies
app.set('trust proxy', ['loopback', 'linklocal', 'uniquelocal']);

// Rate limiting
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000'), // Use .env value (60 seconds) or fallback to 15 minutes
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '1000'), // Use .env value (1000 requests) or fallback to 100
  message: 'Too many requests from this IP, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
});

// Serve static files from uploads directory with CORS headers BEFORE main CORS middleware
app.use('/uploads', (req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, OPTIONS, POST, PUT, DELETE');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
  res.header('Access-Control-Allow-Credentials', 'true');
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
    return;
  }
  next();
}, express.static('uploads'));

// Middlewares
app.use(helmet()); // Security headers
app.use(cors(corsOptions)); // CORS configuration
app.use(morgan('combined')); // HTTP request logger
app.use(limiter); // Rate limiting
app.use(express.json({ limit: '10mb' })); // Parse JSON bodies
app.use(express.urlencoded({ extended: true, limit: '10mb' })); // Parse URL-encoded bodies

// API Routes
app.use('/api', apiRoutes);
app.use('/api/delivery-validation', deliveryValidationRoutes);
app.use('/api/complain', complaintRoutes);

// Test endpoint to verify image access
app.get('/test-image/:filename', (req, res) => {
  const filename = req.params.filename;
  const imagePath = path.join(__dirname, '..', 'uploads', filename);
  
  if (fs.existsSync(imagePath)) {
    res.sendFile(imagePath);
  } else {
    res.status(404).json({ error: 'Image not found' });
  }
});

// Root endpoint
app.get('/', (req, res) => {
  res.status(200).json({
    message: 'Smart Local Shop Delivery API',
    version: '1.0.0',
    status: 'running',
    endpoints: {
      health: '/api/health',
      info: '/api/info',
      api: '/api'
    }
  });
});

// 404 handler for undefined routes
app.use('*', (req, res) => {
  res.status(404).json({
    error: 'Not Found',
    message: `Route ${req.originalUrl} not found`,
    timestamp: new Date().toISOString()
  });
});

// Global error handler (must be last)
app.use(globalErrorHandler);

// Start server
const server = httpServer.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Server is running on port ${PORT}`);
  console.log(`🌐 Accessible at: http://0.0.0.0:${PORT}`);
  console.log(`📱 Works on all devices in the same network`);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (err: any) => {
  console.error('UNHANDLED REJECTION! Shutting down...');
  console.error(err.name, err.message);
  httpServer.close(() => {
    process.exit(1);
  });
});

// Handle uncaught exceptions
process.on('uncaughtException', (err: any) => {
  console.error('UNCAUGHT EXCEPTION! Shutting down...');
  console.error(err.name, err.message);
  httpServer.close(() => {
    process.exit(1);
  });
});

export default app;
