import nodemailer from 'nodemailer';
import fs from 'fs';
import path from 'path';

// Email configuration
const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 587,
  secure: false,
  auth: {
    user: process.env.GMAIL_EMAIL,
    pass: process.env.GMAIL_APP_PASSWORD
  }
});

export class EmailService {
  static async sendQuickOrderNotification(data: {
    vendorEmail: string;
    vendorName: string;
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    description: string;
    quantity?: number;
    imageUrl?: string;
  }) {
    try {
      const subject = 'New Quick Order Request';
      
      // Prepare image attachments and paths
      const attachments: any[] = [];
      let productImageSrc = '';
      
      // Handle product image if provided
      if (data.imageUrl) {
        console.log('DEBUG: Processing product image:', data.imageUrl);
        
        // Check if it's a local path or URL
        if (data.imageUrl.startsWith('http')) {
          // URL - download and attach
          try {
            const response = await fetch(data.imageUrl);
            const buffer = Buffer.from(await response.arrayBuffer());
            
            // Add to attachments
            attachments.push({
              filename: 'product-image.jpg',
              content: buffer,
              cid: 'productImage'
            });
            productImageSrc = 'cid:productImage';
            console.log('DEBUG: Downloaded and attached product image');
          } catch (error) {
            console.error('DEBUG: Failed to download product image:', error);
            productImageSrc = data.imageUrl; // Fallback to URL
          }
        } else {
          // Local path - attach directly
          const imagePath = path.join(process.cwd(), data.imageUrl.replace(/^\//, ''));
          if (fs.existsSync(imagePath)) {
            attachments.push({
              filename: 'product-image.jpg',
              path: imagePath,
              cid: 'productImage'
            });
            productImageSrc = 'cid:productImage';
            console.log('DEBUG: Added product image attachment from local path:', imagePath);
          } else {
            console.warn('DEBUG: Product image file not found:', imagePath);
            productImageSrc = data.imageUrl; // Fallback to original path
          }
        }
      }
      
      const htmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>New Quick Order Request</title>
          <style>
            body {
              font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
              line-height: 1.6;
              color: #333;
              max-width: 600px;
              margin: 0 auto;
              padding: 20px;
              background-color: #f8f9fa;
            }
            .container {
              background-color: #ffffff;
              padding: 30px;
              box-shadow: 0 4px 20px rgba(0,0,0,0.08);
              border: 1px solid #e9ecef;
            }
            .header {
              background: #07bc4c;;
              color: white;
              padding: 17px;
              text-align: center;
              margin: -30px -30px 25px -30px;
              position: relative;
            }
       
            .header h1 {
              margin: 0;
              font-size: 23px;
              font-weight: 700;
              position: relative;
              z-index: 1;
              text-shadow: 0 2px 4px rgba(0,0,0,0.2);
            }
          
            .section {
              margin-bottom: 25px;
            }
            .section-title {
              font-size: 16px;
              font-weight: 600;
              color: #07bc4c;
              margin-top: 15px;
              margin-bottom: 12px;
              border-bottom: 2px solid #07bc4c;
              padding-bottom: 8px;
              display: flex;
              align-items: center;
              gap: 8px;
            }
            .section-title::before {
              content: '📋';
              font-size: 18px;
            }
            .info-grid {
              display: grid;
              grid-template-columns: 1fr 1fr;
              gap: 15px;
              margin-bottom: 20px;
            }
            .info-item {
              background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
              padding: 12px 18px;
              transition: all 0.3s ease;
              display: flex;
              align-items: baseline;
              gap: 10px;
            }
            .info-item:hover {
              transform: translateY(-2px);
              box-shadow: 0 4px 12px rgba(7,188,76,0.15);
            }
            .info-label {
              font-weight: 600;
              color: #6c757d;
              font-size: 11px;
              text-transform: uppercase;
              letter-spacing: 0.8px;
              margin-bottom: 0;
              min-width: 120px;
            }
            .info-value {
              color: #2c3e50;
              font-size: 14px;
              font-weight: 500;
            }
            .description {
              background: linear-gradient(135deg, #e8f5e8 0%, #d4edda 100%);
              border: 1px solid #c3e6cb;
              padding: 20px;
              margin: 15px 0;
              position: relative;
            }
            .description::before {
              content: '💬';
              position: absolute;
              top: -10px;
              left: 15px;
              background: #07bc4c;
              color: white;
              width: 24px;
              height: 24px;
              border-radius: 50%;
              display: flex;
              align-items: center;
              justify-content: center;
              font-size: 12px;
            }
            .description-text {
              font-style: italic;
              color: #155724;
              font-size: 15px;
              margin: 0;
              padding-left: 10px;
            }
            .image-container {
              text-align: center;
              margin: 25px 0;
            }
            .product-image {
              max-width: 280px;
              max-height: 200px;
              box-shadow: 0 4px 15px rgba(0,0,0,0.1);
              border: 1px solid #e9ecef;
            }
            .product-image:hover {
              transform: scale(1.05);
            }
            .footer {
              text-align: center;
              margin-top: 30px;
              padding-top: 20px;
              border-top: 1px solid #e9ecef;
              color: #6c757d;
              font-size: 12px;
            }
            .footer-brand {
              color: #07bc4c;
              font-weight: 600;
              font-size: 14px;
              margin-bottom: 5px;
            }
            .cta-button {
              display: inline-block;
              background: linear-gradient(135deg, #07bc4c 0%, #05a843 100%);
              color: white;
              padding: 14px 30px;
              text-decoration: none;
              border-radius: 8px;
              font-weight: 600;
              font-size: 14px;
              text-align: center;
              transition: all 0.3s ease;
              box-shadow: 0 4px 15px rgba(7,188,76,0.3);
              border: none;
              cursor: pointer;
            }
            .cta-button:hover {
              transform: translateY(-2px);
              box-shadow: 0 6px 20px rgba(7,188,76,0.4);
            }
            .cta-container {
              text-align: center;
              margin: 25px 0;
            }
            .badge {
              display: inline-block;
              background: #07bc4c;
              color: white;
              padding: 4px 12px;
              border-radius: 20px;
              font-size: 11px;
              font-weight: 600;
              text-transform: uppercase;
              letter-spacing: 0.5px;
              margin-left: 8px;
            }
            .priority-indicator {
              display: flex;
              align-items: center;
              gap: 8px;
              margin-bottom: 20px;
            }
            .priority-dot {
              width: 8px;
              height: 8px;
              background: #ff6b35;
              border-radius: 50%;
              animation: pulse 2s infinite;
            }
            @keyframes pulse {
              0% { opacity: 1; }
              50% { opacity: 0.5; }
              100% { opacity: 1; }
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>New Quick Order Request</h1>
            </div>
            <div class="section">
              <div class="section-title">Customer Information</div>
              <div class="info-grid">
                <div class="info-item">
                  <div class="info-label">Customer Name:</div>
                  <div class="info-value">${data.customerName}</div>
                </div>
                <div class="info-item">
                  <div class="info-label">Contact Email:</div>
                  <div class="info-value">${data.customerEmail}</div>
                </div>
                <div class="info-item">
                  <div class="info-label">Phone Number:</div>
                  <div class="info-value">${data.customerPhone}</div>
                </div>
                ${data.quantity ? `
                <div class="info-item">
                  <div class="info-label">Quantity:</div>
                  <div class="info-value">${data.quantity}</div>
                </div>
                ` : ''}
              </div>
            </div>
            
            <div class="section">
              <div class="section-title">Order Details</div>
              <div class="description">
                <div class="description-text">"${data.description}"</div>
              </div>
            </div>
            
            ${data.imageUrl ? `
            <div class="section">
              <div class="section-title">Product Image</div>
              <div class="image-container">
                <img src="${productImageSrc}" alt="Product Image" class="product-image">
              </div>
            </div>
            ` : ''}
            
            <div class="cta-container">
              <a href="${process.env.FRONTEND_URL || 'http://localhost:5173'}/login?redirect=/dashboard/orders-received" class="cta-button">
                View Order
              </a>
            </div>
            
            <div class="footer">
              <div class="footer-brand">Smart Local Shop</div>
              <p>This is an automated notification about a new quick order request.</p>
              <p>Please log in to your dashboard to accept or reject this order.</p>
              <p style="margin-top: 10px; font-size: 11px; color: #adb5bd;">
                Powered by Smart Local Shop Delivery
              </p>
            </div>
          </div>
        </body>
        </html>
      `;

      const mailOptions = {
        from: process.env.GMAIL_EMAIL || `"Quick Order System" <${process.env.GMAIL_EMAIL}>`,
        to: data.vendorEmail,
        subject: subject,
        html: htmlContent,
        attachments: attachments.length > 0 ? attachments : undefined
      };

      console.log('DEBUG: Sending email with', attachments.length, 'attachments');
      const result = await transporter.sendMail(mailOptions);
      console.log('✅ Quick order email sent successfully to vendor:', data.vendorEmail);
      console.log('📧 Email result:', result.messageId);
      
      return { success: true, messageId: result.messageId };
    } catch (error: any) {
      console.error('❌ Error sending quick order email:', error);
      throw new Error(`Failed to send email: ${error?.message || error}`);
    }
  }
}

export default EmailService;
