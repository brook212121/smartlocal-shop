import { Server as SocketIOServer } from 'socket.io';
import { Server as HTTPServer } from 'http';
import jwt from 'jsonwebtoken';
import User from '../models/User';
import Order from '../models/Order';

export interface LocationUpdate {
  deliveryAgentId: string;
  orderId: string;
  location: {
    type: "Point";
    coordinates: [number, number]; // [longitude, latitude]
  };
  timestamp: Date;
}

export class SocketService {
  private io: SocketIOServer;
  private connectedAgents = new Map<string, string>(); // agentId -> socketId

  constructor(server: HTTPServer) {
    this.io = new SocketIOServer(server, {
      cors: {
        origin: process.env.NODE_ENV === 'production' 
          ? false 
          : ["http://localhost:3000", "https://kala-epidemiological-overquickly.ngrok-free.dev"],
        methods: ["GET", "POST"]
      }
    });

    this.setupMiddleware();
    this.setupEventHandlers();
  }

  private setupMiddleware() {
    // Authentication middleware
    this.io.use(async (socket, next) => {
      try {
        const token = socket.handshake.auth.token;
        if (!token) {
          return next(new Error('Authentication token required'));
        }

        const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
        const user = await User.findById(decoded.id);
        
        if (!user) {
          return next(new Error('User not found'));
        }

        socket.data.user = user;
        next();
      } catch (error) {
        next(new Error('Invalid authentication token'));
      }
    });
  }

  private setupEventHandlers() {
    this.io.on('connection', (socket) => {
      const user = socket.data.user;
      console.log(`🔌 User connected: ${user._id} (${user.role})`);

      // Join role-based rooms
      socket.join(`role_${user.role}`);
      socket.join(`user_${user._id}`);

      // Handle delivery agent location updates
      if (user.role === 'DELIVERY') {
        socket.on('location_update', async (data: LocationUpdate) => {
          await this.handleLocationUpdate(socket, data);
        });

        // Handle order tracking start/stop
        socket.on('start_tracking', async (orderId: string) => {
          await this.handleStartTracking(socket, orderId);
        });

        socket.on('stop_tracking', async (orderId: string) => {
          await this.handleStopTracking(socket, orderId);
        });
      }

      // Handle customer location tracking requests
      if (user.role === 'CUSTOMER') {
        socket.on('track_order', async (orderId: string) => {
          await this.handleTrackOrder(socket, orderId);
        });
      }

      // Handle vendor tracking requests
      if (user.role === 'VENDOR') {
        socket.on('track_order', async (orderId: string) => {
          await this.handleTrackOrder(socket, orderId);
        });
      }

      socket.on('disconnect', () => {
        console.log(`🔌 User disconnected: ${user._id} (${user.role})`);
        this.connectedAgents.delete(user._id.toString());
      });
    });
  }

  private async handleLocationUpdate(socket: any, data: LocationUpdate) {
    try {
      const user = socket.data.user;
      
      // Update delivery agent location in database
      await User.findByIdAndUpdate(user._id, {
        $set: {
          'location': {
            type: 'Point',
            coordinates: data.location.coordinates
          },
          'lastLocationUpdate': new Date()
        }
      });

      // Update order with current location
      await Order.findByIdAndUpdate(data.orderId, {
        $set: {
          'delivery.currentLocation': {
            type: 'Point',
            coordinates: data.location.coordinates
          },
          'delivery.lastLocationUpdate': new Date()
        }
      });

      // Broadcast location update to relevant parties
      const order = await Order.findById(data.orderId)
        .populate('customer', '_id')
        .populate('vendor', '_id');

      if (order) {
        // Send to customer
        this.io.to(`user_${order.customer._id}`).emit('agent_location_update', {
          orderId: data.orderId,
          agentId: user._id,
          location: data.location,
          timestamp: data.timestamp
        });

        // Send to vendor
        this.io.to(`user_${order.vendor._id}`).emit('agent_location_update', {
          orderId: data.orderId,
          agentId: user._id,
          location: data.location,
          timestamp: data.timestamp
        });
      }

      console.log(`📍 Location updated for agent ${user._id}:`, data.location.coordinates);
    } catch (error) {
      console.error('❌ Error handling location update:', error);
      socket.emit('error', { message: 'Failed to update location' });
    }
  }

  private async handleStartTracking(socket: any, orderId: string) {
    try {
      const user = socket.data.user;
      
      // Verify this order is assigned to this delivery agent
      const order = await Order.findOne({
        _id: orderId,
        'delivery.deliveryAgent': user._id,
        deliveryStatus: { $in: ['ASSIGNED', 'PICKED_UP', 'OUT_FOR_DELIVERY'] }
      });

      if (!order) {
        socket.emit('error', { message: 'Order not found or not assigned to you' });
        return;
      }

      // Join order tracking room
      socket.join(`order_${orderId}`);
      
      // Notify customer and vendor that tracking has started
      this.io.to(`user_${order.customer._id}`).emit('tracking_started', {
        orderId,
        agentId: user._id
      });

      this.io.to(`user_${order.vendor._id}`).emit('tracking_started', {
        orderId,
        agentId: user._id
      });

      socket.emit('tracking_started', { orderId });
      console.log(`📍 Tracking started for order ${orderId} by agent ${user._id}`);
    } catch (error) {
      console.error('❌ Error starting tracking:', error);
      socket.emit('error', { message: 'Failed to start tracking' });
    }
  }

  private async handleStopTracking(socket: any, orderId: string) {
    try {
      const user = socket.data.user;
      
      // Leave order tracking room
      socket.leave(`order_${orderId}`);
      
      // Notify customer and vendor that tracking has stopped
      const order = await Order.findById(orderId);
      if (order) {
        this.io.to(`user_${order.customer._id}`).emit('tracking_stopped', {
          orderId,
          agentId: user._id
        });

        this.io.to(`user_${order.vendor._id}`).emit('tracking_stopped', {
          orderId,
          agentId: user._id
        });
      }

      socket.emit('tracking_stopped', { orderId });
      console.log(`📍 Tracking stopped for order ${orderId} by agent ${user._id}`);
    } catch (error) {
      console.error('❌ Error stopping tracking:', error);
      socket.emit('error', { message: 'Failed to stop tracking' });
    }
  }

  private async handleTrackOrder(socket: any, orderId: string) {
    try {
      const user = socket.data.user;
      
      // Verify user can track this order
      const order = await Order.findOne({
        _id: orderId,
        $or: [
          { customer: user._id },
          { vendor: user._id }
        ]
      }).populate('delivery.deliveryAgent', '_id firstName lastName');

      if (!order) {
        socket.emit('error', { message: 'Order not found or access denied' });
        return;
      }

      // Join order tracking room
      socket.join(`order_${orderId}`);
      
      // Send current agent location if available
      if (order.delivery?.deliveryAgent && order.delivery?.currentLocation) {
        const agent = order.delivery.deliveryAgent as any; // Type assertion for populated fields
        socket.emit('agent_location_update', {
          orderId,
          agentId: order.delivery.deliveryAgent._id,
          agentName: agent.firstName && agent.lastName ? 
            `${agent.firstName} ${agent.lastName}` : 
            'Delivery Agent',
          location: order.delivery.currentLocation,
          timestamp: order.delivery.lastLocationUpdate
        });
      }

      socket.emit('tracking_active', { orderId });
      console.log(`📍 User ${user._id} started tracking order ${orderId}`);
    } catch (error) {
      console.error('❌ Error handling track order:', error);
      socket.emit('error', { message: 'Failed to track order' });
    }
  }

  // Public methods
  public getIO() {
    return this.io;
  }

  public broadcastToRole(role: string, event: string, data: any) {
    this.io.to(`role_${role}`).emit(event, data);
  }

  public broadcastToUser(userId: string, event: string, data: any) {
    this.io.to(`user_${userId}`).emit(event, data);
  }
}

export default SocketService;
