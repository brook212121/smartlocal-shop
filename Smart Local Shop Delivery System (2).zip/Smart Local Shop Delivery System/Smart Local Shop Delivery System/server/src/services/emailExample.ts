// Example usage of EmailService for Quick Order Notifications
import EmailService from './emailService';

// Example: Send quick order email to assigned vendor
export const exampleQuickOrderEmail = async () => {
  try {
    const result = await EmailService.sendQuickOrderNotification({
      vendorEmail: 'vendor@example.com',
      vendorName: 'John Doe',
      customerName: 'Jane Smith',
      customerEmail: 'customer@example.com',
      customerPhone: '+251912345678',
      description: 'I need fresh vegetables and fruits for home delivery',
      quantity: 2,
      imageUrl: 'http://localhost:3000/uploads/product-image.jpg'
    });
    
    console.log('✅ Example email sent:', result);
  } catch (error) {
    console.error('❌ Example email failed:', error);
  }
};

// Example email template output:
/*
Subject: New Quick Order Request

HTML Email Content:
- Clean, professional design with gradient header
- Customer information grid (Name, Email, Phone, Quantity)
- Order description highlighted section
- Product image (if available)
- Call-to-action button to dashboard
- Footer with instructions

Email includes:
✓ Customer name and contact details
✓ Order description (what they need)
✓ Quantity (if provided)
✓ Product image (if uploaded)
✓ Professional styling and layout
✓ Direct link to vendor dashboard
*/
