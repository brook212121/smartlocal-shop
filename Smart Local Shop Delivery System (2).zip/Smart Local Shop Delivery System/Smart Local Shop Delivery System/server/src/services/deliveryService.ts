import User from '../models/User';
import Order from '../models/Order';
import { Types } from 'mongoose';

export interface DeliveryAgent {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  coordinates: {
    latitude: number;
    longitude: number;
    address?: string;
  };
  isActive: boolean;
  isOnline: boolean;
  rating?: number;
  totalDeliveries?: number;
  lastLocationUpdate?: Date;
}

export interface DeliveryAssignment {
  deliveryAgentId: string;
  deliveryAgentName: string;
  deliveryAgentPhone: string;
  status: "ASSIGNED" | "PICKED_UP" | "DELIVERED";
  assignedAt: string;
  estimatedDeliveryTime?: string;
}

class DeliveryService {
  // Get available delivery agents
  async getAvailableDeliveryAgents(): Promise<DeliveryAgent[]> {
    try {
      const agents = await User.find({
        isDelivery: true,
        isActive: true,
        isOnline: true,
        location: { $exists: true }
      })
      .select('firstName lastName email phone location locationData isActive isOnline rating totalDeliveries lastLocationUpdate isDelivery isVendor')
      .lean();

      return agents.map(agent => ({
        _id: agent._id.toString(),
        firstName: agent.firstName,
        lastName: agent.lastName,
        email: agent.email,
        phone: agent.phone,
        coordinates: {
          latitude: (agent as any).coordinates?.lat || 0,
          longitude: (agent as any).coordinates?.lng || 0,
          address: `${(agent as any).locationData?.street || ''}, ${(agent as any).locationData?.city || ''}, ${(agent as any).locationData?.county || ''}`
        },
        isActive: agent.isActive,
        isOnline: agent.isOnline,
        rating: (agent as any).rating,
        totalDeliveries: (agent as any).totalDeliveries,
        lastLocationUpdate: (agent as any).lastLocationUpdate
      }));
    } catch (error) {
      console.error('Error fetching delivery agents:', error);
      return [];
    }
  }

  // Find nearest delivery agent to vendor location using Google// Find nearest delivery agent using GeoJSON
  async findNearestDeliveryAgentGeoJSON(
    vendorLocation: { latitude: number; longitude: number }
  ): Promise<{ agent: DeliveryAgent | null; distance: number; duration: number }> {
    try {
      console.log('=== DEBUG: Finding delivery agents near vendor location ===');
      console.log('Vendor location:', vendorLocation);
      
      // Use MongoDB's $nearSphere with GeoJSON
      const agents = await User.find({
        isDelivery: true,
        isActive: true,
        location: {
          $nearSphere: {
            $geometry: {
              type: 'Point',
              coordinates: [vendorLocation.longitude, vendorLocation.latitude]
            },
            $maxDistance: 100000 // 100km in meters
          }
        }
      })
      .select('firstName lastName phone location lastLocationUpdate isDelivery isVendor isActive')
      .lean();

      console.log('Found agents with isDelivery: true:', agents.length);
      console.log('Agents found:', agents.map(a => ({ name: a.firstName + ' ' + a.lastName, isDelivery: (a as any).isDelivery, isActive: a.isActive })));

      if (agents.length === 0) {
        console.log('No delivery agents found, checking all users with isDelivery: true...');
        const allDeliveryAgents = await User.find({ isDelivery: true }).lean();
        console.log('All delivery agents in database:', allDeliveryAgents.length);
        console.log('All delivery agents:', allDeliveryAgents.map(a => ({ name: a.firstName + ' ' + a.lastName, isDelivery: (a as any).isDelivery, isActive: a.isActive, hasLocation: !!(a as any).location })));
        
        return { agent: null, distance: 0, duration: 0 };
      }

      // Get the first (nearest) agent
      const nearestAgent = agents[0];
      
      // Calculate distance using haversine formula for more accuracy
      const distance = this.calculateHaversineDistance(
        vendorLocation.latitude,
        vendorLocation.longitude,
        (nearestAgent as any).coordinates?.lat || 0,
        (nearestAgent as any).coordinates?.lng || 0
      );

      // Calculate estimated delivery time (30 minutes + 5 minutes per km)
      const duration = 30 + (distance * 5);

      const agent: DeliveryAgent = {
        _id: nearestAgent._id.toString(),
        firstName: nearestAgent.firstName,
        lastName: nearestAgent.lastName,
        email: nearestAgent.email,
        phone: nearestAgent.phone,
        coordinates: {
          latitude: (nearestAgent as any).coordinates?.lat || 0,
          longitude: (nearestAgent as any).coordinates?.lng || 0
        },
        isActive: nearestAgent.isActive,
        isOnline: nearestAgent.isOnline,
        rating: (nearestAgent as any).rating,
        totalDeliveries: (nearestAgent as any).totalDeliveries,
        lastLocationUpdate: (nearestAgent as any).lastLocationUpdate
      };

      return {
        agent,
        distance: Math.round(distance * 100) / 100, // Round to 2 decimal places
        duration: Math.round(duration)
      };
    } catch (error) {
      console.error('Error finding nearest delivery agent using GeoJSON:', error);
      return { agent: null, distance: 0, duration: 0 };
    }
  }

  // Find nearest delivery agent (legacy method for fallback)
  async findNearestDeliveryAgent(
    vendorLocation: { latitude: number; longitude: number }
  ): Promise<{ agent: DeliveryAgent | null; distance: number; duration: number }> {
    try {
      // Get available delivery agents
      const agents = await this.getAvailableDeliveryAgents();
      
      if (agents.length === 0) {
        return { agent: null, distance: 0, duration: 0 };
      }

      // Calculate Haversine distances for initial filtering
      const agentsWithDistance = agents.map(agent => {
        const distance = this.calculateHaversineDistance(
          vendorLocation.latitude,
          vendorLocation.longitude,
          agent.coordinates.latitude,
          agent.coordinates.longitude
        );
        return {
          agent,
          haversineDistanceKm: distance
        };
      });

      // Filter agents within 100km radius
      const nearbyAgents = agentsWithDistance.filter(item => item.haversineDistanceKm <= 100);
      
      if (nearbyAgents.length === 0) {
        return { agent: null, distance: 0, duration: 0 };
      }

      // Sort by Haversine distance
      nearbyAgents.sort((a, b) => a.haversineDistanceKm - b.haversineDistanceKm);

      // For now, return the closest by Haversine distance
      // In production, you'd use Google Distance Matrix API for accurate driving distances
      const nearest = nearbyAgents[0];
      
      return {
        agent: nearest.agent,
        distance: nearest.haversineDistanceKm,
        duration: Math.round(nearest.haversineDistanceKm * 2) // Rough estimate: 2 minutes per km
      };
    } catch (error) {
      console.error('Error finding nearest delivery agent:', error);
      return { agent: null, distance: 0, duration: 0 };
    }
  }

  // Assign delivery agent to order
  async assignDeliveryAgent(
    orderId: string,
    deliveryAgentId: string,
    vendorLocation: { latitude: number; longitude: number },
    customerLocation: { latitude: number; longitude: number }
  ): Promise<DeliveryAssignment> {
    try {
      // Get delivery agent details
      const agent = await User.findById(deliveryAgentId)
        .select('firstName lastName email phone')
        .lean();

      if (!agent) {
        throw new Error('Delivery agent not found');
      }

      // Update order with delivery agent
      const order = await Order.findById(orderId);
      if (!order) {
        throw new Error('Order not found');
      }

      // Set delivery agent and update delivery status
      order.delivery.deliveryAgent = new Types.ObjectId(deliveryAgentId);
      order.deliveryStatus = 'ASSIGNED';
      order.status = 'READY_FOR_PICKUP';
      
      // Set customer location if not already set
      if (!order.delivery.address.coordinates) {
        order.delivery.address.coordinates = {
          latitude: customerLocation.latitude,
          longitude: customerLocation.longitude
        };
      }

      // Save order with delivery assignment
      try {
        await order.save();
      } catch (saveError: any) {
        console.error('Failed to save order to database:', saveError);
        throw new Error(`Failed to save delivery assignment: ${saveError.message || saveError}`);
      }

      const assignment: DeliveryAssignment = {
        deliveryAgentId,
        deliveryAgentName: `${agent.firstName} ${agent.lastName}`,
        deliveryAgentPhone: agent.phone,
        status: 'ASSIGNED',
        assignedAt: new Date().toISOString()
      };

      return assignment;
    } catch (error) {
      console.error('Error assigning delivery agent:', error);
      throw error;
    }
  }

  // Update delivery status
  async updateDeliveryStatus(
    orderId: string,
    status: "ASSIGNED" | "PICKED_UP" | "DELIVERED"
  ): Promise<void> {
    try {
      const order = await Order.findById(orderId);
      if (!order) {
        throw new Error('Order not found');
      }

      order.deliveryStatus = status;
      
      // Update order status based on delivery status
      switch (status) {
        case 'ASSIGNED':
          order.status = 'READY_FOR_PICKUP';
          break;
        case 'PICKED_UP':
          order.status = 'OUT_FOR_DELIVERY';
          break;
        case 'DELIVERED':
          order.status = 'DELIVERED';
          order.delivery.actualTime = new Date();
          break;
      }

      await order.save();

      console.log('Delivery status updated:', {
        orderId,
        deliveryStatus: status,
        orderStatus: order.status
      });
    } catch (error) {
      console.error('Error updating delivery status:', error);
      throw error;
    }
  }

  // Get delivery assignments for agent
  async getDeliveryAssignments(deliveryAgentId: string): Promise<any[]> {
    try {
      const orders = await Order.find({
        'delivery.deliveryAgent': deliveryAgentId,
        status: { $in: ['READY_FOR_PICKUP', 'OUT_FOR_DELIVERY'] }
      })
      .populate('customer', 'firstName lastName email phone')
      .populate('vendor', 'firstName lastName email phone location')
      .populate('items.product', 'name price images')
      .sort({ createdAt: -1 });

      return orders.map(order => ({
        _id: order._id,
        orderNumber: order.orderNumber,
        description: order.items.map((item: any) => (item.product as any)?.name || 'Product').join(', '),
        price: order.pricing.total,
        quantity: (order as any).totalItems || order.items.reduce((total: number, item: any) => total + item.quantity, 0),
        status: order.status,
        deliveryStatus: order.deliveryStatus,
        vendor: {
          firstName: (order.vendor as any).firstName,
          lastName: (order.vendor as any).lastName,
          phone: (order.vendor as any).phone,
          location: (order.vendor as any).vendorLocation
        },
        customer: {
          firstName: (order.customer as any).firstName,
          lastName: (order.customer as any).lastName,
          phone: (order.customer as any).phone,
          location: order.delivery.address.coordinates
        },
        delivery: {
          required: true,
          deliveryAgentId: deliveryAgentId,
          status: order.deliveryStatus,
          assignedAt: order.updatedAt,
          estimatedDeliveryTime: order.delivery.estimatedTime
        },
        createdAt: order.createdAt
      }));
    } catch (error) {
      console.error('Error fetching delivery assignments:', error);
      return [];
    }
  }

  // Find nearest vendor to customer location using GeoJSON
  async findNearestVendor(
    customerLocation: { latitude: number; longitude: number },
    requestingUserId?: string,  // ✅ Add requestingUserId parameter
    vendorLocation?: { latitude: number; longitude: number }
  ): Promise<{ vendor: any; distance: number }> {
    try {
      console.log('🔍 DEBUG: Finding nearest vendor for customer location:', customerLocation);
      console.log('🔍 DEBUG: Excluding user ID:', requestingUserId);
      
      // Build query conditions
      const queryConditions: any = {
        role: 'VENDOR',
        isActive: true,
        vendorLocation: {
          $nearSphere: {
            $geometry: {
              type: 'Point',
              coordinates: [customerLocation.longitude, customerLocation.latitude]
            },
            $maxDistance: 50000 // 50km in meters
          }
        }
      };
      
      // Exclude requesting user if provided
      if (requestingUserId) {
        queryConditions._id = { $ne: requestingUserId };
      }
      
      // Use MongoDB's $nearSphere with GeoJSON
      const vendors = await User.find(queryConditions)
      .select('firstName lastName email phone coordinates vendorLocation isActive isOnline averageRating totalDeliveries lastLocationUpdate')
      .lean();

      console.log('🔍 DEBUG: Found vendors near customer:', vendors.length);
      console.log('🔍 DEBUG: First vendor (if any):', vendors[0]);

      if (vendors.length === 0) {
        console.log('🔍 DEBUG: No vendors found within 50km, checking all vendors...');
        // Let's check if there are any vendors at all
        const allVendors = await User.find({ role: 'VENDOR', isActive: true })
          .select('firstName lastName coordinates vendorLocation')
          .limit(5)
          .lean();
        console.log('🔍 DEBUG: Total vendors in database:', allVendors.length);
        console.log('🔍 DEBUG: Sample vendors:', allVendors);
        return { vendor: null, distance: 0 };
      }

      // Add safety check for vendors[0]
      const firstVendor = vendors[0];
      if (!firstVendor || !firstVendor.coordinates || firstVendor.coordinates.lat == null || firstVendor.coordinates.lng == null) {
        return { vendor: null, distance: 0 };
      }
      
      // Add guard check for vendorLocation
      if (!firstVendor.vendorLocation || !firstVendor.vendorLocation.coordinates || firstVendor.vendorLocation.coordinates.length !== 2) {
        console.error("vendorLocation is missing or invalid");
        return { vendor: null, distance: 0 };
      }
      
      // Extract coordinates from GeoJSON format
      const vendorLongitude = firstVendor.vendorLocation.coordinates[0];
      const vendorLatitude = firstVendor.vendorLocation.coordinates[1];
      
      // Calculate distance using haversine formula for more accuracy
      const distance = this.calculateHaversineDistance(
        customerLocation.latitude,
        customerLocation.longitude,
        vendorLatitude,
        vendorLongitude
      );

      const nearestVendor = {
        vendor: firstVendor,
        distance: Math.round(distance * 100) / 100 // Round to 2 decimal places
      };
      
      return nearestVendor;

    } catch (error: any) {
      console.error('Error finding nearest vendor:', error);
      return { vendor: null, distance: 0 };
    }
  }

  // Calculate Haversine distance between two points
  private calculateHaversineDistance(
    lat1: number,
    lon1: number,
    lat2: number,
    lon2: number
  ): number {
    const R = 6371; // Earth's radius in kilometers
    const dLat = this.toRadians(lat2 - lat1);
    const dLon = this.toRadians(lon2 - lon1);
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRadians(lat1)) * Math.cos(this.toRadians(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  private toRadians(degrees: number): number {
    return degrees * (Math.PI / 180);
  }
}

export default new DeliveryService();
