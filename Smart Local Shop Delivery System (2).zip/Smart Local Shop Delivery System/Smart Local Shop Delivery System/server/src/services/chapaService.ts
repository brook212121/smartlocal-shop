import axios from 'axios';

// Chapa API configuration
const CHAPA_API_URL = process.env.CHAPA_API_URL || 'https://api.chapa.co/v1';
const CHAPA_SECRET_KEY = process.env.CHAPA_SECRET_KEY;

// Debug: Check if Chapa credentials are loaded
console.log('Chapa Service Configuration:', {
  CHAPA_API_URL,
  CHAPA_SECRET_KEY: CHAPA_SECRET_KEY ? `${CHAPA_SECRET_KEY.substring(0, 10)}...` : 'NOT_SET',
  ADMIN_ACCOUNT_NAME: process.env.ADMIN_ACCOUNT_NAME,
  ADMIN_ACCOUNT_NUMBER: process.env.ADMIN_ACCOUNT_NUMBER
});

// Admin bank account configured in Chapa dashboard
const ADMIN_BANK_ACCOUNT = {
  account_name: process.env.ADMIN_ACCOUNT_NAME || 'Smart Local Shop',
  account_number: process.env.ADMIN_ACCOUNT_NUMBER || '',
  bank_code: process.env.ADMIN_BANK_CODE || '',
  bank_name: process.env.ADMIN_BANK_NAME || 'Commercial Bank of Ethiopia'
};

export interface ChapaPaymentRequest {
  amount: number;
  currency: string;
  email: string;
  first_name: string;
  last_name: string;
  phone_number: string;
  tx_ref: string; // Unique transaction reference
  callback_url: string;
  return_url: string;
  customization?: {
    title?: string;
    description?: string;
    logo?: string;
  };
}

export interface ChapaPaymentResponse {
  status: string;
  message: string;
  data: {
    checkout_url: string;
    tx_ref: string;
    amount: string;
    currency: string;
    email: string;
    first_name: string;
    last_name: string;
    phone_number: string;
    created_at: string;
    updated_at: string;
  };
}

export interface ChapaVerificationResponse {
  status: string;
  message: string;
  data: {
    first_name: string;
    last_name: string;
    email: string;
    phone_number: string;
    amount: string;
    currency: string;
    status: string; // 'success', 'pending', 'failed'
    tx_ref: string;
    flw_ref: string;
    created_at: string;
    updated_at: string;
    subaccount?: string;
    charge_amount?: string;
    app_fee?: string;
    merchant_fee?: string;
  };
}

class ChapaService {
  private headers = {
    'Authorization': `Bearer ${CHAPA_SECRET_KEY}`,
    'Content-Type': 'application/json'
  };

  /**
   * Initialize payment with Chapa checkout
   * Buyers pay the admin account directly
   */
  async initializePayment(paymentData: ChapaPaymentRequest): Promise<ChapaPaymentResponse> {
    try {
      console.log('💳 Initializing Chapa payment with data:', {
        amount: paymentData.amount,
        currency: paymentData.currency,
        email: paymentData.email,
        tx_ref: paymentData.tx_ref,
        callback_url: paymentData.callback_url
      });

      // Check if secret key is available
      if (!CHAPA_SECRET_KEY) {
        throw new Error('CHAPA_SECRET_KEY is not configured');
      }

      // Add admin account as subaccount to receive funds
      const requestData = {
        ...paymentData,
        subaccount: 'admin_account', // Admin receives all payments
        split_type: 'percentage',
        split_value: 100, // 100% goes to admin
        // Admin bank account for settlement
        bank_transfer_details: {
          account_name: ADMIN_BANK_ACCOUNT.account_name,
          account_number: ADMIN_BANK_ACCOUNT.account_number,
          bank_code: ADMIN_BANK_ACCOUNT.bank_code,
          bank_name: ADMIN_BANK_ACCOUNT.bank_name
        }
      };

      console.log('📤 Sending request to Chapa API:', CHAPA_API_URL);

      const response = await axios.post(
        `${CHAPA_API_URL}/transaction/initialize`,
        requestData,
        { headers: this.headers }
      );

      console.log('✅ Chapa API response:', {
        status: response.data.status,
        message: response.data.message,
        checkout_url: response.data.data?.checkout_url,
        tx_ref: response.data.data?.tx_ref
      });

      return response.data;
    } catch (error: any) {
      console.error('❌ Chapa payment initialization error:', error.response?.data || error.message);
      throw new Error(error.response?.data?.message || 'Failed to initialize payment');
    }
  }

  /**
   * Verify transaction status with Chapa API
   */
  async verifyTransaction(tx_ref: string): Promise<ChapaVerificationResponse> {
    try {
      const response = await axios.get(
        `${CHAPA_API_URL}/transaction/verify/${tx_ref}`,
        { headers: this.headers }
      );

      return response.data;
    } catch (error: any) {
      console.error('Chapa verification error:', error.response?.data || error.message);
      throw new Error(error.response?.data?.message || 'Failed to verify transaction');
    }
  }

  /**
   * Generate unique transaction reference
   */
  generateTransactionReference(prefix: string = 'SLS'): string {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(2, 8).toUpperCase();
    return `${prefix}${timestamp}${random}`;
  }

  /**
   * Check if transaction is successful
   */
  isTransactionSuccessful(verificationData: ChapaVerificationResponse): boolean {
    return verificationData.data.status === 'success';
  }

  /**
   * Get payment amount from verification data
   */
  getPaymentAmount(verificationData: ChapaVerificationResponse): number {
    return parseFloat(verificationData.data.amount);
  }

  /**
   * Get transaction reference from verification data
   */
  getTransactionReference(verificationData: ChapaVerificationResponse): string {
    return verificationData.data.tx_ref;
  }

  /**
   * Note: Chapa vendor payout is NOT implemented
   * All withdrawals are handled internally via system wallet
   * Real-world bank transfers are done manually by admin
   */
  async processVendorPayout(withdrawalData: any): Promise<never> {
    throw new Error('Vendor payout via Chapa is not implemented. Use internal wallet system for withdrawals.');
  }
}

export default new ChapaService();
