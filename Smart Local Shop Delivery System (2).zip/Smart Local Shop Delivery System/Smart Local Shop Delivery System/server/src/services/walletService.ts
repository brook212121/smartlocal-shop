import AdminWallet, { IAdminWallet } from '../models/AdminWallet';
import VendorWallet, { IVendorWallet } from '../models/VendorWallet';
import Withdrawal, { IWithdrawal } from '../models/Withdrawal';
import Order from '../models/Order';

export interface WalletTransaction {
  type: 'PAYMENT_RECEIVED' | 'VENDOR_WITHDRAWAL' | 'SYSTEM_FEE' | 'REFUND' | 'EARNED' | 'WITHDRAWAL' | 'HELD' | 'RELEASED' | 'FEE_DEDUCTED';
  amount: number;
  description: string;
  referenceId?: string;
  vendorId?: string;
  orderId?: string;
  withdrawalId?: string;
}

class WalletService {
  /**
   * Get or create admin wallet
   */
  async getAdminWallet(): Promise<IAdminWallet> {
    let wallet = await AdminWallet.findOne();
    if (!wallet) {
      wallet = await AdminWallet.create({
        totalBalance: 0,
        totalReceived: 0,
        totalPaidOut: 0,
        pendingPayouts: 0,
        transactionHistory: []
      });
    }
    return wallet;
  }

  /**
   * Get vendor wallet by vendor ID
   */
  async getVendorWallet(vendorId: string): Promise<IVendorWallet> {
    let wallet = await VendorWallet.findOne({ vendorId });
    if (!wallet) {
      wallet = await VendorWallet.create({
        vendorId,
        totalEarned: 0,
        availableBalance: 0,
        pendingBalance: 0,
        totalWithdrawn: 0,
        holdingPeriodMinutes: 2,
        transactionHistory: [],
        withdrawalMethods: []
      });
    }
    return wallet;
  }

  /**
   * Process payment received from buyer via Chapa
   * Credits admin wallet and marks order as paid
   */
  async processPaymentReceived(orderId: string, amount: number, txRef: string): Promise<void> {
    try {
      // Update order status to PAID
      const order = await Order.findById(orderId);
      if (!order) {
        throw new Error('Order not found');
      }
      
      order.status = 'PAID';
      order.payment.status = 'PAID';
      order.payment.transactionId = txRef;
      await order.save();

      // Credit admin wallet with full payment amount
      const adminWallet = await this.getAdminWallet();
      adminWallet.totalBalance += amount;
      adminWallet.totalReceived += amount;
      
      // Add transaction to admin wallet history
      adminWallet.transactionHistory.push({
        type: 'PAYMENT_RECEIVED',
        amount,
        description: `Payment received for order ${order.orderNumber}`,
        referenceId: orderId,
        vendorId: order.vendor as any,
        createdAt: new Date()
      });
      
      adminWallet.lastUpdated = new Date();
      await adminWallet.save();

      // Only process wallet updates for PAID orders to prevent double counting
      if (order.payment?.status !== 'PAID') {
        console.log(`🔍 DEBUG: Skipping wallet update - order not PAID. Status: ${order.payment?.status}`);
        return;
      }
      
      // Check if wallet already processed for this order to prevent duplicates
      if (order.isWalletProcessed) {
        console.log(`🔍 DEBUG: Skipping wallet update - order already processed. Order: ${order.orderNumber}`);
        return;
      }
      
      console.log(`🔍 DEBUG: Processing PAID order ${order.orderNumber} for amount ${amount}`);
      
      // Credit vendor wallet (new flow)
      const vendorWallet = await this.getVendorWallet((order.vendor as any).toString());
      
      // Add full payment amount to pendingBalance (under holding period)
      vendorWallet.pendingBalance += amount;
      
      // Mark order as wallet processed to prevent duplicate updates
      order.isWalletProcessed = true;
      await order.save();
      
      console.log(`🔍 DEBUG: Adding ${amount} to pendingBalance: ${vendorWallet.pendingBalance}`);
      
      // Do NOT add anything to availableBalance yet
      // Do NOT deduct platform fee yet
      
      // Add transaction to vendor wallet history
      vendorWallet.transactionHistory.push({
        type: 'CUSTOMER_PAYMENT',
        amount,
        description: `Customer payment received for order ${order.orderNumber}`,
        referenceId: orderId,
        orderId: order._id,
        createdAt: new Date()
      });
      
      // Add transaction for funds pending
      vendorWallet.transactionHistory.push({
        type: 'FUNDS_PENDING',
        amount,
        description: `Funds pending for order ${order.orderNumber}`,
        referenceId: orderId,
        orderId: order._id,
        createdAt: new Date()
      });
      
      vendorWallet.lastUpdated = new Date();
      await vendorWallet.save();

    } catch (error) {
      throw error;
    }
  }

  /**
   * Release funds from holding period (idempotent - safe to run multiple times)
   */
  async releaseHeldFunds(vendorId: string): Promise<void> {
    try {
      console.log(`🔍 DEBUG: Releasing funds for vendor ${vendorId}`);
      
      const vendorWallet = await this.getVendorWallet(vendorId);
      const holdingPeriodMinutes = vendorWallet.holdingPeriodMinutes || 10080;
      const cutoffDate = new Date();
      cutoffDate.setMinutes(cutoffDate.getMinutes() - holdingPeriodMinutes);

      console.log(`🔍 DEBUG: Holding period: ${holdingPeriodMinutes} minutes`);
      console.log(`🔍 DEBUG: Cutoff date: ${cutoffDate.toISOString()}`);
      console.log(`🔍 DEBUG: Current pending balance: ${vendorWallet.pendingBalance}`);
      console.log(`🔍 DEBUG: Current available balance: ${vendorWallet.availableBalance}`);
      
      // Log all transactions for debugging
      console.log(`🔍 DEBUG: All transactions (${vendorWallet.transactionHistory.length}):`);
      vendorWallet.transactionHistory.forEach((tx, index) => {
        console.log(`🔍 DEBUG: Transaction ${index}: type=${tx.type}, amount=${tx.amount}, isReleased=${tx.isReleased}, createdAt=${tx.createdAt.toISOString()}, description="${tx.description}"`);
      });

      // Find HELD transactions that are past holding period AND not yet released
      const transactionsToRelease = vendorWallet.transactionHistory.filter(
        tx => tx.type === 'HELD' && 
              tx.createdAt < cutoffDate && 
              !tx.isReleased
      );

      console.log(`🔍 DEBUG: Found ${transactionsToRelease.length} transactions to release`);
      
      if (transactionsToRelease.length === 0) {
        console.log(`🔍 DEBUG: No transactions to release - all funds already available`);
        return; // No funds to release
      }

      // Log details of transactions to be released
      transactionsToRelease.forEach((tx, index) => {
        console.log(`🔍 DEBUG: Transaction to release ${index}: amount=${tx.amount}, createdAt=${tx.createdAt.toISOString()}, cutoff=${cutoffDate.toISOString()}, isPastHolding=${tx.createdAt < cutoffDate}`);
      });

      const totalToRelease = transactionsToRelease.reduce((sum, tx) => sum + tx.amount, 0);
      console.log(`🔍 DEBUG: Total amount to release: ${totalToRelease}`);

      // Validate that we don't release more than pending balance
      if (totalToRelease > vendorWallet.pendingBalance) {
        console.log(`🔍 DEBUG WARNING: Total to release (${totalToRelease}) exceeds pending balance (${vendorWallet.pendingBalance})`);
        console.log(`🔍 DEBUG: Adjusting to prevent negative balance`);
        return; // Skip release to prevent negative balance
      }

      // Update vendor wallet - move funds from pendingBalance to availableBalance
      vendorWallet.pendingBalance -= totalToRelease;
      vendorWallet.availableBalance += totalToRelease;
      
      console.log(`🔍 DEBUG: Updated pending balance: ${vendorWallet.pendingBalance}`);
      console.log(`🔍 DEBUG: Updated available balance: ${vendorWallet.availableBalance}`);

      // Mark the original HELD transactions as released
      transactionsToRelease.forEach(tx => {
        tx.isReleased = true;
        console.log(`🔍 DEBUG: Marked transaction as released: amount=${tx.amount}, description="${tx.description}"`);
      });

      // Add a single FUNDS_RELEASED transaction for the total amount
      vendorWallet.transactionHistory.push({
        type: 'FUNDS_RELEASED',
        amount: totalToRelease,
        description: `Funds released from holding period (${transactionsToRelease.length} orders)`,
        createdAt: new Date(),
        isReleased: true // Mark as released since this is the release transaction
      });

      vendorWallet.lastUpdated = new Date();
      await vendorWallet.save();

      console.log(`🔍 DEBUG: Funds released successfully!`);
      console.log(`🔍 DEBUG: Final balances - Available: ${vendorWallet.availableBalance}, Pending: ${vendorWallet.pendingBalance}`);

    } catch (error) {
      console.error('🔍 ERROR: Failed to release held funds:', error);
      throw error;
    }
  }

  /**
   * Process vendor withdrawal request
   * Auto-approves based on rules and updates wallets
   */
  async processWithdrawal(withdrawalId: string): Promise<IWithdrawal> {
    const withdrawal = await Withdrawal.findById(withdrawalId).populate('vendorId');
    if (!withdrawal) {
      throw new Error('Withdrawal not found');
    }

    const vendorWallet = await this.getVendorWallet(withdrawal.vendorId.toString());
    const adminWallet = await this.getAdminWallet();

    // Check approval rules
    // Vendor can only withdraw from availableBalance
    const sufficientBalance = vendorWallet.availableBalance >= withdrawal.amount;
    const verifiedMethod = withdrawal.withdrawalMethod.type === 'BANK_TRANSFER' && 
                          withdrawal.withdrawalMethod.accountNumber ? true :
                          withdrawal.withdrawalMethod.type === 'MOBILE_MONEY' && 
                          withdrawal.withdrawalMethod.phoneNumber ? true : false;
    const withinLimits = withdrawal.amount <= 50000; // Max 50,000 ETB per withdrawal

    withdrawal.approvalRules = {
      sufficientBalance,
      verifiedMethod,
      withinLimits
    };

    // Auto-approve if all rules pass
    if (sufficientBalance && verifiedMethod && withinLimits) {
      withdrawal.status = 'APPROVED';
      withdrawal.autoApproved = true;
      withdrawal.processedAt = new Date();

      // Calculate platform fee and vendor receives amount
      const platformFee = withdrawal.amount * 0.05; // 5% platform fee
      const vendorReceives = withdrawal.amount - platformFee;

      // Update vendor wallet
      vendorWallet.availableBalance -= withdrawal.amount; // Deduct full requested amount
      vendorWallet.totalWithdrawn += vendorReceives; // Add actual amount vendor receives
      
      // Add withdrawal transaction
      vendorWallet.transactionHistory.push({
        type: 'WITHDRAWAL_REQUESTED',
        amount: withdrawal.amount,
        description: `Withdrawal requested - ${withdrawal.withdrawalMethod.type}`,
        referenceId: withdrawal._id.toString(),
        withdrawalId: withdrawal._id,
        createdAt: new Date()
      });

      // Add platform fee transaction
      vendorWallet.transactionHistory.push({
        type: 'PLATFORM_FEE_DEDUCTED',
        amount: platformFee,
        description: `Platform fee deducted for withdrawal ${withdrawal._id}`,
        referenceId: withdrawal._id.toString(),
        withdrawalId: withdrawal._id,
        createdAt: new Date()
      });

      // Add vendor payout transaction
      vendorWallet.transactionHistory.push({
        type: 'VENDOR_PAYOUT',
        amount: vendorReceives,
        description: `Vendor payout processed - ${withdrawal.withdrawalMethod.accountHolderName}`,
        referenceId: withdrawal._id.toString(),
        withdrawalId: withdrawal._id,
        createdAt: new Date()
      });

      // Update admin wallet - receive platform fee only during withdrawal
      adminWallet.totalBalance += platformFee;
      adminWallet.totalReceived += platformFee;
      
      adminWallet.transactionHistory.push({
        type: 'SYSTEM_FEE',
        amount: platformFee,
        description: `Platform fee from withdrawal ${withdrawal._id}`,
        referenceId: withdrawal._id.toString(),
        vendorId: withdrawal.vendorId as any,
        createdAt: new Date()
      });

      withdrawal.status = 'PAID_OUT';
      withdrawal.paidOutAt = new Date();
      withdrawal.fee = platformFee;
      withdrawal.netAmount = vendorReceives;
      
      // Add settlement note for manual processing
      withdrawal.notes = 'Auto-approved withdrawal. Platform fee deducted. Manual bank transfer required for real-world settlement.';
      withdrawal.settlementReference = `WD${Date.now()}`;

      await vendorWallet.save();
      await adminWallet.save();
    } else {
      withdrawal.status = 'REJECTED';
      if (!sufficientBalance) {
        withdrawal.rejectionReason = 'Insufficient available balance';
      } else if (!verifiedMethod) {
        withdrawal.rejectionReason = 'Withdrawal method not verified';
      } else {
        withdrawal.rejectionReason = 'Amount exceeds withdrawal limits';
      }
    }

    await withdrawal.save();
    return withdrawal;
  }

  /**
   * Get vendor wallet balance
   */
  async getVendorBalance(vendorId: string): Promise<{
    totalEarned: number;
    availableBalance: number;
    pendingBalance: number;
    totalWithdrawn: number;
    holdingPeriod: number;
  }> {
    try {
      console.log(`🔍 DEBUG: Getting vendor balance for ${vendorId}`);
      
      if (!vendorId) {
        console.log(`🔍 DEBUG ERROR: No vendorId provided to getVendorBalance`);
        throw new Error('Vendor ID is required');
      }
      
      // First, release any funds that are past holding period
      console.log(`🔍 DEBUG: About to call releaseHeldFunds`);
      await this.releaseHeldFunds(vendorId);
      console.log(`🔍 DEBUG: releaseHeldFunds completed`);
      
      console.log(`🔍 DEBUG: About to call getVendorWallet`);
      const wallet = await this.getVendorWallet(vendorId);
      console.log(`🔍 DEBUG: getVendorWallet completed`);
      
      console.log(`🔍 DEBUG: Final balances - Available: ${wallet.availableBalance}, Pending: ${wallet.pendingBalance}`);
      
      const result = {
        totalEarned: wallet.totalEarned,
        availableBalance: wallet.availableBalance,
        pendingBalance: wallet.pendingBalance,
        totalWithdrawn: wallet.totalWithdrawn,
        holdingPeriod: wallet.holdingPeriodMinutes
      };
      
      console.log(`🔍 DEBUG: Returning balance result:`, result);
      return result;
    } catch (error: any) {
      console.error('🔍 DEBUG ERROR: getVendorBalance failed:', error);
      console.error('🔍 DEBUG ERROR: Error stack:', error.stack);
      console.error('🔍 DEBUG ERROR: Error message:', error.message);
      throw error;
    }
  }

  /**
   * Get admin wallet balance
   */
  async getAdminBalance(): Promise<{
    totalBalance: number;
    totalReceived: number;
    totalPaidOut: number;
    pendingPayouts: number;
  }> {
    const wallet = await this.getAdminWallet();
    return {
      totalBalance: wallet.totalBalance,
      totalReceived: wallet.totalReceived,
      totalPaidOut: wallet.totalPaidOut,
      pendingPayouts: wallet.pendingPayouts
    };
  }

  /**
   * Get vendor withdrawal history
   */
  async getVendorWithdrawalHistory(vendorId: string): Promise<IWithdrawal[]> {
    return await Withdrawal.find({ vendorId })
      .sort({ createdAt: -1 })
      .populate('vendorId', 'firstName lastName email');
  }

  /**
   * Get all vendor withdrawals for admin
   */
  async getAllWithdrawals(): Promise<IWithdrawal[]> {
    return await Withdrawal.find({})
      .sort({ createdAt: -1 })
      .populate('vendorId', 'firstName lastName email');
  }
}

export default new WalletService();
