import nodemailer from 'nodemailer';
import User from '../models/User';
import { ImageUploadHelper } from '../utils/imageUpload';
import fs from 'fs';
import path from 'path';
import axios from 'axios';

interface VendorComplaintData {
  vendorId: string;
  orderId: string;
  productName: string;
  originalProductImage: string;
  deliveredProductImage: string;
  confidence: number;
  rejectionMessage: string;
  vendorStatus: string;
  customerName?: string;
  customerPhone?: string;
}

export default class VendorEmailService {
  private transporter: nodemailer.Transporter;

  constructor() {
    this.transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      secure: false,
      auth: {
        user: process.env.GMAIL_EMAIL,
        pass: process.env.GMAIL_APP_PASSWORD
      }
    });
  }

  private formatSimilarityScore(similarity: number): string {
    const formattedScore = similarity > 1 
      ? similarity.toFixed(2) + "%"
      : (similarity * 100).toFixed(2) + "%";
    return formattedScore;
  }

  async sendComplaintNotification(data: VendorComplaintData): Promise<void> {
    try {
      const vendor = await User.findById(data.vendorId).select('email firstName lastName');
      if (!vendor) {
        console.error('Vendor not found for complaint notification');
        return;
      }

      console.log('DEBUG: Starting email notification process...');

      // Prepare image attachments and paths
      const attachments: any[] = [];
      let orderedImagePath = '';
      let deliveryImagePath = '';

      // Handle ordered product image - download from URL and convert to attachment
      if (data.originalProductImage.startsWith('http')) {
        // Download image from URL and save locally
        try {
          console.log('DEBUG: Downloading ordered image from URL:', data.originalProductImage);
          const response = await axios.get(data.originalProductImage, {
            responseType: 'arraybuffer',
            timeout: 10000
          });
          
          // Ensure uploads directory exists
          const uploadsDir = path.join(process.cwd(), 'uploads');
          if (!fs.existsSync(uploadsDir)) {
            fs.mkdirSync(uploadsDir, { recursive: true });
          }
          
          // Save image locally
          orderedImagePath = path.join(uploadsDir, `ordered-${data.orderId}.jpg`);
          fs.writeFileSync(orderedImagePath, response.data);
          
          // Add to attachments
          attachments.push({
            filename: `ordered-${data.orderId}.jpg`,
            path: orderedImagePath,
            cid: 'orderedImage'
          });
          console.log('DEBUG: Downloaded and attached ordered image:', orderedImagePath);
        } catch (error) {
          console.error('DEBUG: Failed to download ordered image:', error);
          orderedImagePath = '';
        }
      } else if (ImageUploadHelper.isBase64Image(data.originalProductImage)) {
        // Convert base64 to file and attach
        try {
          orderedImagePath = await ImageUploadHelper.convertBase64ToImage(
            data.originalProductImage, 
            `ordered-${data.orderId}`
          );
          const filePath = path.join(process.cwd(), 'uploads', path.basename(orderedImagePath));
          if (fs.existsSync(filePath)) {
            attachments.push({
              filename: `ordered-${data.orderId}.jpg`,
              path: filePath,
              cid: 'orderedImage'
            });
            console.log('DEBUG: Added ordered image attachment from base64:', filePath);
          }
        } catch (error) {
          console.error('DEBUG: Failed to convert ordered image:', error);
          orderedImagePath = '';
        }
      } else {
        // Local path - convert to full path
        orderedImagePath = path.join(process.cwd(), data.originalProductImage);
        if (fs.existsSync(orderedImagePath)) {
          attachments.push({
            filename: `ordered-${data.orderId}.jpg`,
            path: orderedImagePath,
            cid: 'orderedImage'
          });
          console.log('DEBUG: Added ordered image attachment from local path:', orderedImagePath);
        }
      }

      // Handle delivered product image
      if (ImageUploadHelper.isBase64Image(data.deliveredProductImage)) {
        // Convert base64 to file and attach
        try {
          deliveryImagePath = await ImageUploadHelper.convertBase64ToImage(
            data.deliveredProductImage, 
            `delivery-${data.orderId}`
          );
          const filePath = path.join(process.cwd(), 'uploads', path.basename(deliveryImagePath));
          if (fs.existsSync(filePath)) {
            attachments.push({
              filename: `delivery-${data.orderId}.jpg`,
              path: filePath,
              cid: 'deliveryImage'
            });
            console.log('DEBUG: Added delivery image attachment:', filePath);
          }
        } catch (error) {
          console.error('DEBUG: Failed to convert delivery image:', error);
          deliveryImagePath = '';
        }
      } else if (data.deliveredProductImage.startsWith('http')) {
        // External URL - use as-is
        deliveryImagePath = data.deliveredProductImage;
        console.log('DEBUG: Delivery image is external URL:', deliveryImagePath);
      } else {
        // Local path
        deliveryImagePath = path.join(process.cwd(), data.deliveredProductImage);
        if (fs.existsSync(deliveryImagePath)) {
          attachments.push({
            filename: `delivery-${data.orderId}.jpg`,
            path: deliveryImagePath,
            cid: 'deliveryImage'
          });
          console.log('DEBUG: Added delivery image from local path:', deliveryImagePath);
        }
      }

      const formattedScore = this.formatSimilarityScore(data.confidence);

      // Both images now use CID attachments for consistent display
      const orderedImageSrc = 'cid:orderedImage';
      const deliveryImageSrc = 'cid:deliveryImage';

      console.log('DEBUG: Both images using CID attachments');
      console.log('DEBUG: Ordered image source for HTML:', orderedImageSrc);
      console.log('DEBUG: Delivery image source for HTML:', deliveryImageSrc);

      const html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; background-color: #ffffff;">
          
          <!-- Header -->
          <div style="text-align: center; margin-bottom: 30px; padding: 20px 0; border-bottom: 1px solid #eee;">
            <h1 style="color: #333; margin: 0; font-size: 24px; font-weight: 600;">
              Complaint Alert
            </h1>
            <p style="color: #666; margin: 10px 0 0 0; font-size: 14px;">
              Fake Product Complaint - Account Status Update
            </p>
          </div>

          <!-- Customer Information -->
          <div style="margin-bottom: 25px; padding: 15px; background-color: #f9f9f9; border-left: 3px solid #07bc64;">
            <h2 style="color: #333; margin: 0 0 15px 0; font-size: 18px;">
              Customer Information
            </h2>
            <div style="display: flex; gap: 20px;">
              <div style="flex: 1;">
                <p style="margin: 0 0 5px 0; color: #666; font-size: 12px; text-transform: uppercase;">Customer Name</p>
                <p style="margin: 0; color: #333; font-size: 16px; font-weight: 600;">${data.customerName || 'Not provided'}</p>
              </div>
              <div style="flex: 1;">
                <p style="margin: 0 0 5px 0; color: #666; font-size: 12px; text-transform: uppercase;">Phone Number</p>
                <p style="margin: 0; color: #333; font-size: 16px; font-weight: 600;">${data.customerPhone || 'Not provided'}</p>
              </div>
            </div>
          </div>

          <!-- Account Status -->
          <div style="margin-bottom: 25px; padding: 15px; background-color: #fff3cd; border: 1px solid #ffeaa7;">
            <h2 style="color: #333; margin: 0 0 10px 0; font-size: 18px;">
              Account Status
            </h2>
            <p style="margin: 0; font-size: 16px; font-weight: bold; color: #d63031; text-transform: uppercase;">
              ${data.vendorStatus}
            </p>
            <p style="margin: 10px 0 0 0; color: #666; font-size: 14px;">
              ${data.vendorStatus === "suspended" 
                ? "Your account has been temporarily suspended due to a complaint."
                : "Your account has been permanently banned due to multiple complaints."}
            </p>
          </div>

          <!-- Complaint Details -->
          <div style="margin-bottom: 25px; padding: 15px; background-color: #f9f9f9;">
            <h2 style="color: #333; margin: 0 0 15px 0; font-size: 18px;">
              Complaint Details
            </h2>
            <div style="line-height: 1.6;">
              <p style="margin: 0 0 8px 0;"><strong>Order ID:</strong> ${data.orderId}</p>
              <p style="margin: 0 0 8px 0;"><strong>Product Name:</strong> ${data.productName}</p>
              <p style="margin: 0 0 8px 0;"><strong>Reason:</strong> Fake product detected</p>
              <p style="margin: 0 0 8px 0; padding: 10px; background-color: #ffebee; color: #d32f2f; border-radius: 4px;"><strong>Details:</strong> ${data.rejectionMessage}</p>
            </div>
          </div>

          <!-- Evidence -->
          <div style="margin-bottom: 25px; padding: 15px; background-color: #f9f9f9;">
            <h2 style="color: #333; margin: 0 0 20px 0; font-size: 18px;">
              Evidence Comparison
            </h2>
            
            <!-- Desktop: Side by side layout -->
            <table style="width: 100%; border-collapse: collapse;" role="presentation">
              <tr>
                <!-- Ordered Product -->
                <td style="width: 50%; padding: 0 10px 20px 0; text-align: left; vertical-align: top;">
                  <h4 style="color: #28a745; margin: 0 0 15px 0; font-size: 16px;">Ordered Product</h4>
                  <div style="border: 1px solid #28a745; padding: 2px; background-color: #fff;">
                    <img src="${orderedImageSrc}" alt="Ordered Product" style="max-width: 100%; height: 250px; width: 100%; object-fit: contain;" />
                  </div>
                </td>

                <!-- Delivered Product -->
                <td style="width: 50%; padding: 0 0 20px 10px; text-align: left; vertical-align: top;">
                  <h3 style="color: #dc3545; margin: 0 0 15px 0; font-size: 16px;">Delivered Product</h3>
                  <div style="border: 1px solid #dc3545; padding: 2px; background-color: #fff;">
                    <img src="${deliveryImageSrc}" alt="Delivered Product" style="max-width: 100%; height: 250px; width: 100%; object-fit: contain;" />
                  </div>
                </td>
              </tr>
            </table>

            <!-- Mobile: Vertical layout (shown on screens <= 480px) -->
            <!--[if mso]>
            <table role="presentation" style="width: 100%;">
              <tr>
                <td style="text-align: left; padding-bottom: 20px;">
                  <h4 style="color: #28a745; margin: 0 0 15px 0; font-size: 16px;">Ordered Product</h4>
                  <div style="border: 1px solid #28a745; padding: 2px; background-color: #fff;">
                    <img src="${orderedImageSrc}" alt="Ordered Product" style="max-width: 100%; height: 200px; width: 100%; object-fit: contain;" />
                  </div>
                </td>
              </tr>
              <tr>
                <td style="text-align: left;">
                  <h3 style="color: #dc3545; margin: 0 0 15px 0; font-size: 16px;">Delivered Product</h3>
                  <div style="border: 1px solid #dc3545; padding: 2px; background-color: #fff;">
                    <img src="${deliveryImageSrc}" alt="Delivered Product" style="max-width: 100%; height: 200px; width: 100%; object-fit: contain;" />
                  </div>
                </td>
              </tr>
            </table>
            <![endif]-->
            
            <!-- Media query for mobile responsiveness -->
            <style type="text/css">
              @media screen and (max-width: 768px) {
                table[role="presentation"] tr {
                  display: block !important;
                }
                table[role="presentation"] td {
                  display: block !important;
                  width: 100% !important;
                  padding: 0 0 20px 0 !important;
                }
                table[role="presentation"] img {
                  height: 200px !important;
                }
              }
            </style>
          </div>

          <!-- Action Required -->
          <div style="margin-bottom: 25px; padding: 15px; background-color: #e3f2fd; border: 1px solid #bbdefb;">
            <h2 style="color: #333; margin: 0 0 10px 0; font-size: 18px;">
              Action Required
            </h2>
            <p style="margin: 0; color: #333; font-size: 14px; line-height: 1.6;">
              If you believe this complaint is incorrect or have evidence to dispute it, please contact our support team immediately with your order details and any relevant documentation.
            </p>
            <p style="margin: 10px 0 0 0; color: #333; font-size: 14px;">
              <strong>Support:</strong> support@smartlocalshop.com
            </p>
          </div>

          <!-- Footer -->
          <div style="text-align: center; padding: 20px 0; border-top: 1px solid #eee; margin-top: 20px;">
            <p style="color: #999; font-size: 12px; margin: 0;">
              This is an automated message from Smart Local Shop Complaint System
            </p>
            <p style="color: #999; font-size: 11px; margin: 10px 0 0 0;">
              Please do not reply to this email. For assistance, contact our support team.
            </p>
          </div>
        </div>
      `;

      const mailOptions = {
        from: process.env.GMAIL_EMAIL,
        to: vendor.email,
        subject: 'Fake Product Complaint - Account Status Update',
        html: html,
        attachments: attachments.length > 0 ? attachments : undefined
      };

      console.log('DEBUG: Sending email with', attachments.length, 'attachments');
      await this.transporter.sendMail(mailOptions);
      console.log(`Complaint email sent to vendor: ${vendor.email}`);
    } catch (error) {
      console.error('Error sending complaint email to vendor:', error);
    }
  }
}
