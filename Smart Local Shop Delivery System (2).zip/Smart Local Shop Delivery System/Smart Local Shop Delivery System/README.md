# 🛍️ Smart Local Shop Delivery System

A comprehensive full-stack platform connecting local Ethiopian businesses with customers through intelligent delivery management, real-time tracking, and AI-powered services.

## 🌟 **Project Overview**

**Smart Local Shop Delivery System** is a modern e-commerce platform specifically designed for Ethiopian local businesses. It bridges the gap between local vendors and customers through an intelligent delivery system with real-time tracking, AI-powered recommendations, and comprehensive business management tools.

### 🎯 **Key Features**

#### **For Customers**
- 🛒 **Browse Local Products**: Discover products from nearby shops
- 🚚 **Real-time Delivery Tracking**: Live order tracking with GPS
- 💳 **Secure Payments**: Multiple payment options including Chapa integration
- ⭐ **Reviews & Ratings**: Community-driven product feedback
- 🤖 **AI Recommendations**: Personalized product suggestions

#### **For Vendors**
- 📊 **Business Dashboard**: Complete sales and analytics overview
- 📦 **Inventory Management**: Easy product catalog management
- 💰 **Wallet System**: Automated payment processing and fund management
- 📈 **Analytics**: Sales trends and customer insights
- 🎯 **Complaint Resolution**: AI-powered dispute handling

#### **For Delivery Agents**
- 🗺️ **Route Optimization**: Smart delivery route planning
- 📱 **Mobile App**: On-the-go delivery management
- 💵 **Earnings Tracking**: Real-time earnings and payment processing
- 📍 **GPS Tracking**: Accurate location-based services

#### **For Administrators**
- 🔧 **System Management**: Complete platform oversight
- 👥 **User Management**: Role-based access control
- 📊 **Analytics Dashboard**: Comprehensive business metrics
- 🛡️ **Security Management**: Advanced security features

## 🏗️ **Architecture**

### **Technology Stack**

#### **Frontend (client/)**
- **Framework**: React 18 + TypeScript
- **Build Tool**: Vite
- **Styling**: Tailwind CSS + Lucide Icons
- **State Management**: React Context + Hooks
- **Maps**: Google Maps API
- **Real-time**: Socket.IO

#### **Backend (server/)**
- **Runtime**: Node.js 18+
- **Framework**: Express.js + TypeScript
- **Database**: MongoDB + Mongoose
- **Authentication**: JWT + bcrypt
- **File Upload**: Multer + Cloudinary
- **Payment**: Chapa Payment Gateway
- **Real-time**: Socket.IO

#### **ML Service (ml-service/)**
- **Language**: Python 3.8+
- **Framework**: FastAPI
- **ML Libraries**: scikit-learn, pandas, numpy
- **Computer Vision**: OpenCV, PIL
- **API Documentation**: OpenAPI/Swagger

### **Project Structure**
```
smart-local-shop-delivery/
├── client/                 # React + Vite + TypeScript Frontend
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/          # Page components
│   │   ├── services/       # API services
│   │   ├── contexts/       # React contexts
│   │   ├── utils/          # Utility functions
│   │   └── types/          # TypeScript types
│   ├── public/             # Static assets
│   └── package.json
├── server/                 # Node.js + Express Backend
│   ├── src/
│   │   ├── controllers/    # API controllers
│   │   ├── models/         # Database models
│   │   ├── routes/         # API routes
│   │   ├── middleware/     # Express middleware
│   │   ├── services/       # Business logic
│   │   └── utils/          # Utility functions
│   ├── uploads/            # File upload directory
│   └── package.json
├── ml-service/              # Python ML Service
│   ├── app/                # FastAPI application
│   ├── models/             # ML models
│   ├── services/           # ML services
│   └── requirements.txt
├── package.json            # Root workspace configuration
├── .gitignore             # Git ignore patterns
├── .prettierrc           # Prettier configuration
└── README.md              # This file
```

## 🚀 **Quick Start**

### **Prerequisites**
- **Node.js** 18+ and npm 9+
- **Python** 3.8+ and pip
- **MongoDB** 5.0+
- **Git**
- **Google Maps API Key** (for location services)

### **Installation**
```bash
# Clone the repository
git clone https://github.com/ketbogale/final.git
cd Phase II

# Install dependencies for all workspaces
npm install

# Set up environment variables
cp server/.env.example server/.env
cp client/.env.example client/.env
cp ml-service/.env.example ml-service/.env

# Install Python dependencies for ML service
cd ml-service
pip install -r requirements.txt
cd ..
```

### **Environment Configuration**
```bash
# Server (.env)
PORT=5000
MONGODB_URI=mongodb://localhost:27017/smart-shop-delivery
JWT_SECRET=your-super-secret-jwt-key
FRONTEND_URL=http://localhost:3000
CHAPA_API_KEY=your-chapa-api-key
GOOGLE_MAPS_API_KEY=your-google-maps-api-key

# Client (.env)
VITE_API_URL=http://localhost:5000/api
VITE_GOOGLE_MAPS_API_KEY=your-google-maps-api-key

# ML Service (.env)
PORT=8000
ENVIRONMENT=development
```

### **Development**
```bash
# Start all services in development mode
npm run dev

# Start individual services
npm run dev:client    # Frontend on http://localhost:3000
npm run dev:server    # Backend on http://localhost:5000
cd ml-service && python main.py  # ML Service on http://localhost:8000
```

### **Production**
```bash
# Build all projects
npm run build

# Start production server
npm run start:server
```

## 🔐 **Authentication & Authorization**

### **User Roles & Permissions**

| **Role** | **Description** | **Key Features** |
|----------|----------------|-----------------|
| **CUSTOMER** | End users who browse and purchase products | • Browse products<br>• Place orders<br>• Track deliveries<br>• Write reviews |
| **VENDOR** | Shop owners who sell products | • Manage inventory<br>• Process orders<br>• View analytics<br>• Handle complaints |
| **DELIVERY** | Delivery agents who fulfill orders | • Accept deliveries<br>• Track routes<br>• Manage earnings<br>• Update delivery status |
| **ADMIN** | System administrators | • Full system access<br>• User management<br>• Analytics dashboard<br>• System configuration |

### **Security Features**
- **JWT Authentication**: Secure token-based authentication with refresh tokens
- **Password Security**: bcrypt hashing with 12 rounds
- **Role-Based Access Control (RBAC)**: Granular permission system
- **Rate Limiting**: Prevent abuse and DDoS attacks
- **CORS Configuration**: Secure cross-origin requests
- **Input Validation**: Comprehensive request validation
- **SQL Injection Prevention**: Parameterized queries
- **XSS Protection**: Content Security Policy headers

## 📊 **Database Schema**

### **Core Models**

#### **User Model**
```typescript
interface User {
  _id: ObjectId;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  role: 'CUSTOMER' | 'VENDOR' | 'DELIVERY' | 'ADMIN';
  profileImage?: string;
  isEmailVerified: boolean;
  isPhoneVerified: boolean;
  isActive: boolean;
  location?: {
    type: 'Point';
    coordinates: [number, number];
  };
  // Role-specific fields
  isCustomer?: boolean;
  isVendor?: boolean;
  isDelivery?: boolean;
  bankName?: string;
  accountNumber?: string;
  vehicle?: {
    type: string;
    plateNumber: string;
    color: string;
  };
}
```

#### **Product Model**
```typescript
interface Product {
  _id: ObjectId;
  name: string;
  description: string;
  price: number;
  category: string;
  images: string[];
  vendor: ObjectId;
  stock: number;
  isActive: boolean;
  tags: string[];
  location?: {
    type: 'Point';
    coordinates: [number, number];
  };
  createdAt: Date;
  updatedAt: Date;
}
```

#### **Order Model**
```typescript
interface Order {
  _id: ObjectId;
  orderNumber: string;
  customer: ObjectId;
  vendor: ObjectId;
  items: OrderItem[];
  status: 'PENDING' | 'CONFIRMED' | 'PREPARING' | 'READY_FOR_PICKUP' | 'OUT_FOR_DELIVERY' | 'DELIVERED' | 'CANCELLED';
  delivery: {
    required: boolean;
    address: {
      street: string;
      city: string;
      county: string;
      coordinates: [number, number];
    };
    estimatedTime: Date;
    actualTime?: Date;
    deliveryFee: number;
    deliveryAgent?: ObjectId;
  };
  payment: {
    method: 'MPESA' | 'CARD' | 'CASH' | 'BANK_TRANSFER';
    status: 'PENDING' | 'PAID' | 'FAILED' | 'REFUNDED';
    transactionId?: string;
    paidAt?: Date;
  };
  pricing: {
    subtotal: number;
    deliveryFee: number;
    serviceFee: number;
    tax: number;
    total: number;
  };
  createdAt: Date;
  updatedAt: Date;
}
```

#### **Complaint Model**
```typescript
interface Complaint {
  _id: ObjectId;
  orderId: ObjectId;
  vendorId: ObjectId;
  customerId: ObjectId;
  productName: string;
  originalProductImage: string;
  deliveryPhoto: string;
  confidence: number;
  rejectionMessage: string;
  customerName: string;
  customerPhone: string;
  isRead: boolean;
  actionTaken: 'none' | 'warning' | 'suspension';
  complaintCount: number;
  createdAt: Date;
  updatedAt: Date;
}
```

### **Database Relationships**
- **Users → Orders**: One-to-Many (Customer/Vendor relationships)
- **Orders → Products**: Many-to-Many (through OrderItems)
- **Orders → Delivery**: One-to-One
- **Orders → Payment**: One-to-One
- **Users → Reviews**: One-to-Many
- **Users → Complaints**: One-to-Many (as vendor/customer)

## 🤖 **Machine Learning Features**

### **Delivery Time Prediction**
```python
# Features used for prediction
features = [
    'distance_km',
    'traffic_level',
    'weather_condition',
    'time_of_day',
    'day_of_week',
    'vehicle_type',
    'road_quality',
    'population_density'
]

# Output: Estimated delivery time in minutes with confidence score
prediction = {
    'estimated_time': 45,
    'confidence': 0.87,
    'factors': {
        'distance_impact': 0.4,
        'traffic_impact': 0.3,
        'weather_impact': 0.2,
        'time_impact': 0.1
    }
}
```

### **Product Recommendation System**
```python
# Hybrid recommendation approach
recommendations = {
    'collaborative': user_based_recommendations(user_id),
    'content_based': item_based_recommendations(user_history),
    'popularity_based': trending_products(location),
    'location_based': nearby_products(user_location)
}
```

### **Complaint Analysis**
```python
# Image similarity analysis for product complaints
def analyze_complaint(original_image, delivery_image):
    similarity = calculate_image_similarity(original_image, delivery_image)
    confidence = calculate_confidence_score(similarity)
    return {
        'is_match': similarity > 0.8,
        'confidence': confidence,
        'rejection_reason': generate_explanation(similarity)
    }
```

## 📚 **API Documentation**

### **Authentication Endpoints**
| **Method** | **Endpoint** | **Description** | **Auth Required** |
|------------|-------------|----------------|------------------|
| `POST` | `/api/auth/register` | User registration | ❌ |
| `POST` | `/api/auth/login` | User login | ❌ |
| `GET` | `/api/auth/me` | Get current user | ✅ |
| `PATCH` | `/api/auth/update-password` | Update password | ✅ |
| `POST` | `/api/auth/logout` | User logout | ✅ |

### **Product Endpoints**
| **Method** | **Endpoint** | **Description** | **Auth Required** |
|------------|-------------|----------------|------------------|
| `GET` | `/api/products` | List products with filters | ❌ |
| `GET` | `/api/products/:id` | Get product details | ❌ |
| `POST` | `/api/products` | Create product | ✅ (Vendor) |
| `PUT` | `/api/products/:id` | Update product | ✅ (Vendor) |
| `DELETE` | `/api/products/:id` | Delete product | ✅ (Vendor) |

### **Order Endpoints**
| **Method** | **Endpoint** | **Description** | **Auth Required** |
|------------|-------------|----------------|------------------|
| `GET` | `/api/orders` | List user orders | ✅ |
| `POST` | `/api/orders` | Create order | ✅ (Customer) |
| `GET` | `/api/orders/:id` | Get order details | ✅ |
| `PUT` | `/api/orders/:id/status` | Update order status | ✅ (Vendor/Delivery) |
| `GET` | `/api/orders/tracking/:id` | Track order | ❌ |

### **Payment Endpoints**
| **Method** | **Endpoint** | **Description** | **Auth Required** |
|------------|-------------|----------------|------------------|
| `POST` | `/api/payments/initialize` | Initialize payment | ✅ |
| `POST` | `/api/payments/verify` | Verify payment | ✅ |
| `GET` | `/api/payments/history` | Payment history | ✅ |

### **Complaint Endpoints**
| **Method** | **Endpoint** | **Description** | **Auth Required** |
|------------|-------------|----------------|------------------|
| `POST` | `/api/complain` | Create complaint | ✅ (Customer) |
| `GET` | `/api/complain/vendor` | Get vendor complaints | ✅ (Vendor) |
| `GET` | `/api/complain/vendor/notifications` | Get notifications | ✅ (Vendor) |
| `PUT` | `/api/complain/vendor/notifications/:id/read` | Mark as read | ✅ (Vendor) |

### **Wallet Endpoints**
| **Method** | **Endpoint** | **Description** | **Auth Required** |
|------------|-------------|----------------|------------------|
| `GET` | `/api/wallets/balance` | Get wallet balance | ✅ |
| `POST` | `/api/wallets/withdraw` | Request withdrawal | ✅ (Vendor) |
| `GET` | `/api/wallets/history` | Transaction history | ✅ |

### **ML Service Endpoints**
| **Method** | **Endpoint** | **Description** |
|------------|-------------|----------------|
| `GET` | `/health` | Service health check |
| `GET` | `/info` | Service information |
| `POST` | `/predict/delivery` | Delivery time prediction |
| `POST` | `/recommend/products` | Product recommendations |
| `POST` | `/analyze/complaint` | Complaint image analysis |

## 🔄 **Real-time Features**

### **Socket.IO Events**
```typescript
// Client-side events
socket.on('order-updated', (order) => {
  // Handle order status updates
});

socket.on('delivery-location', (location) => {
  // Update delivery agent location
});

socket.on('new-order', (order) => {
  // Notify vendor of new order
});

// Server-side events
socket.emit('order-updated', order);
socket.emit('delivery-location', location);
socket.emit('new-order', order);
```

### **Real-time Use Cases**
- **Order Tracking**: Live order status updates
- **Delivery Location**: Real-time delivery agent GPS tracking
- **Notifications**: Instant order and delivery notifications
- **Chat**: Customer-vendor communication
- **Analytics**: Live dashboard updates

## 🛠️ **Development Guidelines**

### **Code Standards**
- **TypeScript**: Strict type checking enabled
- **ESLint**: AirBnb configuration with custom rules
- **Prettier**: Consistent code formatting
- **Husky**: Pre-commit hooks for code quality
- **Conventional Commits**: Standardized commit messages

### **Testing Strategy**
```bash
# Run all tests
npm test

# Run unit tests
npm run test:unit

# Run integration tests
npm run test:integration

# Run E2E tests
npm run test:e2e

# Generate coverage report
npm run test:coverage
```

### **Code Quality Gates**
- **Test Coverage**: Minimum 80%
- **TypeScript**: No type errors
- **ESLint**: No linting errors
- **Performance**: Bundle size < 1MB
- **Security**: No high-severity vulnerabilities

## 📱 **Mobile Responsiveness**

### **Responsive Design**
- **Mobile First**: Progressive enhancement approach
- **Breakpoints**: 
  - Mobile: 320px - 768px
  - Tablet: 768px - 1024px
  - Desktop: 1024px+
- **Touch Support**: Optimized for touch interactions
- **Performance**: Optimized for mobile networks

### **PWA Features**
- **Service Worker**: Offline functionality
- **Web App Manifest**: Installable app
- **Push Notifications**: Order updates
- **Background Sync**: Data synchronization

## 🚀 **Deployment**

### **Development Environment**
```bash
# Local development
npm run dev

# Docker development
docker-compose up -d
```

### **Production Environment**
```bash
# Build for production
npm run build

# Start production server
npm run start

# Docker production
docker-compose -f docker-compose.prod.yml up -d
```

### **Environment Variables**
```bash
# Production (.env.production)
NODE_ENV=production
PORT=5000
MONGODB_URI=mongodb://your-production-db
JWT_SECRET=your-production-secret
FRONTEND_URL=https://your-domain.com
CHAPA_API_KEY=your-production-chapa-key
```

## 📈 **Monitoring & Analytics**

### **Application Monitoring**
- **Performance**: Response time tracking
- **Error Tracking**: Sentry integration
- **User Analytics**: Google Analytics
- **Business Metrics**: Custom dashboard
- **Health Checks**: Service availability monitoring

### **Logging Strategy**
```typescript
// Structured logging example
logger.info('Order created', {
  orderId: order._id,
  customerId: order.customer,
  vendorId: order.vendor,
  amount: order.pricing.total,
  timestamp: new Date()
});
```

## 🤝 **Contributing**

### **Development Workflow**
1. **Fork** the repository
2. **Create** a feature branch (`git checkout -b feature/amazing-feature`)
3. **Make** your changes with proper testing
4. **Commit** with conventional commit message (`git commit -m 'feat: add amazing feature'`)
5. **Push** to the branch (`git push origin feature/amazing-feature`)
6. **Open** a Pull Request

### **Code Review Process**
- **Automated Checks**: Tests, linting, type checking
- **Manual Review**: Code quality and architecture
- **Security Review**: Vulnerability assessment
- **Performance Review**: Impact assessment

### **Contributor Guidelines**
- Follow existing code patterns and conventions
- Write clear, descriptive commit messages
- Update documentation for new features
- Add comprehensive tests for new functionality
- Ensure backward compatibility

## 🆘 **Troubleshooting**

### **Common Issues**

#### **Installation Problems**
```bash
# Clear npm cache
npm cache clean --force

# Delete node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

#### **Database Connection**
```bash
# Check MongoDB status
mongod --version

# Start MongoDB service
sudo systemctl start mongod
```

#### **Development Server Issues**
```bash
# Check port availability
netstat -an | grep :3000
netstat -an | grep :5000

# Kill processes on ports
kill -9 $(lsof -ti:3000)
kill -9 $(lsof -ti:5000)
```

### **FAQ**

**Q: How do I add a new user role?**
A: Update the User model schema and modify authentication middleware.

**Q: How do I add a new payment method?**
A: Extend the Payment model and add corresponding payment processor.

**Q: How do I deploy to production?**
A: Use the provided Docker configuration or follow the deployment guide.

**Q: How do I debug ML service issues?**
A: Check the ML service logs and ensure all dependencies are installed.

## 📄 **License**

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 **Acknowledgments**

- **Chapa**: Ethiopian payment gateway integration
- **Google Maps**: Location services and mapping
- **MongoDB**: Database and data management
- **OpenAI**: AI-powered features and recommendations
- **Ethiopian Business Community**: For feedback and insights

## 📞 **Contact & Support**

For support and questions:
- **GitHub Issues**: [Create an issue](https://github.com/ketbogale/final/issues)
- **Email**: support@smartshop.et
- **Documentation**: [Project Wiki](https://github.com/ketbogale/final/wiki)
- **Community**: [Discord Server](https://discord.gg/smartshop)

---

**🇪🇹 Built ❤️ for the Ethiopian local business community**

*Empowering local businesses through technology and innovation*
