import React, { useState, useEffect } from 'react';
import { X, Search, User, MapPin, Phone, Star, Truck } from 'lucide-react';
import Spinner from '../../components/ui/Spinner';
import { DeliveryAgent } from '../types/admin';

interface AssignDeliveryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAssign: (agentId: string) => void;
  orderId: string;
  isLoading?: boolean;
}

const AssignDeliveryModal: React.FC<AssignDeliveryModalProps> = ({
  isOpen,
  onClose,
  onAssign,
  orderId,
  isLoading = false
}) => {
  const [agents, setAgents] = useState<DeliveryAgent[]>([]);
  const [selectedAgent, setSelectedAgent] = useState<string>('');
  const [loadingAgents, setLoadingAgents] = useState(false);

  useEffect(() => {
    if (isOpen) {
      fetchDeliveryAgents();
    }
  }, [isOpen]);

  const fetchDeliveryAgents = async () => {
    setLoadingAgents(true);
    try {
      // Mock data for now - replace with actual API call
      const mockAgents: DeliveryAgent[] = [
        {
          _id: '1',
          firstName: 'John',
          lastName: 'Doe',
          email: 'john@example.com',
          phone: '+251912345678',
          isActive: true,
          currentOrders: 2,
          totalDelivered: 45
        },
        {
          _id: '2',
          firstName: 'Jane',
          lastName: 'Smith',
          email: 'jane@example.com',
          phone: '+251987654321',
          isActive: true,
          currentOrders: 1,
          totalDelivered: 32
        }
      ];
      setAgents(mockAgents);
    } catch (error) {
      console.error('Error fetching delivery agents:', error);
    } finally {
      setLoadingAgents(false);
    }
  };

  const handleAssign = () => {
    if (selectedAgent) {
      onAssign(selectedAgent);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Assign Delivery Agent</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="p-6">
          <div className="mb-4">
            <p className="text-sm text-gray-600">
              Order ID: <span className="font-medium">{orderId}</span>
            </p>
          </div>

          {loadingAgents ? (
            <div className="flex justify-center items-center h-32">
              <Spinner size="md" />
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Select Delivery Agent
                </label>
                <div className="space-y-3">
                  {agents.map((agent) => (
                    <label
                      key={agent._id}
                      className="flex items-center p-4 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50"
                    >
                      <input
                        type="radio"
                        name="agent"
                        value={agent._id}
                        checked={selectedAgent === agent._id}
                        onChange={(e) => setSelectedAgent(e.target.value)}
                        className="mr-3"
                      />
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <User className="h-5 w-5 text-gray-400 mr-2" />
                            <div>
                              <div className="font-medium text-gray-900">
                                {agent.firstName} {agent.lastName}
                              </div>
                              <div className="text-sm text-gray-500">{agent.email}</div>
                              <div className="text-sm text-gray-500">{agent.phone}</div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="flex items-center text-sm text-gray-500">
                              <Truck className="h-4 w-4 mr-1" />
                              {agent.currentOrders} active
                            </div>
                            <div className="text-sm text-gray-500">
                              {agent.totalDelivered} delivered
                            </div>
                          </div>
                        </div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {agents.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-gray-500">No delivery agents available</p>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex justify-end space-x-3 p-6 border-t border-gray-200">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
          >
            Cancel
          </button>
          <button
            onClick={handleAssign}
            disabled={!selectedAgent || isLoading}
            className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <>
                <Spinner size="sm" className="mr-2" />
                Assigning...
              </>
            ) : (
              'Assign Agent'
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AssignDeliveryModal;
