import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { Menu, User } from 'lucide-react';
import SidebarItem from '../../components/SidebarItem';
import { useAuth } from '../../contexts/AuthContext';

const AdminLayout: React.FC = () => {
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = React.useState(false);
  const [isHovered, setIsHovered] = React.useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = React.useState(false);
  
  // Use AuthContext instead of localStorage
  const { authState } = useAuth();
  const user = authState.user;

  const navigation = [
    {
      name: 'Home',
      href: '/admin',
      icon: 'home',
      current: location.pathname === '/admin'
    },
    {
      name: 'User Management',
      href: '/admin/users',
      icon: 'people',
      current: location.pathname === '/admin/users'
    },
    {
      name: 'Order Management',
      href: '/admin/orders',
      icon: 'shopping_cart',
      current: location.pathname === '/admin/orders'
    },
    {
      name: 'Product Management',
      href: '/admin/products',
      icon: 'inventory',
      current: location.pathname === '/admin/products'
    }
  ];

  const handleLogout = () => {
    // Handle logout logic
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    // Navigate to login page
    window.location.href = '/login';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile sidebar */}
      <div className={`fixed inset-0 z-50 lg:hidden ${sidebarOpen ? 'block' : 'hidden'}`}>
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75" onClick={() => setSidebarOpen(false)} />
        <div className="fixed inset-y-0 left-0 flex flex-col w-64 bg-green-700">
          <nav className="flex-1 px-2 py-4 space-y-1">
            {navigation.map((item) => (
              <SidebarItem
                key={item.name}
                icon={item.icon}
                label={item.name}
                to={item.href}
              />
            ))}
          </nav>
          <div className="p-4 border-t border-green-600">
          </div>
        </div>
      </div>
      {/* Desktop sidebar */}
      <div 
        className="hidden lg:fixed lg:inset-y-0 lg:flex transition-all duration-300 ease-in-out z-50"
        style={{ width: isHovered ? '220px' : '70px' }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div className={`flex flex-col flex-grow bg-green-700 pt-5 pb-4 overflow-y-auto transition-all duration-300 ${isHovered ? 'shadow-2xl' : 'shadow-lg'} relative z-50`}>
          <nav className="mt-5 flex-1 px-2 space-y-1">
            {navigation.map((item) => (
              <SidebarItem
                key={item.name}
                icon={item.icon}
                label={isHovered ? item.name : ''}
                to={item.href}
                showLabel={isHovered}
              />
            ))}
          </nav>
          <div className="p-4 border-t border-green-800">
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className={`lg:pl-[70px] pl-0`}>
        {/* Desktop header */}
        <div className="sticky top-0 z-30 flex-shrink-0 flex h-16 bg-white border-b border-gray-200">
          <button
            onClick={() => setSidebarOpen(true)}
            className="px-4 border-r border-gray-200 text-gray-500 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-green-500 lg:hidden"
          >
            <Menu className="h-6 w-6" />
          </button>
          
          <div className="flex-1 flex justify-end px-4 lg:px-6">
            
            {/* Profile dropdown */}
            <div className="flex items-center">
              <div className="relative">
                <button
                  type="button"
                  className="flex items-center text-sm rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                  onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                >
                  <span className="sr-only">Open user menu</span>
                  <div className="h-8 w-8 rounded-full bg-green-800 flex items-center justify-center">
                    <User className="h-5 w-5 text-white" />
                  </div>
                </button>

                {/* Profile dropdown panel */}
                {profileDropdownOpen && (
                  <div className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5">
                    <div className="py-1">
                      <div className="px-4 py-2 border-b border-gray-100">
                        <p className="text-sm font-medium text-gray-900">
                          {user?.firstName} {user?.lastName}
                        </p>
                        <p className="text-sm text-gray-500">{user?.email}</p>
                        <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-purple-100 text-purple-800 mt-1">
                          {user?.role}
                        </span>
                      </div>
                      <a
                        href="/admin/profile"
                        className="flex items-center gap-3 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                        onClick={(e) => {
                          e.preventDefault();
                          window.location.href = '/admin/profile';
                        }}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" className="lucide lucide-user-icon lucide-user"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                        Profile
                      </a>
                      <a
                        href="#"
                        className="flex items-center gap-3 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                        onClick={(e) => {
                          e.preventDefault();
                          // Handle settings click
                          console.log('Settings feature coming soon');
                        }}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" className="lucide lucide-settings-icon lucide-settings"><path d="M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915"/><circle cx="12" cy="12" r="3"/></svg>
                        Settings
                      </a>
                      <button
                        onClick={handleLogout}
                        className="flex items-center gap-3 w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-100 hover:text-red-700"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" className="lucide lucide-log-out-icon lucide-log-out"><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/></svg>
                        Log out
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
        <main className="flex-1">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
