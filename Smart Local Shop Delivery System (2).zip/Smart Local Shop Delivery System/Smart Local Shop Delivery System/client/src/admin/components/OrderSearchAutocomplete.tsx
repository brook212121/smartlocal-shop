import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, X, Package, User } from 'lucide-react';
import { adminService } from '../services/adminService';
import { AdminOrder } from '../types/admin';
import { safeFetch, isUserOffline, getUserFriendlyErrorMessage } from '../../utils/errorHandler';

interface OrderSearchAutocompleteProps {
  placeholder?: string;
  className?: string;
}

const OrderSearchAutocomplete: React.FC<OrderSearchAutocompleteProps> = ({
  placeholder = "Search by order number...",
  className = ""
}) => {
  // Single source of truth states
  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [searchResults, setSearchResults] = useState<AdminOrder[]>([]);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [highlightedIndex, setHighlightedIndex] = useState(-1);
  const [isLoading, setIsLoading] = useState(false);
  
  // Refs for request management
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const lastQueryRef = useRef('');
  const latestRequestIdRef = useRef<number>(0);
  const currentRequestControllerRef = useRef<AbortController | null>(null);

  // DEBOUNCE: Convert query to debouncedQuery
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(query);
    }, 300);

    return () => clearTimeout(timer);
  }, [query]);

  // SINGLE API TRIGGER: Only place where searchOrders is called
  useEffect(() => {
    // Cancel previous request
    if (currentRequestControllerRef.current) {
      currentRequestControllerRef.current.abort();
    }

    // Minimum query length check
    if (debouncedQuery.trim().length < 2) {
      setSearchResults([]);
      setIsDropdownOpen(false);
      setHighlightedIndex(-1);
      setIsLoading(false);
      return;
    }

    // REQUEST DEDUPLICATION: Skip if same query was already searched
    if (lastQueryRef.current === debouncedQuery) {
      return;
    }

    // Check offline status first
    if (isUserOffline()) {
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    lastQueryRef.current = debouncedQuery; // Mark as searched
    
    // Set request ID for tracking
    const currentRequestId = Date.now();
    latestRequestIdRef.current = currentRequestId;

    // Perform search
    const performSearch = async () => {
      try {
        // Create AbortController for this request
        const controller = new AbortController();
        currentRequestControllerRef.current = controller;

        const results = await adminService.searchOrders(debouncedQuery.trim(), 5, controller.signal);
        
        // Only update state if this is the latest request
        if (currentRequestId === latestRequestIdRef.current) {
          setSearchResults(results);
          setIsDropdownOpen(results.length > 0);
          setHighlightedIndex(-1);
        }
      } catch (error: any) {
        // Only handle error if this is the latest request
        if (currentRequestId === latestRequestIdRef.current) {
          // Don't show error for cancelled requests
          if (error.name !== 'AbortError') {
            // Use global error handler for user-friendly messages
            const friendlyMessage = getUserFriendlyErrorMessage(error);
            
            // Handle network errors gracefully
            if (error.code === 'NETWORK_ERROR' || error.message === 'Network Error') {
              setSearchResults([]);
              setIsDropdownOpen(true); // Show "No orders found" message
              setHighlightedIndex(-1);
            } else {
              setSearchResults([]);
              setIsDropdownOpen(true); // Show "No orders found" message
              setHighlightedIndex(-1);
            }
          }
        }
      } finally {
        // Only update loading state if this is the latest request
        if (currentRequestId === latestRequestIdRef.current) {
          setIsLoading(false);
        }
      }
    };

    performSearch();
  }, [debouncedQuery]); // Only depends on debouncedQuery

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node) &&
        !inputRef.current?.contains(event.target as Node)
      ) {
        setIsDropdownOpen(false);
        setHighlightedIndex(-1);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Handle keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!isDropdownOpen || searchResults.length === 0) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setHighlightedIndex(prev => 
          prev < searchResults.length - 1 ? prev + 1 : 0
        );
        break;
      case 'ArrowUp':
        e.preventDefault();
        setHighlightedIndex(prev => 
          prev > 0 ? prev - 1 : searchResults.length - 1
        );
        break;
      case 'Enter':
        e.preventDefault();
        if (highlightedIndex >= 0) {
          handleOrderSelect(searchResults[highlightedIndex]);
        }
        break;
      case 'Escape':
        setIsDropdownOpen(false);
        setHighlightedIndex(-1);
        inputRef.current?.blur();
        break;
    }
  };

  const handleOrderSelect = (order: AdminOrder) => {
    navigate(`/admin/orders/${order._id}`);
    setQuery('');
    setDebouncedQuery('');
    setSearchResults([]);
    setIsDropdownOpen(false);
    setHighlightedIndex(-1);
  };

  // ONLY STATE UPDATE: No API calls here
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setQuery(e.target.value);
  };

  const handleClear = () => {
    // Cancel any ongoing request
    if (currentRequestControllerRef.current) {
      currentRequestControllerRef.current.abort();
    }
    
    setQuery('');
    setDebouncedQuery('');
    lastQueryRef.current = '';
    setSearchResults([]);
    setIsDropdownOpen(false);
    setHighlightedIndex(-1);
    setIsLoading(false);
    inputRef.current?.focus();
  };

  const handleInputFocus = () => {
    if (query.trim().length >= 2 && searchResults.length > 0) {
      setIsDropdownOpen(true);
    }
  };

  return (
    <div className={`relative ${className}`}>
      {/* Search Input */}
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          onFocus={handleInputFocus}
          className="block w-full pl-10 pr-10 py-3 border border-gray-300 rounded-lg leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-2 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
          placeholder={placeholder}
          autoComplete="off"
        />
        <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
          {isLoading ? (
            <div className="animate-spin h-4 w-4 border-2 border-green-500 border-t-transparent rounded-full"></div>
          ) : query ? (
            <button
              onClick={handleClear}
              className="text-gray-400 hover:text-gray-600 transition-colors duration-200"
              title="Clear search"
            >
              <X className="h-5 w-5" />
            </button>
          ) : null}
        </div>
      </div>

      {/* Dropdown */}
      {isDropdownOpen && (
        <div
          ref={dropdownRef}
          className="absolute z-50 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-96 overflow-hidden"
        >
          {isLoading ? (
            <div className="px-4 py-8 text-center text-gray-500">
              <div className="animate-spin h-6 w-6 border-2 border-green-500 border-t-transparent rounded-full mx-auto mb-2"></div>
              <p className="text-sm">Searching...</p>
            </div>
          ) : searchResults.length > 0 ? (
            <div className="py-1">
              {searchResults.map((order, index) => (
                <div
                  key={order._id}
                  onClick={() => handleOrderSelect(order)}
                  className={`px-4 py-3 cursor-pointer transition-colors duration-150 ${
                    index === highlightedIndex
                      ? 'bg-green-50 text-green-900 border-l-4 border-green-500'
                      : 'hover:bg-gray-50 text-gray-900'
                  }`}
                >
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0">
                      <Package className="h-5 w-5 text-gray-400 mt-0.5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium text-gray-900 truncate">
                          {order.orderNumber || order._id.slice(-8)}...
                        </p>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          order.status === 'PENDING' ? 'bg-yellow-100 text-yellow-800' :
                          order.status === 'CONFIRMED' ? 'bg-blue-100 text-blue-800' :
                          order.status === 'PREPARING' ? 'bg-purple-100 text-purple-800' :
                          order.status === 'OUT_FOR_DELIVERY' ? 'bg-orange-100 text-orange-800' :
                          order.status === 'DELIVERED' ? 'bg-green-100 text-green-800' :
                          order.status === 'CANCELLED' ? 'bg-red-100 text-red-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {order.status}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="px-4 py-8 text-center text-gray-500">
              <Package className="h-8 w-8 mx-auto mb-2 text-gray-300" />
              <p className="text-sm">No orders found</p>
              <p className="text-xs text-gray-400 mt-1">
                Try searching by order number
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default OrderSearchAutocomplete;
