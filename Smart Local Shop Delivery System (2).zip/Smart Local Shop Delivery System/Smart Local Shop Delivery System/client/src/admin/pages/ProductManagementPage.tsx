import React, { useState, useEffect } from 'react';
import { Plus, Search, Edit, Trash2, Package } from 'lucide-react';
import Spinner from '../../components/ui/Spinner';
import { useToast } from '../../contexts/ToastContext';
import { adminService } from '../services/adminService';
import { AdminProduct } from '../types/admin';

const ProductManagementPage: React.FC = () => {
  const { handleApiError } = useToast();
  const [products, setProducts] = useState<AdminProduct[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<AdminProduct[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Fetch products on mount
  useEffect(() => {
    fetchProducts();
  }, []);

  // Filter products when search changes
  useEffect(() => {
    const filtered = products.filter((product) =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.vendor.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.vendor.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.category.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredProducts(filtered);
  }, [products, searchTerm]);

  const fetchProducts = async () => {
    try {
      const data = await adminService.getAllProducts();
      setProducts(data);
    } catch (error) {
      console.error('Error fetching products:', error);
      handleApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  const formatCurrency = (amount: number) => `ETB ${amount.toFixed(2)}`;

  // Helper function to get full image URL
  const getImageUrl = (imagePath: string) => {
    if (!imagePath) return '/placeholder-product.jpg';
    if (imagePath.startsWith('http')) return imagePath;
    
    // For localhost development, use relative URL for Vite proxy
    const hostname = window.location.hostname;
    if (hostname === 'localhost' || hostname === '127.0.0.1') {
      return imagePath.startsWith('/') ? imagePath : `/${imagePath}`;
    }
    
    // For other environments, use full URL
    return `http://localhost:5000${imagePath.startsWith('/') ? '' : '/'}${imagePath}`;
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Spinner size="lg" />
      </div>
    );
  }

  return (
    <div className="p-6">
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">
          Product Management
        </h1>
      </div>

      {/* Search Bar */}
      <div className="mb-6">
        <div className="relative max-w-md">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search products..."
            className="block w-full px-4 py-2 border border-gray-300 rounded-md
                       focus:outline-none focus:ring-1 focus:ring-green-500
                       focus:border-green-500"
          />
        </div>
      </div>

      {/* Products Card */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        {/* Card Header */}
        <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
          <h3 className="text-lg font-semibold text-gray-900">
            All Products
          </h3>
          <span className="text-sm font-medium text-green-600">
            {filteredProducts.length} products
          </span>
        </div>

        {/* Card Content */}
        {filteredProducts.length === 0 ? (
          <div className="p-6 text-center text-gray-500">
            No products found.
          </div>
        ) : (
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <div key={product._id} className="bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-200 overflow-hidden">
                  {/* Product Image */}
                  <div className="aspect-w-1 aspect-h-1 w-full h-48 bg-gray-100">
                    {product.images && product.images.length > 0 ? (
                      <img
                        className="w-full h-full object-cover"
                        src={getImageUrl(product.images[0])}
                        alt={product.name}
                        loading="lazy"
                        onError={(e) => {
                          console.log('Image failed to load:', getImageUrl(product.images[0]));
                          e.currentTarget.style.display = 'none';
                          e.currentTarget.nextElementSibling?.classList.remove('hidden');
                        }}
                        onLoad={() => {
                          console.log('Image loaded successfully:', getImageUrl(product.images[0]));
                        }}
                      />
                    ) : null}
                    
                  </div>
                  
                  {/* Product Info */}
                  <div className="p-4">
                    <h4 className="text-lg font-semibold text-gray-900 mb-2 truncate">
                      {product.name}
                    </h4>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Vendor:</span>
                        <span className="text-sm font-medium text-gray-900">
                          {product.vendor ? `${product.vendor.firstName} ${product.vendor.lastName}` : 'Unknown Vendor'}
                        </span>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Category:</span>
                        <span className="text-sm font-medium text-gray-900">
                          {product.category}
                        </span>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Price:</span>
                        <span className="text-lg font-bold text-green-600">
                          {formatCurrency(product.price)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductManagementPage;