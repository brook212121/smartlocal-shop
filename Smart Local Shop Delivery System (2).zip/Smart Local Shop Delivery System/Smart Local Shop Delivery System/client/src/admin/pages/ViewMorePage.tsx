import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useToast } from '../../contexts/ToastContext';
import { ArrowLeft, User, ChevronDown, DollarSign, Package, ShoppingCart, Zap, AlertTriangle } from 'lucide-react';
import Spinner from '../../components/ui/Spinner';
import { adminService } from '../services/adminService';

// View types enum
type ActiveView = 'none' | 'orders' | 'transactions' | 'complaints';

interface ExtendedUserData {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  role: string;
  isActive: boolean;
  createdAt: string | Date;
  lastLogin?: string | Date;
  address?: {
    street: string;
    city: string;
    state: string;
    coordinates?: {
      latitude: number;
      longitude: number;
    };
  };
  profileImage?: string;
  verificationStatus?: 'pending' | 'verified' | 'rejected';
  locationInfo?: {
    ipAddress: string;
    location: {
      country: string;
      city: string;
      region: string;
      coordinates: {
        latitude: number;
        longitude: number;
      };
    };
    deviceInfo: {
      type: string;
      browser: string;
      os: string;
    };
  };
  stats?: {
    totalOrders: number;
    totalDelivered: number;
    averageOrderValue: number;
  };
};

const ViewMorePage: React.FC = () => {
  const { userId } = useParams<{ userId: string }>();
  const navigate = useNavigate();
  const { handleApiResponse, handleApiError } = useToast();
  
  const [userData, setUserData] = useState<ExtendedUserData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [userComplaints, setUserComplaints] = useState<any[]>([]);
  const [isLoadingComplaints, setIsLoadingComplaints] = useState(false);
  const [userOrders, setUserOrders] = useState<any[]>([]);
  const [isLoadingOrders, setIsLoadingOrders] = useState(false);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [isLoadingTransactions, setIsLoadingTransactions] = useState(false);
  const [earnings, setEarnings] = useState<any>(null);
  const [activeView, setActiveView] = useState<ActiveView>('none');
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (userId) {
      fetchUserDetails(userId);
    }
  }, [userId]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const fetchUserDetails = async (id: string) => {
    try {
      setIsLoading(true);
      const data = await adminService.getUserDetails(id);
      setUserData(data);
    } catch (error) {
      console.error('Error fetching user details:', error);
      handleApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchUserComplaints = async (id: string) => {
    try {
      setIsLoadingComplaints(true);
      const response = await adminService.getUserComplaints(id);
      setUserComplaints(response.data || []);
    } catch (error) {
      console.error('Error fetching user complaints:', error);
      handleApiError(error);
    } finally {
      setIsLoadingComplaints(false);
    }
  };

  const fetchUserOrders = async (id: string) => {
    try {
      setIsLoadingOrders(true);
      const response = await adminService.getUserOrders(id);
      const orders = response.orders || [];
      setUserOrders(orders);
      
      // Debug: Log order status values
      console.log('Order status values:', orders.map((o: any) => ({ id: o.id, status: o.status })));
      console.log('Delivered count:', orders.filter((o: any) => o.status?.toLowerCase() === 'delivered').length);
    } catch (error) {
      console.error('Error fetching user orders:', error);
      handleApiError(error);
    } finally {
      setIsLoadingOrders(false);
    }
  };

  const fetchUserTransactions = async (id: string) => {
    try {
      setIsLoadingTransactions(true);
      const res = await adminService.getUserTransactions(id);
      setTransactions(res.transactions || []);
      setEarnings(res.earnings || null);
      
      // Store earnings data if available
      if (res.earnings) {
        console.log('User earnings:', res.earnings);
      }
    } catch (error) {
      console.error('Error fetching user transactions:', error);
      handleApiError(error);
    } finally {
      setIsLoadingTransactions(false);
    }
  };

  // Unified view switching function
  const switchToView = async (view: ActiveView) => {
    if (!userId) return;
    
    // Reset all states first
    setActiveView('none');
    setUserComplaints([]);
    setUserOrders([]);
    setTransactions([]);
    setEarnings(null);
    setIsLoadingComplaints(false);
    setIsLoadingOrders(false);
    setIsLoadingTransactions(false);
    
    // Small delay to ensure reset
    setTimeout(() => {
      setActiveView(view);
      
      // Fetch data based on view
      switch (view) {
        case 'complaints':
          fetchUserComplaints(userId);
          break;
        case 'orders':
          fetchUserOrders(userId);
          break;
        case 'transactions':
          fetchUserTransactions(userId);
          break;
        default:
          break;
      }
    }, 50);
  };

  const formatDate = (dateInput: string | Date) => {
    const date = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
    return date.toLocaleString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <Spinner size="lg" />
        </div>
      </div>
    );
  }

  if (!userData) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px]">
        <div className="text-center">
          <p className="text-gray-500 mb-4">User not found</p>
          <button
            onClick={() => navigate('/admin/users')}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Users
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      {/* User Header */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-gray-200 flex items-center justify-center">
              <User className="h-6 w-6 text-gray-500" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">{userData.firstName} {userData.lastName}</h2>
              <p className="text-sm text-gray-500">{userData.email}</p>
            </div>
          </div>
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-md text-sm font-medium transition-colors"
            >
              {isLoadingTransactions ? (
                <>
                  <Spinner size="sm" />
                  Loading...
                </>
              ) : (
                <>
                  Navigate
                  <ChevronDown className={`w-4 h-4 transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} />
                </>
              )}
            </button>
            
            {isDropdownOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 z-10">
                <div className="py-1">
                  <button
                    onClick={() => {
                      switchToView('transactions');
                      setIsDropdownOpen(false);
                    }}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-700 transition-colors"
                  >
                    <span className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-blue-500" />
                      Transaction
                    </span>
                  </button>
                  <button
                    onClick={() => {
                      switchToView('orders');
                      setIsDropdownOpen(false);
                    }}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-700 transition-colors"
                  >
                    <span className="flex items-center gap-2">
                      <ShoppingCart className="w-4 h-4 text-green-500" />
                      Order
                    </span>
                  </button>
                  <button
                    onClick={() => {
                      switchToView('complaints');
                      setIsDropdownOpen(false);
                    }}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-red-50 hover:text-red-700 transition-colors"
                  >
                    <span className="flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-red-500" />
                      Complaint
                    </span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* User Complaints Section */}
      {activeView === 'complaints' && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mt-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-600" />
              User Complaints
            </h3>
            <button
              onClick={() => setActiveView('none')}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          </div>

          {/* Complaint Statistics */}
          {!isLoadingComplaints && userComplaints.length > 0 && (
            <div className="mb-6 bg-gray-50 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-6">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-600">Total:</span>
                    <span className="font-semibold text-gray-900">{userComplaints.length}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-green-600">Resolved:</span>
                    <span className="font-semibold text-green-700">
                      {userComplaints.filter(c => c.status === 'resolved').length}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-orange-600">Unresolved:</span>
                    <span className="font-semibold text-orange-700">
                      {userComplaints.filter(c => c.status !== 'resolved').length}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {isLoadingComplaints ? (
            <div className="flex items-center justify-center py-8">
              <Spinner size="md" />
            </div>
          ) : userComplaints.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {userComplaints.map((complaint, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
                  <div className="mb-3">
                    <h4 className="font-medium text-gray-900 text-base mb-1 truncate">{complaint.productName}</h4>
                    <p className="text-sm text-gray-500">
                      {new Date(complaint.createdAt).toLocaleDateString('en-GB', { 
                        day: 'numeric', 
                        month: 'short', 
                        year: 'numeric' 
                      })}
                    </p>
                  </div>
                  
                  <div className="mb-3">
                    <div className="bg-red-50 rounded p-2">
                      <p className="text-sm text-red-600 font-medium mb-1">Reason:</p>
                      <p className="text-sm text-red-700 line-clamp-2">{complaint.rejectionMessage}</p>
                    </div>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Buyer:</span>
                      <span className="font-medium text-gray-900 truncate ml-2">
                        {(() => {
                          // Try to get buyer name from populated order data first
                          if (complaint.orderId?.customer) {
                            const customer = complaint.orderId.customer;
                            const fullName = `${customer.firstName} ${customer.lastName}`.trim();
                            return fullName || customer.email || 'N/A';
                          }
                          // Fallback to customerName field
                          if (complaint.customerName && complaint.customerName.trim() !== '' && 
                              complaint.customerName !== 'Not provided') {
                            return complaint.customerName;
                          }
                          // Last resort
                          return 'N/A';
                        })()}
                      </span>
                    </div>
                  </div>

                  {(complaint.originalProductImage || complaint.deliveryPhoto) && (
                    <div className="mt-3 grid grid-cols-2 gap-1">
                      {complaint.originalProductImage && (
                        <div>
                          <p className="text-sm text-gray-500 mb-1">Original</p>
                          <img 
                            src={complaint.originalProductImage} 
                            alt="Original product" 
                            className="w-full h-20 object-contain rounded border border-gray-200"
                            onError={(e) => {
                              e.currentTarget.style.display = 'none';
                              e.currentTarget.nextElementSibling?.classList.remove('hidden');
                            }}
                            onLoad={(e) => {
                              e.currentTarget.style.display = 'block';
                              e.currentTarget.nextElementSibling?.classList.add('hidden');
                            }}
                          />
                          <div className="hidden text-xs text-gray-400 text-center mt-1">
                            Image not available
                          </div>
                        </div>
                      )}
                      {complaint.deliveryPhoto && (
                        <div>
                          <p className="text-sm text-gray-500 mb-1">Delivered</p>
                          <img 
                            src={complaint.deliveryPhoto} 
                            alt="Delivered product" 
                            className="w-full h-20 object-contain rounded border border-gray-200"
                            onError={(e) => {
                              e.currentTarget.style.display = 'none';
                              e.currentTarget.nextElementSibling?.classList.remove('hidden');
                            }}
                            onLoad={(e) => {
                              e.currentTarget.style.display = 'block';
                              e.currentTarget.nextElementSibling?.classList.add('hidden');
                            }}
                          />
                          <div className="hidden text-xs text-gray-400 text-center mt-1">
                            Image not available
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <AlertTriangle className="w-12 h-12 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500">No complaints found for this user</p>
            </div>
          )}
        </div>
      )}

      {/* User Orders Section */}
      {activeView === 'orders' && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mt-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <ShoppingCart className="w-5 h-5 text-green-600" />
            User Orders
          </h3>

          {isLoadingOrders ? (
            <div className="flex items-center justify-center py-8">
              <Spinner size="md" />
            </div>
          ) : (
            <>
              {/* STATS */}
              <div className="mb-6 bg-gray-50 rounded-lg p-4">
                <div className="flex items-center gap-6">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-600">Total Orders:</span>
                    <span className="font-semibold text-gray-900">{userOrders.length}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-green-600">Total Amount:</span>
                    <span className="font-semibold text-green-700">
                      ETB {userOrders.reduce((sum, o) => sum + (o.totalAmount || 0), 0).toFixed(2)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-blue-600">Delivered:</span>
                    <span className="font-semibold text-blue-700">
                      {userOrders.filter((o: any) => o.status?.toLowerCase() === 'delivered').length}
                    </span>
                  </div>
                </div>
              </div>

              {/* LIST */}
              {userOrders.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {userOrders.map((order: any) => (
                    <div key={order.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
                      <div className="mb-2">
                        <p className="font-medium text-gray-900">Order #{order.orderNumber}</p>
                        <p className="text-sm text-gray-500">
                          {new Date(order.createdAt).toLocaleDateString('en-GB', { 
                            day: 'numeric', 
                            month: 'short', 
                            year: 'numeric' 
                          })}
                        </p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm"><strong>Amount:</strong> ETB {order.totalAmount}</p>
                        <p className="text-sm"><strong>Status:</strong> 
                          <span className={`ml-1 px-2 py-1 rounded-full text-xs font-medium ${
                            order.status?.toLowerCase() === 'delivered' ? 'bg-green-100 text-green-800' :
                            order.status?.toLowerCase() === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                            order.status?.toLowerCase() === 'cancelled' ? 'bg-red-100 text-red-800' :
                            'bg-gray-100 text-gray-800'
                          }`}>
                            {order.status}
                          </span>
                        </p>
                        {order.vendor && (
                          <p className="text-sm"><strong>Vendor:</strong> {order.vendor.name}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <ShoppingCart className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-500">No orders found for this user</p>
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* User Transactions Section */}
      {activeView === 'transactions' && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mt-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-blue-600" />
            User Transactions
          </h3>

          {isLoadingTransactions ? (
            <div className="flex items-center justify-center py-8">
              <Spinner size="md" />
            </div>
          ) : (
            <>
              {/* STATS */}
              <div className="mb-6 bg-gray-50 rounded-lg p-4">
                <div className="flex items-center gap-6 flex-wrap">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-600">Total Transactions:</span>
                    <span className="font-semibold text-gray-900">{transactions.length}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-green-600">Total Spent:</span>
                    <span className="font-semibold text-green-700">
                      ETB {transactions.reduce((sum, t) => sum + (t.amount || 0), 0).toFixed(2)}
                    </span>
                  </div>
                  {earnings && earnings.role === 'VENDOR' && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-purple-600">Total Earned:</span>
                      <span className="font-semibold text-purple-700">
                        ETB {earnings.totalEarned.toFixed(2)}
                      </span>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-green-600">Successful:</span>
                    <span className="font-semibold text-green-700">
                      {transactions.filter((t: any) => t.status === 'completed' || t.status === 'paid').length}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-red-600">Failed:</span>
                    <span className="font-semibold text-red-700">
                      {transactions.filter((t: any) => t.status === 'failed').length}
                    </span>
                  </div>
                </div>
              </div>

              {/* LIST */}
              {transactions.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {transactions.map((txn: any) => (
                    <div key={txn.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
                      <div className="mb-2">
                        <p className="font-medium text-gray-900">Transaction ID: {txn.id.slice(-8)}</p>
                        <p className="text-sm text-gray-500">
                          {new Date(txn.createdAt).toLocaleDateString('en-GB', { 
                            day: 'numeric', 
                            month: 'short', 
                            year: 'numeric' 
                          })}
                        </p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm"><strong>Amount:</strong> ETB {txn.amount}</p>
                        <p className="text-sm"><strong>Status:</strong> 
                          <span className={`ml-1 px-2 py-1 rounded-full text-xs font-medium ${
                            txn.status === 'completed' || txn.status === 'paid' ? 'bg-green-100 text-green-800' :
                            txn.status === 'failed' ? 'bg-red-100 text-red-800' :
                            txn.status === 'pending' || txn.status === 'processing' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-gray-100 text-gray-800'
                          }`}>
                            {txn.status}
                          </span>
                        </p>
                        <p className="text-sm"><strong>Method:</strong> {txn.paymentMethod}</p>
                        {txn.orderNumber && (
                          <p className="text-sm"><strong>Order:</strong> {txn.orderNumber}</p>
                        )}
                        {txn.reference && (
                          <p className="text-sm"><strong>Reference:</strong> {txn.reference}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <DollarSign className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-500">No transactions found for this user</p>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default ViewMorePage;
