import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { DollarSign, ShoppingCart, Users, Package, TrendingUp, TrendingDown, Wallet } from 'lucide-react';
import Loading from '../../components/common/Loading';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { safeFetch, isUserOffline, getUserFriendlyErrorMessage } from '../../utils/errorHandler';

interface DashboardSummary {
  totalRevenue: number;
  totalOrders: number;
  paidOrders: number;
  totalVendors: number;
  totalCustomers: number;
  totalDelivery: number;
  adminWalletBalance: number;
  revenueMetrics: {
    averageOrderValue: number;
    conversionRate: number;
  };
}

interface RevenueData {
  date: string;
  revenue: number;
  orders: number;
}

interface RevenueResponse {
  range: number;
  data: RevenueData[];
}

const AdminDashboardPage: React.FC = () => {
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [revenueData, setRevenueData] = useState<RevenueResponse | null>(null);
  const [revenueRange, setRevenueRange] = useState<number>(7);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // ✅ Move useAuth to top level
  const { authState } = useAuth();
  const token = authState.token;

  // Fetch dashboard data on component mount
  useEffect(() => {
    fetchDashboardData();
  }, []);

  useEffect(() => {
    if (summary) {
      fetchRevenueData(revenueRange);
    }
  }, [revenueRange, summary]);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Check offline status first
      if (isUserOffline()) {
        setError('Unable to load dashboard. Please check your internet connection.');
        return;
      }
      
      // Use token from top level, not useAuth call
      if (!token) {
        setError('Authentication required');
        return;
      }
      
      const response = await safeFetch('/api/admin/dashboard/summary', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setSummary(data.data);
      } else if (response.status === 403) {
        setError('Access denied. Admin privileges required.');
      } else {
        setError('Unable to load dashboard data');
      }
    } catch (error) {
      // Use global error handler for user-friendly messages
      const friendlyMessage = getUserFriendlyErrorMessage(error);
      setError(friendlyMessage);
    } finally {
      setLoading(false);
    }
  };

  const fetchRevenueData = async (range: number) => {
    try {
      // Check offline status first
      if (isUserOffline()) {
        return;
      }
      
      // Use token from top level, not useAuth call
      if (!token) {
        return;
      }
      
      const response = await safeFetch(`/api/admin/dashboard/revenue?range=${range}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setRevenueData(data.data);
      }
    } catch (error) {
      // Use global error handler for user-friendly messages
      const friendlyMessage = getUserFriendlyErrorMessage(error);
      if (import.meta.env.DEV) {
        console.error('Error fetching revenue data:', error);
      }
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ET', {
      style: 'currency',
      currency: 'ETB',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  // Custom tooltip component for the line chart
  const CustomTooltip = ({ active, payload, label }: {
    active?: boolean;
    payload?: any[];
    label?: any;
  }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-2 border border-gray-200 rounded shadow">
          <p className="text-sm font-medium">{formatDate(label || '')}</p>
          <p className="text-sm text-green-600">ETB {payload[0].value}</p>
        </div>
      );
    }
    return null;
  };

  if (loading) return <Loading />;

  if (error) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6">
          <h3 className="text-red-800 font-semibold mb-2">Access Error</h3>
          <p className="text-red-600">{error}</p>
        </div>
      </div>
    );
  }

  if (!summary) {
    return (
      <div className="p-6">
        <div className="text-center py-12">
          <p className="text-gray-500">No dashboard data available</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-8">Admin Revenue Dashboard</h1>
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Revenue</p>
              <p className="text-2xl font-bold text-green-600">
                {formatCurrency(summary.totalRevenue)}
              </p>
              <p className="text-xs text-gray-500 mt-1">From paid orders</p>
            </div>
            <DollarSign className="h-8 w-8 text-green-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Orders</p>
              <p className="text-2xl font-bold text-blue-600">
                {summary.totalOrders.toLocaleString()}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                {summary.paidOrders} paid ({summary.revenueMetrics.conversionRate.toFixed(1)}%)
              </p>
            </div>
            <ShoppingCart className="h-8 w-8 text-blue-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Users</p>
              <p className="text-2xl font-bold text-purple-600">
                {summary.totalVendors.toLocaleString()}
              </p>
              <p className="text-xs text-gray-500 mt-1">Active sellers</p>
            </div>
            <Package className="h-8 w-8 text-purple-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Delivery</p>
              <p className="text-2xl font-bold text-orange-600">
                {(summary.totalDelivery || 0).toLocaleString()}
              </p>
              <p className="text-xs text-gray-500 mt-1">Active delivery agents</p>
            </div>
            <Users className="h-8 w-8 text-orange-600" />
          </div>
        </div>
      </div>

      {/* Admin Wallet Balance */}
      <div className="bg-white rounded-lg shadow p-6 mb-8">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-600">Admin Wallet Balance</p>
            <p className="text-3xl font-bold text-indigo-600">
              {formatCurrency(summary.adminWalletBalance)}
            </p>
            <p className="text-xs text-gray-500 mt-1">Escrow account balance</p>
          </div>
          <Wallet className="h-10 w-10 text-indigo-600" />
        </div>
      </div>

      {/* Revenue Chart */}
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-gray-900">Revenue Trend</h2>
          <div className="flex gap-2">
            <button
              onClick={() => setRevenueRange(7)}
              className={`px-3 py-1 rounded-lg text-sm font-medium ${
                revenueRange === 7
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              7 Days
            </button>
            <button
              onClick={() => setRevenueRange(30)}
              className={`px-3 py-1 rounded-lg text-sm font-medium ${
                revenueRange === 30
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              30 Days
            </button>
          </div>
        </div>

        {revenueData ? (
          <div>
            {/* Revenue Trend Line Chart */}
            <div className="h-64 mb-4">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={revenueData.data}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="date" 
                    tickFormatter={formatDate}
                    tick={{ fontSize: 12 }}
                  />
                  <YAxis 
                    tickFormatter={(value: number) => `ETB ${value}`}
                    tick={{ fontSize: 12 }}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Line 
                    type="monotone" 
                    dataKey="revenue" 
                    stroke="#3B82F6" 
                    strokeWidth={2}
                    dot={{ fill: '#3B82F6', r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Revenue Summary */}
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-gray-200">
              <div className="text-center">
                <p className="text-sm text-gray-600">Total Revenue</p>
                <p className="text-lg font-semibold text-green-600">
                  {formatCurrency(revenueData.data.reduce((sum, day) => sum + day.revenue, 0))}
                </p>
              </div>
              <div className="text-center">
                <p className="text-sm text-gray-600">Average Daily</p>
                <p className="text-lg font-semibold text-blue-600">
                  {formatCurrency(revenueData.data.reduce((sum, day) => sum + day.revenue, 0) / revenueData.data.length)}
                </p>
              </div>
              <div className="text-center">
                <p className="text-sm text-gray-600">Total Orders</p>
                <p className="text-lg font-semibold text-purple-600">
                  {revenueData.data.reduce((sum, day) => sum + day.orders, 0)}
                </p>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-gray-500">Loading revenue data...</p>
          </div>
        )}
      </div>

      {/* Additional Metrics */}
      <div className="bg-white rounded-lg shadow p-6 mt-8">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Performance Metrics</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <p className="text-sm text-gray-600 mb-2">Average Order Value</p>
            <p className="text-2xl font-bold text-gray-900">
              {formatCurrency(summary.revenueMetrics.averageOrderValue)}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-600 mb-2">Payment Conversion Rate</p>
            <p className="text-2xl font-bold text-gray-900">
              {summary.revenueMetrics.conversionRate.toFixed(1)}%
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboardPage;
