import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useToast } from '../../contexts/ToastContext';
import { ArrowLeft, Package, User, Phone, Mail, MapPin, Clock, Truck, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import Spinner from '../../components/ui/Spinner';
import { adminService } from '../services/adminService';

interface OrderItem {
  _id: string;
  product: {
    _id: string;
    name: string;
    price: number;
    images?: string[];
  };
  quantity: number;
  price: number;
}

interface OrderDetails {
  _id: string;
  orderNumber: string;
  status: 'PENDING' | 'CONFIRMED' | 'PREPARING' | 'READY' | 'OUT_FOR_DELIVERY' | 'DELIVERED' | 'CANCELLED';
  pricing: {
    subtotal: number;
    tax: number;
    deliveryFee: number;
    total: number;
  };
  items: OrderItem[];
  customer: {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
  };
  vendor: {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
  };
  delivery: {
    address: {
      street: string;
      city: string;
      county: string;
    };
    instructions?: string;
    estimatedTime?: string;
    deliveryAgent?: {
      _id: string;
      firstName: string;
      lastName: string;
      phone: string;
    };
  };
  payment: {
    status: 'PENDING' | 'PAID' | 'FAILED';
    method: string;
    transactionId?: string;
  };
  createdAt: string;
  updatedAt: string;
}

const OrderDetailsPage: React.FC = () => {
  const { orderId } = useParams<{ orderId: string }>();
  const navigate = useNavigate();
  const { handleApiError } = useToast();
  
  const [order, setOrder] = useState<OrderDetails | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (orderId) {
      fetchOrderDetails(orderId);
    }
  }, [orderId]);

  const fetchOrderDetails = async (id: string) => {
    try {
      setIsLoading(true);
      const data = await adminService.getOrderDetails(id);
      setOrder(data);
    } catch (error) {
      console.error('Error fetching order details:', error);
      handleApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PENDING':
        return 'bg-yellow-100 text-yellow-800';
      case 'CONFIRMED':
        return 'bg-blue-100 text-blue-800';
      case 'PREPARING':
        return 'bg-purple-100 text-purple-800';
      case 'READY':
        return 'bg-indigo-100 text-indigo-800';
      case 'OUT_FOR_DELIVERY':
        return 'bg-orange-100 text-orange-800';
      case 'DELIVERED':
        return 'bg-green-100 text-green-800';
      case 'CANCELLED':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'PENDING':
        return <AlertCircle className="h-5 w-5" />;
      case 'CONFIRMED':
        return <CheckCircle className="h-5 w-5" />;
      case 'PREPARING':
        return <Package className="h-5 w-5" />;
      case 'READY':
        return <CheckCircle className="h-5 w-5" />;
      case 'OUT_FOR_DELIVERY':
        return <Truck className="h-5 w-5" />;
      case 'DELIVERED':
        return <CheckCircle className="h-5 w-5" />;
      case 'CANCELLED':
        return <XCircle className="h-5 w-5" />;
      default:
        return <AlertCircle className="h-5 w-5" />;
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ET', {
      style: 'currency',
      currency: 'ETB',
      minimumFractionDigits: 2
    }).format(amount);
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="flex justify-center items-center h-64">
          <Spinner size="lg" />
        </div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="p-6">
        <div className="text-center py-12">
          <p className="text-gray-500">Order not found</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      {/* Header */}
      <div className="mb-6">
        <button
          onClick={() => navigate('/admin/orders')}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4"
        >
          <ArrowLeft className="h-5 w-5" />
          Back to Orders
        </button>
      </div>

      {/* Order Overview Card */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 sm:p-6 mb-6">
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between mb-6 gap-4">
          <div>
            <h4 className="text-sm sm:text-base font-semibold text-gray-900 mb-2">
              Order {order.orderNumber}
            </h4>
          </div>
          <div className="text-right text-sm text-gray-500">
            <p>Created: {formatDate(order.createdAt)}</p>
            <p>Updated: {formatDate(order.updatedAt)}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {/* Customer Information */}
          <div className="space-y-4">
            <h3 className="text-base sm:text-lg font-medium text-gray-900 mb-4">Customer Information</h3>
            <div className="bg-gray-50 rounded-lg p-3 sm:p-4 space-y-3">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-gray-500 flex-shrink-0" />
                <span className="text-sm text-gray-900 break-words">
                  {order.customer.firstName} {order.customer.lastName}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-gray-500 flex-shrink-0" />
                <span className="text-sm text-gray-900 break-words">{order.customer.phone}</span>
              </div>
            </div>
          </div>

          {/* Vendor Information */}
          <div className="space-y-4">
            <h3 className="text-base sm:text-lg font-medium text-gray-900 mb-4">Vendor Information</h3>
            <div className="bg-gray-50 rounded-lg p-3 sm:p-4 space-y-3">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-gray-500 flex-shrink-0" />
                <span className="text-sm text-gray-900 break-words">
                  {order.vendor.firstName} {order.vendor.lastName}
                </span>
              </div>
             
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-gray-500 flex-shrink-0" />
                <span className="text-sm text-gray-900 break-words">{order.vendor.phone}</span>
              </div>
            </div>
          </div>

          {/* Delivery Information */}
          <div className="space-y-4 sm:col-span-2 lg:col-span-1">
            <h3 className="text-base sm:text-lg font-medium text-gray-900 mb-4">Delivery Information</h3>
            <div className="bg-gray-50 rounded-lg p-3 sm:p-4 space-y-3">
              {order.delivery.instructions && (
                <div className="text-sm text-gray-600">
                  <strong>Instructions:</strong> {order.delivery.instructions}
                </div>
              )}
              {order.delivery.estimatedTime && (
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-gray-500 flex-shrink-0" />
                  <span className="text-sm text-gray-900">{order.delivery.estimatedTime}</span>
                </div>
              )}
              {order.delivery.deliveryAgent && (
                <div className="text-sm text-gray-600">
                  <strong>Delivery Agent:</strong> {order.delivery.deliveryAgent.firstName} {order.delivery.deliveryAgent.lastName}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 sm:gap-6">
        {/* Order Items */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 sm:p-6">
          <h3 className="text-base sm:text-lg font-medium text-gray-900 mb-4">Order Items</h3>
          <div className="space-y-4 sm:space-y-6">
            {order.items.map((item, index) => (
              <div key={item._id || index} className="flex flex-col sm:flex-row sm:items-center sm:justify-between p-4 sm:p-6 bg-gray-50 rounded-lg gap-4">
                <div className="flex items-center gap-4">
                  {/* Product Image */}
                  <div className="h-40 w-40 sm:h-48 sm:w-48 rounded-xl bg-gray-200 flex items-center justify-center overflow-hidden shadow-sm flex-shrink-0">
                    {item.product.images && item.product.images.length > 0 ? (
                      <img 
                        src={item.product.images[0]} 
                        alt={item.product.name}
                        className="h-full w-full object-cover"
                        onError={(e) => {
                          // Fallback to placeholder if image fails to load
                          e.currentTarget.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTI4IiBoZWlnaHQ9IjEyOCIgdmlld0JveD0iMCAwIDEyOCAxMjgiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiBmaWxsPSIjRjNGNEY2Ii8+CjxwYXRoIGQ9Ik00OCA2NEg4MFY4MEg0OFY2NFoiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS13aWR0aD0iNCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2U9IiM5Q0EzQUYiLz4KPHJlY3QgeD0iNTYiIHk9Ijc2IiB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHJ4PSI4IiBmaWxsPSIjOUNBM0FGIi8+Cjwvc3ZnPg==';
                        }}
                      />
                    ) : (
                      <Package className="h-14 w-14 sm:h-16 sm:w-16 text-gray-400" />
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Payment & Pricing */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 sm:p-6">
          <h3 className="text-base sm:text-lg font-medium text-gray-900 mb-4">Payment & Pricing</h3>
          <div className="space-y-4">
            <div className="bg-gray-50 rounded-lg p-4 space-y-3">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Subtotal</span>
                <span className="text-sm font-medium text-gray-900">{formatCurrency(order.pricing.subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Tax</span>
                <span className="text-sm font-medium text-gray-900">{formatCurrency(order.pricing.tax)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Delivery Fee</span>
                <span className="text-sm font-medium text-gray-900">{formatCurrency(order.pricing.deliveryFee)}</span>
              </div>
              <div className="border-t pt-3">
                <div className="flex justify-between">
                  <span className="text-base font-medium text-gray-900">Total</span>
                  <span className="text-base font-bold text-green-600">{formatCurrency(order.pricing.total)}</span>
                </div>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4 space-y-3">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Payment Status</span>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  order.payment.status === 'PAID' 
                    ? 'bg-green-100 text-green-800' 
                    : order.payment.status === 'PENDING'
                    ? 'bg-yellow-100 text-yellow-800'
                    : 'bg-red-100 text-red-800'
                }`}>
                  {order.payment.status}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Payment Method</span>
                <span className="text-sm font-medium text-gray-900">{order.payment.method}</span>
              </div>
              {order.payment.transactionId && (
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Transaction ID</span>
                  <span className="text-sm font-medium text-gray-900 break-words">{order.payment.transactionId}</span>
                </div>
              )}
            </div>
          </div>
          
          {/* Product Details */}
          <div className="space-y-4">
            <h4 className="text-base font-medium text-gray-900">Product Details</h4>
            {order.items.map((item, index) => (
              <div key={item._id || index} className="bg-gray-50 rounded-lg p-4">
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-gray-900 text-base sm:text-lg break-words">{item.product.name}</p>
                  <p className="text-sm text-gray-500 mt-1">Quantity: {item.quantity}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderDetailsPage;
