import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../../contexts/ToastContext';
import { adminService } from '../services/adminService';
import { AdminUser } from '../types/admin';
import SearchAutocomplete from '../../components/SearchAutocomplete';
import { X, User as UserIcon, MoreHorizontal, Search } from 'lucide-react';

const UserManagementPage: React.FC = () => {
  const navigate = useNavigate();
  const { handleApiResponse, handleApiError } = useToast();
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [selectedUser, setSelectedUser] = useState<AdminUser | null>(null);
  const [showUserDetails, setShowUserDetails] = useState(false);
  const [pagination, setPagination] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');

  // Memoize users data to prevent unnecessary re-renders
  const memoizedUsers = useMemo(() => users, [users]);

  // Force refresh on component mount to clear any cached references
  useEffect(() => {
    fetchUsers();
  }, []);

  // Fetch users with pagination and search
  const fetchUsers = async (page = 1, search = '') => {
    try {
      setIsLoading(true);
      const data = await adminService.getAllUsers({ 
        page, 
        limit: 20, 
        search: search.trim() 
      });
      console.log('Users fetched:', data); // Debug log
      setUsers(data.users);
      setPagination(data.pagination);
      setCurrentPage(page);
    } catch (error) {
      console.error('Error fetching users:', error);
      handleApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  // Debounced search function
  const handleSearch = useCallback((term: string) => {
    const timer = setTimeout(() => {
      fetchUsers(1, term);
    }, 300);
    return () => clearTimeout(timer);
  }, []);

  const handleUserDetails = (user: AdminUser) => {
    console.log('handleUserDetails called with user:', user); // Debug log
    setSelectedUser(user);
    setShowUserDetails(true);
    console.log('Modal state set to show:', true); // Debug log
  };

  const handleDeleteUser = async (userId: string) => {
    if (window.confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
      try {
        await adminService.deleteUser(userId);
        setUsers(users.filter(user => user._id !== userId));
        handleApiResponse('User deleted successfully');
        closeUserDetails();
      } catch (error) {
        console.error('Error deleting user:', error);
        handleApiError(error);
      }
    }
  };

  const closeUserDetails = () => {
    setShowUserDetails(false);
    setSelectedUser(null);
  };

  const handleStatusToggle = async (userId: string) => {
    try {
      const updatedUser = await adminService.toggleUserStatus(userId);
      setUsers(users.map(user => 
        user._id === userId ? updatedUser : user
      ));
      
      // Custom message for vendors
      let message = `User ${updatedUser.isActive ? 'activated' : 'deactivated'} successfully`;
      if (updatedUser.role === 'VENDOR' && updatedUser.status) {
        message += `. Vendor status set to ${updatedUser.status}`;
      }
      
      handleApiResponse(message);
    } catch (error) {
      console.error('Error toggling user status:', error);
      handleApiError(error);
    }
  };

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">User Management</h1>
        <p className="text-gray-600 mt-2">Manage user roles and account status</p>
      </div>

      {/* Search Interface */}
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <Search className="h-5 w-5 text-green-600 mr-2" />
            <h2 className="text-lg font-semibold text-gray-900">Search Users</h2>
          </div>
          
          <SearchAutocomplete
            items={memoizedUsers}
            searchKeys={['firstName', 'lastName', 'email']}
            placeholder="Search users..."
            onSelect={handleUserDetails}
            onSearch={handleSearch}
            className="w-full"
            inputClassName="block w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
            dropdownClassName="mt-1 bg-white border border-gray-300 rounded-md shadow-lg max-h-60 overflow-y-auto"
          />
        </div>
      </div>

      {/* Instructions */}
      <div className="text-center py-12">
        <div className="max-w-md mx-auto">
          <div className="mb-4">
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100">
              <svg className="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">Search for Users</h3>
          <p className="text-sm text-gray-500">
            Use the search box above to find and view user details. Type a name or email to see suggestions.
          </p>
        </div>
      </div>

      {/* User Details Modal */}
      {showUserDetails && selectedUser && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative min-h-screen flex items-center justify-center p-4">
            <div className="relative bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              {/* Modal Header */}
              <div className="flex items-center justify-between p-6 border-b border-gray-200">
                <h2 className="text-xl font-semibold text-gray-900">User Details</h2>
                <button
                  onClick={closeUserDetails}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* User Info */}
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4">
                      <div className="h-16 w-16 rounded-full bg-green-600 flex items-center justify-center">
                        <UserIcon className="h-8 w-8 text-white" />
                      </div>
                      <div>
                        <h3 className="text-lg font-medium text-gray-900">
                          {selectedUser.firstName} {selectedUser.lastName}
                        </h3>
                        <p className="text-sm text-gray-500">{selectedUser.email}</p>
                        <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-purple-100 text-purple-800">
                          {selectedUser.role}
                        </span>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div>
                        <span className="text-sm font-medium text-gray-700">Phone:</span>
                        <span className="text-sm text-gray-900 ml-2">{selectedUser.phone || 'Not provided'}</span>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-700">Status:</span>
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ml-2 ${
                          selectedUser.isActive 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {selectedUser.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-700">Email Verified:</span>
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ml-2 ${
                          selectedUser.isEmailVerified 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {selectedUser.isEmailVerified ? 'Verified' : 'Not Verified'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* User Activity */}
                  <div className="space-y-4">
                    <h4 className="text-lg font-medium text-gray-900 mb-4">Account Activity</h4>
                    <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-700">Last Login:</span>
                        <span className="text-sm text-gray-900">
                          {selectedUser.lastLogin 
                            ? new Intl.DateTimeFormat('en-GB', {
                                day: 'numeric',
                                month: 'long',
                                year: 'numeric'
                              }).format(new Date(selectedUser.lastLogin))
                            : 'Never logged in'
                          }
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-700">Account Created:</span>
                        <span className="text-sm text-gray-900">
                          {new Intl.DateTimeFormat('en-GB', {
                            day: 'numeric',
                            month: 'long',
                            year: 'numeric'
                          }).format(new Date(selectedUser.createdAt))}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-700">Profile Status:</span>
                        <span className={`text-sm font-medium ${
                          selectedUser.isActive ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {selectedUser.isActive ? 'Account is active' : 'Account is inactive'}
                        </span>
                      </div>
                      {selectedUser.role === 'VENDOR' && (
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-gray-700">Vendor Status:</span>
                          <span className={`text-sm font-medium ${
                            selectedUser.status === 'active' ? 'text-green-600' : 
                            selectedUser.status === 'suspended' ? 'text-yellow-600' : 
                            selectedUser.status === 'banned' ? 'text-red-600' : 'text-gray-600'
                          }`}>
                            {selectedUser.status ? selectedUser.status.charAt(0).toUpperCase() + selectedUser.status.slice(1) : 'Unknown'}
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Quick Actions */}
                    <div className="mt-6 space-y-3">
                      <h4 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h4>
                      <div className="flex flex-wrap gap-3">
                        <button
                          onClick={() => {
                            handleStatusToggle(selectedUser._id);
                            closeUserDetails();
                          }}
                          className={`px-4 py-2 rounded-md text-sm font-medium ${
                            selectedUser.isActive
                              ? 'bg-red-600 hover:bg-red-700 text-white'
                              : 'bg-green-600 hover:bg-green-700 text-white'
                          }`}
                        >
                          {selectedUser.isActive ? 'Deactivate' : 'Activate'}
                        </button>
                        <button
                          onClick={() => {
                            handleDeleteUser(selectedUser._id);
                          }}
                          className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-md text-sm font-medium"
                        >
                          Delete
                        </button>
                        <button
                          onClick={() => {
                            // Navigate to View More page with user ID
                            navigate(`/admin/users/${selectedUser._id}`);
                          }}
                          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-sm font-medium flex items-center gap-2"
                        >
                          <MoreHorizontal className="h-4 w-4" />
                          View More
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserManagementPage;
