import React from 'react';
import { useNavigate } from 'react-router-dom';
import OrderSearchAutocomplete from '../components/OrderSearchAutocomplete';
import { RefreshCw, Search } from 'lucide-react';

const OrderManagementPage: React.FC = () => {
  const navigate = useNavigate();

  const handleRefresh = () => {
    // For server-side search, we don't need to refresh data
    // The search will always fetch fresh data from the server
    window.location.reload();
  };

  return (
    <div className="p-6">
      <div className="mb-8 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Order Management</h1>
          <p className="text-gray-600 mt-2">Search and view order details</p>
        </div>
        <button
          onClick={handleRefresh}
          className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
        >
          <RefreshCw className="h-4 w-4" />
          Refresh
        </button>
      </div>

      {/* Search Interface */}
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <Search className="h-5 w-5 text-green-600 mr-2" />
            <h2 className="text-lg font-semibold text-gray-900">Search Orders</h2>
          </div>
          
          <OrderSearchAutocomplete 
            placeholder="Search by order number..."
            className="w-full"
          />
        </div>
      </div>
    </div>
  );
};

export default OrderManagementPage;