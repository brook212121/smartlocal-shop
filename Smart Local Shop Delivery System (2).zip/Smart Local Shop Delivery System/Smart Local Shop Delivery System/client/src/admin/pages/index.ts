export { default as AdminDashboardPage } from './AdminDashboardPage';
export { default as UserManagementPage } from './UserManagementPage';
export { default as ProductManagementPage } from './ProductManagementPage';
export { default as OrderManagementPage } from './OrderManagementPage';
export { default as AdminOrderDetailsPage } from './OrderDetailsPage';
export { default as ViewMorePage } from './ViewMorePage';
export { default as AdminProfilePage } from './AdminProfilePage';
