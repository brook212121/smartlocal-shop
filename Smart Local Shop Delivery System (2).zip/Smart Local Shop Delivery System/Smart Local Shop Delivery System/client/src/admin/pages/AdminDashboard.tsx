import React, { useState, useEffect } from 'react';
import { Users, ShoppingCart, Package, Truck, TrendingUp } from 'lucide-react';
import Spinner from '../../components/ui/Spinner';
import { useToast } from '../../contexts/ToastContext';
import AdminStatCard from '../components/AdminStatCard';
import { adminService } from '../services/adminService';
import { AdminStats } from '../types/admin';

const AdminDashboard: React.FC = () => {
  const { handleApiResponse, handleApiError } = useToast();
  const [stats, setStats] = useState<AdminStats>({
    totalUsers: 0,
    totalVendors: 0,
    totalOrders: 0,
    openQuickOrders: 0,
    pendingDeliveries: 0
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchDashboardStats();
  }, []);

  const fetchDashboardStats = async () => {
    try {
      const data = await adminService.getDashboardStats();
      setStats(data);
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      handleApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Spinner size="lg" />
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-8">
        <p className="text-gray-600 mt-2">System overview and management</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
        <AdminStatCard
          title="Total Users"
          value={stats.totalUsers}
          icon={<Users className="h-6 w-6 text-white" />}
          color="bg-blue-500"
          trend={{ value: 12, isPositive: true }}
        />
        
        <AdminStatCard
          title="Total Vendors"
          value={stats.totalVendors}
          icon={<Package className="h-6 w-6 text-white" />}
          color="bg-purple-500"
          trend={{ value: 8, isPositive: true }}
        />
        
        <AdminStatCard
          title="Total Orders"
          value={stats.totalOrders}
          icon={<ShoppingCart className="h-6 w-6 text-white" />}
          color="bg-green-500"
          trend={{ value: 15, isPositive: true }}
        />
        
        <AdminStatCard
          title="Open Quick Orders"
          value={stats.openQuickOrders}
          icon={<Truck className="h-6 w-6 text-white" />}
          color="bg-orange-500"
          trend={{ value: -5, isPositive: false }}
        />
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
          <div className="space-y-3">
            <a
              href="/admin/users"
              className="block p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center">
                <Users className="h-5 w-5 text-blue-600 mr-3" />
                <div>
                  <div className="font-medium text-gray-900">Manage Users</div>
                  <div className="text-sm text-gray-500">Assign roles and manage accounts</div>
                </div>
              </div>
            </a>
            
            <a
              href="/admin/orders"
              className="block p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center">
                <ShoppingCart className="h-5 w-5 text-green-600 mr-3" />
                <div>
                  <div className="font-medium text-gray-900">Manage Orders</div>
                  <div className="text-sm text-gray-500">View orders and assign delivery</div>
                </div>
              </div>
            </a>
            
            <a
              href="/admin/quick-orders"
              className="block p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center">
                <Package className="h-5 w-5 text-purple-600 mr-3" />
                <div>
                  <div className="font-medium text-gray-900">Quick Orders</div>
                  <div className="text-sm text-gray-500">Moderate custom order requests</div>
                </div>
              </div>
            </a>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">System Status</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Database Connection</span>
              <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                Healthy
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">API Response Time</span>
              <span className="text-sm text-gray-900">120ms</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Active Sessions</span>
              <span className="text-sm text-gray-900">24</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Server Uptime</span>
              <span className="text-sm text-gray-900">99.9%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
