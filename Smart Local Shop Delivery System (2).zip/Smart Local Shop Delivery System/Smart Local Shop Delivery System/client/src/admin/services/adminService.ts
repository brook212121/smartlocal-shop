import api from '../../services/api';
import { AdminUser, AdminOrder, AdminProduct, AdminQuickOrder, AdminStats, DeliveryAgent } from '../types/admin';
import { safeFetch, isUserOffline, getUserFriendlyErrorMessage } from '../../utils/errorHandler';

// Admin Profile interface
export interface AdminProfile {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  profilePhoto?: string;
  role: string;
  createdAt: string;
}

export interface ProfileUpdateData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  profilePhoto?: string;
}

export interface PasswordChangeData {
  currentPassword: string;
  newPassword: string;
}

export const adminService = {
  // Dashboard Stats
  async getDashboardStats(): Promise<AdminStats> {
    try {
      // Check offline status first
      if (isUserOffline()) {
        throw new Error("NETWORK_ERROR");
      }
      
      const response = await api.get('/admin/stats');
      return response.data.data;
    } catch (error) {
      // Use global error handler for user-friendly messages
      const friendlyMessage = getUserFriendlyErrorMessage(error);
      if (import.meta.env.DEV) {
        console.error('Error fetching admin stats:', error);
      }
      throw error;
    }
  },

  // User Management
  async getAllUsers(options?: { page?: number; limit?: number; search?: string; role?: string }): Promise<{ users: AdminUser[]; pagination: any }> {
    try {
      const params = new URLSearchParams();
      if (options?.page) params.append('page', options.page.toString());
      if (options?.limit) params.append('limit', options.limit.toString());
      if (options?.search) params.append('search', options.search);
      if (options?.role) params.append('role', options.role);
      
      const url = `/admin/users${params.toString() ? `?${params.toString()}` : ''}`;
      const response = await api.get(url);
      return response.data.data;
    } catch (error) {
      console.error('Error fetching users:', error);
      throw error;
    }
  },

  async updateUserRole(userId: string, role: string): Promise<AdminUser> {
    try {
      const response = await api.put(`/admin/users/${userId}/role`, { role });
      return response.data.data.user;
    } catch (error) {
      console.error('Error updating user role:', error);
      throw error;
    }
  },

  async toggleUserStatus(userId: string): Promise<AdminUser> {
    try {
      const response = await api.put(`/admin/users/${userId}/toggle-status`);
      return response.data.data.user;
    } catch (error) {
      console.error('Error toggling user status:', error);
      throw error;
    }
  },

  async deleteUser(userId: string): Promise<void> {
    try {
      await api.delete(`/admin/users/${userId}`);
    } catch (error) {
      console.error('Error deleting user:', error);
      throw error;
    }
  },

  async getUserDetails(userId: string): Promise<any> {
    try {
      const response = await api.get(`/admin/users/${userId}/details`);
      return response.data.data;
    } catch (error) {
      const friendlyMessage = getUserFriendlyErrorMessage(error);
      if (import.meta.env.DEV) {
        console.error('Error fetching user details:', error);
      }
      throw error;
    }
  },

  async getUserComplaints(userId: string): Promise<any> {
    try {
      const response = await api.get(`/admin/users/${userId}/complaints`);
      return response.data;
    } catch (error) {
      const friendlyMessage = getUserFriendlyErrorMessage(error);
      if (import.meta.env.DEV) {
        console.error('Error fetching user complaints:', error);
      }
      throw error;
    }
  },

  async getUserOrders(userId: string): Promise<any> {
    try {
      const response = await api.get(`/admin/users/${userId}/orders`);
      return response.data;
    } catch (error) {
      const friendlyMessage = getUserFriendlyErrorMessage(error);
      if (import.meta.env.DEV) {
        console.error('Error fetching user orders:', error);
      }
      throw error;
    }
  },

  async getUserTransactions(userId: string): Promise<any> {
    try {
      const response = await api.get(`/admin/users/${userId}/transactions`);
      return response.data;
    } catch (error) {
      const friendlyMessage = getUserFriendlyErrorMessage(error);
      if (import.meta.env.DEV) {
        console.error('Error fetching user transactions:', error);
      }
      throw error;
    }
  },

  async getOrderDetails(orderId: string): Promise<any> {
    try {
      const response = await api.get(`/admin/orders/${orderId}/details`);
      return response.data.data;
    } catch (error) {
      console.error('Error fetching order details:', error);
      throw error;
    }
  },

  // Product Management (Read-only)
  async getAllProducts(): Promise<AdminProduct[]> {
    try {
      const response = await api.get('/admin/products');
      return response.data.data.products;
    } catch (error) {
      console.error('Error fetching products:', error);
      throw error;
    }
  },

  // Order Management
  async getAllOrders(page = 1, limit = 10): Promise<AdminOrder[]> {
    try {
      console.log('AdminService: Starting getAllOrders...');
      // Add cache-busting timestamp and pagination
      const timestamp = Date.now();
      const url = `/admin/orders?page=${page}&limit=${limit}&t=${timestamp}`;
      console.log('AdminService: Fetching from URL:', url);
      
      const response = await api.get(url);
      console.log('AdminService: Response received:', response.status);
      console.log('AdminService: Response data:', response.data);
      
      const orders = response.data.data.orders;
      console.log('AdminService: Orders extracted:', orders);
      console.log('AdminService: Orders type:', typeof orders);
      console.log('AdminService: Orders is array:', Array.isArray(orders));
      console.log('AdminService: Orders length:', orders?.length);
      
      return orders;
    } catch (error) {
      console.error('AdminService: Error fetching orders:', error);
      console.error('AdminService: Error details:', (error as any).response?.data || (error as any).message);
      throw error;
    }
  },

  async searchOrders(query: string, limit = 10, signal?: AbortSignal): Promise<AdminOrder[]> {
    try {
      console.log('AdminService: Starting searchOrders with query:', query);
      
      if (!query || query.trim().length === 0) {
        console.log('AdminService: Empty query, returning empty array');
        return [];
      }
      
      // Add cache-busting timestamp
      const timestamp = Date.now();
      const url = `/admin/orders/search?query=${encodeURIComponent(query.trim())}&limit=${limit}&t=${timestamp}`;
      console.log('AdminService: Searching from URL:', url);
      
      const response = await api.get(url, { signal });
      console.log('AdminService: Search response received:', response.status);
      console.log('AdminService: Search response data:', response.data);
      
      const orders = response.data.data.orders;
      console.log('AdminService: Search orders extracted:', orders);
      console.log('AdminService: Search orders length:', orders?.length);
      
      return orders;
    } catch (error: any) {
      // Don't log errors for cancelled requests
      if (error.name !== 'CanceledError' && error.name !== 'AbortError') {
        console.error('AdminService: Error searching orders:', error);
        console.error('AdminService: Search error details:', (error as any).response?.data || (error as any).message);
      }
      throw error;
    }
  },

  async assignDeliveryAgent(orderId: string, agentId: string): Promise<AdminOrder> {
    try {
      const response = await api.put(`/admin/orders/${orderId}/assign-delivery`, { agentId });
      return response.data.data.order;
    } catch (error) {
      console.error('Error assigning delivery agent:', error);
      throw error;
    }
  },

  async getDeliveryAgents(): Promise<DeliveryAgent[]> {
    try {
      const response = await api.get('/admin/delivery-agents');
      return response.data.data.agents;
    } catch (error) {
      console.error('Error fetching delivery agents:', error);
      throw error;
    }
  },

  // Quick Order Management
  async getAllQuickOrders(): Promise<AdminQuickOrder[]> {
    try {
      const response = await api.get('/admin/quick-orders');
      return response.data.data.quickOrders;
    } catch (error) {
      console.error('Error fetching quick orders:', error);
      // Return empty array instead of mock data
      return [];
    }
  },

  async closeQuickOrder(orderId: string): Promise<AdminQuickOrder> {
    try {
      const response = await api.put(`/admin/quick-orders/${orderId}/close`);
      return response.data.data.quickOrder;
    } catch (error) {
      console.error('Error closing quick order:', error);
      throw error;
    }
  },

  // Profile Management
  async getProfile(): Promise<AdminProfile> {
    try {
      const response = await api.get('/admin/profile');
      return response.data.data;
    } catch (error) {
      console.error('Error fetching admin profile:', error);
      throw error;
    }
  },

  async updateProfile(profileData: ProfileUpdateData): Promise<AdminProfile> {
    try {
      const response = await api.patch('/admin/profile', profileData);
      return response.data.data;
    } catch (error) {
      console.error('Error updating admin profile:', error);
      throw error;
    }
  },

  async changePassword(passwordData: PasswordChangeData): Promise<void> {
    try {
      const response = await api.patch('/admin/change-password', passwordData);
      return response.data;
    } catch (error) {
      console.error('Error changing admin password:', error);
      throw error;
    }
  },

  async setAdminPassword(passwordData: { newPassword: string }): Promise<void> {
    try {
      const response = await api.post('/admin/set-password', passwordData);
      return response.data;
    } catch (error) {
      console.error('Error setting admin password:', error);
      throw error;
    }
  }
};
