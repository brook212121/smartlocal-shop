export interface AdminUser {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  role: 'CUSTOMER' | 'VENDOR' | 'DELIVERY' | 'ADMIN';
  isActive: boolean;
  isEmailVerified: boolean;
  status?: 'active' | 'suspended' | 'banned';
  createdAt: string;
  lastLogin?: string;
}

export interface AdminOrder {
  _id: string;
  orderNumber: string;
  customer: {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
  };
  vendor: {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
  };
  items: {
    product: {
      _id: string;
      name: string;
      price: number;
    };
    quantity: number;
    price: number;
  }[];
  status: 'PENDING' | 'CONFIRMED' | 'PREPARING' | 'READY_FOR_PICKUP' | 'OUT_FOR_DELIVERY' | 'DELIVERED' | 'CANCELLED' | 'REFUNDED';
  delivery: {
    address: {
      street: string;
      city: string;
      county: string;
    };
    deliveryFee: number;
    deliveryAgent?: {
      _id: string;
      firstName: string;
      lastName: string;
      phone: string;
    };
  };
  pricing: {
    subtotal: number;
    deliveryFee: number;
    total: number;
    currency: string;
  };
  createdAt: string;
  estimatedDeliveryTime?: string;
}

export interface AdminProduct {
  _id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  vendor: {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
  };
  stock: {
    quantity: number;
    lowStockThreshold: number;
  };
  images: string[];
  isActive: boolean;
  createdAt: string;
}

export interface AdminQuickOrder {
  _id: string;
  description: string;
  quantity: string;
  customer: {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
  };
  status: 'OPEN' | 'ASSIGNED' | 'CLOSED';
  image?: string;
  createdAt: string;
  assignedVendor?: {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
  };
}

export interface AdminStats {
  totalUsers: number;
  totalVendors: number;
  totalOrders: number;
  openQuickOrders: number;
  pendingDeliveries: number;
}

export interface DeliveryAgent {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  isActive: boolean;
  currentOrders: number;
  totalDelivered: number;
}
