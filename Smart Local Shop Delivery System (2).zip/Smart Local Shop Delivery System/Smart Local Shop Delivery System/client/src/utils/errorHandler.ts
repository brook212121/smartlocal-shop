/**
 * Global Error Handler Utility
 * Converts technical errors into user-friendly messages
 */

export function getUserFriendlyErrorMessage(error: any): string {
  // Handle null/undefined errors
  if (!error) {
    return "Something went wrong. Please try again.";
  }

  // Get error message
  const errorMessage = error.message || error.toString();

  // Network errors
  if (errorMessage.includes("Failed to fetch") || 
      errorMessage.includes("NetworkError") ||
      errorMessage.includes("NETWORK_ERROR")) {
    return "Network error. Please check your internet connection and try again.";
  }

  // Timeout errors
  if (errorMessage.includes("timeout") || 
      errorMessage.includes("timed out")) {
    return "Request timed out. Please try again.";
  }

  // Authentication errors
  if (errorMessage.includes("401") || 
      errorMessage.includes("Unauthorized") ||
      errorMessage.includes("session") ||
      errorMessage.includes("token")) {
    return "Session expired. Please log in again.";
  }

  // Permission errors
  if (errorMessage.includes("403") || 
      errorMessage.includes("Forbidden") ||
      errorMessage.includes("permission")) {
    return "You don't have permission to perform this action.";
  }

  // Not found errors
  if (errorMessage.includes("404") || 
      errorMessage.includes("not found")) {
    return "Requested resource not found.";
  }

  // Server errors
  if (errorMessage.includes("500") || 
      errorMessage.includes("Internal Server Error")) {
    return "Server error. Please try again later.";
  }

  // Validation errors
  if (errorMessage.includes("validation") || 
      errorMessage.includes("Invalid") ||
      errorMessage.includes("required")) {
    return "Invalid input. Please check your information and try again.";
  }

  // Order-specific errors
  if (errorMessage.includes("order") || 
      errorMessage.includes("delivery")) {
    return "Unable to process order. Please try again.";
  }

  // Payment-specific errors
  if (errorMessage.includes("payment") || 
      errorMessage.includes("chapa")) {
    return "Payment processing failed. Please try again.";
  }

  // Default fallback
  return "Something went wrong. Please try again.";
}

/**
 * Check if user is offline
 */
export function isUserOffline(): boolean {
  return !navigator.onLine;
}

/**
 * Standardized error handler for API calls
 */
export function handleApiError(error: any, showToast: (message: string, type?: 'success' | 'error') => void): void {
  // Check if offline first
  if (isUserOffline()) {
    showToast("You are offline. Please check your connection.", "error");
    return;
  }

  // Get user-friendly message
  const friendlyMessage = getUserFriendlyErrorMessage(error);
  
  // Show toast with clean message
  showToast(friendlyMessage, "error");
  
  // Log detailed error for debugging (only in development)
  if (import.meta.env.DEV) {
    console.error('API Error Details:', error);
  }
}

/**
 * Wrapper for fetch calls with standardized error handling
 */
export async function safeFetch(url: string, options?: RequestInit): Promise<Response> {
  // Check if offline
  if (isUserOffline()) {
    throw new Error("NETWORK_ERROR");
  }

  try {
    const response = await fetch(url, options);
    return response;
  } catch (error) {
    // Convert fetch errors to standardized error
    throw new Error("NETWORK_ERROR");
  }
}
