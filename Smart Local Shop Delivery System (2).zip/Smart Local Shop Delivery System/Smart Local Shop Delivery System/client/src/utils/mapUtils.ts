// Map utility functions and interfaces

export interface Location {
  latitude: number;
  longitude: number;
  address: string;
}

export interface DistanceMatrixResponse {
  status: 'OK' | 'ZERO_RESULTS' | 'OVER_DAILY_LIMIT' | 'OVER_QUERY_LIMIT' | 'REQUEST_DENIED' | 'INVALID_REQUEST' | 'UNKNOWN_ERROR';
  rows?: Array<{
    elements: Array<{
      status: string;
      distance?: {
        text: string;
        value: number;
      };
      duration?: {
        text: string;
        value: number;
      };
    }>;
  }>;
}

// Haversine formula to calculate distance between two coordinates
export const haversineDistance = (
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number => {
  console.log(`🎯 DEBUG: Haversine calculation:`);
  console.log(`🎯 DEBUG: Point 1: ${lat1}, ${lon1}`);
  console.log(`🎯 DEBUG: Point 2: ${lat2}, ${lon2}`);
  
  const R = 6371; // Earth's radius in kilometers
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;

  console.log(`🎯 DEBUG: dLat: ${dLat}, dLon: ${dLon}`);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) *
    Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) *
    Math.sin(dLon / 2);

  console.log(`🎯 DEBUG: a value: ${a}`);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;

  console.log(`🎯 DEBUG: Haversine result: ${distance.toFixed(2)}km`);
  return distance; // Distance in kilometers
};

// Validate coordinates are real numbers
export const validateCoordinates = (latitude: number, longitude: number): boolean => {
  return typeof latitude === 'number' && 
         typeof longitude === 'number' && 
         latitude !== 0 && 
         longitude !== 0 && 
         !isNaN(latitude) && 
         !isNaN(longitude) &&
         isFinite(latitude) &&
         isFinite(longitude);
};

// Format coordinates to 6 decimal places
export const formatCoordinates = (latitude: number, longitude: number) => ({
  latitude: parseFloat(latitude.toFixed(6)),
  longitude: parseFloat(longitude.toFixed(6))
});

// Reverse geocoding to get address from coordinates
export const reverseGeocode = async (latitude: number, longitude: number): Promise<string> => {
  console.log('🗺️ REVERSE GEOCODING REQUEST:');
  console.log('📍 Input Coordinates:', { latitude, longitude });
  console.log('📍 Formatted for API:', `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`);
  
  try {
    const apiUrl = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`;
    console.log('🌐 API Request URL:', apiUrl);
    
    const response = await fetch(apiUrl, {
      headers: {
        'User-Agent': 'YourApp/1.0'
      }
    });
    
    console.log('📡 API Response Status:', response.status, response.statusText);
    
    if (!response.ok) {
      console.warn('❌ Reverse geocoding failed:', response.status, response.statusText);
      return `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
    }
    
    const data = await response.json();
    console.log('📦 Raw API Response:', data);
    
    if (data.error) {
      console.warn('❌ Geocoding API error:', data.error);
      return `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
    }
    
    const address = data.display_name || 
                  data.address?.road || 
                  data.address?.city || 
                  data.address?.town || 
                  data.address?.village || 
                  `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
    
    console.log('🏠 PROCESSED ADDRESS DATA:');
    console.log('📍 Display Name:', data.display_name);
    console.log('📍 Address Components:', data.address);
    console.log('📍 Final Address:', address);
    console.log('📍 Address Type:', typeof address);
    
    return address;
  } catch (error) {
    console.error('❌ Reverse geocoding error:', error);
    console.error('❌ Error Details:', {
      message: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : 'No stack trace',
      coordinates: { latitude, longitude }
    });
    return `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
  }
};
