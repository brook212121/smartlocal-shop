/**
 * Dynamic Image URL Utilities for LAN Support
 * Automatically builds image URLs based on current network location
 */

import { getApiBaseUrl } from './apiConfig';

/**
 * Get the full URL for an image path
 * Works with both absolute and relative paths
 */
export const getImageUrl = (imagePath?: string): string => {
  if (!imagePath) {
    return "/placeholder.png";
  }

  // If it's already a full URL (starts with http), return as is
  if (imagePath.startsWith('http')) {
    return imagePath;
  }

  // If it's a data URL, return as is
  if (imagePath.startsWith('data:')) {
    return imagePath;
  }

  // For localhost development, use Vite proxy
  const hostname = window.location.hostname;
  if (hostname === 'localhost' || hostname === '127.0.0.1') {
    // Use Vite proxy for image requests
    const cleanPath = imagePath.startsWith('/') ? imagePath : `/${imagePath}`;
    return cleanPath; // Return relative path for Vite proxy
  }
  
  // For other environments (ngrok, production), build full URL
  // For uploads, use the base URL without /api prefix
  const envApiUrl = (import.meta as any).env?.VITE_API_URL;
  if (envApiUrl && envApiUrl.includes('ngrok')) {
    // For ngrok, use the base URL without /api for images
    const baseUrl = envApiUrl.replace(/\/$/, '');
    const cleanPath = imagePath.startsWith('/') ? imagePath : `/${imagePath}`;
    return `${baseUrl}${cleanPath}`;
  }
  
  // For other environments, use API base URL
  const baseUrl = getApiBaseUrl();
  const cleanPath = imagePath.startsWith('/') ? imagePath : `/${imagePath}`;
  
  return `${baseUrl}${cleanPath}`;
};

/**
 * Get a fallback image URL if the primary one fails
 */
export const getFallbackImageUrl = (): string => {
  return "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iI2YzZjRmNiIvPgogIDx0ZXh0IHg9IjE1MCIgeT0iMTAwIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTYiIGZpbGw9IiM5Y2EzYWYiIHRleHQtYW5jaG9yPSJtaWRkbGUiPgogICAgTm8gSW1hZ2UgQXZhaWxhYmxlCiAgPC90ZXh0Pgo8L3N2Zz4=";
};
