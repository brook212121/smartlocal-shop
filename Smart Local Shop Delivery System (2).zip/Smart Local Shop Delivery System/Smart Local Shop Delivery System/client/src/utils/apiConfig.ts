/**
 * API Configuration for Localhost Development
 * Uses environment variable or defaults to localhost:5000
 */

/**
 * Get the base API URL dynamically based on environment
 */
export const getApiBaseUrl = (): string => {
  // Use environment variable or default to localhost:5000
  const API_BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";
  return API_BASE_URL;
};

/**
 * Get the full API URL for a specific endpoint
 */
export const getApiUrl = (endpoint: string): string => {
  const baseUrl = getApiBaseUrl();
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  const apiEndpoint = cleanEndpoint.startsWith('/api') ? cleanEndpoint : `/api${cleanEndpoint}`;
  const finalUrl = `${baseUrl}${apiEndpoint}`;
  
  // Debug logging
  console.log('🔍 API URL Debug:', {
    endpoint,
    baseUrl,
    cleanEndpoint,
    apiEndpoint,
    finalUrl
  });
  
  return finalUrl;
};

/**
 * Check if the app is running in development mode
 */
export const isDevelopment = (): boolean => {
  return import.meta.env.DEV || import.meta.env.MODE === 'development';
};

/**
 * Get the current network information for debugging
 */
export const getNetworkInfo = () => {
  return {
    protocol: window.location.protocol,
    hostname: window.location.hostname,
    port: window.location.port,
    href: window.location.href,
    apiBaseUrl: getApiBaseUrl(),
    isDevelopment: isDevelopment(),
    userAgent: navigator.userAgent,
  };
};

// Export the base URL for direct use
export const API_BASE_URL = getApiBaseUrl();
