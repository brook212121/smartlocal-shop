import { Route } from 'react-router-dom';
import {
  HeroSection,
  FeaturesSection,
  HowItWorksSection,
  UserRolesSection,
  TrustImpactSection,
} from '../components';
import {
  LoginPage,
  RegisterPage,
  RegisterStep2Page,
  ForgotPasswordPage,
  ResetPasswordPage,
  VerifyEmailPage,
} from '../pages';
import { PublicLayout } from '../layouts';

export const publicRoutes = (
  <Route path="/" element={<PublicLayout />}>
    <Route
      index
      element={
        <>
          <HeroSection />
          <FeaturesSection />
          <HowItWorksSection />
          <UserRolesSection />
          <TrustImpactSection />
        </>
      }
    />
    <Route path="login" element={<LoginPage />} />
    <Route path="register" element={<RegisterPage />} />
    <Route path="register-step-2" element={<RegisterStep2Page />} />
    <Route path="forgot-password" element={<ForgotPasswordPage />} />
    <Route path="reset-password" element={<ResetPasswordPage />} />
    <Route path="verify-email" element={<VerifyEmailPage />} />
  </Route>
);
