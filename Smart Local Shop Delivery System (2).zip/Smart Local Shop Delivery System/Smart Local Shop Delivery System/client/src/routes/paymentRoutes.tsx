import { Route } from 'react-router-dom';
import {
  PaymentPage,
  PaymentSuccessPage,
  PaymentReturnPage,
} from '../payment/pages';
import { OrderDeliveryOptionPage } from '../pages';

export const paymentRoutes = (
  <>
    <Route path="/browse" element={<PaymentPage />} />
    <Route path="/order/delivery-option" element={<OrderDeliveryOptionPage />} />
    <Route path="/payment" element={<PaymentPage />} />
    <Route path="/payment/success" element={<PaymentSuccessPage />} />
    <Route path="/payment/return" element={<PaymentReturnPage />} />
    <Route path="/change-password" element={<PaymentPage />} />
  </>
);
