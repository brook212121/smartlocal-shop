import { Route } from 'react-router-dom';
import { AdminProtectedRoute } from '../components';
import {
  AdminDashboardPage,
  UserManagementPage,
  ProductManagementPage,
  OrderManagementPage,
  AdminOrderDetailsPage,
  ViewMorePage,
  AdminProfilePage,
} from '../admin/pages';
import { AdminLayout } from '../layouts';

export const adminRoutes = (
  <Route
    path="/admin"
    element={
      <AdminProtectedRoute>
        <AdminLayout />
      </AdminProtectedRoute>
    }
  >
    <Route index element={<AdminDashboardPage />} />
    <Route path="users" element={<UserManagementPage />} />
    <Route path="users/:userId" element={<ViewMorePage />} />
    <Route path="products" element={<ProductManagementPage />} />
    <Route path="orders" element={<OrderManagementPage />} />
    <Route path="orders/:orderId" element={<AdminOrderDetailsPage />} />
    <Route path="profile" element={<AdminProfilePage />} />
  </Route>
);
