import { Route } from 'react-router-dom';
import {
  DeliveryDashboard,
  AssignedOrdersPage,
  OrderDetailsPage,
  DeliveryOrderDetailsPage,
  AgentProfile,
} from '../delivery/pages';
import { DeliveryDashboardLayout } from '../layouts';

export const deliveryRoutes = (
  <Route path="/delivery" element={<DeliveryDashboardLayout />}>
    <Route index element={<DeliveryDashboard />} />
    <Route path="assigned-orders" element={<AssignedOrdersPage />} />
    <Route path="order/:id" element={<DeliveryOrderDetailsPage />} />
    <Route path="profile" element={<AgentProfile />} />
  </Route>
);
