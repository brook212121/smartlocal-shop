import { Route } from 'react-router-dom';
import {
  DashboardLayout,
} from '../components';
import {
  ProductsPage,
  OrdersPage,
  CustomerOrderDetailsPage,
  QuickOrdersPage,
  VendorProductsPage,
  VendorDashboardPage,
  VendorIndividualProductsPage,
  CustomerRequestsPage,
  OrdersReceivedPage,
  ProductDetailsPage,
  OrderDeliveryOptionPage,
  UserProfilePage,
  ChangePasswordPage,
  WalletPage,
} from '../pages';

export const dashboardRoutes = (
  <Route path="/dashboard" element={<DashboardLayout />}>
    <Route index element={<WalletPage />} />
    <Route path="products" element={<ProductsPage />} />
    <Route path="products/:id" element={<ProductDetailsPage />} />
    <Route path="orders" element={<OrdersPage />} />
    <Route path="orders/:id" element={<CustomerOrderDetailsPage />} />
    <Route path="quick-orders" element={<QuickOrdersPage />} />
    <Route path="vendor-dashboard" element={<VendorDashboardPage />} />
    <Route path="vendor-products" element={<VendorProductsPage />} />
    <Route path="vendor/:vendorId" element={<VendorIndividualProductsPage />} />
    <Route path="customer-requests" element={<CustomerRequestsPage />} />
    <Route path="orders-received" element={<OrdersReceivedPage />} />
    <Route path="wallet" element={<WalletPage />} />
    <Route path="profile" element={<UserProfilePage />} />
    <Route path="settings" element={<div className="p-6"><h1 className="text-2xl font-bold text-gray-900">Settings Page - Coming Soon</h1></div>} />
  </Route>
);
