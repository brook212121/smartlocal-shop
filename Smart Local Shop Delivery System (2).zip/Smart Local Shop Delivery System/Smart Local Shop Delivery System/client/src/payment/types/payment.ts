export interface PaymentMethod {
  id: string;
  name: string;
  type: 'BANK' | 'MPESA';
  icon: string;
  enabled: boolean;
  description?: string;
  isRecommended?: boolean;
}

export interface PaymentRequest {
  productId: string;
  quantity: number;
  totalPrice: number;
  subtotal: number;
  deliveryFee: number;
  requiresDelivery: boolean;
  orderId: string; // Add orderId for existing orders
  paymentMethod: PaymentMethod;
  customerInfo: {
    name: string;
    email: string;
    phone: string;
  };
}

export interface PaymentResponse {
  success: boolean;
  paymentId?: string;
  message: string;
  orderData?: {
    productId: string;
    quantity: number;
    totalPrice: number;
    paymentStatus: 'SUCCESS' | 'FAILED' | 'PENDING';
  };
  checkout_url?: string;
  tx_ref?: string;
}

export interface PaymentState {
  isLoading: boolean;
  paymentMethod: PaymentMethod | null;
  error: string | null;
}
