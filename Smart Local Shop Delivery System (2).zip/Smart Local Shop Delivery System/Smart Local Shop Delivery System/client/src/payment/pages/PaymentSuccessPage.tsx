import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate, useLocation } from 'react-router-dom';
import { CheckCircle, ArrowLeft, Package, CreditCard, User, Truck, MapPin, Phone } from 'lucide-react';
import Spinner from '../../components/ui/Spinner';
import { useToast } from '../../contexts/ToastContext';
import { deliveryService } from '../../services/deliveryService';

interface SuccessPageState {
  orderId: string;
  productName: string;
  quantity: number;
  totalPrice: number;
  paymentMethod: string;
  deliverySelected?: boolean;
  vendorLocation?: {
    latitude: number;
    longitude: number;
  };
  customerLocation?: {
    latitude: number;
    longitude: number;
  };
}

const PaymentSuccessPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { handleApiResponse } = useToast();

  const [orderData, setOrderData] = useState<SuccessPageState | null>(null);
  const [isAssigningDelivery, setIsAssigningDelivery] = useState(false);
  const [deliveryAssignment, setDeliveryAssignment] = useState<any>(null);

  useEffect(() => {
    // Parse URL parameters
    const params = new URLSearchParams(location.search);
    
    if (!params) {
      navigate('/dashboard/products');
      return;
    }

    const state: SuccessPageState = {
      orderId: params.get('orderId') || '',
      productName: params.get('productName') || 'Quick Order',
      quantity: parseInt(params.get('quantity') || '1'),
      totalPrice: parseFloat(params.get('totalPrice') || '0'),
      paymentMethod: params.get('paymentMethod') || 'Online Payment',
      deliverySelected: params.get('deliverySelected') === 'true',
      vendorLocation: params.get('vendorLocation') ? JSON.parse(params.get('vendorLocation')!) : undefined,
      customerLocation: params.get('customerLocation') ? JSON.parse(params.get('customerLocation')!) : undefined
    };

    setOrderData(state);
    
    // Show success notification
    handleApiResponse(`Order placed successfully! Order ID: ${state.orderId}`);
    
    // Assign delivery agent if delivery was selected
    if (state.deliverySelected && state.vendorLocation && state.customerLocation) {
      assignDeliveryAgent(state.orderId, state.vendorLocation, state.customerLocation);
    }
  }, [location.search, navigate, handleApiResponse]);

  const assignDeliveryAgent = async (
    orderId: string,
    vendorLocation: { latitude: number; longitude: number },
    customerLocation: { latitude: number; longitude: number }
  ) => {
    try {
      setIsAssigningDelivery(true);
      
      // Get available delivery agents first
      const availableAgents = await deliveryService.getAvailableDeliveryAgents();
      
      if (availableAgents.length > 0) {
        // Use the first available agent for now (in real implementation, you'd find nearest)
        const selectedAgent = availableAgents[0];
        
        // Assign delivery agent to order
        const assignment = await deliveryService.assignDeliveryAgent(
          orderId,
          selectedAgent._id,
          vendorLocation,
          customerLocation
        );
        
        setDeliveryAssignment(assignment);
        handleApiResponse(`Delivery agent assigned: ${selectedAgent.firstName} ${selectedAgent.lastName}`);
      } else {
        handleApiResponse('No delivery agents available at the moment');
      }
    } catch (error) {
      console.error('Error assigning delivery agent:', error);
      handleApiResponse('Failed to assign delivery agent');
    } finally {
      setIsAssigningDelivery(false);
    }
  };

  if (!orderData) {
    return (
      <div className="flex justify-center items-center h-64">
        <Spinner size="lg" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Success Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Payment Successful!</h1>
          <p className="text-lg text-gray-600">Your order has been placed successfully</p>
        </div>

        {/* Order Details Card */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Order Details</h2>
            <div className="text-sm text-gray-500">
              Order ID: <span className="font-mono font-medium">{orderData.orderId}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Product Information */}
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <Package className="h-6 w-6 text-green-600 mt-1" />
                <div>
                  <h3 className="font-medium text-gray-900">Product</h3>
                  <p className="text-gray-600">{orderData.productName}</p>
                  <p className="text-sm text-gray-500">Quantity: {orderData.quantity}</p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <CreditCard className="h-6 w-6 text-green-600 mt-1" />
                <div>
                  <h3 className="font-medium text-gray-900">Payment Method</h3>
                  <p className="text-gray-600">{orderData.paymentMethod}</p>
                  <p className="text-sm text-green-600">Payment Status: Successful</p>
                </div>
              </div>
            </div>

            {/* Order Summary */}
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <User className="h-6 w-6 text-green-600 mt-1" />
                <div>
                  <h3 className="font-medium text-gray-900">Customer</h3>
                  <p className="text-gray-600">Customer Name</p>
                  <p className="text-sm text-gray-500">customer@example.com</p>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-medium text-gray-900 mb-2">Order Summary</h3>
                <div className="space-y-1">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Subtotal</span>
                    <span className="font-medium">ETB {orderData.totalPrice}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Delivery Fee</span>
                    <span className="font-medium">ETB 0</span>
                  </div>
                  <div className="border-t pt-2 flex justify-between">
                    <span className="font-semibold text-gray-900">Total Paid</span>
                    <span className="font-bold text-green-600">ETB {orderData.totalPrice}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Delivery Assignment Information */}
        {orderData.deliverySelected && (
          <div className="bg-teal-50 border border-teal-200 rounded-lg p-6 mb-6">
            <h3 className="font-semibold text-teal-900 mb-4 flex items-center">
              <Truck className="h-5 w-5 mr-2" />
              Delivery Assignment
            </h3>
            
            {isAssigningDelivery ? (
              <div className="flex items-center text-teal-800">
                <Spinner size="sm" className="mr-2" />
                <span>Assigning delivery agent...</span>
              </div>
            ) : deliveryAssignment ? (
              <div className="space-y-3">
                <div className="flex items-center">
                  <User className="h-4 w-4 text-teal-600 mr-2" />
                  <span className="text-sm font-medium text-teal-700 w-24">Agent Name:</span>
                  <span className="text-sm text-teal-900">
                    {deliveryAssignment.deliveryAgentName}
                  </span>
                </div>
                <div className="flex items-center">
                  <Phone className="h-4 w-4 text-teal-600 mr-2" />
                  <span className="text-sm font-medium text-teal-700 w-24">Phone:</span>
                  <span className="text-sm text-teal-900">
                    {deliveryAssignment.deliveryAgentPhone}
                  </span>
                </div>
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 text-teal-600 mr-2" />
                  <span className="text-sm font-medium text-teal-700 w-24">Status:</span>
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                    deliveryAssignment.status === 'ASSIGNED' ? 'bg-blue-100 text-blue-800' :
                    deliveryAssignment.status === 'PICKED_UP' ? 'bg-purple-100 text-purple-800' :
                    deliveryAssignment.status === 'DELIVERED' ? 'bg-green-100 text-green-800' :
                    'bg-yellow-100 text-yellow-800'
                  }`}>
                    {deliveryAssignment.status}
                  </span>
                </div>
                <div className="text-xs text-teal-600 mt-2">
                  Assigned at: {new Date(deliveryAssignment.assignedAt).toLocaleString()}
                </div>
              </div>
            ) : (
              <div className="text-teal-800">
                <p className="text-sm">• Delivery agent will be assigned shortly</p>
                <p className="text-sm">• You will receive updates on delivery status</p>
                <p className="text-sm">• Contact support if you need assistance</p>
              </div>
            )}
          </div>
        )}

        {/* Next Steps */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
          <h3 className="font-semibold text-blue-900 mb-3">What happens next?</h3>
          <div className="space-y-2 text-sm text-blue-800">
            <p>• You will receive an order confirmation shortly</p>
            <p>• The vendor will prepare your order for delivery</p>
            <p>• You can track your order status in "My Orders"</p>
            <p>• Delivery details will be updated once assigned</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={() => navigate('/dashboard/orders')}
            className="flex items-center justify-center px-6 py-3 bg-green-600 text-white rounded-md hover:bg-green-700 font-medium"
          >
            <Package className="h-5 w-5 mr-2" />
            View My Orders
          </button>
          
          <button
            onClick={() => navigate('/dashboard/products')}
            className="flex items-center justify-center px-6 py-3 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 font-medium"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back to Shopping
          </button>
        </div>
      </div>
    </div>
  );
};

export default PaymentSuccessPage;
