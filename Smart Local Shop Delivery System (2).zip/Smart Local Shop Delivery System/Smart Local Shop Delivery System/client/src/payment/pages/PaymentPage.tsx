import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { CreditCard, Smartphone, Wallet, ArrowLeft, Check } from 'lucide-react';
import Spinner from '../../components/ui/Spinner';
import { useToast } from '../../contexts/ToastContext';
import PaymentMethodCard from '../components/PaymentMethodCard';
import { paymentService } from '../services/paymentService';
import { PaymentMethod, PaymentRequest } from '../types/payment';
import api from '../../services/api';
import { safeFetch, isUserOffline } from '../../utils/errorHandler';

const PaymentPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { handleApiError } = useToast();

  // State for inline messages
  const [inlineMessage, setInlineMessage] = useState<{
    type: 'success' | 'error' | 'info';
    text: string;
  } | null>(null);

  // Get orderId from URL parameters
  const orderId = new URLSearchParams(location.search).get('orderId');
  
  // Get additional parameters from QuickOrders modal
  const quantity = new URLSearchParams(location.search).get('quantity');
  const unitPrice = new URLSearchParams(location.search).get('unitPrice');
  const deliveryFee = new URLSearchParams(location.search).get('deliveryFee');
  const totalPrice = new URLSearchParams(location.search).get('totalPrice');
  
  // State for order data
  const [orderData, setOrderData] = useState<{
    productId: string;
    productName: string;
    quantity: number;
    unitPrice: number;
    subtotal: number;
    deliveryFee: number;
    requiresDelivery: boolean;
    totalPrice: number;
  } | null>(null);

  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [isLoadingOrder, setIsLoadingOrder] = useState(true);

  // Fetch order details when orderId is available
  useEffect(() => {
    if (!orderId) {
      navigate('/dashboard/products');
      return;
    }

    const fetchOrderDetails = async () => {
      try {
        // Check offline status first
        if (isUserOffline()) {
          handleApiError(new Error("NETWORK_ERROR"));
          setIsLoadingOrder(false);
          return;
        }
        
        const response = await api.get(`/orders/${orderId}`);
        
        if (response.data.success) {
          const order = response.data.data.order;
          
          // Use URL parameters if available (from QuickOrders modal), otherwise use order data
          const finalQuantity = quantity ? parseInt(quantity) : (order.items[0]?.quantity || 1);
          const finalUnitPrice = unitPrice ? parseFloat(unitPrice) : (order.items[0]?.price || 0);
          const finalDeliveryFee = deliveryFee ? parseFloat(deliveryFee) : (order.pricing?.deliveryFee || 0);
          const finalTotalPrice = totalPrice ? parseFloat(totalPrice) : (order.pricing?.total || 0);
          
          setOrderData({
            productId: order.items[0]?.product?._id || '',
            productName: order.items[0]?.product?.name || '',
            quantity: finalQuantity,
            unitPrice: finalUnitPrice,
            subtotal: finalUnitPrice * finalQuantity,
            deliveryFee: finalDeliveryFee,
            requiresDelivery: finalDeliveryFee > 0,
            totalPrice: finalTotalPrice
          });
        } else {
          handleApiError(new Error('Unable to load order details'));
        }
      } catch (error) {
        handleApiError(error);
        // Don't navigate away immediately - let user see the error
      } finally {
        setIsLoadingOrder(false);
      }
    };

    fetchOrderDetails();
  }, [orderId]);

  useEffect(() => {
    const methods = paymentService.getPaymentMethods();
    setPaymentMethods(methods);
    
    // Auto-select Chapa payment (recommended method)
    const chapaMethod = methods.find(m => m.id === 'chapa');
    if (chapaMethod) {
      setSelectedMethod(chapaMethod);
    }
  }, [orderData]);

  const handlePayment = async () => {
    try {
      setIsProcessing(true);

      // Check offline status first
      if (isUserOffline()) {
        handleApiError(new Error("NETWORK_ERROR"));
        setIsProcessing(false);
        return;
      }

      if (!orderData || !selectedMethod || !orderId) {
        setInlineMessage({
          type: 'error',
          text: 'Payment information incomplete'
        });
        return;
      }

      const paymentRequest: PaymentRequest = {
        productId: orderData.productId,
        productName: orderData.productName,
        quantity: orderData.quantity,
        totalPrice: orderData.totalPrice,
        subtotal: orderData.subtotal,
        deliveryFee: orderData.deliveryFee,
        requiresDelivery: orderData.requiresDelivery,
        orderId: orderId!, // Include the existing orderId
        paymentMethod: selectedMethod,
        customerInfo: {
          name: 'Customer Name', // TODO: Get from user context
          email: 'customer@example.com', // TODO: Get from user context
          phone: '+251912345678' // TODO: Get from user context
        }
      };

      const response = await paymentService.processPayment(paymentRequest);

      if (response.success) {
        setInlineMessage({
          type: 'info',
          text: 'Redirecting to payment gateway...'
        });
        
        // Clear message after 3 seconds
        setTimeout(() => {
          setInlineMessage(null);
        }, 3000);
        
        // Redirect to Chapa checkout page
        if (response.checkout_url) {
          window.location.href = response.checkout_url;
        } else {
          setInlineMessage({
            type: 'error',
            text: 'Payment service unavailable. Please try again.'
          });
        }
      } else {
        setInlineMessage({
          type: 'error',
          text: 'Payment processing failed. Please try again.'
        });
      }
    } catch (error) {
      handleApiError(error);
    } finally {
      setIsProcessing(false);
    }
  };

  if (isLoadingOrder) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-center">
          <Spinner size="lg" className="mx-auto mb-4" />
          <p className="text-gray-500">Loading order details...</p>
        </div>
      </div>
    );
  }

  if (!orderData) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-center">
          <p className="text-gray-500 mb-4">No order data found</p>
          <div className="space-x-4">
            <button
              onClick={() => window.location.reload()}
              className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 mr-2"
            >
              Retry
            </button>
            <button
              onClick={() => navigate('/dashboard/products')}
              className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700"
            >
              Browse Products
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center mb-8">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center text-gray-600 hover:text-gray-900 mr-4"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            
          </button>
          <h1 className="text-2xl font-bold text-gray-900">Complete Your Order</h1>
        </div>

        {/* Inline Message */}
        {inlineMessage && (
          <div className={`mb-6 p-4 rounded-md ${
            inlineMessage.type === 'success' ? 'bg-green-100 text-green-800 border-green-200' :
            inlineMessage.type === 'error' ? 'bg-red-100 text-red-800 border-red-200' :
            'bg-blue-100 text-blue-800 border-blue-200'
          }`}>
            <div className="flex items-center">
              {inlineMessage.type === 'success' && (
                <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 0 8 8 0 0116 0 0 8 8 0 01-1.414 1.414L10 16.586l-1.414 1.414z" clipRule="evenodd" />
                </svg>
              )}
              {inlineMessage.type === 'error' && (
                <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 0 8 8 0 0116 0 0 8 8 0 01-1.414 1.414L10 16.586l-1.414 1.414z" clipRule="evenodd" />
                </svg>
              )}
              {inlineMessage.type === 'info' && (
                <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0 0 8 8 0 01-1.414 1.414L10 16.586l-1.414 1.414z" clipRule="evenodd" />
                </svg>
              )}
              <span className="font-medium">{inlineMessage.text}</span>
            </div>
          </div>
        )}

        <div className="max-w-2xl mx-auto">
          {/* Payment Method */}
          <div className="space-y-6">
            {/* Payment Methods */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="space-y-3">
                {paymentMethods.map((method) => (
                  <PaymentMethodCard
                    key={method.id}
                    method={method}
                    isSelected={selectedMethod?.id === method.id}
                    onSelect={setSelectedMethod}
                    disabled={!method.enabled}
                  />
                ))}
              </div>
            </div>

            {/* Payment Button */}
            <button
              onClick={handlePayment}
              disabled={!selectedMethod || isProcessing}
              className="w-full text-white py-3 px-4 rounded-md disabled:opacity-50 disabled:cursor-not-allowed font-medium text-lg flex items-center justify-center transition-colors"
              style={{ backgroundColor: '#0D1B34' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#1A2B4A';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = '#0D1B34';
              }}
            >
              {isProcessing ? (
                <>
                  <Spinner size="sm" className="mr-2" />
                  Processing Payment...
                </>
              ) : (
                <>
                  <img 
                    src="/chapa-logo.jpg" 
                    alt="Chapa Pay"
                    className="h-5 w-5 mr-2"
                  />
                  Pay {orderData.totalPrice.toFixed(2)} ETB
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentPage;
