import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { CheckCircle, XCircle, Clock, RefreshCw } from 'lucide-react';
import Spinner from '../../components/ui/Spinner';
import { getApiUrl } from '../../utils/apiConfig';
import { safeFetch, isUserOffline, getUserFriendlyErrorMessage } from '../../utils/errorHandler';
import { useToast } from '../../contexts/ToastContext';

const PaymentReturnPage: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { handleApiError } = useToast();
  const [paymentStatus, setPaymentStatus] = useState<'success' | 'failed' | 'processing'>('processing');
  const [paymentDetails, setPaymentDetails] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [verificationAttempts, setVerificationAttempts] = useState(0);

  useEffect(() => {
    const urlParams = new URLSearchParams(location.search);
    const tx_ref = urlParams.get('tx_ref');
    const error = urlParams.get('error');

    if (error) {
      setPaymentStatus('failed');
      setPaymentDetails({ error: 'Payment processing failed' });
      return;
    }

    if (tx_ref) {
      verifyPaymentStatus(tx_ref);
    } else {
      setPaymentStatus('failed');
      setPaymentDetails({ error: 'No payment information found' });
    }
  }, [location.search]);

  const verifyPaymentStatus = async (tx_ref: string) => {
    try {
      // Check offline status first
      if (isUserOffline()) {
        setPaymentStatus('failed');
        setPaymentDetails({ 
          tx_ref,
          error: 'Unable to verify payment. Please check your internet connection.'
        });
        setLoading(false);
        return;
      }
      
      // Call the test verification endpoint to verify with Chapa API
      const response = await safeFetch(getApiUrl(`/api/payment/test-verification?tx_ref=${tx_ref}`), {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      const data = await response.json();

      if (data.status === 'success') {
        setPaymentStatus('success');
        setPaymentDetails({
          tx_ref,
          payment_status: data.data.payment_status,
          order_status: data.data.order_status,
          order_number: data.data.order_number,
          order_id: data.data.order_id // Add MongoDB order ID
        });
      } else {
        setPaymentStatus('failed');
        setPaymentDetails({ 
          tx_ref,
          error: 'Payment verification failed',
          verification_data: data.data
        });
      }
    } catch (error) {
      // Use user-friendly error message
      const friendlyMessage = getUserFriendlyErrorMessage(error);
      
      // Retry verification if it failed (but not for network errors)
      if (verificationAttempts < 3 && !friendlyMessage.includes('Network error')) {
        setVerificationAttempts(prev => prev + 1);
        setTimeout(() => verifyPaymentStatus(tx_ref), 2000); // Retry after 2 seconds
      } else {
        setPaymentStatus('failed');
        setPaymentDetails({ 
          tx_ref,
          error: friendlyMessage
        });
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRetryPayment = () => {
    navigate('/payment');
  };

  const handleRetryVerification = () => {
    const urlParams = new URLSearchParams(location.search);
    const tx_ref = urlParams.get('tx_ref');
    if (tx_ref) {
      setLoading(true);
      setVerificationAttempts(0);
      verifyPaymentStatus(tx_ref);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <Spinner size="lg" />
          </div>
          <h2 className="text-xl font-semibold text-gray-900">Verifying your payment...</h2>
          {verificationAttempts > 0 && (
            <p className="text-xs text-gray-400">Retry attempt {verificationAttempts}/3</p>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
        <div className="text-center">
          {paymentStatus === 'success' ? (
            <>
              <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
              <h1 className="text-2xl font-bold text-gray-900 mb-2">Payment Successful!</h1>
              <p className="text-gray-600 mb-6">
                Your payment has been processed successfully. Your order has been confirmed.
              </p>
              
              {paymentDetails?.tx_ref && (
                <div className="bg-gray-50 rounded-lg p-4 mb-6">
                  <p className="text-sm text-gray-600">Transaction Reference</p>
                  <p className="font-mono text-sm font-semibold">{paymentDetails.tx_ref}</p>
                  {paymentDetails.order_number && (
                    <>
                      <p className="text-sm text-gray-600 mt-2">Order Number</p>
                      <p className="font-mono text-sm font-semibold">{paymentDetails.order_number}</p>
                    </>
                  )}
                </div>
              )}

              {paymentDetails.order_id && (
              <div className="space-y-3">
                <button
                  onClick={() => navigate(`/dashboard/orders/${paymentDetails.order_id}`)}
                  className="w-full bg-green-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-green-700 transition-colors"
                >
                  View Order 
                </button>
              </div>
            )}
            </>
          ) : (
            <>
              <XCircle className="h-16 w-16 text-red-600 mx-auto mb-4" />
              <h1 className="text-2xl font-bold text-gray-900 mb-2">Payment Verification Failed</h1>
              <p className="text-gray-600 mb-6">
                {paymentDetails?.error || 'We could not verify your payment status. Please try again.'}
              </p>
              
              {paymentDetails?.tx_ref && (
                <div className="bg-gray-50 rounded-lg p-4 mb-6">
                  <p className="text-sm text-gray-600">Transaction Reference</p>
                  <p className="font-mono text-sm font-semibold">{paymentDetails.tx_ref}</p>
                </div>
              )}

              <div className="space-y-3">
                <button
                  onClick={handleRetryVerification}
                  className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                >
                  Retry Verification
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default PaymentReturnPage;
