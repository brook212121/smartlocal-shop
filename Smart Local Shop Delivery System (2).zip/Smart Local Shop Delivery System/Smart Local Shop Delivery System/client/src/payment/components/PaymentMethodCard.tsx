import React from 'react';
import { PaymentMethod } from '../types/payment';

interface PaymentMethodCardProps {
  method: PaymentMethod;
  isSelected: boolean;
  onSelect: (method: PaymentMethod) => void;
  disabled?: boolean;
}

const PaymentMethodCard: React.FC<PaymentMethodCardProps> = ({
  method,
  isSelected,
  onSelect,
  disabled = false
}) => {
  const isEmoji = (icon: string) => {
    return icon.length <= 2 && /[\u{1F600}-\u{1F64F}]|[\u{1F300}-\u{1F5FF}]|[\u{1F680}-\u{1F6FF}]|[\u{1F1E0}-\u{1F1FF}]|[\u{2600}-\u{26FF}]|[\u{2700}-\u{27BF}]/u.test(icon);
  };

  return (
    <div
      className={`
        relative border-2 rounded-lg p-4 cursor-pointer transition-all
        ${isSelected 
          ? 'border-green-600 bg-green-50' 
          : 'border-gray-200 hover:border-gray-300'
        }
        ${disabled 
          ? 'opacity-50 cursor-not-allowed' 
          : 'hover:shadow-md'
        }
      `}
      onClick={() => !disabled && onSelect(method)}
    >
      <div className="flex items-center space-x-3">
        <div className="flex-shrink-0">
          {isEmoji(method.icon) ? (
            <div className="text-2xl">{method.icon}</div>
          ) : (
            <img 
              src={method.icon} 
              alt={method.name}
              className="w-10 h-10 object-contain"
              onError={(e) => {
                // Fallback to emoji if image fails to load
                const target = e.target as HTMLImageElement;
                target.style.display = 'none';
                const emojiDiv = document.createElement('div');
                emojiDiv.className = 'text-2xl';
                emojiDiv.textContent = method.name === 'Tele Birr' ? '💰' : '💳';
                target.parentNode?.replaceChild(emojiDiv, target);
              }}
            />
          )}
        </div>
        <div className="flex-1">
          <h3 className="font-medium text-gray-900">{method.name}</h3>
          <p className="text-sm text-gray-500">
            {method.enabled ? 'Available' : 'Currently unavailable'}
          </p>
        </div>
        {isSelected && (
          <div className="w-5 h-5 rounded-full bg-green-600 flex items-center justify-center">
            <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
          </div>
        )}
      </div>
    </div>
  );
};

export default PaymentMethodCard;
