import React from 'react';
import { Truck, Package } from 'lucide-react';

interface DeliveryOptionProps {
  requiresDelivery: boolean;
  onDeliveryChange: (requiresDelivery: boolean) => void;
  subtotal: number;
}

const DeliveryOption: React.FC<DeliveryOptionProps> = ({
  requiresDelivery,
  onDeliveryChange,
  subtotal
}) => {
  const deliveryFee = requiresDelivery ? subtotal * 0.02 : 0;

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <div className="flex items-center mb-4">
        <Truck className="h-5 w-5 text-green-600 mr-2" />
        <h3 className="text-lg font-semibold text-gray-900">Delivery Option</h3>
      </div>
      
      <div className="space-y-4">
        <div>
          <p className="text-gray-700 font-medium mb-3">Do you want a delivery person?</p>
          
          <div className="space-y-3">
            <label className="flex items-center p-4 border-2 rounded-lg cursor-pointer transition-colors hover:bg-gray-50">
              <input
                type="radio"
                name="delivery"
                checked={requiresDelivery}
                onChange={() => onDeliveryChange(true)}
                className="sr-only"
              />
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center">
                  <div className="w-4 h-4 border-2 border-green-600 rounded-full mr-3 flex items-center justify-center">
                    {requiresDelivery && (
                      <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                    )}
                  </div>
                  <span className="font-medium text-gray-900">YES</span>
                </div>
                <div className="text-right">
                  <span className="text-sm text-gray-500">Add 2% delivery fee</span>
                  <div className="font-semibold text-green-600">
                    +{deliveryFee.toFixed(2)} ETB
                  </div>
                </div>
              </div>
            </label>

            <label className="flex items-center p-4 border-2 rounded-lg cursor-pointer transition-colors hover:bg-gray-50">
              <input
                type="radio"
                name="delivery"
                checked={!requiresDelivery}
                onChange={() => onDeliveryChange(false)}
                className="sr-only"
              />
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center">
                  <div className="w-4 h-4 border-2 border-green-600 rounded-full mr-3 flex items-center justify-center">
                    {!requiresDelivery && (
                      <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                    )}
                  </div>
                  <span className="font-medium text-gray-900">NO</span>
                </div>
                <div className="text-right">
                  <span className="text-sm text-gray-500">Continue with original price</span>
                  <div className="font-semibold text-gray-600">
                    No additional fee
                  </div>
                </div>
              </div>
            </label>
          </div>
        </div>

        {/* Delivery Fee Summary */}
        {requiresDelivery && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-green-800">
                <Package className="h-4 w-4 inline mr-1" />
                Delivery Fee (2%):
              </span>
              <span className="font-semibold text-green-900">
                {deliveryFee.toFixed(2)} ETB
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DeliveryOption;
