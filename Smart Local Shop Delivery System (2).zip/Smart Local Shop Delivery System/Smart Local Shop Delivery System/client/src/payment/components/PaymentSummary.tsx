import React from 'react';
import { Package, Truck, CreditCard } from 'lucide-react';

interface PaymentSummaryProps {
  productName: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  deliveryFee?: number;
}

const PaymentSummary: React.FC<PaymentSummaryProps> = ({
  productName,
  quantity,
  unitPrice,
  totalPrice,
  deliveryFee = 0
}) => {
  const currency = 'ETB';

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Order Summary</h3>
      
      {/* Product Details */}
      <div className="space-y-4">
        <div className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg">
          <div className="flex-shrink-0">
            <Package className="h-12 w-12 text-green-600" />
          </div>
          <div className="flex-1">
            <h4 className="font-medium text-gray-900">{productName}</h4>
            <div className="flex items-center space-x-4 mt-2">
              <span className="text-sm text-gray-500">Quantity: {quantity}</span>
              <span className="text-sm text-gray-500">Unit Price: {currency} {unitPrice}</span>
            </div>
          </div>
        </div>

        {/* Price Breakdown */}
        <div className="border-t border-gray-200 pt-4 space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-gray-600">Subtotal</span>
            <span className="font-medium">{currency} {unitPrice * quantity}</span>
          </div>
          
          {deliveryFee > 0 && (
            <div className="flex justify-between items-center">
              <span className="text-gray-600 flex items-center">
                <Truck className="h-4 w-4 mr-1" />
                Delivery Fee
              </span>
              <span className="font-medium">{currency} {deliveryFee}</span>
            </div>
          )}

          <div className="flex justify-between items-center">
            <span className="text-gray-600 flex items-center">
              <CreditCard className="h-4 w-4 mr-1" />
              Processing Fee
            </span>
            <span className="font-medium">{currency} 0</span>
          </div>
        </div>

        {/* Total */}
        <div className="border-t border-gray-200 pt-4">
          <div className="flex justify-between items-center">
            <span className="text-lg font-semibold text-gray-900">Total Amount</span>
            <span className="text-2xl font-bold text-green-600">
              {currency} {totalPrice}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentSummary;
