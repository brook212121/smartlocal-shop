import api from '../../services/api';
import { PaymentRequest, PaymentResponse } from '../types/payment';
import { safeFetch, isUserOffline, getUserFriendlyErrorMessage } from '../../utils/errorHandler';

export const paymentService = {
  // Process payment with Chapa integration
  async processPayment(paymentRequest: PaymentRequest): Promise<PaymentResponse> {
    try {
      // Check offline status first
      if (isUserOffline()) {
        return {
          success: false,
          message: 'Unable to process payment. Please check your internet connection.'
        };
      }
      
      // Initialize Chapa payment directly (order already exists)
      const chapaResponse = await this.initializeChapaPayment(paymentRequest.orderId);
      
      if (chapaResponse.success) {
        return {
          success: true,
          paymentId: chapaResponse.payment_id,
          message: 'Payment initialized successfully',
          orderData: {
            productId: paymentRequest.productId,
            quantity: paymentRequest.quantity,
            totalPrice: paymentRequest.totalPrice,
            paymentStatus: 'PENDING'
          },
          checkout_url: chapaResponse.checkout_url,
          tx_ref: chapaResponse.tx_ref
        };
      } else {
        return {
          success: false,
          message: 'Payment service unavailable. Please try again.'
        };
      }
    } catch (error) {
      // Use global error handler for user-friendly messages
      const friendlyMessage = getUserFriendlyErrorMessage(error);
      return {
        success: false,
        message: friendlyMessage
      };
    }
  },

  // Create order before payment
  async createOrderBeforePayment(paymentRequest: PaymentRequest) {
    try {
      // Check offline status first
      if (isUserOffline()) {
        return {
          success: false,
          message: 'Unable to create order. Please check your internet connection.'
        };
      }
      
      const response = await api.post('/orders', {
        productId: paymentRequest.productId,
        quantity: paymentRequest.quantity,
        requiresDelivery: paymentRequest.requiresDelivery,
        deliveryFee: paymentRequest.deliveryFee,
        subtotal: paymentRequest.subtotal,
        totalAmount: paymentRequest.totalPrice
        // Note: paymentStatus is not sent here - payment happens after order creation
      });

      // Validate response structure
      if (!response.data || !response.data.data || !response.data.data.order) {
        return {
          success: false,
          message: 'Unable to create order'
        };
      }

      const order = response.data.data.order;

      return {
        success: true,
        orderId: order._id,
        message: 'Order created successfully'
      };
    } catch (error: any) {
      // Use global error handler for user-friendly messages
      const friendlyMessage = getUserFriendlyErrorMessage(error);
      return {
        success: false,
        message: friendlyMessage
      };
    }
  },

  // Initialize Chapa payment
  async initializeChapaPayment(orderId: string) {
    try {
      // Check offline status first
      if (isUserOffline()) {
        return {
          success: false,
          message: 'Unable to initialize payment. Please check your internet connection.'
        };
      }
      
      const response = await api.post('/payments/initialize', {
        orderId: orderId
      });

      return {
        success: true,
        checkout_url: response.data.data.checkout_url,
        tx_ref: response.data.data.tx_ref,
        payment_id: response.data.data.payment_id,
        message: 'Redirecting to payment gateway...'
      };
    } catch (error: any) {
      // Use global error handler for user-friendly messages
      const friendlyMessage = getUserFriendlyErrorMessage(error);
      return {
        success: false,
        message: friendlyMessage
      };
    }
  },

  // Verify payment status
  async verifyPayment(tx_ref: string) {
    try {
      // Check offline status first
      if (isUserOffline()) {
        return {
          success: false,
          message: 'Unable to verify payment. Please check your internet connection.'
        };
      }
      
      const response = await api.post('/payments/verify', {
        tx_ref: tx_ref
      });

      return {
        success: true,
        data: response.data.data,
        message: 'Payment verified successfully'
      };
    } catch (error: any) {
      // Use global error handler for user-friendly messages
      const friendlyMessage = getUserFriendlyErrorMessage(error);
      return {
        success: false,
        message: friendlyMessage
      };
    }
  },

  // Get payment status
  async getPaymentStatus(orderId: string) {
    try {
      // Check offline status first
      if (isUserOffline()) {
        return {
          success: false,
          message: 'Unable to get payment status. Please check your internet connection.'
        };
      }
      
      const response = await api.get(`/payments/status/${orderId}`);

      return {
        success: true,
        data: response.data.data,
        message: 'Payment status retrieved successfully'
      };
    } catch (error: any) {
      // Use global error handler for user-friendly messages
      const friendlyMessage = getUserFriendlyErrorMessage(error);
      return {
        success: false,
        message: friendlyMessage
      };
    }
  },

  // Get available payment methods (Chapa only)
  getPaymentMethods() {
    return [
      {
        id: 'chapa',
        name: 'Chapa Pay',
        type: 'BANK' as const,
        icon: '/chapa-logo.jpg', // Chapa logo (JPG version)
        enabled: true,
        description: 'Secure payment via Chapa',
        isRecommended: true
      }
    ];
  }
};
