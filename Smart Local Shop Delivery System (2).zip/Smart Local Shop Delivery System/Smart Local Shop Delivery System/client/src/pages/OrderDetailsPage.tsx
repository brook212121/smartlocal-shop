import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Package, 
  Clock, 
  CheckCircle, 
  XCircle, 
  Truck, 
  User, 
  MapPin, 
  Phone
} from 'lucide-react';
import Spinner from '../components/ui/Spinner';
import { useToast } from '../contexts/ToastContext';
import api from '../services/api';
import { getImageUrl } from '../utils/imageUtils';

interface Order {
  _id: string;
  orderNumber: string;
  createdAt: string;
  status: 'PENDING' | 'CONFIRMED' | 'PREPARING' | 'READY_FOR_PICKUP' | 'OUT_FOR_DELIVERY' | 'DELIVERED' | 'CANCELLED';
  pricing: {
    total: number;
    currency: string;
  };
  items: OrderItem[];
  delivery: {
    address: {
      street: string;
      city: string;
      county: string;
    };
    deliveryAgent?: {
      _id: string;
      firstName: string;
      lastName: string;
      email: string;
      phone?: string;
    };
  };
  payment?: {
    status: 'PENDING' | 'PAID' | 'FAILED' | 'REFUNDED' | 'PARTIALLY_REFUNDED';
    transactionId?: string;
    paidAt?: Date;
  };
  vendor?: {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone?: string;
  };
}

interface OrderItem {
  product: {
    _id: string;
    name: string;
    images: string[];
    description?: string;
  };
  quantity: number;
  price: number;
}

const OrderDetailsPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [order, setOrder] = useState<Order | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [userLocation, setUserLocation] = useState<string>('');
  const [addressLoading, setAddressLoading] = useState(false);
  const { handleApiError } = useToast();

  useEffect(() => {
    if (id) {
      fetchOrder(id);
    }
  }, [id]);

  const fetchOrder = async (orderId: string) => {
    try {
      setIsLoading(true);
      const response = await api.get(`/orders/${orderId}`);
      setOrder(response.data.data.order);
    } catch (error) {
      console.error('Error fetching order:', error);
      handleApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Google Maps reverse geocoding for address - using current user location
  useEffect(() => {
    const fetchUserLocation = async () => {
      setAddressLoading(true);
      try {
        console.log('🔍 OrderDetailsPage: Getting current user location...');
        
        // Get current user location
        navigator.geolocation.getCurrentPosition(
          async (position) => {
            const { latitude, longitude } = position.coords;
            console.log('🔍 OrderDetailsPage: Got user coordinates:', latitude, longitude);
            
            // Reverse geocode to get address
            const response = await fetch(
              `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${import.meta.env.VITE_GOOGLE_MAPS_API_KEY}`
            );
            
            const data = await response.json();
            
            if (data.status === 'OK' && data.results && data.results.length > 0) {
              const formattedAddress = data.results[0].formatted_address;
              console.log('🔍 OrderDetailsPage: Address fetched successfully:', formattedAddress);
              setUserLocation(formattedAddress);
            } else {
              console.warn('🔍 OrderDetailsPage: Geocoding failed:', data);
              setUserLocation('Address unavailable');
            }
          },
          (error) => {
            console.error('🔍 OrderDetailsPage: Geolocation error:', error);
            setUserLocation('Location unavailable');
          }
        );
      } catch (error) {
        console.error('🔍 OrderDetailsPage: Error fetching location:', error);
        setUserLocation('Location unavailable');
      } finally {
        setAddressLoading(false);
      }
    };

    fetchUserLocation();
  }, []); // Run once on component mount

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'PENDING':
        return <Clock className="h-5 w-5 text-yellow-500" />;
      case 'CONFIRMED':
        return <CheckCircle className="h-5 w-5 text-blue-500" />;
      case 'PREPARING':
        return <Package className="h-5 w-5 text-orange-500" />;
      case 'READY_FOR_PICKUP':
        return <Package className="h-5 w-5 text-purple-500" />;
      case 'OUT_FOR_DELIVERY':
        return <Truck className="h-5 w-5 text-indigo-500" />;
      case 'DELIVERED':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'CANCELLED':
        return <XCircle className="h-5 w-5 text-red-500" />;
      default:
        return <Clock className="h-5 w-5 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PENDING':
        return 'bg-yellow-100 text-yellow-800';
      case 'CONFIRMED':
        return 'bg-blue-100 text-blue-800';
      case 'PREPARING':
        return 'bg-orange-100 text-orange-800';
      case 'READY_FOR_PICKUP':
        return 'bg-purple-100 text-purple-800';
      case 'OUT_FOR_DELIVERY':
        return 'bg-indigo-100 text-indigo-800';
      case 'DELIVERED':
        return 'bg-green-100 text-green-800';
      case 'CANCELLED':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Spinner size="lg" />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-center">
          <Package className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Order not found</h3>
          <p className="text-gray-500 mb-4">The order you're looking for doesn't exist.</p>
          <button
            onClick={() => navigate('/dashboard/orders')}
            className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700"
          >
            Back to Orders
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Product Images */}
          <div className="space-y-4">
            {/* Main Product Image */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden relative">
              <img
                src={getImageUrl(order.items[0]?.product?.images?.[0])}
                alt={order.items[0]?.product?.name || 'Product'}
                className="w-full h-96 object-cover"
              />
              {/* Status Badge - Top Right on Mobile */}
              <div className="absolute top-4 right-4 sm:hidden">
                <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                  {getStatusIcon(order.status)}
                  <span className="ml-1 capitalize">{order.status.toLowerCase()}</span>
                </span>
              </div>
            </div>
            
            {/* Thumbnail Gallery */}
            {order.items.length > 1 && (
              <div className="grid grid-cols-4 gap-2">
                {order.items.map((item, index) => (
                  <button
                    key={index}
                    className="relative overflow-hidden rounded-lg border-2 border-gray-200 transition-colors"
                  >
                    <img
                      src={getImageUrl(item.product?.images?.[0])}
                      alt={item.product?.name || 'Product'}
                      className="w-full h-20 object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Order Information */}
          <div className="space-y-6">
            {/* Order Header */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900 mb-2">Order Details</h1>
                  
                  <p className="text-sm text-gray-500 mt-2">
                    Placed on {formatDate(order.createdAt)}
                  </p>
                </div>
              </div>
            </div>

            {/* Product Information */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Product Information</h3>
              <div className="space-y-4">
                {order.items.map((item, index) => (
                  <div key={index} className="border-b border-gray-200 pb-4 last:border-b-0">
                    <h4 className="font-medium text-gray-900 text-lg">{item.product?.name}</h4>
                    <p className="text-gray-600 mt-1">{item.product?.description || 'No description available'}</p>
                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-center space-x-4">
                        <span className="text-sm text-gray-500">Quantity: {item.quantity}</span>
                        <span className="text-sm text-gray-500">Unit Price: ETB {item.price}</span>
                      </div>
                      <div className="text-right">
                        <div className="font-medium text-green-600">
                          ETB {item.price * item.quantity}
                        </div>
                        <div className="text-xs text-gray-500">Item Total</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Order Summary */}
              <div className="border-t border-gray-200 mt-6 pt-4">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-semibold text-gray-900">Total Amount:</span>
                  <span className="text-2xl font-bold text-green-600">
                    ETB {order.pricing.total}
                  </span>
                </div>
              </div>
            </div>

            {/* Vendor Information */}
            {order.vendor && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Vendor Information</h3>
                <div className="space-y-3">
                  <div className="flex items-center">
                    <User className="h-5 w-5 text-gray-400 mr-3" />
                    <div>
                      <div className="font-medium text-gray-900">
                        {order.vendor.firstName} {order.vendor.lastName}
                      </div>
                      <div className="text-sm text-gray-500">{order.vendor.email}</div>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Phone className="h-5 w-5 text-gray-400 mr-3" />
                    <span className="text-gray-900">
                      {order.vendor.phone || 'No phone available'}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Delivery Agent Information */}
            {order.delivery?.deliveryAgent && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  {order.delivery.deliveryAgent._id === order.vendor?._id 
                    ? 'Vendor Delivery Service' 
                    : 'Delivery Agent Information'
                  }
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center">
                    <Truck className="h-5 w-5 text-gray-400 mr-3" />
                    <div>
                      <div className="font-medium text-gray-900">
                        {order.delivery.deliveryAgent.firstName} {order.delivery.deliveryAgent.lastName}
                      </div>
                      <div className="text-sm text-gray-500">{order.delivery.deliveryAgent.email}</div>
                      {order.delivery.deliveryAgent._id === order.vendor?._id && (
                        <div className="text-xs text-blue-600 mt-1">Vendor handling delivery</div>
                      )}
                    </div>
                  </div>
                  {order.delivery.deliveryAgent.phone && (
                    <div className="flex items-center">
                      <Phone className="h-5 w-5 text-gray-400 mr-3" />
                      <span className="text-gray-900">{order.delivery.deliveryAgent.phone}</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Delivery Information */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Delivery Information</h3>
              <div className="space-y-3">
                <div className="flex items-start">
                  <MapPin className="h-5 w-5 text-gray-400 mr-3 mt-1" />
                  <div>
                    <div className="font-medium text-gray-900">Delivery Address</div>
                    <p className="text-sm text-gray-600">
                      {addressLoading ? (
                        <span className="flex items-center">
                          <Spinner size="sm" />
                          <span className="ml-2">Getting address...</span>
                        </span>
                      ) : (
                        (() => {
                          // Always prioritize Google Maps result if available
                          if (userLocation) {
                            console.log('🔍 OrderDetailsPage: Using pure Google Maps result');
                            return userLocation;
                          }
                          
                          // Fallback to order delivery address
                          if (order.delivery?.address) {
                            const fallbackParts = [];
                            if (order.delivery.address.street) fallbackParts.push(order.delivery.address.street);
                            if (order.delivery.address.city) fallbackParts.push(order.delivery.address.city);
                            if (order.delivery.address.county) fallbackParts.push(order.delivery.address.county);
                            return fallbackParts.join(', ');
                          }
                          
                          return 'Address not available';
                        })()
                      )}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Order Actions */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Order Actions</h3>
              <div className="space-y-3">
                {order.status === 'DELIVERED' && (
                  <button className="w-full flex items-center justify-center px-4 py-3 bg-green-600 text-white rounded-md hover:bg-green-700">
                    <CheckCircle className="h-5 w-5 mr-2" />
                    Order Completed
                  </button>
                )}
                
                {/* Back to Orders / Finish Payment Button */}
                <button 
                  onClick={() => {
                    if (order.payment?.status === 'PAID') {
                      navigate('/dashboard/orders');
                    } else {
                      // Navigate to payment flow for pending orders
                      navigate(`/payment?orderId=${order._id}`);
                    }
                  }}
                  className="w-full flex items-center justify-center px-4 py-3 bg-green-600 text-white rounded-md hover:bg-green-700"
                >
                  <ArrowLeft className="h-5 w-5 mr-2" />
                  {order.payment?.status === 'PAID' ? 'Back to Orders' : 'Finish Payment'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderDetailsPage;
