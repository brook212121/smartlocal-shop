import React, { useState, FormEvent } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Mail, Lock, Eye, EyeOff, User } from 'lucide-react';
import Spinner from '../components/ui/Spinner';
import { useAuth } from '../contexts/AuthContext';
import { isUserOffline } from '../utils/errorHandler';

interface LoginFormData {
  email: string;
  password: string;
}

const LoginPage = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  
  // Get redirect parameter from URL
  const searchParams = new URLSearchParams(location.search);
  const redirectPath = searchParams.get('redirect');
  const [formData, setFormData] = useState<LoginFormData>({
    email: '',
    password: ''
  });
  
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value.trim() // Trim all inputs to remove extra spaces
    }));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    
    // Trim password again to ensure no spaces
    const trimmedPassword = formData.password.trim();
    const trimmedEmail = formData.email.trim();

    setIsLoading(true);
    setError('');

    // Check offline status first
    if (isUserOffline()) {
      setError('Unable to login. Please check your connection and try again.');
      setIsLoading(false);
      return;
    }

    try {
      // Use AuthContext login function
      const loginResult = await login(trimmedEmail, trimmedPassword);
      
      // Use returned user data directly instead of waiting for auth state
      const userRole = loginResult?.user?.role;
      
      // Only proceed with role-based routing if login was successful
      if (loginResult?.success) {
        // Check if account is suspended
        if (loginResult?.user?.isActive === false) {
          setError('This account is suspended, please contact center for help.');
          setIsLoading(false);
          return;
        }
        
        // Use redirect path if available, otherwise use role-based routing
        if (redirectPath) {
          navigate(redirectPath);
        } else {
          // Role-based routing
          switch (userRole) {
            case 'ADMIN':
              navigate('/admin');
              break;
            case 'DELIVERY':
              navigate('/delivery');
              break;
            case 'VENDOR':
              navigate('/dashboard/products');
              break;
            case 'CUSTOMER':
              navigate('/dashboard/products');
              break;
            default:
              navigate('/login');
              break;
          }
        }
      } else {
        // Use the specific error message from AuthContext
        setError(loginResult?.error || 'Login failed');
      }
    } catch (error: any) {
      // Use the error message from the catch block
      setError(error?.message || 'Login failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (

    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md mx-auto">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <div className="mb-6">
            <h2 className="text-3xl font-bold text-center mb-2">
              Login
            </h2>
            <p className="mt-2 text-center text-sm text-gray-600">
              Welcome back to Smart Local Shop Delivery
            </p>
          </div>

          {error && (
            <div className="mb-4 bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded">
              {error}
            </div>
          )}

          <form className="space-y-6" onSubmit={handleSubmit}>
            {/* Email Field */}
            <div className="mb-2">
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                Email Address
              </label>
              <div className="mt-1 relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  id="email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                  placeholder="Enter email address"
                />
              </div>
            </div>

            {/* Password Field */}
            <div className="mb-2">
              <div className="flex items-center justify-between">
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                  Password
                </label>
                <div className="text-sm">
                  <Link
                    to="/forgot-password"
                    className="font-medium text-green-600 hover:text-green-500"
                  >
                    Forgot password?
                  </Link>
                </div>
              </div>
              <div className="mt-1 relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  required
                  value={formData.password}
                  onChange={handleChange}
                  className="block w-full pl-10 pr-10 py-3 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                  placeholder="Enter your password"
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-5 w-5 text-gray-400" />
                  ) : (
                    <Eye className="h-5 w-5 text-gray-400" />
                  )}
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <div>
              <button
                type="submit"
                disabled={isLoading}
                className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <div className="flex items-center">
                    <Spinner size="sm" className="mr-2" />
                    Signing in...
                  </div>
                ) : (
                  <div className="flex items-center">
                    <User className="h-4 w-4 mr-2" />
                    Sign In
                  </div>
                )}
              </button>
            </div>
          </form>

          {/* Links */}
          <div className="mt-6">
            <div className="flex items-center justify-center">
              <div className="text-sm">
                <span className="text-gray-600">Don't have an account? </span>
                <Link
                  to="/register"
                  className="font-medium text-green-600 hover:text-green-500"
                >
                  Sign up
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
