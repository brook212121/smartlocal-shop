import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowLeft, Eye, EyeOff, Phone, CreditCard } from 'lucide-react';
import Spinner from '../components/ui/Spinner';
import { getApiUrl } from '../utils/apiConfig';

interface RegisterFormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  password: string;
  bankName: string;
  accountNumber: string;
  role: 'VENDOR' | 'DELIVERY';
  termsAccepted: boolean;
}

interface ValidationErrors {
  [key: string]: string;
}

const RegisterStep2Page: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<RegisterFormData>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    password: '',
    bankName: '',
    accountNumber: '',
    role: 'VENDOR',
    termsAccepted: false
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);

  // Ethiopian banks
  const banks = [
    'Commercial Bank of Ethiopia',
    'Bank of Abyssinia',
    'Awash Bank',
    'Cooperative Bank of Oromia'
  ];

  // Load data from step 1
  useEffect(() => {
    const savedData = localStorage.getItem('registrationData');
    if (savedData) {
      const parsedData = JSON.parse(savedData);
      setFormData(prev => ({
        ...prev,
        firstName: parsedData.firstName || '',
        lastName: parsedData.lastName || '',
        email: parsedData.email || '',
        password: parsedData.password || '',
        role: parsedData.role || 'CUSTOMER'
      }));
    } else {
      // If no data, redirect back to step 1
      navigate('/register');
    }
  }, [navigate]);

  const validateField = (name: string, value: string | boolean): string | undefined => {
    switch (name) {
      case 'phone':
        if (!value || (value as string).trim() === '') {
          return 'Phone number is required';
        }
        const phoneRegex = /^(?:\+251|0)?[97]\d{8}$/;
        if (!phoneRegex.test(value as string)) {
          return 'Phone number must be a valid Ethiopian number (09XXXXXXXX, 07XXXXXXXX, +2519XXXXXXXX, or +2517XXXXXXXX)';
        }
        break;

      case 'bankName':
        if (!value || (value as string) === '') {
          return 'Bank selection is required';
        }
        break;

      case 'accountNumber':
        if (!value || (value as string).trim() === '') {
          return 'Account number is required';
        }
        if (!/^\d+$/.test(value as string)) {
          return 'Account number must contain only numbers';
        }
        break;

      case 'termsAccepted':
        if (!value) {
          return 'You must accept Terms & Conditions to register';
        }
        break;
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const finalValue = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value.trim();
    
    setFormData(prev => ({
      ...prev,
      [name]: finalValue
    }));

    // Clear error for this field when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});
    setIsLoading(true);

    try {
      // Validate all fields
      const newErrors: ValidationErrors = {};
      
      const phoneError = validateField('phone', formData.phone);
      if (phoneError) newErrors.phone = phoneError;
      
      const bankNameError = validateField('bankName', formData.bankName);
      if (bankNameError) newErrors.bankName = bankNameError;
      
      const accountNumberError = validateField('accountNumber', formData.accountNumber);
      if (accountNumberError) newErrors.accountNumber = accountNumberError;
      
      const termsError = validateField('termsAccepted', formData.termsAccepted);
      if (termsError) newErrors.termsAccepted = termsError;

      if (Object.keys(newErrors).length > 0) {
        setErrors(newErrors);
        setIsLoading(false);
        return;
      }

      // Trim phone and account number before sending
      const trimmedFormData = {
        ...formData,
        phone: formData.phone?.trim(),
        accountNumber: formData.accountNumber?.trim(),
        bankName: formData.bankName?.trim()
      };

      const response = await fetch(getApiUrl('/api/auth/register'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(trimmedFormData),
      });

      const data = await response.json();

      if (response.ok) {
        // Clear localStorage
        localStorage.removeItem('registrationData');
        
        // Extract user data and token
        const { user, token } = data.data;
        
        // Store user data and token in localStorage
        localStorage.setItem('user', JSON.stringify(user));
        localStorage.setItem('token', token);
        
        // Show success message and redirect based on role
        setShowSuccessMessage(true);
        
        // Redirect to login page after 3 seconds
        setTimeout(() => {
          navigate('/login');
        }, 3000); 
      } else {
        setErrors({ general: data.message || 'Registration failed' });
      }
    } catch (error) {
      setErrors({ general: 'Network error. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };

  const isFormValid = () => {
    return (
      formData.phone.trim() !== '' &&
      formData.bankName !== '' &&
      formData.accountNumber.trim() !== '' &&
      formData.termsAccepted &&
      !errors.phone &&
      !errors.bankName &&
      !errors.accountNumber &&
      !errors.termsAccepted
    );
  };

  const handleBack = () => {
    // Save current data and go back
    localStorage.setItem('registrationData', JSON.stringify(formData));
    navigate('/register');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <div className="flex items-center mb-6">
            <button
              type="button"
              onClick={handleBack}
              className="mr-3 p-2 rounded-md text-gray-400 hover:text-gray-600 hover:bg-gray-100"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <h2 className="text-2xl font-bold text-gray-900">
              Complete Registration
            </h2>
          </div>
          {errors.general && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-md">
              <p className="text-sm text-red-600">{errors.general}</p>
            </div>
          )}
          {showSuccessMessage && (
            <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-md">
              <p className="text-sm text-green-600">
                Registration successful! leading to login.
              </p>
            </div>
          )}

          <form className="space-y-6" onSubmit={handleSubmit}>
            {/* Phone */}
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                Phone Number
              </label>
              <div className="mt-1 relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Phone className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                  placeholder="09XXXXXXXX or +2519XXXXXXXX"
                />
              </div>
              {errors.phone && (
                <p className="mt-1 text-sm text-red-600">{errors.phone}</p>
              )}
            </div>

            {/* Bank Selection */}
            <div className="mb-2">
              <label htmlFor="bankName" className="block text-sm font-medium text-gray-700 mb-2">
                Bank 
              </label>
              <div className="mt-1 relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <CreditCard className="h-4 w-4 text-gray-400" />
                </div>
                <select
                  id="bankName"
                  name="bankName"
                  value={formData.bankName}
                  onChange={handleChange}
                  className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                >
                  <option value="">Select bank</option>
                  {banks.map(bank => (
                    <option key={bank} value={bank}>{bank}</option>
                  ))}
                </select>
              </div>
              {errors.bankName && (
                <p className="mt-1 text-sm text-red-600">{errors.bankName}</p>
              )}
            </div>

            {/* Account Number */}
            <div className="mb-2">
              <label htmlFor="accountNumber" className="block text-sm font-medium text-gray-700 mb-2">
                Account Number
              </label>
              <div className="mt-1 relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <CreditCard className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  type="text"
                  id="accountNumber"
                  name="accountNumber"
                  value={formData.accountNumber}
                  onChange={handleChange}
                  className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                  placeholder="Enter your account number"
                />
              </div>
              {errors.accountNumber && (
                <p className="mt-1 text-sm text-red-600">{errors.accountNumber}</p>
              )}
              {formData.bankName && (
                <p className="mt-1 text-xs text-gray-500">
                  {formData.bankName === 'Bank of Abyssinia' 
                    ? 'Account number must be 8-10 digits'
                    : 'Account number must be 13 digits'
                  }
                </p>
              )}
            </div>

            {/* Terms & Conditions */}
            <div>
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="termsAccepted"
                  name="termsAccepted"
                  checked={formData.termsAccepted}
                  onChange={handleChange}
                  className={`h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded ${
                    errors.termsAccepted ? 'border-red-500' : ''
                  }`}
                />
                <label htmlFor="termsAccepted" className="ml-2 block text-sm text-gray-900">
                  I accept Terms & Conditions 
                </label>
              </div>
              {errors.termsAccepted && (
                <p className="mt-1 text-sm text-red-600">{errors.termsAccepted}</p>
              )}
            </div>

            {/* Submit Button */}
            <div>
              <button
                type="submit"
                disabled={!isFormValid() || isLoading}
                className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <div className="flex items-center">
                    <Spinner size="sm" className="mr-2" />
                    Creating Account...
                  </div>
                ) : (
                  <span className="flex items-center">
                    Create Account
                  </span>
                )}
              </button>
            </div>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600">
              Already have an account?{' '}
              <Link to="/login" className="font-medium text-green-600 hover:text-green-500">
                Sign in
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RegisterStep2Page;
