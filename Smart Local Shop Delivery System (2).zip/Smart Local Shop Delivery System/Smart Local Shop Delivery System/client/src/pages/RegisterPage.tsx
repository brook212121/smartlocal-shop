import React, { useState, useEffect, FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff, User, Mail, Phone, Lock } from 'lucide-react';
import Spinner from '../components/ui/Spinner';
import { useAuth } from '../contexts/AuthContext';

interface RegisterFormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  password: string;
  bankName: string;
  accountNumber: string;
  role: 'VENDOR' | 'DELIVERY';
  termsAccepted: boolean;
}

interface ValidationErrors {
  firstName?: string;
  lastName?: string;
  email?: string;
  phone?: string;
  password?: string;
  bankName?: string;
  accountNumber?: string;
  role?: string;
  termsAccepted?: string;
  general?: string;
}

const RegisterPage = () => {
  const navigate = useNavigate();
  const { register } = useAuth();

  const [formData, setFormData] = useState<RegisterFormData>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    password: '',
    bankName: '',
    accountNumber: '',
    role: 'VENDOR',
    termsAccepted: false
  });
  
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<ValidationErrors>({});

  // Ethiopian banks
  const banks = [
    'Commercial Bank of Ethiopia',
    'Bank of Abyssinia',
    'Awash Bank',
    'Cooperative Bank of Oromia'
  ];

  const validateField = (name: string, value: string | boolean): string | undefined => {
    switch (name) {
      case 'firstName':
        if (!value || (value as string).trim() === '') {
          return 'First name is required';
        }
        if ((value as string).trim().length < 3) {
          return 'First name must be at least 3 characters long';
        }
        if (!/^[A-Za-z]+$/.test((value as string).trim())) {
          return 'First name can only contain letters';
        }
        break;

      case 'lastName':
        if (!value || (value as string).trim() === '') {
          return 'Last name is required';
        }
        if ((value as string).trim().length < 2) {
          return 'Last name must be at least 2 characters long';
        }
        if (!/^[A-Za-z]+$/.test((value as string).trim())) {
          return 'Last name can only contain letters';
        }
        break;

      case 'email':
        if (!value || (value as string).trim() === '') {
          return 'Email is required';
        }
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value as string)) {
          return 'Please enter a valid email address';
        }
        break;

      case 'password':
        if (!value || (value as string).trim() === '') {
          return 'Password is required';
        }
        const password = value as string;
        if (password.length < 8) {
          return 'Password must be at least 8 characters long';
        }
        if (!/[A-Z]/.test(password)) {
          return 'Password must contain at least one uppercase letter';
        }
        if (!/[a-z]/.test(password)) {
          return 'Password must contain at least one lowercase letter';
        }
        if (!/\d/.test(password)) {
          return 'Password must contain at least one number';
        }
        if (/\s/.test(password)) {
          return 'Password cannot contain spaces';
        }
        break;

      case 'phone':
        if (!value || (value as string).trim() === '') {
          return 'Phone number is required';
        }
        const phoneRegex = /^(?:\+251|0)?[97]\d{8}$/;
        if (!phoneRegex.test(value as string)) {
          return 'Phone number must be a valid Ethiopian number (09XXXXXXXX, 07XXXXXXXX, +2519XXXXXXXX, or +2517XXXXXXXX)';
        }
        break;

      case 'bankName':
        if (!value || (value as string) === '') {
          return 'Bank selection is required';
        }
        break;

      case 'accountNumber':
        if (!value || (value as string).trim() === '') {
          return 'Account number is required';
        }
        if (!/^\d+$/.test(value as string)) {
          return 'Account number must contain only numbers';
        }
        break;

      case 'role':
        if (!value || (value as string).trim() === '') {
          return 'Please select a role';
        }
        break;

      case 'termsAccepted':
        if (!value) {
          return 'You must accept Terms & Conditions to register';
        }
        break;
    }
  };

  const isFirstStepValid = () => {
    return (
      formData.firstName.trim() !== '' &&
      formData.lastName.trim() !== '' &&
      formData.email.trim() !== '' &&
      formData.password.trim() !== '' &&
      formData.role !== undefined &&
      !errors.firstName &&
      !errors.lastName &&
      !errors.email &&
      !errors.password &&
      !errors.role
    );
  };

  const handleNext = () => {
    // Validate first step
    const newErrors: ValidationErrors = {};
    
    const firstNameError = validateField('firstName', formData.firstName);
    if (firstNameError) newErrors.firstName = firstNameError;
    
    const lastNameError = validateField('lastName', formData.lastName);
    if (lastNameError) newErrors.lastName = lastNameError;
    
    const emailError = validateField('email', formData.email);
    if (emailError) newErrors.email = emailError;
    
    const passwordError = validateField('password', formData.password);
    if (passwordError) newErrors.password = passwordError;
    
    const roleError = validateField('role', formData.role);
    if (roleError) newErrors.role = roleError;

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    // Store form data and navigate to next step
    localStorage.setItem('registrationData', JSON.stringify(formData));
    navigate('/register-step-2');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const finalValue = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value.trim(); // Trim text inputs
    
    setFormData(prev => ({
      ...prev,
      [name]: finalValue
    }));

    // Clear error for this field when user starts typing
    if (errors[name as keyof ValidationErrors]) {
      setErrors(prev => ({
        ...prev,
        [name]: undefined
      }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: ValidationErrors = {};

    // Validate all fields
    Object.keys(formData).forEach(key => {
      const error = validateField(key, formData[key as keyof RegisterFormData]);
      if (error) {
        newErrors[key as keyof ValidationErrors] = error;
      }
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    setErrors({});

    try {
      // Trim password and email before sending
      const trimmedFormData = {
        ...formData,
        email: formData.email?.trim(),
        password: formData.password?.trim(),
        firstName: formData.firstName?.trim(),
        lastName: formData.lastName?.trim(),
        phone: formData.phone?.trim(),
        bankName: formData.bankName?.trim(),
        accountNumber: formData.accountNumber?.trim()
      };

      // Use AuthContext register function
      await register(trimmedFormData);
      
      // Navigate to login page after successful registration
      navigate('/login');
    } catch (error) {
      setErrors({
        general: 'Registration failed. Please try again.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const isFormValid = () => {
    return (
      formData.firstName.trim() !== '' &&
      formData.lastName.trim() !== '' &&
      formData.email.trim() !== '' &&
      formData.phone.trim() !== '' &&
      formData.password.trim() !== '' &&
      formData.bankName !== undefined &&
      formData.accountNumber.trim() !== '' &&
      formData.role !== undefined &&
      formData.termsAccepted === true &&
      Object.keys(errors).length === 0
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md mx-auto">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <div className="mb-6">
            <h2 className="text-3xl font-bold text-center mb-2">
              Create Account
            </h2>
            
          </div>

          {errors.general && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-md">
              <p className="text-sm text-red-600">{errors.general}</p>
            </div>
          )}

          <form className="space-y-6" onSubmit={handleSubmit}>
            {/* Role Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Register as 
              </label>
              <div className="grid grid-cols-2 gap-3">
                <label className="relative flex items-center p-3 cursor-pointer transition-colors hover:bg-gray-50 rounded-lg">
                  <input
                    type="radio"
                    name="role"
                    value="VENDOR"
                    checked={formData.role === 'VENDOR'}
                    onChange={handleChange}
                    className="w-4 h-4 text-green-600 focus:ring-green-500 border-gray-300"
                  />
                  <div className={`ml-3 flex flex-col items-start ${
                    formData.role === 'VENDOR' ? 'text-green-600' : 'text-gray-600'
                  }`}>
                    <span className="text-sm font-medium">User</span>
                  </div>
                </label>
                
                <label className="relative flex items-center p-3 cursor-pointer transition-colors hover:bg-gray-50 rounded-lg">
                  <input
                    type="radio"
                    name="role"
                    value="DELIVERY"
                    checked={formData.role === 'DELIVERY'}
                    onChange={handleChange}
                    className="w-4 h-4 text-green-600 focus:ring-green-500 border-gray-300"
                  />
                  <div className={`ml-3 flex flex-col items-start ${
                    formData.role === 'DELIVERY' ? 'text-green-600' : 'text-gray-600'
                  }`}>
                    <span className="text-sm font-medium">Agent</span>
                  </div>
                </label>
              </div>
              {errors.role && (
                <p className="mt-1 text-sm text-red-600">{errors.role}</p>
              )}
            </div>

            {/* Name Fields */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-2">
                  First Name 
                </label>
                <div className="mt-1 relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <User className="h-4 w-4 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    id="firstName"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleChange}
                    className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                    placeholder="Enter first name"
                  />
                </div>
                {errors.firstName && (
                  <p className="mt-1 text-sm text-red-600">{errors.firstName}</p>
                )}
              </div>

              <div>
                <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-2">
                  Last Name 
                </label>
                <div className="mt-1 relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <User className="h-4 w-4 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    id="lastName"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleChange}
                    className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                    placeholder="Enter last name"
                  />
                </div>
                {errors.lastName && (
                  <p className="mt-1 text-sm text-red-600">{errors.lastName}</p>
                )}
              </div>
            </div>

            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                Email Address
              </label>
              <div className="mt-1 relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                  placeholder="Enter email address"
                />
              </div>
              {errors.email && (
                <p className="mt-1 text-sm text-red-600">{errors.email}</p>
              )}
            </div>

            {/* Password */}
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                Password 
              </label>
              <div className="mt-1 relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  id="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  className="block w-full pl-10 pr-10 py-3 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                  placeholder="Enter password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                >
                  {showPassword ? (
                    <EyeOff className="h-5 w-5 text-gray-400" />
                  ) : (
                    <Eye className="h-5 w-5 text-gray-400" />
                  )}
                </button>
              </div>
              {errors.password && (
                <p className="mt-1 text-sm text-red-600">{errors.password}</p>
              )}
              <p className="mt-1 text-xs text-gray-500">
                Must contain at least 8 characters, one uppercase, one lowercase, and one number
              </p>
            </div>

            {/* Next Button */}
            <div className="pt-4">
              <button
                type="button"
                onClick={handleNext}
                disabled={isLoading || !isFirstStepValid()}
                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
              >
                {isLoading ? (
                  <Spinner size="sm" className="mr-2" />
                ) : (
                  'Next'
                )}
              </button>
            </div>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600">
              Already have an account?{' '}
              <Link to="/login" className="font-medium text-green-600 hover:text-green-500">
                Sign in
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;
