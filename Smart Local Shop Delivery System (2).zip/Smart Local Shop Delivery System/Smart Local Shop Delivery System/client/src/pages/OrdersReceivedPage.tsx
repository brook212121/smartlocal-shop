import { useState, useEffect } from 'react';
import { ShoppingCart, Mail, Phone, MessageCircle, Send, X, ChevronDown } from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import { useAuth } from '../contexts/AuthContext'; // ✅ Import AuthContext
import { getApiUrl } from '../utils/apiConfig';
import { getImageUrl } from '../utils/imageUtils';
import Spinner from '../components/ui/Spinner';

interface ChatMessage {
  _id: string;
  quickOrderId: string;
  senderId: string;
  senderType: 'VENDOR' | 'CUSTOMER';
  message: string;
  price?: number;
  createdAt: string;
  sender?: {
    firstName: string;
    lastName: string;
  };
}

interface VendorResponse {
  _id: string;
  vendorId: string;
  quickOrderId: string;
  vendor: {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
  };
  message: string;
  price: number;
  createdAt: string;
}

interface VendorOrder {
  _id: string;
  orderNumber: string;
  customer: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
  };
  items: Array<{
    product: {
      name: string;
      price: number;
      images: string[];
    };
    quantity: number;
    price: number;
  }>;
  status: 'PENDING' | 'CONFIRMED' | 'PREPARING' | 'READY_FOR_PICKUP' | 'OUT_FOR_DELIVERY' | 'DELIVERED' | 'CANCELLED' | 'REFUNDED';
  pricing: {
    total: number;
    currency: string;
  };
  createdAt: string;
  assignedVendor?: {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
  };
  assignmentDistance?: number;
  isQuickOrder?: boolean;
  responses?: VendorResponse[];
}

const OrdersReceivedPage = () => {
  const { authState } = useAuth(); // 
  const token = authState.token; // 

  const [vendorOrders, setVendorOrders] = useState<VendorOrder[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [expandedChats, setExpandedChats] = useState<Set<string>>(new Set());
  const [chatMessages, setChatMessages] = useState<{ [key: string]: ChatMessage[] }>({});
  const [newMessages, setNewMessages] = useState<{ [key: string]: { message: string; price: string } }>({});
  const [isSending, setIsSending] = useState<{ [key: string]: boolean }>({});
  const [showChatModal, setShowChatModal] = useState(false);
  const [selectedOrderForChat, setSelectedOrderForChat] = useState<VendorOrder | null>(null);
  const { handleApiResponse, handleApiError } = useToast();

  const fetchVendorOrders = async () => {
    setIsLoading(true);
    try {
      console.log('Fetching Quick Orders assigned to vendor from /api/quick-orders/vendor...');
      const response = await fetch(getApiUrl('/api/quick-orders/vendor'), {
        headers: {
          'Authorization': `Bearer ${token}` // 
        },
        credentials: 'include'
      });

      console.log('Response status:', response.status);
      console.log('Response ok:', response.ok);

      if (response.ok) {
        const data = await response.json();
        console.log('Quick Orders response data:', data);
        console.log('Quick Orders array:', data.data);
        console.log('Quick Orders length:', data.data?.length);
        
        // Fetch responses for each order
        const ordersWithResponses = await Promise.all(
          data.data.map(async (order: VendorOrder) => {
            try {
              const responsesResponse = await fetch(getApiUrl(`/api/quick-orders/${order._id}/responses`), {
                headers: {
                  'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                credentials: 'include'
              });
              
              if (responsesResponse.ok) {
                const responsesData = await responsesResponse.json();
                return { ...order, responses: responsesData.data || [] };
              }
              return order;
            } catch (error) {
              console.error('Error fetching responses:', error);
              return order;
            }
          })
        );
        
        setVendorOrders(ordersWithResponses);
      } else {
        const errorData = await response.json();
        console.log('Error response:', errorData);
      }
    } catch (error) {
      console.error('Error fetching vendor orders:', error);
      handleApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  const acceptOrder = async (orderId: string) => {
    if (!confirm('Are you sure you want to accept this order?')) {
      return;
    }

    try {
      const response = await fetch(getApiUrl(`/api/orders/${orderId}/accept`), {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        credentials: 'include'
      });

      if (response.ok) {
        handleApiResponse(response, 'Order accepted successfully!');
        fetchVendorOrders(); // Refresh orders
      } else {
        const errorData = await response.json();
        handleApiError(new Error(errorData.message || 'Failed to accept order'));
      }
    } catch (error) {
      console.error('Error accepting order:', error);
      handleApiError(error);
    }
  };

  const openChatModal = async (order: VendorOrder) => {
    setSelectedOrderForChat(order);
    setShowChatModal(true);
    // Fetch chat messages when opening modal
    await fetchChatMessages(order._id);
  };

  const fetchChatMessages = async (orderId: string) => {
    try {
      const response = await fetch(getApiUrl(`/api/quick-orders/${orderId}/chat`), {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        credentials: 'include'
      });

      if (response.ok) {
        const data = await response.json();
        setChatMessages(prev => ({ ...prev, [orderId]: data.data || [] }));
      }
    } catch (error) {
      console.error('Error fetching chat messages:', error);
    }
  };

  const sendMessage = async (orderId: string) => {
    const messageData = newMessages[orderId];
    if (!messageData?.message.trim() || !messageData?.price) {
      alert('Please enter both message and price');
      return;
    }

    setIsSending(prev => ({ ...prev, [orderId]: true }));
    
    try {
      const response = await fetch(getApiUrl(`/api/quick-orders/${orderId}/respond`), {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({
          message: messageData.message,
          price: parseFloat(messageData.price)
        })
      });

      if (response.ok) {
        // Clear input
        setNewMessages(prev => ({ ...prev, [orderId]: { message: '', price: '' } }));
        // Refresh chat messages
        await fetchChatMessages(orderId);
        // Refresh vendor orders to get new responses
        await fetchVendorOrders();
        handleApiResponse(response, 'Chat sent successfully! Your response has been delivered to the quick order owner.');
      } else {
        const errorData = await response.json();
        handleApiError(errorData);
      }
    } catch (error) {
      console.error('Error sending message:', error);
      handleApiError(error);
    } finally {
      setIsSending(prev => ({ ...prev, [orderId]: false }));
    }
  };

  const continueToPayment = async (response: VendorResponse) => {
    try {
      // Fetch the latest vendor response to get current price
      const latestResponse = await fetch(getApiUrl(`/api/quick-orders/${response.quickOrderId}/responses`), {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (latestResponse.ok) {
        const responsesData = await latestResponse.json();
        const currentVendorResponse = responsesData.data.find((r: VendorResponse) => r.vendorId === response.vendorId);
        
        if (currentVendorResponse) {
          // Create order with latest vendor price
          const orderResponse = await fetch(getApiUrl('/api/orders/from-quick-order'), {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${localStorage.getItem('token')}`,
              'Content-Type': 'application/json'
            },
            credentials: 'include',
            body: JSON.stringify({
              quickOrderId: response.quickOrderId,
              vendorId: response.vendorId,
              agreedPrice: currentVendorResponse.price
            })
          });

          if (orderResponse.ok) {
            const orderData = await orderResponse.json();
            handleApiResponse(orderResponse, 'Order created successfully! Redirecting to payment...');
            // Refresh quick orders to update status
            await fetchVendorOrders();
            // Redirect to payment page
            setTimeout(() => {
              window.location.href = `/payment/${orderData.data._id}`;
            }, 1500);
          } else {
            const errorData = await orderResponse.json();
            handleApiError(errorData);
          }
        } else {
          handleApiError(new Error('Vendor response not found'));
        }
      } else {
        const errorData = await latestResponse.json();
        handleApiError(errorData);
      }
    } catch (error) {
      console.error('Error creating order:', error);
      handleApiError(error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PENDING':
        return 'bg-yellow-100 text-yellow-800';
      case 'CONFIRMED':
        return 'bg-blue-100 text-blue-800';
      case 'PREPARING':
        return 'bg-orange-100 text-orange-800';
      case 'READY_FOR_PICKUP':
        return 'bg-purple-100 text-purple-800';
      case 'OUT_FOR_DELIVERY':
        return 'bg-indigo-100 text-indigo-800';
      case 'DELIVERED':
        return 'bg-green-100 text-green-800';
      case 'CANCELLED':
        return 'bg-red-100 text-red-800';
      case 'REFUNDED':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  useEffect(() => {
    fetchVendorOrders();
  }, []);

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      <div className="mb-8">
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <p className="text-gray-600">View and manage Quick Orders assigned to you by customers.</p>
        </div>

        {isLoading ? (
          <Spinner size="lg" />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {vendorOrders.map(order => (
              <div key={order._id} className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-6">
                {/* Order Header */}
                <div className="mb-4">
                  {order.items.length > 0 && order.items[0].product?.images?.[0] && (
                    <img
                      src={getImageUrl(order.items[0].product.images[0])}
                      alt={order.items[0].product?.name || 'Product'}
                      className="w-full h-48 object-cover rounded-lg"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAwIiBoZWlnaHQ9IjE5MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iODAwIiBoZWlnaHQ9IjE5MCIgZmlsbD0iI2YzZjRmNiIvPgogIDx0ZXh0IHg9IjQwMCIgeT0iOTYiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIyNCIgZmlsbD0iIzljYTNhZiIgdGV4dC1hbmNob3I9Im1pZGRsZSI+CiAgICBObyBJbWFnZQogIDwvdGV4dD4KPC9zdmc+";
                      }}
                    />
                  )}
                </div>

                {/* Date below image */}
                <div className="text-sm text-gray-500 mb-4">
                  {formatDate(order.createdAt)}
                </div>

                {/* Product Information */}
                <div className="mb-4">
                  <div className="flex items-center gap-3">
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">
                        {order.items.length > 0 ? order.items[0].product?.name : 'No product'}
                      </div>
                      {order.items.length > 1 && (
                        <div className="text-xs text-gray-500">+{order.items.length - 1} more items</div>
                      )}
                      <div className="text-sm text-gray-600">
                        Quantity: {order.items.reduce((sum, item) => sum + item.quantity, 0)}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Customer Contact */}
                <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                  <div className="text-sm font-medium text-gray-700 mb-2">{order.customer?.firstName} {order.customer?.lastName}</div>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center">
                      <Mail className="h-4 w-4 mr-2 text-gray-400" />
                      {order.customer?.email || 'No email'}
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => order.customer?.phone ? window.open(`tel:${order.customer.phone}`) : null}
                        className="flex-1 bg-green-600 text-white px-3 py-2 rounded-md hover:bg-green-700 transition-colors text-sm font-medium flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                        disabled={!order.customer?.phone}
                      >
                        <Phone className="h-4 w-4 mr-1" />
                        Make Call
                      </button>
                      <button
                        onClick={() => openChatModal(order)}
                        className="flex-1 bg-blue-600 text-white px-3 py-2 rounded-md hover:bg-blue-700 transition-colors text-sm font-medium flex items-center justify-center"
                      >
                        <MessageCircle className="h-4 w-4 mr-1" />
                        Start Chat
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {vendorOrders.length === 0 && !isLoading && (
          <div className="text-center py-12">
            <ShoppingCart className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Quick Orders received</h3>
            <p className="text-gray-500">Quick Orders assigned to you will appear here</p>
          </div>
        )}
      </div>

      {/* Chat Modal */}
      {showChatModal && selectedOrderForChat && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full h-[80vh] flex flex-col relative">
            {/* Close Button */}
            <button
              onClick={() => setShowChatModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 z-10"
            >
              <X className="h-6 w-6" />
            </button>

            {/* Header */}
            <div className="flex-shrink-0 p-6 border-b">
              <h3 className="text-xl font-bold text-gray-900 mb-2">Chat with Customer</h3> 
            </div>

            {/* Chat Messages */}
            <div className="flex-1 overflow-y-auto p-6">
              <div className="space-y-3">
                {chatMessages[selectedOrderForChat._id]?.map((message) => (
                  <div key={message._id} className={`flex ${message.senderType === 'VENDOR' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-xs px-4 py-2 rounded-lg ${
                      message.senderType === 'VENDOR' 
                        ? 'bg-green-600 text-white' 
                        : 'bg-gray-200 text-gray-900'
                    }`}>
                      <div className="text-sm font-medium mb-1">
                        {message.sender?.firstName} {message.sender?.lastName}
                      </div>
                      <div className="text-sm">{message.message}</div>
                      {message.price && (
                        <div className="text-sm font-bold mt-1">
                          Price: ETB {message.price.toFixed(2)}
                        </div>
                      )}
                      <div className="text-xs opacity-75 mt-1">
                        {formatDate(message.createdAt)}
                      </div>
                    </div>
                  </div>
                ))}
                {(!chatMessages[selectedOrderForChat._id] || chatMessages[selectedOrderForChat._id].length === 0) && (
                  <div className="text-center text-gray-500 text-sm py-8">
                    No messages yet. Start the conversation!
                  </div>
                )}
              </div>
            </div>

            {/* Message Input */}
            <div className="flex-shrink-0 border-t p-3">
              <div className="space-y-3">
                <div>
                  <textarea
                    value={newMessages[selectedOrderForChat._id]?.message || ''}
                    onChange={(e) => setNewMessages(prev => ({ 
                      ...prev, 
                      [selectedOrderForChat._id]: { ...prev[selectedOrderForChat._id], message: e.target.value } 
                    }))}
                    placeholder="Type your message..."
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200 resize-none"
                    rows={3}
                  />
                </div>
                <div className="flex gap-2">
                  <div className="flex-1 relative">
                    <input
                      type="number"
                      value={newMessages[selectedOrderForChat._id]?.price || ''}
                      onChange={(e) => setNewMessages(prev => ({ 
                        ...prev, 
                        [selectedOrderForChat._id]: { ...prev[selectedOrderForChat._id], price: e.target.value } 
                      }))}
                      placeholder="Your price (ETB)"
                      className="block w-full px-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                      min="0"
                      step="0.01"
                    />
                    <button
                      onClick={() => sendMessage(selectedOrderForChat._id)}
                      disabled={isSending[selectedOrderForChat._id] || !newMessages[selectedOrderForChat._id]?.message?.trim() || !newMessages[selectedOrderForChat._id]?.price}
                      className="absolute right-1 top-1/2 transform -translate-y-1/2 bg-green-600 text-white p-1.5 rounded-md hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
                    >
                      {isSending[selectedOrderForChat._id] ? (
                        <Spinner size="sm" />
                      ) : (
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M3.714 3.048a.498.498 0 0 0-.683.627l2.843 7.627a2 2 0 0 1 0 1.396l-2.842 7.627a.498.498 0 0 0 .682.627l18-8.5a.5.5 0 0 0 0-.904z"/>
                          <path d="M6 12h16"/>
                        </svg>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default OrdersReceivedPage;
