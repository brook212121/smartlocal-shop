import { useState, useEffect, useRef } from 'react';
import { Plus, Edit2, Trash2, X, Package, Image as ImageIcon, Search } from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import { useAuth } from '../contexts/AuthContext';
import { getApiUrl } from '../utils/apiConfig';
import { getImageUrl } from '../utils/imageUtils';
import { vendorService } from '../services/vendorService';
import Spinner from '../components/ui/Spinner';

interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  category: string;
  image: string;
  inStock: boolean;
  quantity: number;
  createdAt: string;
}

const VendorProductsPage = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { handleApiResponse, handleApiError } = useToast();
  
  // Use AuthContext for authentication
  const { authState } = useAuth();
  const { token, user, isLoading: authLoading, isAuthenticated } = authState;

  const [formData, setFormData] = useState({
    name: '',
    price: '',
    description: '',
    category: 'Vegetables',
    image: '',
    inStock: true,
    quantity: '1'
  });

  const fetchVendorProducts = async () => {
    try {
      if (!token) {
        throw new Error('Authentication token required');
      }
      
      const response = await fetch(getApiUrl('/api/products'), {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        console.log('API Response:', data); // Debug log
        // Transform products to have full image URLs
        const transformedProducts = data.data.products?.map((product: any) => ({
          ...product,
          image: getImageUrl(product.images && product.images.length > 0 ? product.images[0] : product.image)
        })) || [];
        setProducts(transformedProducts);
      } else if (response.status === 403) {
        // Vendor access required - show upgrade option
        setProducts([]);
      } else {
        const errorData = await response.json();
        console.error("Vendor products request failed:", response.status, errorData);
        handleApiError(new Error(errorData.message || 'Failed to fetch vendor products'));
      }
    } catch (error) {
      console.error("Error fetching vendor products:", error);
      handleApiError(error);
    } finally {
      setLoading(false);
    }
  };

  // Filter products based on search term
  useEffect(() => {
    if (searchTerm.trim() === '') {
      setFilteredProducts(products);
    } else {
      const filtered = products.filter(product =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredProducts(filtered);
    }
  }, [products, searchTerm]);

  const categories = ['FOOD_BEVERAGES', 'GROCERIES', 'OTHER', 'HEALTH_BEAUTY', 'HOME_GARDEN', 'ELECTRONICS', 'CLOTHING', 'SPORTS_OUTDOORS', 'BOOKS_MEDIA', 'TOYS_GAMES', 'AUTOMOTIVE', 'PHARMACY'];

  const resetForm = () => {
    setFormData({
      name: '',
      price: '',
      description: '',
      category: 'FOOD_BEVERAGES',
      image: '',
      inStock: true,
      quantity: '1'
    });
    setImagePreview('');
    setEditingProduct(null);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    console.log('File selected:', file);
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        console.log('Reader result:', reader.result);
        setImagePreview(reader.result as string);
        setFormData({ ...formData, image: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.price || !formData.description || !formData.quantity) {
      handleApiError(new Error('Please fill in all required fields'));
      return;
    }

    setIsLoading(true);

    try {
      const url = editingProduct 
        ? getApiUrl(`/api/products/${editingProduct.id}`)
        : getApiUrl('/api/products');
      
      const method = editingProduct ? 'PUT' : 'POST';

      // Create FormData for file upload
      const formDataToSend = new FormData();
      formDataToSend.append('name', formData.name);
      formDataToSend.append('description', formData.description);
      formDataToSend.append('category', formData.category);
      formDataToSend.append('price', formData.price);
      formDataToSend.append('quantity', formData.quantity || '0');

      // Handle image - either file upload or existing Base64
      if (fileInputRef.current?.files?.[0]) {
        formDataToSend.append('image', fileInputRef.current.files[0]);
      } else if (formData.image) {
        // Convert Base64 to blob for existing images
        const response = await fetch(formData.image);
        const blob = await response.blob();
        formDataToSend.append('image', blob, 'product.jpg');
      }

      const response = await fetch(url, {
        method,
        headers: {
          'Authorization': `Bearer ${token}`
          // Don't set Content-Type for FormData - browser sets it automatically
        },
        body: formDataToSend
      });

      if (response.ok) {
        handleApiResponse(response, editingProduct ? 'Product updated successfully!' : 'Product created successfully!');
        setIsFormOpen(false);
        setEditingProduct(null);
        resetForm();
        fetchVendorProducts();
      } else {
        const errorData = await response.json();
        handleApiError(new Error(errorData.message || 'Failed to save product'));
      }
    } catch (error) {
      console.error('Error saving product:', error);
      handleApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEdit = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      price: product.price.toString(),
      description: product.description,
      category: product.category,
      image: product.image,
      inStock: product.inStock,
      quantity: product.quantity?.toString() || '1'
    });
    setImagePreview(product.image);
    setIsFormOpen(true);
  };

  const handleDelete = async (productId: string) => {
    if (!confirm('Are you sure you want to delete this product?')) {
      return;
    }

    try {
      const response = await fetch(getApiUrl(`/api/products/${productId}`), {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        handleApiResponse(response, 'Product deleted successfully!');
        fetchVendorProducts();
      } else {
        const errorData = await response.json();
        handleApiError(new Error(errorData.message || 'Failed to delete product'));
      }
    } catch (error) {
      console.error('Error deleting product:', error);
      handleApiError(error);
    }
  };

  useEffect(() => {
    if (token) {
      console.log('🔍 VendorProductsPage: Token available for API calls');
    }
  }, [token]);

  useEffect(() => {
    console.log('🔍 DEBUG: VendorProductsPage useEffect triggered');
    
    // Guard until auth is ready
    if (authLoading) return;
    if (!isAuthenticated || !token) {
      console.error('🔍 DEBUG: Not authenticated, skipping API calls');
      setLoading(false);
      return;
    }
    
    // Load products first (don't wait for geolocation)
    fetchVendorProducts();
    
    // Try geolocation in background (don't block page load)
    console.log('🔍 Starting automatic vendor location detection...');
    
    // Check if running in secure context (HTTPS or localhost)
    const isSecureContext = window.isSecureContext;
    const isLocalhost = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
    const isHTTPS = window.location.protocol === 'https:';
    
    console.log('🔍 DEBUG: Security context check:', {
      isSecureContext,
      isLocalhost,
      isHTTPS,
      protocol: window.location.protocol,
      hostname: window.location.hostname
    });
    
    // Check if geolocation is supported
    if (!navigator.geolocation) {
      console.error('❌ Geolocation is not supported by this browser');
      return;
    }
    
    // Only request geolocation in secure context or localhost
    if (!isSecureContext && !isLocalhost) {
      console.warn('⚠️ Geolocation requires secure context (HTTPS) or localhost');
      console.log('🔧 Solution: Use HTTPS tunnel (ngrok) or localhost');
      console.log('� Mobile: Products will load without location detection');
      return;
    }
    
    console.log('📍 DEBUG: Secure context confirmed, requesting permission...');
    
    // Check if we already have coordinates stored to avoid repeated requests
    const checkExistingLocation = async () => {
      try {
        const response = await fetch('/api/vendors/current-location', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        
        if (response.ok) {
          const data = await response.json();
          if (data.success && data.data.location && data.data.location.latitude && data.data.location.longitude) {
            console.log('✅ Vendor already has valid coordinates:', data.data.location);
            return true; // Skip geolocation request
          }
        }
      } catch (error) {
        console.log('📍 No existing coordinates found, requesting new location...');
      }
      return false; // Need to request location
    };
    
    // Request location only if not already stored
    const requestLocation = async () => {
      try {
        const position = await new Promise<GeolocationPosition>((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(
            resolve,
            reject,
            {
              enableHighAccuracy: true,
              timeout: 15000,
              maximumAge: 300000 // 5 minutes
            }
          );
        });
        
        console.log('📍 GPS Location detected:', position.coords);
        
        const { latitude, longitude } = position.coords;
        
        // Validate coordinates are real numbers
        if (typeof latitude === 'number' && typeof longitude === 'number' && 
            latitude !== 0 && longitude !== 0 && 
            !isNaN(latitude) && !isNaN(longitude)) {
          
          const location = {
            latitude: parseFloat(latitude.toFixed(6)),
            longitude: parseFloat(longitude.toFixed(6)),
            address: 'Auto-detected location'
          };
          
          console.log('✅ Valid coordinates, sending to backend:', location);
          
          // Send to backend
          await vendorService.updateVendorLocation(location);
          
          console.log('🎉 Vendor location updated successfully');
          
        } else {
          console.warn('⚠️ Invalid GPS coordinates detected:', { latitude, longitude });
        }
      } catch (error) {
        console.warn('⚠️ Geolocation error:', error);
        
        if (error instanceof GeolocationPositionError) {
          switch(error.code) {
            case error.PERMISSION_DENIED:
              console.log('🚫 Location permission denied by user');
              break;
            case error.POSITION_UNAVAILABLE:
              console.log('🚫 Location information unavailable');
              break;
            case error.TIMEOUT:
              console.log('🚫 Location request timed out');
              break;
            default:
              console.log('🚫 Unknown geolocation error:', error.message);
              break;
          }
        }
      }
    };
    
    // Check existing location first, then request if needed
    checkExistingLocation().then(hasLocation => {
      if (!hasLocation) {
        requestLocation();
      }
    });
  }, []);

  const handleUpgradeToVendor = async () => {
    try {
      const response = await fetch(getApiUrl('/api/auth/upgrade-to-vendor'), {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        handleApiResponse(response, 'Account upgraded to vendor status successfully!');
        // Refresh the page to update user context
        window.location.reload();
      } else {
        const errorData = await response.json();
        handleApiError(new Error(errorData.message || 'Failed to upgrade account'));
      }
    } catch (error) {
      console.error('Error upgrading to vendor:', error);
      handleApiError(error);
    }
  };

  const toggleStockStatus = (productId: string) => {
    const product = products.find(p => p.id === productId);
    if (product && product.quantity > 0) {
      setProducts(products.map(p => 
        p.id === productId ? { ...p, inStock: !p.inStock } : p
      ));
    }
  };

  if (loading) return <Spinner size="lg" />;

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      <div className="mb-8">

        {/* Search and Filter Section */}
        <div className="mb-6">
          <div className="flex gap-3 items-center justify-between">
            <div className="flex-1 max-w-md relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                  }
                }}
                className="block w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                placeholder="Search products..."
                autoComplete="off"
              />
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm('')}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600 transition-colors duration-200"
                  title="Clear search"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
            
            {/* Add Product Button */}
            <button
              onClick={() => {
                resetForm();
                setIsFormOpen(true);
              }}
              className="flex items-center px-3 sm:px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 whitespace-nowrap"
            >
              <Plus className="h-5 w-4 mr-2" />
            </button>
          </div>
          
          {searchTerm && (
            <div className="mt-2 text-sm text-gray-600">
              Found {filteredProducts.length} products matching "{searchTerm}"
            </div>
          )}
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map(product => (
            <div key={product.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 flex flex-col border border-gray-100">
              {/* Product Image Container */}
              <div className="relative flex-shrink-0 bg-gradient-to-br from-gray-50 to-gray-100">
                <div className="aspect-w-16 aspect-h-12 relative h-56">
                  <img
                    src={getImageUrl(product.image)}
                    alt={product.name}
                    loading="lazy"
                    className="w-full h-full object-contain p-4 transition-transform duration-300 hover:scale-105"
                    onError={(e) => {
                      console.error('Image failed to load:', getImageUrl(product.image), e);
                      e.currentTarget.src = '/api/placeholder/300/200';
                    }}
                    onLoad={() => {
                      console.log('Image loaded successfully:', getImageUrl(product.image));
                    }}
                  />
                </div>
              </div>
              
              {/* Product Content */}
              <div className="p-5 flex-1 flex flex-col">
                {/* Product Name and Quantity */}
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-lg font-bold text-gray-900 line-clamp-2 leading-tight flex-1">
                    {product.name}
                  </h3>
                  <span className="text-sm font-semibold text-gray-600 ml-2">
                    Left: {product.quantity !== undefined ? product.quantity : 0}
                  </span>
                </div>
                
                {/* Product Description */}
                <p className="text-sm text-gray-600 mb-4 line-clamp-3 flex-1 leading-relaxed">
                  {product.description}
                </p>
                
                {/* Price Section */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-baseline">
                    <span className="text-2xl font-bold text-green-600">ETB</span>
                    <span className="text-2xl font-bold text-green-600 ml-1">{product.price}</span>
                  </div>
                </div>
                
                {/* Action Buttons */}
                <div className="flex gap-2 mt-auto">
                  <button
                    onClick={() => handleEdit(product)}
                    className="flex-1 flex items-center justify-center px-3 py-2 bg-blue-500 text-white text-sm font-medium rounded-lg hover:bg-blue-600 transition-colors duration-200 shadow-sm"
                  >
                    <Edit2 className="h-4 w-4 mr-1" />
                    Edit
                  </button>
                  {(() => {
                    const isOutOfStock = product.quantity === 0;
                    return (
                      <button
                        onClick={() => toggleStockStatus(product.id)}
                        disabled={isOutOfStock}
                        className={`flex-1 flex items-center justify-center px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 shadow-sm ${
                          isOutOfStock
                            ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                            : product.inStock 
                              ? 'bg-orange-500 text-white hover:bg-orange-600' 
                              : 'bg-green-500 text-white hover:bg-green-600'
                        }`}
                      >
                        {isOutOfStock ? 'Out of Stock' : (product.inStock ? 'Out of Stock' : 'In Stock')}
                      </button>
                    );
                  })()}
                  <button
                    onClick={() => handleDelete(product.id)}
                    className="flex items-center justify-center px-2 py-1 border border-red-300 text-sm text-red-600 rounded hover:bg-red-50"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <Package className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {searchTerm.trim() === '' ? 'No products yet' : 'No products found'}
            </h3>
            <p className="text-gray-600 mb-4">
              {searchTerm.trim() === '' 
                ? 'Start by adding your first product' 
                : `No products match "${searchTerm}"`
              }
            </p>
          </div>
        )}
      </div>

      {/* Add/Edit Product Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-gray-900">
                  {editingProduct ? 'Edit Product' : 'Add New Product'}
                </h2>
                <button
                  onClick={() => {
                    setIsFormOpen(false);
                    resetForm();
                  }}
                  className="text-gray-400 hover:text-gray-500"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Image Upload */}
                <div>
                  <label htmlFor="image" className="block text-sm font-medium text-gray-700 mb-2">Product Image</label>
                  <div className="flex items-center gap-4">
                    {imagePreview ? (
                      <div className="relative">
                        <img
                          src={getImageUrl(imagePreview)}
                          alt="Product preview"
                          className="w-24 h-24 object-cover rounded-lg"
                          onError={(e) => {
                            console.error('Preview image failed to load:', getImageUrl(imagePreview), e);
                          }}
                          onLoad={() => {
                            console.log('Preview image loaded successfully:', getImageUrl(imagePreview));
                          }}
                        />
                        <button
                          type="button"
                          onClick={() => {
                            console.log('Clearing image preview');
                            setImagePreview('');
                            setFormData({ ...formData, image: '' });
                          }}
                          className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    ) : (
                      <div
                        onClick={() => fileInputRef.current?.click()}
                        className="w-24 h-24 border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-gray-400"
                      >
                        <ImageIcon className="h-8 w-8 text-gray-400 mb-1" />
                        <span className="text-xs text-gray-500">Add Image</span>
                      </div>
                    )}
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </div>
                </div>

                {/* Product Name and Quantity */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                      Product Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="block w-full px-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                      placeholder="Enter product name"
                    />
                  </div>

                  <div>
                    <label htmlFor="quantity" className="block text-sm font-medium text-gray-700 mb-2">
                      Quantity
                    </label>
                    <input
                      type="number"
                      id="quantity"
                      required
                      min="0"
                      value={formData.quantity}
                      onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                      className="block w-full px-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                      placeholder="1"
                    />
                  </div>
                </div>

                {/* Price and Category */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="price" className="block text-sm font-medium text-gray-700 mb-2">
                      Price (ETB) 
                    </label>
                    <input
                      type="number"
                      id="price"
                      required
                      min="0"
                      step="0.01"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                      className="block w-full px-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                      placeholder="0.00"
                    />
                  </div>
                  <div>
                    <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-2">
                      Category
                    </label>
                    <select
                      id="category"
                      required
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                      className="block w-full px-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                    >
                      {categories.map(category => (
                        <option key={category} value={category}>{category}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
                    Description
                  </label>
                  <textarea
                    id="description"
                    required
                    rows={4}
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                    placeholder="Describe your product..."
                  />
                </div>

                {/* Stock Status */}
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="inStock"
                    checked={formData.inStock}
                    onChange={(e) => setFormData({ ...formData, inStock: e.target.checked })}
                    className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                  />
                  <label htmlFor="inStock" className="ml-2 block text-sm text-gray-700">
                    In Stock
                  </label>
                </div>

                {/* Submit Buttons */}
                <div className="flex gap-3 pt-4">
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="flex-1 flex items-center justify-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isLoading ? (
                      <div className="flex items-center">
                        <Spinner size="sm" />
                        <span className="ml-2">{editingProduct ? 'Updating...' : 'Adding...'}</span>
                      </div>
                    ) : (
                      editingProduct ? 'Update Product' : 'Add Product'
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setIsFormOpen(false);
                      resetForm();
                    }}
                    className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VendorProductsPage;
