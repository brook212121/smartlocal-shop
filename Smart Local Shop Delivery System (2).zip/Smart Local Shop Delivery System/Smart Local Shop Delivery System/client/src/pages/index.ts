// Public pages
export { default as LoginPage } from './LoginPage';
export { default as RegisterPage } from './RegisterPage';
export { default as RegisterStep2Page } from './RegisterStep2Page';
export { default as ForgotPasswordPage } from './ForgotPasswordPage';
export { default as ResetPasswordPage } from './ResetPasswordPage';
export { default as VerifyEmailPage } from './VerifyEmailPage';

// Dashboard pages
export { default as ProductsPage } from './ProductsPage';
export { default as OrdersPage } from './OrdersPage';
export { default as CustomerOrderDetailsPage } from './OrderDetailsPage';
export { default as QuickOrdersPage } from './QuickOrdersPage';
export { default as VendorProductsPage } from './VendorProductsPage';
export { default as VendorDashboardPage } from './VendorDashboardPage';
export { default as VendorIndividualProductsPage } from './VendorIndividualProductsPage';
export { default as CustomerRequestsPage } from './CustomerRequestsPage';
export { default as OrdersReceivedPage } from './OrdersReceivedPage';
export { default as ProductDetailsPage } from './ProductDetailsPage';
export { default as OrderDeliveryOptionPage } from './OrderDeliveryOptionPage';

// Profile pages
export { default as UserProfilePage } from './UserProfile';
export { default as ChangePasswordPage } from './ChangePasswordPage';
export { default as WalletPage } from './Wallet';

// 404 page
export { default as NotFound } from './NotFound';
