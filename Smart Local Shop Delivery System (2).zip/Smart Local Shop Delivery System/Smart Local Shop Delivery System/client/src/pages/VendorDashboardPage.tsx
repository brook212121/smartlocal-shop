import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Package, MessageCircle, ShoppingCart, Wallet, User, DollarSign, TrendingUp } from 'lucide-react';
import { getApiUrl } from '../utils/apiConfig';
import { vendorService } from '../services/vendorService';
import { useToast } from '../contexts/ToastContext';
import { safeFetch, isUserOffline } from '../utils/errorHandler';

interface QuickOrder {
  id: string;
  description: string;
  image?: string;
  quantity?: number;
  status: 'OPEN' | 'CLOSED' | 'FULFILLED';
  createdAt: string;
  customerId: {
    firstName: string;
    lastName: string;
    email: string;
  };
}

interface VendorOrder {
  id: string;
  orderNumber: string;
  productName: string;
  quantity: number;
  price: number;
  status: 'PENDING' | 'ACCEPTED' | 'PREPARING' | 'READY' | 'DELIVERED' | 'CANCELLED';
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  totalAmount: number;
  createdAt: string;
}

interface WalletData {
  availableBalance: number;
  pendingBalance: number;
  totalEarned: number;
  totalWithdrawn: number;
  holdingPeriod: number;
}

const VendorDashboardPage = () => {
  const [activeTab, setActiveTab] = useState<'products' | 'requests' | 'orders' | 'wallet'>('products');
  const [quickOrders, setQuickOrders] = useState<QuickOrder[]>([]);
  const [vendorOrders, setVendorOrders] = useState<VendorOrder[]>([]);
  const [walletData, setWalletData] = useState<WalletData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showLocationBanner, setShowLocationBanner] = useState(false);
  const [locationStatus, setLocationStatus] = useState<'checking' | 'granted' | 'denied' | 'error'>('checking');
  const { handleApiResponse, handleApiError } = useToast();

  // Automatic location detection on component mount
  useEffect(() => {
    // Request location permission automatically
    const requestLocationPermission = async () => {
      if (!navigator.geolocation) {
        setLocationStatus('error');
        setShowLocationBanner(true);
        return;
      }
      
      setLocationStatus('checking');
      setShowLocationBanner(false);
      
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          try {
            const { latitude, longitude } = position.coords;
            
            if (typeof latitude === 'number' && typeof longitude === 'number' && 
                latitude !== 0 && longitude !== 0 && 
                !isNaN(latitude) && !isNaN(longitude)) {
              
              const location = {
                latitude: parseFloat(latitude.toFixed(6)),
                longitude: parseFloat(longitude.toFixed(6)),
                address: 'Auto-detected location'
              };
              
              // Check offline status before updating location
              if (isUserOffline()) {
                setLocationStatus('error');
                setShowLocationBanner(true);
                return;
              }
              
              await vendorService.updateVendorLocation(location);
              
              setLocationStatus('granted');
              setShowLocationBanner(false);
              
            } else {
              setLocationStatus('error');
              setShowLocationBanner(true);
            }
          } catch (error) {
            handleApiError(error);
            setLocationStatus('error');
            setShowLocationBanner(true);
          }
        },
        (error) => {
          console.warn('⚠️ AUTO: Geolocation error:', error);
          
          switch(error.code) {
            case error.PERMISSION_DENIED:
              console.log('🚫 AUTO: Location permission denied by user');
              setLocationStatus('denied');
              setShowLocationBanner(true);
              break;
            case error.POSITION_UNAVAILABLE:
              console.log('🚫 AUTO: Location information unavailable');
              setLocationStatus('error');
              setShowLocationBanner(true);
              break;
            case error.TIMEOUT:
              console.log('🚫 AUTO: Location request timed out');
              setLocationStatus('error');
              setShowLocationBanner(true);
              break;
            default:
              console.log('🚫 AUTO: Unknown geolocation error:', error.message);
              setLocationStatus('error');
              setShowLocationBanner(true);
              break;
          }
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 300000
        }
      );
    };
    
    // Start location detection
    requestLocationPermission();
  }, []); // Run only once on mount

  // Load wallet data on component mount
  useEffect(() => {
    const loadWalletData = async () => {
      try {
        console.log('� Loading wallet data...');
        const response = await fetch(getApiUrl('/api/vendors/wallet'), {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        });
        
        if (response.ok) {
          const data = await response.json();
          console.log('💰 Wallet data loaded:', data);
          setWalletData(data.data);
        } else {
          console.error('💰 Failed to load wallet data');
        }
      } catch (error) {
        console.error('💰 Error loading wallet data:', error);
      }
    };
    
    loadWalletData();
  }, []);

  // Fetch data functions
  const fetchQuickOrders = async () => {
    try {
      const response = await fetch(getApiUrl('/api/quick-orders/open'), {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        credentials: 'include'
      });

      if (response.ok) {
        const data = await response.json();
        setQuickOrders(data.data.quickOrders);
      }
    } catch (error) {
      console.error('Error fetching quick orders:', error);
    }
  };

  const fetchVendorOrders = async () => {
    try {
      const response = await fetch(getApiUrl('/api/vendor-orders'), {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        credentials: 'include'
      });

      if (response.ok) {
        const data = await response.json();
        setVendorOrders(data.data.orders);
      }
    } catch (error) {
      console.error('Error fetching vendor orders:', error);
    }
  };

  const acceptOrder = async (orderId: string) => {
    if (!confirm('Are you sure you want to accept this order?')) {
      return;
    }

    try {
      const response = await fetch(getApiUrl(`/api/orders/${orderId}/accept`), {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        },
        credentials: 'include'
      });

      if (response.ok) {
        handleApiResponse(response, 'Order accepted successfully!');
        fetchVendorOrders(); // Refresh orders
      } else {
        const errorData = await response.json();
        handleApiError(new Error(errorData.message || 'Failed to accept order'));
      }
    } catch (error) {
      console.error('Error accepting order:', error);
      handleApiError(error);
    }
  };

  const createOrderFromQuickOrder = async (quickOrderId: string) => {
    const productName = prompt('Enter product name:');
    const price = prompt('Enter price (ETB):');
    const quantity = prompt('Enter quantity:');
    const deliveryAddress = prompt('Enter delivery address:');

    if (!productName || !price || !quantity) {
      handleApiError(new Error('All fields are required'));
      return;
    }

    try {
      const response = await fetch(getApiUrl(`/api/orders/quick/${quickOrderId}`), {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({
          productName: productName.trim(),
          price: parseFloat(price),
          quantity: parseInt(quantity),
          deliveryAddress: deliveryAddress?.trim() || ''
        })
      });

      if (response.ok) {
        handleApiResponse(response, 'Order created successfully!');
        fetchQuickOrders(); // Refresh quick orders
        fetchVendorOrders(); // Refresh vendor orders
      } else {
        const errorData = await response.json();
        handleApiError(new Error(errorData.message || 'Failed to create order'));
      }
    } catch (error) {
      console.error('Error creating order:', error);
      handleApiError(error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'OPEN':
        return 'bg-green-100 text-green-800';
      case 'CLOSED':
        return 'bg-yellow-100 text-yellow-800';
      case 'FULFILLED':
        return 'bg-blue-100 text-blue-800';
      case 'PENDING':
        return 'bg-yellow-100 text-yellow-800';
      case 'ACCEPTED':
        return 'bg-blue-100 text-blue-800';
      case 'PREPARING':
        return 'bg-orange-100 text-orange-800';
      case 'READY':
        return 'bg-purple-100 text-purple-800';
      case 'DELIVERED':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const fetchWalletData = async () => {
    try {
      const response = await fetch('/api/withdrawals/balance', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setWalletData(data.data);
      }
    } catch (error) {
      console.error('Error fetching wallet data:', error);
    }
  };

  useEffect(() => {
    if (activeTab === 'requests') {
      fetchQuickOrders();
    } else if (activeTab === 'orders') {
      fetchVendorOrders();
    } else if (activeTab === 'wallet') {
      fetchWalletData();
    }
  }, [activeTab]);

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      {/* Location Banner */}
      {showLocationBanner && (
        <div className="mb-4 bg-yellow-50 border-l-4 border-yellow-400 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-yellow-700">
                {locationStatus === 'denied' 
                  ? 'Location permission denied. Enable location to receive orders from nearby customers.'
                  : 'Location access required. Enable location to receive orders from nearby customers.'
                }
              </p>
              <div className="mt-2">
                <button
                  onClick={() => {
                    // Retry location detection
                    setLocationStatus('checking');
                    setShowLocationBanner(false);
                    navigator.geolocation.getCurrentPosition(
                      async (position) => {
                        const { latitude, longitude } = position.coords;
                        if (typeof latitude === 'number' && typeof longitude === 'number' && 
                            latitude !== 0 && longitude !== 0 && 
                            !isNaN(latitude) && !isNaN(longitude)) {
                          const location = {
                            latitude: parseFloat(latitude.toFixed(6)),
                            longitude: parseFloat(longitude.toFixed(6)),
                            address: 'Auto-detected location'
                          };
                          await vendorService.updateVendorLocation(location);
                          setLocationStatus('granted');
                          setShowLocationBanner(false);
                        } else {
                          setLocationStatus('error');
                          setShowLocationBanner(true);
                        }
                      },
                      (error) => {
                        setLocationStatus('denied');
                        setShowLocationBanner(true);
                      }
                    );
                  }}
                  className="text-sm text-yellow-700 underline font-medium hover:text-yellow-800"
                >
                  Enable Location
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VendorDashboardPage;
