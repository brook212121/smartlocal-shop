import { useState, useEffect } from 'react';
import { ShoppingCart, Mail, MessageCircle, Send, X, ChevronDown } from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import { useAuth } from '../contexts/AuthContext'; // ✅ Import AuthContext
import { getApiUrl } from '../utils/apiConfig';
import { getImageUrl } from '../utils/imageUtils';
import Loading from '../components/common/Loading';

interface ChatMessage {
  _id: string;
  quickOrderId: string;
  senderId: string;
  senderType: 'VENDOR' | 'CUSTOMER';
  message: string;
  price?: number;
  createdAt: string;
  sender?: {
    firstName: string;
    lastName: string;
  };
}

interface CustomerQuickOrder {
  _id: string;
  orderNumber: string;
  customer: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
  };
  items: Array<{
    product: {
      name: string;
      price: number;
      description: string;
      quantity: number;
    };
    image?: string;
    status: 'OPEN' | 'CLOSED' | 'FULFILLED';
    createdAt: string;
  }>;
  responses?: Array<{
    vendorId: string;
    vendor: {
      _id: string;
      firstName: string;
      lastName: string;
      email: string;
      phone: string;
    };
    message: string;
    price: number;
    createdAt: string;
  }>;
  assignedVendor?: {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
  };
  status: 'OPEN' | 'CLOSED' | 'FULFILLED';
}

const CustomerQuickOrdersPage = () => {
  const { authState } = useAuth(); // ✅ Use AuthContext
  const token = authState.token; // ✅ Get token from AuthContext
  
  const [orders, setOrders] = useState<CustomerQuickOrder[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [expandedOrders, setExpandedOrders] = useState<Set<string>>(new Set());
  const [selectedOrderForChat, setSelectedOrderForChat] = useState<CustomerQuickOrder | null>(null);
  const [chatMessages, setChatMessages] = useState<{ [key: string]: ChatMessage[] }>({});
  const [newMessages, setNewMessages] = useState<{ [key: string]: string }>({});
  const [isSending, setIsSending] = useState<{ [key: string]: boolean }>({});
  const { handleApiResponse, handleApiError } = useToast();

  const fetchCustomerOrders = async () => {
    setIsLoading(true);
    try {
      console.log('Fetching Customer Quick Orders that vendors can respond to...');
      const response = await fetch(getApiUrl('/api/quick-orders/customer'), {
        headers: {
          'Authorization': `Bearer ${token}` // ✅ Use AuthContext token
        },
      });

      if (response.ok) {
        const data = await response.json();
        
        // Fetch responses for each order
        const ordersWithResponses = await Promise.all(
          data.data.map(async (order: CustomerQuickOrder) => {
            try {
              const responsesResponse = await fetch(getApiUrl(`/api/quick-orders/${order._id}/responses`), {
                headers: {
                  'Authorization': `Bearer ${token}` // ✅ Use AuthContext token
                },
              });

              if (responsesResponse.ok) {
                const responsesData = await responsesResponse.json();
                return { ...order, responses: responsesData.data || [] };
              }
              return order;
            } catch (error) {
              console.error('Error fetching responses:', error);
              return order;
            }
          })
        );

        console.log('Customer orders fetched:', ordersWithResponses);
        setOrders(ordersWithResponses);
      } else {
        const errorData = await response.json();
        handleApiError(new Error(errorData.message || 'Failed to fetch customer orders'));
      }
    } catch (error) {
      console.error('Error fetching customer orders:', error);
      handleApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleOrderExpansion = (orderId: string) => {
    setExpandedOrders(prev => {
      const newSet = new Set(prev);
      if (newSet.has(orderId)) {
        newSet.delete(orderId);
      } else {
        newSet.add(orderId);
      }
      return newSet;
    });
  };

  const openChatModal = async (order: CustomerQuickOrder) => {
    setSelectedOrderForChat(order);
    setExpandedOrders(prev => new Set(prev).add(order._id));
    // Fetch chat messages when opening modal
    await fetchChatMessages(order._id);
  };

  const fetchChatMessages = async (orderId: string) => {
    try {
      const response = await fetch(getApiUrl(`/api/quick-orders/${orderId}/chat`), {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
      });

      if (response.ok) {
        const data = await response.json();
        setChatMessages(prev => ({ ...prev, [orderId]: data.data || [] }));
      }
    } catch (error) {
      console.error('Error fetching chat messages:', error);
    }
  };

  const sendMessage = async (orderId: string) => {
    const message = newMessages[orderId];
    if (!message?.trim()) {
      alert('Please enter a message');
      return;
    }

    setIsSending(prev => ({ ...prev, [orderId]: true }));
    
    try {
      const response = await fetch(getApiUrl(`/api/quick-orders/${orderId}/chat`), {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: message.trim()
        })
      });

      if (response.ok) {
        // Clear input
        setNewMessages(prev => ({ ...prev, [orderId]: '' }));
        
        // Refresh chat messages
        await fetchChatMessages(orderId);
        
        handleApiResponse(response, 'Chat sent successfully! Your response has been delivered to the customer.');
      } else {
        const errorData = await response.json();
        handleApiError(new Error(errorData.message || 'Failed to send chat message'));
      }
    } catch (error) {
      console.error('Error sending chat message:', error);
      handleApiError(error);
    } finally {
      setIsSending(prev => ({ ...prev, [orderId]: false }));
    }
  };

  const acceptOrder = async (response: any) => {
    try {
      const orderResponse = await fetch(getApiUrl(`/api/orders/${response.quickOrderId}/accept`), {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({
          vendorId: response.vendorId,
          agreedPrice: response.price,
          quantity: response.quantity || 1,
          unitPrice: response.price
        })
      });

      if (orderResponse.ok) {
        handleApiResponse(orderResponse, 'Order accepted successfully!');
        fetchCustomerOrders(); // Refresh orders
      } else {
        const errorData = await orderResponse.json();
        handleApiError(new Error(errorData.message || 'Failed to accept order'));
      }
    } catch (error) {
      console.error('Error accepting order:', error);
      handleApiError(error);
    }
  };

  useEffect(() => {
    fetchCustomerOrders();
  }, []);

  if (isLoading) {
    return <Loading />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Customer Quick Orders</h1>
              <p className="text-gray-600 mt-1">Quick orders that customers have created (available for vendors to respond to)</p>
            </div>
          </div>

          <div className="space-y-4">
            {orders.length === 0 ? (
              <div className="text-center py-12">
                <div className="text-gray-500 text-lg mb-4">No customer orders available</div>
                <p className="text-gray-400">When customers create quick orders, they will appear here for vendors to respond to.</p>
              </div>
            ) : (
              orders.map((order: CustomerQuickOrder) => (
                <div key={order._id} className="border border-gray-200 rounded-lg p-4 mb-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">Order #{order.orderNumber}</h3>
                      <p className="text-sm text-gray-600">Created: {new Date(order.createdAt).toLocaleDateString()}</p>
                      <span className={`inline-block px-2 py-1 text-xs font-medium rounded-full ${
                        order.status === 'OPEN' ? 'bg-yellow-100 text-yellow-800' :
                        order.status === 'CLOSED' ? 'bg-gray-100 text-gray-800' :
                        'bg-green-100 text-green-800'
                      }`}>
                        {order.status}
                      </span>
                    </div>
                    <div className="text-right">
                      <button 
                        onClick={() => toggleOrderExpansion(order._id)}
                        className="text-blue-600 hover:text-blue-800 text-sm flex items-center"
                      >
                        <ChevronDown 
                          className={`w-4 h-4 transition-transform ${expandedOrders.has(order._id) ? 'rotate-180' : ''}`}
                        />
                      </button>
                    </div>
                  </div>

                  <div className="mb-3">
                    <p className="text-gray-700 font-medium mb-1">{order.items[0]?.product?.name || 'Product'}</p>
                    <p className="text-gray-600 text-sm mb-2">{order.items[0]?.product?.description || 'No description'}</p>
                    <p className="text-gray-600 text-sm mb-2">Quantity: {order.items[0]?.quantity || 1}</p>
                    {order.items[0]?.image && (
                      <img 
                        src={getImageUrl(order.items[0]?.image)} 
                        alt={order.items[0]?.product?.name || 'Product'} 
                        className="w-full h-48 object-cover rounded-lg mb-2"
                      />
                    )}
                  </div>

                  {order.assignedVendor && (
                    <div className="border-t border-gray-200 pt-3 mt-3">
                      <div className="flex items-center mb-2">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                          <ShoppingCart className="w-4 h-4 text-blue-600" />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-900">Assigned to: {order.assignedVendor.firstName} {order.assignedVendor.lastName}</p>
                          <p className="text-xs text-gray-500">{order.assignedVendor.email}</p>
                        </div>
                      </div>
                    </div>
                  )}

                  {expandedOrders.has(order._id) && (
                    <div className="border-t border-gray-200 pt-3">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-lg font-medium text-gray-900">Vendor Responses</h4>
                          <button 
                            onClick={() => setExpandedOrders(prev => {
                              const newSet = new Set(prev);
                              newSet.delete(order._id);
                              return newSet;
                            })}
                            className="text-gray-400 hover:text-gray-600"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>

                        {order.responses && order.responses.length > 0 ? (
                          order.responses.map((response: any) => (
                            <div key={response._id} className="border border-gray-200 rounded-lg p-3 mb-2">
                              <div className="flex justify-between items-start mb-2">
                                <div>
                                  <h5 className="font-medium text-gray-900">{response.vendor.firstName} {response.vendor.lastName}</h5>
                                  <p className="text-sm text-gray-600">Price: {response.price}</p>
                                  <p className="text-sm text-gray-700">{response.message}</p>
                                </div>
                                <div className="text-right">
                                  <button 
                                    onClick={() => acceptOrder(response)}
                                    className="bg-green-600 text-white px-3 py-2 rounded-lg hover:bg-green-700 text-sm"
                                  >
                                    Accept
                                  </button>
                                </div>
                              </div>
                            </div>
                          ))
                        ) : (
                          <div className="text-center py-4 text-gray-500">
                            No vendor responses Yet
                          </div>
                        )}
                      </div>

                      <div className="border-t border-gray-200 pt-3">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-lg font-medium text-gray-900">Chat</h4>
                          <button 
                            onClick={() => openChatModal(order)}
                            className="text-blue-600 hover:text-blue-800 text-sm flex items-center"
                          >
                            <MessageCircle className="w-4 h-4 mr-2" />
                            Chat
                          </button>
                        </div>
                      </div>

                      {expandedOrders.has(order._id) && selectedOrderForChat?._id === order._id && (
                        <div className="border-t border-gray-200 pt-3">
                          <div className="bg-gray-50 rounded-lg p-4">
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="text-lg font-medium text-gray-900">Chat with Customer</h4>
                              <button 
                                onClick={() => setExpandedOrders(prev => {
                                  const newSet = new Set(prev);
                                  newSet.delete(order._id);
                                  return newSet;
                                })}
                                className="text-gray-400 hover:text-gray-600"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>

                            <div className="space-y-2">
                              {chatMessages[order._id]?.map((message: ChatMessage) => (
                                <div key={message._id} className={`flex ${message.senderType === 'CUSTOMER' ? 'justify-end' : 'justify-start'} mb-2`}>
                                  <div className={`max-w-xs ${message.senderType === 'CUSTOMER' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'} rounded-lg px-3 py-2`}>
                                    <p className="text-sm">{message.message}</p>
                                    <p className="text-xs text-gray-500 mt-1">
                                      {new Date(message.createdAt).toLocaleString()}
                                    </p>
                              <div className="space-y-2">
                                {chatMessages[order._id]?.map((message: ChatMessage) => (
                                  <div key={message._id} className={`flex ${message.senderType === 'CUSTOMER' ? 'justify-end' : 'justify-start'} mb-2`}>
                                    <div className={`max-w-xs ${message.senderType === 'CUSTOMER' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'} rounded-lg px-3 py-2`}>
                                      <p className="text-sm">{message.message}</p>
                                      <p className="text-xs text-gray-500 mt-1">
                                        {new Date(message.createdAt).toLocaleString()}
                                      </p>
                                    </div>
                                  </div>
                                ))}
                              </div>

                              <div className="flex mt-2">
                                <input
                                  type="text"
                                  value={newMessages[order._id] || ''}
                                  onChange={(e) => setNewMessages(prev => ({ ...prev, [order._id]: e.target.value }))}
                                  placeholder="Type your message..."
                                  className="flex-1 px-3 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                />
                                <button
                                  onClick={() => sendMessage(order._id)}
                                  disabled={isSending[order._id]}
                                  className="bg-blue-600 text-white px-3 py-2 rounded-l-md hover:bg-blue-700 disabled:opacity-50"
                                >
                                  {isSending[order._id] ? (
                                    <span className="flex items-center">
                                      <Send className="w-4 h-4 mr-2 animate-spin" />
                                      Sending...
                                    </span>
                                  ) : (
                                    <span className="flex items-center">
                                      <Send className="w-4 h-4 mr-2" />
                                      Send
                                    </span>
                                  )}
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CustomerQuickOrdersPage;
