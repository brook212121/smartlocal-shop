import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ShoppingCart, Package, User, Phone, Heart } from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import api from '../services/api';
import { getImageUrl } from '../utils/imageUtils';
import Loading from '../components/common/Loading';
import RelatedProducts from '../components/RelatedProducts';
import activityService from '../services/activityService';

interface Product {
  _id: string;
  name: string;
  price: number;
  description: string;
  category: string;
  images: string[];
  vendor: {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone?: string;
  };
  stock?: {
    quantity: number;
  };
}

const ProductDetailsPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [liked, setLiked] = useState(false);
  const [totalLikes, setTotalLikes] = useState(0);
  const [likeLoading, setLikeLoading] = useState(false);
  const { handleApiError } = useToast();

  useEffect(() => {
    if (id) {
      fetchProduct(id);
    }
  }, [id]);

  useEffect(() => {
    // Start tracking when product loads
    if (product && id) {
      activityService.startProductView(id);
    }

    // Cleanup function to track view duration when leaving
    return () => {
      if (product && id) {
        activityService.endProductView(id, product.name, product.category, product.vendor._id);
      }
    };
  }, [product, id]);

  const fetchProduct = async (productId: string) => {
    try {
      setIsLoading(true);
      const response = await api.get(`/products/public/${productId}`);
      setProduct(response.data.data.product);
    } catch (error) {
      console.error('Error fetching product:', error);
      handleApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePlaceOrder = () => {
    if (!product) return;
    
    // Track order activity
    activityService.trackOrder(product._id, product.name, product.category, product.vendor._id);
    
    // Navigate to delivery option page with order data
    navigate('/order/delivery-option', {
      state: {
        productId: product._id,
        productName: product.name,
        quantity: quantity,
        unitPrice: product.price,
        subtotal: product.price * quantity
      }
    });
  };

  const handleQuantityChange = (value: number) => {
    if (value >= 1 && value <= 99) {
      setQuantity(value);
    }
  };

  const fetchProductLikes = async () => {
    if (!id) return;
    
    try {
      const response = await api.get(`/products/${id}/likes`);
      if (response.data.success) {
        setLiked(response.data.data.likedByUser);
        setTotalLikes(response.data.data.totalLikes);
      }
    } catch (error) {
      console.error('Error fetching product likes:', error);
    }
  };

  const toggleLike = async () => {
    if (!id || likeLoading) return;
    
    try {
      setLikeLoading(true);
      const response = await api.post(`/products/${id}/like`);
      if (response.data.success) {
        setLiked(response.data.data.liked);
        setTotalLikes(response.data.data.totalLikes);
      }
    } catch (error) {
      handleApiError(error);
    } finally {
      setLikeLoading(false);
    }
  };

  useEffect(() => {
    if (id) {
      fetchProductLikes();
    }
  }, [id]);

  if (isLoading) return <Loading />;

  if (!product) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-center">
          <Package className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Product not found</h3>
          <p className="text-gray-500 mb-4">The product you're looking for doesn't exist.</p>
          <button
            onClick={() => navigate('/products')}
            className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700"
          >
            Back to Products
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <img
                src={getImageUrl(product.images[selectedImage])}
                alt={product.name}
                loading="lazy"
                className="w-full h-96 object-cover"
              />
            </div>
          </div>

          {/* Product Information */}
          <div className="space-y-6 max-h-[96vh] overflow-y-auto pr-2">
            {/* Product Header */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900 mb-2">{product.name}</h1>
                  <div className="flex items-center space-x-4">
                   
                  </div>
                </div>
                
                {/* Like Button and Count */}
                <div className="flex items-center space-x-2">
                  <button
                    onClick={toggleLike}
                    disabled={likeLoading}
                    className={`flex items-center space-x-1 rounded-full p-2 shadow-md transition-colors ${
                      liked ? 'text-red-500 bg-red-50' : 'text-gray-400 hover:text-red-500 bg-gray-50'
                    } ${likeLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                    aria-label={liked ? 'Unlike product' : 'Like product'}
                  >
                    <Heart 
                      className={`h-5 w-5 ${liked ? 'fill-current' : ''}`} 
                    />
                  </button>
                  
                  <div className="flex items-center bg-white rounded-full px-3 py-1 shadow-md text-sm font-medium">
                    <span className="ml-1">{totalLikes}</span>
                  </div>
                </div>
              </div>

              <p className="text-gray-600 leading-relaxed mb-4">{product.description}</p>
            </div>

            {/* Vendor Information */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Vendor Information</h3>
              <div className="space-y-3">
                <div className="flex items-center">
                  <button
                    onClick={() => navigate(`/dashboard/vendor/${product.vendor._id}`)}
                    className="flex items-center text-blue-600 hover:text-blue-800 transition-colors"
                    title="View Vendor Profile"
                  >
                    <User className="h-5 w-5 text-gray-400 mr-3 hover:text-blue-600 transition-colors" />
                  </button>
                  <div>
                    <div className="font-medium text-gray-900">
                      {product.vendor.firstName} {product.vendor.lastName}
                    </div>
                    <div className="text-sm text-gray-500">{product.vendor.email}</div>
                  </div>
                </div>
                {product.vendor.phone && (
                  <div className="flex items-center">
                    <Phone className="h-5 w-5 text-gray-400 mr-3" />
                    <span className="text-gray-900">{product.vendor.phone}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Order Section */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Place Order</h3>
              
              <div className="space-y-4">
                {/* Quantity Selector */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Quantity</label>
                  <div className="flex items-center space-x-3">
                    <button
                      onClick={() => handleQuantityChange(quantity - 1)}
                      disabled={quantity <= 1}
                      className="w-10 h-10 rounded-md border border-gray-300 flex items-center justify-center hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      -
                    </button>
                    <input
                      type="number"
                      min="1"
                      max={99}
                      value={quantity}
                      onChange={(e) => handleQuantityChange(parseInt(e.target.value) || 1)}
                      className="w-20 text-center border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                    <button
                      onClick={() => handleQuantityChange(quantity + 1)}
                      className="w-10 h-10 rounded-md border border-gray-300 flex items-center justify-center hover:bg-gray-50"
                    >
                      +
                    </button>
                  </div>
                  <p className="text-sm text-gray-500 mt-1">
                    Quantity: {quantity} units
                  </p>
                </div>

                {/* Price Summary */}
                <div className="border-t border-gray-200 pt-4">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-gray-600">Total Price:</span>
                    <span className="text-2xl font-bold text-green-600">
                      ETB {product.price * quantity}
                    </span>
                  </div>
                </div>

                {/* Place Order Button */}
                <button
                  onClick={handlePlaceOrder}
                  className="w-full bg-green-600 text-white py-3 px-4 rounded-md hover:bg-green-700 transition-colors font-medium text-lg"
                >
                  <ShoppingCart className="h-5 w-5 mr-2 inline" />
                  Place Order
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Horizontal Divider - Same width as main content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="border-t border-gray-300 my-8"></div>
      </div>
      
      {/* Related Products Section - Inside main container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <RelatedProducts productId={product._id} />
      </div>
    </div>
  );
};

export default ProductDetailsPage;
