import { useState, useEffect, useRef, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Package, Clock, CheckCircle, XCircle, Truck, Eye, Search, X, Camera } from 'lucide-react';
import Spinner from '../components/ui/Spinner';
import { useToast } from '../contexts/ToastContext';
import { useAuth } from '../contexts/AuthContext';
import { useQuery } from '@tanstack/react-query';
import api from '../services/api';
import { getImageUrl, getFallbackImageUrl } from '../utils/imageUtils';
import DeliveryValidationModal from '../components/delivery/DeliveryValidationModal';

interface Order {
  _id: string;
  orderNumber: string;
  createdAt: string;
  status: 'PENDING' | 'CONFIRMED' | 'PREPARING' | 'READY_FOR_PICKUP' | 'OUT_FOR_DELIVERY' | 'DELIVERED' | 'CANCELLED';
  pricing: {
    total: number;
    currency: string;
  };
  items: OrderItem[];
  delivery: {
    address: {
      street: string;
      city: string;
      county: string;
    };
  };
  deliveryOTP?: string;
  otpGeneratedAt?: string;
  otpSent?: boolean;
  otpVerified?: boolean;
  vendor?: {
    firstName: string;
    lastName: string;
  };
  deliveryValidation?: {
    validated: boolean;
    validatedAt?: string;
    match?: boolean;
    confidence?: number;
    reason?: string;
    deliveryImage?: string;
  };
}

interface OrderItem {
  product: {
    _id: string;
    name: string;
    images: string[];
  };
  quantity: number;
  price: number;
}

const OrdersPage = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [userLocation, setUserLocation] = useState<string>('');
  const [addressLoading, setAddressLoading] = useState(false);
  const [sendingOTP, setSendingOTP] = useState<string | null>(null);
  const [isValidationModalOpen, setIsValidationModalOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const { handleApiError, handleApiResponse } = useToast();
  const { authState } = useAuth();
  
  // 🔧 PERFORMANCE FIX: Request deduplication refs
  const isFetchingLocation = useRef(false);
  
  // 🔧 PERFORMANCE FIX: React Query for orders with caching and deduplication
  const { data: ordersData, isLoading, error, refetch } = useQuery({
    queryKey: ['orders', authState.user?._id],
    queryFn: async () => {
      const response = await api.get('/orders');
      return response.data.data.orders || [];
    },
    enabled: !!authState.isAuthenticated && !!authState.user,
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000, // 10 minutes (gcTime replaced cacheTime)
    retry: 2,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
  });
  
  const orders = ordersData || [];
  
  // Filter orders with OTP for debugging
  const ordersWithOTP = orders.filter((order: Order) => order.status === 'OUT_FOR_DELIVERY' && order.deliveryOTP);
  
  // 🔧 PERFORMANCE FIX: Memoized filtered orders to prevent unnecessary re-renders
  const filteredOrders = useMemo(() => {
    if (!searchTerm.trim()) return orders;
    
    return orders.filter((order: Order) => 
      order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.items.some((item: OrderItem) => 
        item.product.name.toLowerCase().includes(searchTerm.toLowerCase())
      ) ||
      order.status.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [orders, searchTerm]);
  
  // 🔧 PERFORMANCE FIX: Get user location with deduplication
  useEffect(() => {
    // Prevent duplicate location requests
    if (isFetchingLocation.current || userLocation) return;
    
    const fetchLocation = async () => {
      if (!navigator.geolocation) {
        setUserLocation('Geolocation not supported');
        return;
      }
      
      isFetchingLocation.current = true;
      setAddressLoading(true);
      
      try {
        const position = await new Promise<GeolocationPosition>((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject);
        });
        
        const { latitude, longitude } = position.coords;
        
        // Use Google Maps Geocoding API
        const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
        
        if (!apiKey) {
          setUserLocation('Address unavailable');
          return;
        }
        
        const response = await fetch(
          `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${apiKey}`
        );
        
        const data = await response.json();
        
        if (data.status === 'OK' && data.results && data.results.length > 0) {
          const formattedAddress = data.results[0].formatted_address;
          setUserLocation(formattedAddress);
        } else {
          setUserLocation('Address unavailable');
        }
      } catch (error) {
        console.error('Error fetching address:', error);
        setUserLocation('Address unavailable');
      } finally {
        setAddressLoading(false);
        isFetchingLocation.current = false;
      }
    };
    
    fetchLocation();
  }, [userLocation]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'PENDING':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case 'CONFIRMED':
        return <CheckCircle className="h-4 w-4 text-blue-500" />;
      case 'PREPARING':
        return <Package className="h-4 w-4 text-orange-500" />;
      case 'READY_FOR_PICKUP':
        return <Package className="h-4 w-4 text-purple-500" />;
      case 'OUT_FOR_DELIVERY':
        return <Truck className="h-4 w-4 text-indigo-500" />;
      case 'DELIVERED':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'CANCELLED':
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PENDING':
        return 'bg-yellow-100 text-yellow-800';
      case 'CONFIRMED':
        return 'bg-blue-100 text-blue-800';
      case 'PREPARING':
        return 'bg-orange-100 text-orange-800';
      case 'READY_FOR_PICKUP':
        return 'bg-purple-100 text-purple-800';
      case 'OUT_FOR_DELIVERY':
        return 'bg-indigo-100 text-indigo-800';
      case 'DELIVERED':
        return 'bg-green-100 text-green-800';
      case 'CANCELLED':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const handleOpenValidationModal = (order: Order) => {
    setSelectedOrder(order);
    setIsValidationModalOpen(true);
  };

  const handleCloseValidationModal = () => {
    setSelectedOrder(null);
    setIsValidationModalOpen(false);
  };

  const handleSendOTP = async (orderId: string) => {
    try {
      setSendingOTP(orderId);
      
      // Safety check for token
      if (!authState.token) {
        throw new Error('No authentication token found. Please log in again.');
      }
      
      // Call send OTP API
      const response = await fetch('/api/orders/send-otp', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authState.token}`
        },
        body: JSON.stringify({ orderId })
      });

      const result = await response.json();

      if (result.success) {
        // Invalidate and refetch orders to get updated data
        refetch();
        handleApiResponse(null, 'OTP sent successfully!');
      } else {
        console.error(`[OTP] Send OTP failed: ${result.message}`);
        handleApiError(new Error(result.message));
      }
    } catch (error) {
      console.error('Error sending OTP:', error);
      handleApiError(error);
    } finally {
      setSendingOTP(null);
    }
  };

  // Create display string with product names before vendor name
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // ✅ Restore getVendorDisplay function (used in JSX)
  const getVendorDisplay = (order: Order) => {
    const productNames = order.items.map(item => item.product?.name || '').join(', ');
    const vendorName = order.vendor ? `${order.vendor.firstName} ${order.vendor.lastName}` : 'Unknown Vendor';
    
    if (productNames) {
      return `${productNames}\n${vendorName}`;
    }
    return vendorName;
  };

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      <div className="mb-8">
        
        {/* Search and Filters */}
        <div className="mb-6">
          <div className="relative max-w-md">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                }
              }}
              className="block w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
              placeholder="Search orders..."
              autoComplete="off"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600 transition-colors duration-200"
                title="Clear search"
              >
                <X className="h-5 w-5" />
              </button>
            )}
          </div>
          {searchTerm && (
            <div className="mt-2 text-sm text-gray-600">
              Found {filteredOrders.length} orders matching "{searchTerm}"
            </div>
          )}
        </div>

        {/* Orders List */}
        {error ? (
          <div className="text-center py-12">
            <div className="text-red-500 mb-4">Error loading orders</div>
            <p className="text-gray-600">{error instanceof Error ? error.message : 'Unknown error'}</p>
            <button 
              onClick={() => refetch()}
              className="mt-4 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
            >
              Retry
            </button>
          </div>
        ) : isLoading || (orders.length === 0 && !error) ? (
          <div className="flex justify-center items-center py-12">
            <Spinner size="lg" />
          </div>
        ) : filteredOrders.length === 0 ? (
          <div className="text-center py-12">
            <Package className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-900">No orders found</h3>
            <p className="mt-1 text-sm text-gray-500">
              {searchTerm ? 'Try adjusting your search' : 'You haven\'t placed any orders yet'}
            </p>
          </div>
        ) : (
        <div className="space-y-4">
          {filteredOrders.map((order: Order) => (
            <div key={order._id} className="bg-white rounded-lg shadow-md p-4 sm:p-6 hover:shadow-lg transition-shadow">
              <div className="flex flex-col sm:flex-row gap-4 sm:gap-6">
                {/* Product Image - Fixed size and proper spacing */}
                <div className="flex-shrink-0">
                  {order.items.length > 0 && order.items[0].product && (
                    <img
                      src={getImageUrl(order.items[0].product.images?.[0])}
                      alt={order.items[0].product?.name || 'Product image'}
                      loading="lazy"
                      className="w-32 h-32 sm:w-40 sm:h-40 object-contain rounded-lg bg-gray-50 p-2"
                      onError={(e) => {
                        console.error('Order image failed to load:', order.items[0].product.images?.[0], e);
                        (e.target as HTMLImageElement).src = getFallbackImageUrl();
                      }}
                    />
                  )}
                </div>
                
                {/* All Text Information */}
                <div className="flex-1 min-w-0">
                  {/* Order Header */}
                  <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between mb-3">
                    <div>
                      <h3 className="font-semibold text-gray-900">{order.orderNumber}</h3>
                      <p className="text-sm text-gray-500">{formatDate(order.createdAt)}</p>
                    </div>
                    <div className="flex items-center gap-2 mt-2 sm:mt-0">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                        {getStatusIcon(order.status)}
                        <span className="ml-1 capitalize">{order.status.toLowerCase()}</span>
                      </span>
                    </div>
                  </div>
                  
                  {/* Vendor and Delivery Info */}
                  <div className="mb-3">
                    <div className="flex flex-col space-y-2">
                      <div className="text-sm text-gray-600">
                        <span className="font-semibold">{getVendorDisplay(order).split('\n')[0]}</span>
                      </div>
                      {getVendorDisplay(order).split('\n')[1] && (
                        <div className="text-sm text-gray-600">
                          Vendor: {getVendorDisplay(order).split('\n')[1]}
                        </div>
                      )}
                      <div className="font-semibold text-green-600">{order.pricing?.currency || 'ETB'} {order.pricing?.total || 0}</div>
                    </div>
                    <p className="text-sm text-gray-600">
                      {addressLoading ? (
                        <span className="flex items-center">
                          <Spinner size="sm" />
                          <span className="ml-2">Getting address...</span>
                        </span>
                      ) : (
                        <>
                          {/* Clean address display - prioritize Google Maps result */}
                          {(() => {
                            // Build address parts array
                            const addressParts = [];
                            
                            // Always prioritize Google Maps result
                            if (userLocation) {
                              addressParts.push(userLocation);
                            }
                            
                            
                            // If no userLocation, fallback to order address
                            if (!userLocation && order.delivery?.address) {
                              if (order.delivery.address.street) addressParts.push(order.delivery.address.street);
                              if (order.delivery.address.city) addressParts.push(order.delivery.address.city);
                              if (order.delivery.address.county) addressParts.push(order.delivery.address.county);
                            }
                            
                            return addressParts.join(', ');
                          })()}
                        </>
                      )}
                    </p>
                  </div>
                  
                                    
                  {/* Action Buttons */}
                  <div className="flex flex-col sm:flex-row gap-2">
                    <button
                      onClick={() => navigate(`/dashboard/orders/${order._id}`)}
                      className="flex items-center justify-center px-4 py-2 border border-gray-300 text-sm text-gray-700 rounded-md hover:bg-gray-50"
                    >
                      <Eye className="h-4 w-4 mr-1" />
                      View Details
                    </button>
                    <button
                      onClick={() => handleOpenValidationModal(order)}
                      className="flex items-center justify-center px-4 py-2 bg-green-600 text-white text-sm rounded-md hover:bg-green-700"
                    >
                      <Camera className="h-4 w-4 mr-1" />
                      Proof
                    </button>
                  </div>
                  
                  {/* OTP Section for Picked Up Orders */}
                  {order.status === 'OUT_FOR_DELIVERY' && order.deliveryOTP && (
                    <div className="mt-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-3">
                        {/* Left: Text */}
                        <div>
                          <div className="font-medium text-gray-900 text-sm sm:text-base">Delivery Confirmation Code</div>
                          <div className="text-xs text-gray-400 sm:text-sm">Share this code with your delivery agent</div>
                        </div>

                        {/* Right: OTP + Button */}
                        <div className="flex items-center gap-3">
                          <div className="px-3 py-1.5 text-sm sm:text-base font-semibold text-green-600 border border-green-500 rounded-md inline-block">
                            {order.deliveryOTP}
                          </div>

                          <button
                            onClick={() => handleSendOTP(order._id)}
                            disabled={sendingOTP === order._id}
                            className="w-full sm:w-auto px-4 py-2 text-sm font-medium bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            {sendingOTP === order._id ? (
                              <>
                                <Spinner size="sm" />
                                Sending OTP...
                              </>
                            ) : (
                              <>
                                <Package className="h-4 w-4 mr-2" />
                                Send OTP
                              </>
                            )}
                          </button>
                        </div>
                      </div>

                      {/* Status Message */}
                      {!order.otpSent ? (
                        <span className="text-xs text-gray-400">Waiting for delivery...</span>
                      ) : (
                        <div className="text-center">
                          <div className="text-sm text-green-600 font-medium">OTP Sent to agent</div>
                          <div className="text-xs text-gray-500">Delivery agent can now confirm delivery</div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
        )}
      </div>
      
      {/* Delivery Validation Modal */}
      {selectedOrder && (
        <DeliveryValidationModal
          isOpen={isValidationModalOpen}
          onClose={handleCloseValidationModal}
          orderId={selectedOrder._id}
          productName={selectedOrder.items[0]?.product?.name || 'Unknown Product'}
          productImage={getImageUrl(selectedOrder.items[0]?.product?.images?.[0])}
          initialValidationState={selectedOrder.deliveryValidation}
        />
      )}
    </div>
  );
};

export default OrdersPage;
