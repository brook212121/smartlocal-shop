import React, { useState, useEffect } from 'react';
import Loading from '../components/common/Loading';
import { Wallet, TrendingUp, ArrowDownRight, Clock, CheckCircle } from 'lucide-react';
import { getApiUrl } from '../utils/apiConfig';
import { useAuth } from '../contexts/AuthContext';
import VendorAnalytics from '../components/wallet/VendorAnalytics';

interface WalletData {
  totalEarned: number;
  availableBalance: number;
  pendingBalance: number;
  totalWithdrawn: number;
  holdingPeriod: number;
}

const WalletPage: React.FC = () => {
  const [walletData, setWalletData] = useState<WalletData | null>(null);
  const [loading, setLoading] = useState(true);
  
  // Use auth context for token
  const { authState } = useAuth();
  const { token, isAuthenticated, isLoading } = authState;

  console.log('🔍 WalletPage render - Auth state:', { token: token ? 'present' : 'missing', isAuthenticated, isLoading });

  useEffect(() => {
    if (!isLoading && isAuthenticated) {
      fetchWalletData();
    }
  }, [isLoading, isAuthenticated]);

  const fetchWalletData = async () => {
    try {
      if (!token) {
        throw new Error('Authentication token required');
      }
      
      const response = await fetch(getApiUrl('/api/withdrawals/balance'), {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setWalletData(data.data);
      }
    } catch (error) {
      console.error('Error fetching wallet data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ET', {
      style: 'currency',
      currency: 'ETB',
      minimumFractionDigits: 0
    }).format(amount);
  };

  if (loading) return <Loading />;

  return (
    <div className="p-3">
      {/* Overview Content */}
      <div className="space-y-8">
          {/* Quick Balance Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg shadow-lg p-6 border border-green-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-green-800">Available Balance</p>
                  <p className="text-2xl font-bold text-green-900">
                    {walletData ? formatCurrency(walletData.availableBalance) : 'ETB 0'}
                  </p>
                  <div className="flex items-center mt-2">
                    <CheckCircle className="h-4 w-4 text-green-600 mr-1" />
                    <span className="text-xs text-green-700">Released and withdrawable</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-lg shadow-lg p-6 border border-yellow-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-yellow-800">Pending Balance</p>
                  <p className="text-2xl font-bold text-yellow-900">
                    {walletData ? formatCurrency(walletData.pendingBalance) : 'ETB 0'}
                  </p>
                  <div className="flex items-center mt-2">
                    <Clock className="h-4 w-4 text-yellow-600 mr-1" />
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-6 border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Earned</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {walletData ? formatCurrency(walletData.totalEarned) : 'ETB 0'}
                  </p>
                  <div className="flex items-center mt-2">
                    <TrendingUp className="h-4 w-4 text-blue-600 mr-1" />
                    <span className="text-xs text-gray-500">Total sales revenue</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-lg p-6 border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Withdrawn</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {walletData ? formatCurrency(walletData.totalWithdrawn) : 'ETB 0'}
                  </p>
                  <div className="flex items-center mt-2">
                    <ArrowDownRight className="h-4 w-4 text-purple-600 mr-1" />
                    <span className="text-xs text-gray-500">Actual amount received (after fees)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Vendor Analytics */}
          <VendorAnalytics />

          {/* How It Works */}
          {walletData && (
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg shadow-lg p-6 border border-blue-200">
              <h2 className="text-xl font-bold text-blue-900 mb-6 flex items-center">
                <Wallet className="h-6 w-6 mr-2" />
                How It Works
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white rounded-lg p-4">
                  <div className="flex items-center mb-3">
                    <div className="bg-green-100 rounded-full p-2 mr-3">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900">1. User Pays</h3>
                  </div>
                  <p className="text-gray-700">When User purchase your products, the full payment amount is added to your Total Earned and Pending Balance for 1 week.</p>
                </div>
                <div className="bg-white rounded-lg p-4">
                  <div className="flex items-center mb-3">
                    <div className="bg-yellow-100 rounded-full p-2 mr-3">
                      <Clock className="h-5 w-5 text-yellow-600" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900">2. Funds Released</h3>
                  </div>
                  <p className="text-gray-700">After 1 week, funds move from Pending Balance to Available Balance and become withdrawable.</p>
                </div>
                <div className="bg-white rounded-lg p-4">
                  <div className="flex items-center mb-3">
                    <div className="bg-blue-100 rounded-full p-2 mr-3">
                      <Wallet className="h-5 w-5 text-blue-600" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900">3. Withdrawal Processed</h3>
                  </div>
                  <p className="text-gray-700">When you withdraw, platform fee (5%) is deducted and you receive the net amount. Total Withdrawn shows actual amount received.</p>
                </div>
              </div>
            </div>
          )}
        </div>
    </div>
  );
};

export default WalletPage;
