import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, Truck, Package, CreditCard } from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';
import Spinner from '../components/ui/Spinner';

interface DeliveryOptionState {
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
}

const OrderDeliveryOptionPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { handleApiError } = useToast();
  const { authState } = useAuth();

  // Get order data from location state
  const orderData = location.state as DeliveryOptionState;

  const [requiresDelivery, setRequiresDelivery] = useState(true); // Default to YES
  const [isProcessing, setIsProcessing] = useState(false);

  // Calculate pricing
  const deliveryFee = requiresDelivery ? orderData?.subtotal * 0.02 : 0;
  const finalTotal = orderData?.subtotal + deliveryFee;

  useEffect(() => {
    if (!orderData) {
      navigate('/dashboard/products');
      return;
    }
  }, [orderData, navigate]);

  const handleContinueToPayment = async () => {
    if (!orderData) return;

    setIsProcessing(true);
    
    try {
      // GET REAL USER GPS COORDINATES
      const coords = await new Promise<{ latitude: number; longitude: number }>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const userCoords = {
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
            };
            
            // DEBUG LOG: Log real user location
            console.log('REAL USER LOCATION:', userCoords);
            
            resolve(userCoords);
          },
          (error) => {
            console.error('Location error:', error);
            reject(new Error('Location access denied. Please enable location services.'));
          },
          {
            enableHighAccuracy: true
          }
        );
      });

      // VALIDATE COORDINATES EXIST
      if (!coords.latitude || !coords.longitude) {
        throw new Error('User location is required');
      }

      // Create order first
      const userAddress = authState.user?.defaultAddress;
      const deliveryAddress = {
        street: userAddress?.street || 'Customer Address',
        city: userAddress?.city || 'Addis Ababa',
        state: userAddress?.county || 'Addis Ababa',
        postalCode: '1000',
        phone: authState.user?.phone || '+251912345678',
        coordinates: coords // ✅ REAL USER COORDINATES
      };

      // DEBUG LOG: Log coordinates being sent
      console.log('Sending coordinates:', coords);

      const orderResponse = await api.post('/orders', {
        productId: orderData.productId,
        quantity: orderData.quantity,
        deliveryAddress,
        orderNotes: `Order for ${orderData.productName} - ${requiresDelivery ? 'Delivery Required' : 'Pickup'}`,
        requiresDelivery: requiresDelivery,
        deliveryFee: deliveryFee,
        subtotal: orderData.subtotal,
        totalAmount: finalTotal,
        // Ensure all required fields are present
        customerName: authState.user?.firstName || 'Customer',
        customerEmail: authState.user?.email || 'customer@example.com',
        customerPhone: authState.user?.phone || '+251912345678'
      });

      if (orderResponse.data.success) {
        const createdOrder = orderResponse.data.data.order;
        
        // Navigate to payment page with orderId
        navigate(`/payment?orderId=${createdOrder._id}`);
      } else {
        handleApiError(new Error(orderResponse.data.message || 'Failed to create order'));
      }
    } catch (error) {
      console.error('Error creating order:', error);
      handleApiError(error);
    } finally {
      setIsProcessing(false);
    }
  };

  if (!orderData) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-center">
          <p className="text-gray-500 mb-4">No order data found</p>
          <button
            onClick={() => navigate('/dashboard/products')}
            className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700"
          >
            Browse Products
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center mb-8">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center text-gray-600 hover:text-gray-900 mr-4"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">Delivery Options</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Column - Order Summary */}
          <div className="space-y-6">
            {/* Order Summary */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Order Summary</h3>
              
              {/* Product Details */}
              <div className="space-y-4">
                <div className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg">
                  <div className="flex-shrink-0">
                    <Package className="h-12 w-12 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900">{orderData.productName}</h4>
                    <div className="flex items-center space-x-4 mt-2">
                      <span className="text-sm text-gray-500">Quantity: {orderData.quantity}</span>
                      <span className="text-sm text-gray-500">Unit Price: ETB {orderData.unitPrice}</span>
                    </div>
                  </div>
                </div>

                {/* Price Breakdown */}
                <div className="border-t border-gray-200 pt-4 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Subtotal</span>
                    <span className="font-medium">ETB {orderData.subtotal.toFixed(2)}</span>
                  </div>
                  
                  {requiresDelivery && (
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600 flex items-center">
                        <Truck className="h-4 w-4 mr-1" />
                        Delivery Fee (2%)
                      </span>
                      <span className="font-medium text-green-600">ETB {deliveryFee.toFixed(2)}</span>
                    </div>
                  )}
                </div>

                {/* Total */}
                <div className="border-t border-gray-200 pt-4">
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-semibold text-gray-900">Total Amount</span>
                    <span className="text-2xl font-bold text-green-600">
                      ETB {finalTotal.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Delivery Options */}
          <div className="space-y-6">
            {/* Delivery Option Selection */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center mb-4">
                <Truck className="h-5 w-5 text-green-600 mr-2" />
                <h3 className="text-lg font-semibold text-gray-900">Delivery Option</h3>
              </div>
              
              <div className="space-y-4">
                <div>
                  <p className="text-gray-700 font-medium mb-3">Do you want a delivery person?</p>
                  
                  <div className="space-y-3">
                    <label className="flex items-center p-4 border-2 rounded-lg cursor-pointer transition-colors hover:bg-gray-50">
                      <input
                        type="radio"
                        name="delivery"
                        checked={requiresDelivery}
                        onChange={() => setRequiresDelivery(true)}
                        className="sr-only"
                      />
                      <div className="flex items-center justify-between w-full">
                        <div className="flex items-center">
                          <div className="w-4 h-4 border-2 border-green-600 rounded-full mr-3 flex items-center justify-center">
                            {requiresDelivery && (
                              <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                            )}
                          </div>
                          <div>
                            <span className="font-medium text-gray-900">YES</span>
                            <p className="text-sm text-gray-500">Professional delivery service</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="text-sm text-gray-500">Add 2% fee</span>
                          <div className="font-semibold text-green-600">
                            +{(orderData.subtotal * 0.02).toFixed(2)} ETB
                          </div>
                        </div>
                      </div>
                    </label>

                    <label className="flex items-center p-4 border-2 rounded-lg cursor-pointer transition-colors hover:bg-gray-50">
                      <input
                        type="radio"
                        name="delivery"
                        checked={!requiresDelivery}
                        onChange={() => setRequiresDelivery(false)}
                        className="sr-only"
                      />
                      <div className="flex items-center justify-between w-full">
                        <div className="flex items-center">
                          <div className="w-4 h-4 border-2 border-green-600 rounded-full mr-3 flex items-center justify-center">
                            {!requiresDelivery && (
                              <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                            )}
                          </div>
                          <div>
                            <span className="font-medium text-gray-900">NO</span>
                            <p className="text-sm text-gray-500">Self-pickup arrangement</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="text-sm text-gray-500">No additional fee</span>
                          <div className="font-semibold text-gray-600">
                            Free
                          </div>
                        </div>
                      </div>
                    </label>
                  </div>
                </div>

                {/* Delivery Fee Summary */}
                {requiresDelivery && (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-green-800">
                        <Package className="h-4 w-4 inline mr-1" />
                        Delivery Fee (2%):
                      </span>
                      <span className="font-semibold text-green-900">
                        ETB {deliveryFee.toFixed(2)}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Continue Button */}
            <button
              onClick={handleContinueToPayment}
              disabled={isProcessing}
              className="w-full bg-green-600 text-white py-3 px-4 rounded-md hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed font-medium text-lg flex items-center justify-center"
            >
              {isProcessing ? (
                <>
                  <Spinner size="sm" />
                  <span className="ml-2">Processing...</span>
                </>
              ) : (
                <>
                  <CreditCard className="h-5 w-5 mr-2" />
                  Continue to Payment
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderDeliveryOptionPage;
