import { useState, useRef, useEffect } from 'react';
import { Plus, Upload, X, Image as ImageIcon, MessageCircle, Clock, CheckCircle, MapPin, Loader2, ChevronDown } from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import { useAuth } from '../contexts/AuthContext';
import { getApiUrl } from '../utils/apiConfig';
import { getImageUrl } from '../utils/imageUtils';
import Spinner from '../components/ui/Spinner';
import { useGoogleMaps } from '../hooks/useGoogleMaps';
import { useLocationPermission } from '../hooks/useLocationPermission';
import { vendorService } from '../services/vendorService';
import { Vendor } from '../services/vendorService';

interface ChatMessage {
  _id: string;
  quickOrderId: string;
  senderId: string;
  senderType: 'VENDOR' | 'CUSTOMER';
  message: string;
  price?: number;
  createdAt: string;
  sender?: {
    firstName: string;
    lastName: string;
  };
}

interface VendorResponse {
  _id: string;
  vendorId: string;
  quickOrderId: string;
  vendor: {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
  };
  message: string;
  price: number;
  createdAt: string;
  status: 'PENDING' | 'ACCEPTED' | 'REJECTED';
}

interface QuickOrder {
  _id: string;
  description: string;
  image?: string;
  quantity?: number;
  status: 'OPEN' | 'CLOSED' | 'FULFILLED';
  createdAt: string;
  responses?: VendorResponse[];
  assignedVendorId?: string;
  assignmentDistance?: number;
  assignedVendor?: {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
  };
}

const QuickOrdersPage = () => {
  const { authState } = useAuth();
  const token = authState.token; // ✅ Use AuthContext token
  
  const [myQuickOrders, setMyQuickOrders] = useState<QuickOrder[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isAssigning, setIsAssigning] = useState(false);
  const [nearestVendor, setNearestVendor] = useState<Vendor | null>(null);
  const [assignmentDistance, setAssignmentDistance] = useState<number>(0);
  const [expandedChats, setExpandedChats] = useState<Set<string>>(new Set());
  const [chatMessages, setChatMessages] = useState<{ [key: string]: ChatMessage[] }>({});
  const [newMessages, setNewMessages] = useState<{ [key: string]: string }>({});
  const [isSending, setIsSending] = useState<{ [key: string]: boolean }>({});
  const [showSuccess, setShowSuccess] = useState<{ [key: string]: boolean }>({});
  const [showChatModal, setShowChatModal] = useState(false);
  const [selectedOrderForChat, setSelectedOrderForChat] = useState<QuickOrder | null>(null);
  
  // ✅ Delete functionality state
  const [deleteDialog, setDeleteDialog] = useState<{ show: boolean; orderId: string | null }>({
    show: false,
    orderId: null
  });
  
  // ✅ Payment modal state
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedResponse, setSelectedResponse] = useState<VendorResponse | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [deliverySelected, setDeliverySelected] = useState(false);
  
  const safaricomColors = {
    primary: '#00BFA5', // Safaricom green
    primaryDark: '#00A085',
    primaryLight: '#4FD1C5',
    secondary: '#FF6B35', // Safaricom orange
    secondaryDark: '#E55A2B',
    background: '#F8F9FA',
    text: '#2D3748',
    textLight: '#718096',
    border: '#E2E8F0',
    success: '#48BB78',
    warning: '#ED8936'
  };
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { handleApiResponse, handleApiError } = useToast();

  // ✅ Delete functionality handlers
  const handleDeleteClick = (orderId: string) => {
    setDeleteDialog({ show: true, orderId });
  };

  const confirmDelete = async () => {
    if (!deleteDialog.orderId) return;
    
    try {
      const response = await fetch(getApiUrl(`/api/quick-orders/${deleteDialog.orderId}`), {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        handleApiResponse(response, 'Quick order deleted successfully!');
        // Remove from UI state
        setMyQuickOrders(prev => prev.filter(order => order._id !== deleteDialog.orderId));
        // Close dialog
        setDeleteDialog({ show: false, orderId: null });
      } else {
        const errorData = await response.json();
        handleApiError(new Error(errorData.message || 'Failed to delete quick order'));
      }
    } catch (error) {
      console.error('Error deleting quick order:', error);
      handleApiError(error);
    }
  };

  const cancelDelete = () => {
    setDeleteDialog({ show: false, orderId: null });
  };
  const { 
    userLocation, 
    setUserLocation, 
    getUserLocation, 
    calculateDistance, 
    findNearestVendor, 
    getNearestVendor,
    autoUpdateVendorLocation,
    getLocationName 
  } = useGoogleMaps();
  
  // Location permission hook for real-time GPS tracking
  const { 
    permissionStatus, 
    location,  // ✅ Use correct property name from hook
    isLoading: locationLoading, 
    requestPermission 
  } = useLocationPermission();

  // Update userLocation when location changes
  useEffect(() => {
    if (location && location !== userLocation) {
      setUserLocation(location);
    }
  }, [location, userLocation, setUserLocation]);

  const [formData, setFormData] = useState({
    description: '',
    quantity: ''
  });

  const resetForm = () => {
    setFormData({
      description: '',
      quantity: ''
    });
    setImagePreview('');
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.description.trim() || formData.description.trim().length < 5) {
      handleApiError(new Error('Description must be at least 5 characters long'));
      return;
    }

    setIsLoading(true);
    setIsAssigning(true);

    try {
      // Step 1: Get customer location first
      let customerLocation = userLocation;
      
      if (!customerLocation) {
        try {
          customerLocation = await getUserLocation();
          setUserLocation(customerLocation);
        } catch (locationError) {
          console.error('Failed to get customer location:', locationError);
          handleApiError(new Error('Unable to get your location. Please enable location services.'));
          return;
        }
      }
      
      // Step 2: Get available vendors for assignment (exclude current user if they're a vendor)
      const availableVendors = await vendorService.getAvailableVendorsForAssignment(authState.user?._id);
      
      if (availableVendors.length === 0) {
        handleApiError(new Error('No vendors available at the moment'));
        return;
      }

      // Step 3: Find nearest vendor using database coordinates
      const assignmentResult = await vendorService.findNearestVendor(customerLocation, authState.user?._id);
      
      console.log('🎯 DEBUG: Assignment result:', assignmentResult);
      console.log('🎯 DEBUG: Assignment result vendor:', assignmentResult?.vendor);
      console.log('🎯 DEBUG: Assignment result vendor ID:', assignmentResult?.vendor?._id);
      console.log('🎯 DEBUG: Assignment result vendor name:', assignmentResult?.vendor?.firstName, assignmentResult?.vendor?.lastName);
      
      if (!assignmentResult.vendor) {
        handleApiError(new Error('No nearby vendors available'));
        return;
      }

      // Check if fallback location was used
      const isFallbackLocation = userLocation?.address?.includes('Central location') || 
                            userLocation?.address?.includes('Default location');
      
      // Create quick order with automatic assignment
      const formDataToSend = new FormData();
      formDataToSend.append('description', formData.description.trim());
      
      if (formData.quantity) {
        formDataToSend.append('quantity', formData.quantity);
      }

      // Handle image upload
      if (fileInputRef.current?.files?.[0]) {
        formDataToSend.append('image', fileInputRef.current.files[0]);
      }

      // Add assigned vendor information
      formDataToSend.append('assignedVendorId', assignmentResult.vendor._id);
      formDataToSend.append('assignmentDistance', assignmentResult.distance.toString());
      formDataToSend.append('assignmentMetadata', JSON.stringify({
        vendorName: `${assignmentResult.vendor.firstName} ${assignmentResult.vendor.lastName}`,
        vendorEmail: assignmentResult.vendor.email,
        vendorPhone: assignmentResult.vendor.phone,
        distance: assignmentResult.distance,
        assignmentTime: new Date().toISOString(),
        customerLocation: {
          address: customerLocation.address,
          latitude: customerLocation.latitude,
          longitude: customerLocation.longitude
        },
        vendorLocation: assignmentResult.vendor.coordinates, // ✅ Use coordinates instead of location
        assignmentRadius: '50km', // Enhanced search radius
        assignmentMethod: 'Database GeoJSON Coordinates',
        locationAccuracy: customerLocation.address?.includes('Central location') ? 'fallback' : 'gps'
      }));

      const response = await fetch(getApiUrl('quick-orders'), {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: formDataToSend
      });

      if (response.ok) {
        const data = await response.json();
        
        // Update state with assignment info
        setMyQuickOrders([data.data.quickOrder, ...myQuickOrders]);
        setNearestVendor(assignmentResult.vendor);
        setAssignmentDistance(assignmentResult.distance);
        setIsFormOpen(false);
        resetForm();
        
        // Format distance display
        const distanceKm = assignmentResult.distance / 1000;
        const distanceText = distanceKm < 0.1 
          ? `${Math.round(assignmentResult.distance)}m away`
          : `${distanceKm.toFixed(1)}km away`;
        
        // Use estimated time based on distance (simple calculation)
        const estimatedMinutes = Math.max(5, Math.round(distanceKm * 3)); // 3 minutes per km minimum
        const timeText = `${estimatedMinutes} min`;

        // Get specific location names
        const customerLocationText = customerLocation?.address || 'Your location';
        
        // Use location name from Google Maps distance matrix response
        let vendorLocation = 'Vendor location';
        console.log('🎯 DEBUG: Full vendor object:', assignmentResult.vendor);
        
        if (assignmentResult.vendor?.coordinates) {
          const vendorLoc = assignmentResult.vendor.coordinates; // Use coordinates instead of location
          
          // Direct to reverse geocoding since coordinates don't have address field
          if (vendorLoc.lat && vendorLoc.lng) { // Use lat/lng instead of latitude/longitude
            // Try reverse geocoding as fallback
            try {
              vendorLocation = await getLocationName(vendorLoc.lat, vendorLoc.lng); // Use lat/lng
            } catch (error) {
              console.error('Reverse geocoding failed:', error);
              // Fallback to coordinates if geocoding fails
              vendorLocation = `Vendor at ${vendorLoc.lat.toFixed(3)}, ${vendorLoc.lng.toFixed(3)}`; // Use lat/lng
            }
          } else {
            vendorLocation = 'Vendor location (coordinates unavailable)';
          }
        } else {
          console.log(' DEBUG: No vendor location object found');
          vendorLocation = 'Vendor location (not available)';
        }
        
        console.log(' DEBUG: Customer location:', customerLocation);
        console.log(' DEBUG: Vendor location:', vendorLocation);
        console.log(' DEBUG: Vendor coordinates object:', assignmentResult.vendor?.coordinates); // Use coordinates instead of location
        
        // Extract more specific area names
        const getSpecificArea = (address: string) => {
          if (!address || 
              address === 'Your location' || 
              address === 'Vendor location' ||
              address === 'Vendor location (coordinates unavailable)' ||
              address === 'Vendor location (not available)') {
            return address;
          }
          
          // Handle coordinate-based locations
          if (address.includes('Vendor at')) {
            return address; // Keep coordinate format as is
          }
          
          // Handle reverse geocoded locations (from coordinates)
          if (address.includes(',') && !address.includes('Vendor at')) {
            // Take first two parts for more specific location
            const parts = address.split(',');
            if (parts.length >= 2) {
              return `${parts[0].trim()}, ${parts[1].trim()}`;
            } else if (parts.length === 1) {
              return parts[0].trim();
            }
          }
          
          return address;
        };

        const customerArea = getSpecificArea(customerLocationText);
        const vendorArea = getSpecificArea(vendorLocation);

        handleApiResponse(data, `Quick order assigned to ${assignmentResult.vendor.firstName} ${assignmentResult.vendor.lastName} (${distanceText}, ${timeText}) from ${customerArea} to ${vendorArea}!`);
      } else {
        const errorData = await response.json();
        handleApiError(new Error(errorData.message || 'Failed to post quick order'));
      }
    } catch (error) {
      console.error('Error posting quick order:', error);
      handleApiError(error);
    } finally {
      setIsLoading(false);
      setIsAssigning(false);
    }
  };

  const fetchMyQuickOrders = async () => {
    try {
      // ✅ Fixed: Remove /api prefix and use AuthContext token
      const response = await fetch(getApiUrl('quick-orders/mine'), {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        
        // Fetch responses for each order
        const ordersWithResponses = await Promise.all(
          data.data.quickOrders.map(async (order: QuickOrder) => {
            try {
              const responsesResponse = await fetch(getApiUrl(`quick-orders/${order._id}/responses`), {
                headers: {
                  'Authorization': `Bearer ${token}`
                }
              });
              
              if (responsesResponse.ok) {
                const responsesData = await responsesResponse.json();
                return { ...order, responses: responsesData.data || [] };
              }
              return order;
            } catch (error) {
              console.error('Error fetching responses:', error);
              return order;
            }
          })
        );
        
        setMyQuickOrders(ordersWithResponses);
      }
    } catch (error) {
      console.error('Error fetching my quick orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const deleteQuickOrder = async (orderId: string) => {
    if (!confirm('Are you sure you want to delete this quick order?')) {
      return;
    }

    try {
      const response = await fetch(getApiUrl(`quick-orders/${orderId}`), {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        setMyQuickOrders(myQuickOrders.filter(order => order._id !== orderId));
        handleApiResponse(response, 'Quick order deleted successfully');
      } else {
        const errorData = await response.json();
        handleApiError(new Error(errorData.message || 'Failed to delete quick order'));
      }
    } catch (error) {
      console.error('Error deleting quick order:', error);
      handleApiError(error);
    }
  };

  const openChatModal = async (order: QuickOrder) => {
    setSelectedOrderForChat(order);
    setShowChatModal(true);
    // Fetch chat messages when opening modal
    await fetchChatMessages(order._id);
  };

  const fetchChatMessages = async (orderId: string) => {
    try {
      // ✅ Fixed: Remove /api prefix and use AuthContext token
      const response = await fetch(getApiUrl(`quick-orders/${orderId}/chat`), {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setChatMessages(prev => ({ ...prev, [orderId]: data.data || [] }));
      }
    } catch (error) {
      console.error('Error fetching chat messages:', error);
    }
  };

  const sendMessage = async (orderId: string) => {
    const message = newMessages[orderId];
    if (!message?.trim()) {
      alert('Please enter a message');
      return;
    }

    setIsSending(prev => ({ ...prev, [orderId]: true }));
    
    try {
      // ✅ Fixed: Remove /api prefix and use AuthContext token
      const response = await fetch(getApiUrl(`quick-orders/${orderId}/chat`), {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: message.trim()
        })
      });

      if (response.ok) {
        // Clear input
        setNewMessages(prev => ({ ...prev, [orderId]: '' }));
        // Refresh chat messages
        await fetchChatMessages(orderId);
        handleApiResponse(response, 'Message sent successfully!');
      } else {
        const errorData = await response.json();
        handleApiError(errorData);
      }
    } catch (error) {
      console.error('Error sending message:', error);
      handleApiError(error);
    } finally {
      setIsSending(prev => ({ ...prev, [orderId]: false }));
    }
  };

  const continueToPayment = async (response: VendorResponse) => {
    // Open payment options modal instead of direct payment
    setSelectedResponse(response);
    setQuantity(1); // Reset to default
    setDeliverySelected(false); // Reset to default
    setShowPaymentModal(true);
  };

  const proceedToPayment = async () => {
    if (!selectedResponse) return;

    try {
      // Calculate final price
      const unitPrice = selectedResponse.price;
      const subtotal = unitPrice * quantity;
      const deliveryFee = deliverySelected ? subtotal * 0.02 : 0;
      const finalTotalPrice = subtotal + deliveryFee;

      // Create order with calculated price and options
      const orderResponse = await fetch(getApiUrl('orders/from-quick-order'), {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          quickOrderId: selectedResponse.quickOrderId,
          vendorId: selectedResponse.vendorId,
          agreedPrice: finalTotalPrice,
          quantity: quantity,
          unitPrice: unitPrice,
          deliverySelected: deliverySelected,
          deliveryFee: deliveryFee,
          customerLocation: userLocation // Use the detected location
        })
      });

      if (orderResponse.ok) {
        const orderData = await orderResponse.json();
        handleApiResponse(orderResponse, 'Order created successfully! Redirecting to payment...');
        // Refresh quick orders to update status
        await fetchMyQuickOrders();
        // Close modal and redirect to payment page with calculated data
        setShowPaymentModal(false);
        
        // Navigate to payment page with order data as URL parameters
        const paymentParams = new URLSearchParams({
          orderId: orderData.data._id,
          quantity: quantity.toString(),
          unitPrice: unitPrice.toString(),
          deliveryFee: deliveryFee.toString(),
          totalPrice: finalTotalPrice.toString(),
          deliverySelected: deliverySelected.toString(),
          productName: 'Quick Order',
          paymentMethod: 'Online Payment',
          vendorLocation: JSON.stringify(nearestVendor?.coordinates || {}), // ✅ Use coordinates instead of location
          customerLocation: JSON.stringify(userLocation || {})
        });
        
        setTimeout(() => {
          window.location.href = `/payment?${paymentParams.toString()}`;
        }, 1500);
      } else {
        const errorData = await orderResponse.json();
        handleApiError(errorData);
      }
    } catch (error) {
      console.error('Error creating order:', error);
      handleApiError(error);
    }
  };

  const getStatusColor = (status: 'OPEN' | 'CLOSED' | 'FULFILLED') => {
    switch (status) {
      case 'OPEN':
        return 'bg-green-100 text-green-800';
      case 'CLOSED':
        return 'bg-yellow-100 text-yellow-800';
      case 'FULFILLED':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'OPEN':
        return <MessageCircle className="h-4 w-4" />;
      case 'CLOSED':
        return <Clock className="h-4 w-4" />;
      case 'FULFILLED':
        return <CheckCircle className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Fetch quick orders on component mount
  useEffect(() => {
    fetchMyQuickOrders();
  }, []);

  if (loading) return <Spinner size="lg" />;

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      {/* My Quick Orders Section */}
      <div className="mb-12">
        <div className="flex justify-between items-center mb-6">
          <div className="flex">
            <p className="text-gray-600 mt-1">Manage your quick order requests</p>
          </div>
          <button
            onClick={() => {
              resetForm();
              setIsFormOpen(true);
            }}
            className="flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
          >
            <Plus className="h-4 w-4 mr-2" />
        
          </button>
        </div>

        {/* My Quick Orders List */}
        {isLoading ? (
          <Spinner size="lg" />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {myQuickOrders.map((order: QuickOrder) => (
              <div key={order._id} className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-6">
                {/* Order Header */}
                <div className="mb-4">
                  {order.image && (
                    <img
                      src={getImageUrl(order.image)}
                      alt="Quick order image"
                      className="w-full h-48 object-cover rounded-lg"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAwIiBoZWlnaHQ9IjE5MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iODAwIiBoZWlnaHQ9IjE5MCIgZmlsbD0iI2YzZjRmNiIvPgogIDx0ZXh0IHg9IjQwMCIgeT0iOTYiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIyNCIgZmlsbD0iIzljYTNhZiIgdGV4dC1hbmNob3I9Im1pZGRsZSI+CiAgICBObyBJbWFnZQogIDwvdGV4dD4KPC9zdmc+";
                      }}
                    />
                  )}
                </div>

                {/* Date below image */}
                <div className="flex justify-between items-center mb-4">
                  <div className="text-sm text-gray-500">
                    {formatDate(order.createdAt)}
                  </div>
                  <button
                    onClick={() => handleDeleteClick(order._id)}
                    className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                    title="Delete quick order"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-trash2-icon lucide-trash-2">
                      <path d="M10 11v6"/>
                      <path d="M14 11v6"/>
                      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>
                      <path d="M3 6h18"/>
                      <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                    </svg>
                  </button>
                </div>

                {/* Assigned Vendor Information */}
                {order.assignedVendor && (
                  <div className="mb-4 p-3 bg-blue-50 border border-green-200 rounded-lg">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span className="text-sm font-medium text-green-800">Assigned to Vendor</span>
                    </div>
                    <div className="text-sm text-green-700">
                      {order.assignedVendor.firstName} {order.assignedVendor.lastName}
                    </div>
                    {order.assignedVendor.phone && (
                      <div className="text-sm text-green-600">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="inline mr-1">
                          <path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384"/>
                        </svg>
                        {order.assignedVendor.phone}
                      </div>
                    )}
                  </div>
                )}

                {/* Product Information */}
                <div className="mb-4">
                  <div className="flex items-center gap-3">
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">
                        {order.description}
                      </div>
                      {order.quantity && (
                        <div className="text-sm text-gray-600">
                          Quantity: {order.quantity}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              
              {/* Vendor Responses Section */}
              {order.responses && order.responses.length > 0 && (
                <div className="mt-4 border-t pt-4">
                  <h4 className="font-medium text-gray-900 mb-4">Vendor Responses ({order.responses.length})</h4>
                  <div className="space-y-3">
                    {order.responses.map((response) => (
                      <div key={response._id} className="bg-green-50 border border-green-200 rounded-lg p-4">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <div className="font-medium text-gray-900">
                              {response.vendor ? `${response.vendor.firstName} ${response.vendor.lastName}` : 'Vendor Information'}
                            </div>
                            <div className="text-sm text-gray-600">
                              {response.vendor ? `${response.vendor.email} | ${response.vendor.phone}` : 'Contact Information'}
                            </div>
                          </div>
                          <div className="text-lg font-bold text-green-600">
                            ETB {response.price.toFixed(2)}
                          </div>
                        </div>
                        <div className="text-sm text-gray-700 mb-3">
                          {response.message}
                        </div>
                        <div className="text-xs text-gray-500 mb-3">
                          {formatDate(response.createdAt)}
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => openChatModal(order)}
                            className="flex-1 bg-blue-600 text-white px-3 py-2 rounded-md hover:bg-blue-700 transition-colors text-sm font-medium flex items-center justify-center"
                          >
                            <MessageCircle className="h-4 w-4 mr-1" />
                            Chat
                          </button>
                          <button
                            onClick={() => continueToPayment(response)}
                            className="flex-1 bg-green-600 text-white px-3 py-2 rounded-md hover:bg-green-700 transition-colors text-sm font-medium"
                          >
                            Continue to Payment
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <button
                onClick={() => deleteQuickOrder(order._id)}
                className="absolute top-4 right-4 text-red-500 hover:text-red-700 p-1"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          ))}
          {myQuickOrders.length === 0 && (
            <div className="text-center py-12">
              <MessageCircle className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No quick orders yet</h3>
              <p className="text-gray-500">Post your first quick order to get started</p>
            </div>
          )}
        </div>
        )}
      </div>

      {/* Assignment Information */}
      {nearestVendor && (
        <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="flex items-center mb-3">
            <MapPin className="h-5 w-5 text-blue-600 mr-2" />
            <h4 className="text-lg font-semibold text-blue-900">Automatic Vendor Assignment</h4>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex items-center">
              <span className="font-medium text-gray-700">Assigned Vendor:</span>
              <span className="ml-2 text-gray-900">
                {nearestVendor.firstName} {nearestVendor.lastName}
              </span>
            </div>
            {nearestVendor.email && (
              <div className="flex items-center">
                <span className="font-medium text-gray-700">Email:</span>
                <span className="ml-2 text-gray-900">{nearestVendor.email}</span>
              </div>
            )}
            {assignmentDistance > 0 && (
              <div className="flex items-center">
                <span className="font-medium text-gray-700">Distance:</span>
                <span className="ml-2 text-gray-900">
                  {(assignmentDistance / 1000).toFixed(1)} km away
                </span>
              </div>
            )}
            <div className="flex items-center text-xs text-gray-600">
              <MapPin className="h-3 w-3 mr-1" />
              Based on your location and available vendors
            </div>
          </div>
        </div>
      )}

      {/* Quick Order Form Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-2 sm:p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[95vh] sm:max-h-[90vh] overflow-y-auto m-2 sm:m-0">
            <div className="p-4 sm:p-6">
              <div className="flex justify-between items-center mb-4 sm:mb-6">
                <h2 className="text-lg sm:text-xl font-bold text-gray-900">Post Quick Order</h2>
                <button
                  onClick={() => {
                    setIsFormOpen(false);
                    resetForm();
                  }}
                  className="text-gray-400 hover:text-gray-500 p-1"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
                {/* Description */}
                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
                    Post what you need
                  </label>
                  <textarea
                    id="description"
                    required
                    rows={3}
                    minLength={5}
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="block w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                    placeholder="Describe what you want to buy (e.g., I need fresh organic tomatoes, about 2kg...)"
                  />
                  <p className="text-xs text-gray-500 mt-1">Minimum 5 characters</p>
                </div>

                {/* Quantity */}
                <div>
                  <label htmlFor="quantity" className="block text-sm font-medium text-gray-700 mb-2">
                    Quantity (optional)
                  </label>
                  <input
                    type="number"
                    id="quantity"
                    min="1"
                    max="999"
                    value={formData.quantity}
                    onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                    className="block w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                    placeholder="e.g., 2kg, 5 pieces"
                  />
                </div>

                {/* Image Upload */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Image (optional)</label>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                    {imagePreview ? (
                      <div className="relative">
                        <img
                          src={imagePreview}
                          alt="Preview"
                          className="w-20 h-20 sm:w-24 sm:h-24 object-cover rounded-lg"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            setImagePreview('');
                            if (fileInputRef.current) {
                              fileInputRef.current.value = '';
                            }
                          }}
                          className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    ) : (
                      <div
                        onClick={() => fileInputRef.current?.click()}
                        className="w-20 h-20 sm:w-24 sm:h-24 border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-gray-400"
                      >
                        <ImageIcon className="h-6 w-6 sm:h-8 sm:w-8 text-gray-400 mb-1" />
                        <span className="text-xs text-gray-500">Add Image</span>
                      </div>
                    )}
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Max file size: 5MB</p>
                </div>

                {/* Submit Buttons */}
                <div className="flex flex-col sm:flex-row gap-3 pt-4">
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="flex-1 flex items-center justify-center px-4 py-3 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed text-sm sm:text-base"
                  >
                    {isLoading ? (
                      <div className="flex items-center">
                        <Spinner size="sm" />
                        <span className="ml-2">Posting...</span>
                      </div>
                    ) : (
                      'Post Quick Order'
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setIsFormOpen(false);
                      resetForm();
                    }}
                    className="flex-1 sm:flex-none px-4 py-3 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 text-sm sm:text-base"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Payment Options Modal */}
      {showPaymentModal && selectedResponse && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full p-6 relative">
            {/* Close Button */}
            <button
              onClick={() => setShowPaymentModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
            >
              <X className="h-6 w-6" />
            </button>

            {/* Header */}
            <div className="mb-6">
              <h3 className="text-xl font-bold text-gray-900 mb-2">Payment Options</h3>
              <div className="text-sm text-gray-600">
                {selectedResponse.vendor ? `${selectedResponse.vendor.firstName} ${selectedResponse.vendor.lastName}` : 'Vendor'}
              </div>
            </div>

            {/* Quantity Selector */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Quantity
              </label>
              <div className="flex items-center justify-between bg-gray-50 rounded-lg p-3">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-10 rounded-full bg-white border border-gray-300 flex items-center justify-center hover:bg-gray-100 transition-colors"
                  disabled={quantity <= 1}
                >
                  <span className="text-xl font-bold text-gray-600">-</span>
                </button>
                <span className="text-2xl font-bold text-gray-900 min-w-[60px] text-center">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-10 rounded-full bg-white border border-gray-300 flex items-center justify-center hover:bg-gray-100 transition-colors"
                >
                  <span className="text-xl font-bold text-gray-600">+</span>
                </button>
              </div>
            </div>

            {/* Delivery Option */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Do you want a delivery agent?
              </label>
              <div className="flex gap-3">
                <button
                  onClick={() => setDeliverySelected(true)}
                  className={`flex-1 py-3 px-4 rounded-full border-2 transition-colors font-medium ${
                    deliverySelected
                      ? 'border-green-500 bg-green-50 text-green-600'
                      : 'border-gray-300 bg-white text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  Yes
                </button>
                <button
                  onClick={() => setDeliverySelected(false)}
                  className={`flex-1 py-3 px-4 rounded-full border-2 transition-colors font-medium ${
                    !deliverySelected
                      ? 'border-green-500 bg-green-50 text-green-600'
                      : 'border-gray-300 bg-white text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  No
                </button>
              </div>
            </div>

            {/* Price Summary */}
            <div className="mb-6 bg-gray-50 rounded-lg p-4">
              <h4 className="font-medium text-gray-900 mb-3">Price Summary</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Unit Price:</span>
                  <span className="font-medium">ETB {selectedResponse.price.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Quantity:</span>
                  <span className="font-medium">{quantity}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal:</span>
                  <span className="font-medium">ETB {(selectedResponse.price * quantity).toFixed(2)}</span>
                </div>
                {deliverySelected && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Delivery Fee (2%):</span>
                    <span className="font-medium">ETB {((selectedResponse.price * quantity) * 0.02).toFixed(2)}</span>
                  </div>
                )}
                <div className="border-t pt-2 mt-2">
                  <div className="flex justify-between">
                    <span className="font-semibold text-gray-900">Total:</span>
                    <span className="font-bold text-lg text-green-600">
                      ETB {(
                        (selectedResponse.price * quantity) + 
                        (deliverySelected ? (selectedResponse.price * quantity) * 0.02 : 0)
                      ).toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Proceed Button */}
            <button
              onClick={proceedToPayment}
              className="w-full py-3 px-4 rounded-lg text-white font-medium transition-colors bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
            >
              Proceed to Payment
            </button>
          </div>
        </div>
      )}

      {/* Chat Modal */}
      {showChatModal && selectedOrderForChat && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full h-[80vh] flex flex-col relative">
            {/* Close Button */}
            <button
              onClick={() => setShowChatModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 z-10"
            >
              <X className="h-6 w-6" />
            </button>

            {/* Header */}
            <div className="flex-shrink-0 p-6 border-b">
              <h3 className="text-xl font-bold text-gray-900 mb-2">Chat with Vendor</h3>
              <div className="text-sm text-gray-600">
                Order: {selectedOrderForChat.description}
              </div>
            </div>

            {/* Chat Messages */}
            <div className="flex-1 overflow-y-auto p-6">
              <div className="space-y-3">
                {chatMessages[selectedOrderForChat._id]?.map((message) => (
                  <div key={message._id} className={`flex ${message.senderType === 'CUSTOMER' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-xs px-4 py-2 rounded-lg ${
                      message.senderType === 'CUSTOMER' 
                        ? 'bg-green-600 text-white' 
                        : 'bg-gray-200 text-gray-900'
                    }`}>
                      <div className="text-sm font-medium mb-1">
                        {message.sender?.firstName} {message.sender?.lastName}
                      </div>
                      <div className="text-sm">{message.message}</div>
                      {message.price && (
                        <div className="text-sm font-bold mt-1">
                          Price: ETB {message.price.toFixed(2)}
                        </div>
                      )}
                      <div className="text-xs opacity-75 mt-1">
                        {formatDate(message.createdAt)}
                      </div>
                    </div>
                  </div>
                ))}
                {(!chatMessages[selectedOrderForChat._id] || chatMessages[selectedOrderForChat._id].length === 0) && (
                  <div className="text-center text-gray-500 text-sm py-8">
                    No messages yet. Start the conversation!
                  </div>
                )}
              </div>
            </div>

            {/* Message Input */}
            <div className="flex-shrink-0 border-t p-3">
              <div className="space-y-3">
                <div className="relative">
                  <textarea
                    value={newMessages[selectedOrderForChat._id] || ''}
                    onChange={(e) => setNewMessages(prev => ({ 
                      ...prev, 
                      [selectedOrderForChat._id]: e.target.value 
                    }))}
                    placeholder="Type your message..."
                    className="w-full px-3 py-2 pr-12 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 resize-none"
                    rows={3}
                  />
                  <button
                    onClick={() => sendMessage(selectedOrderForChat._id)}
                    disabled={isSending[selectedOrderForChat._id] || !newMessages[selectedOrderForChat._id]?.trim()}
                    className="absolute right-2 bottom-2 bg-green-600 text-white p-1.5 rounded-md hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
                  >
                    {isSending[selectedOrderForChat._id] ? (
                      <Spinner size="sm" />
                    ) : (
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M3.714 3.048a.498.498 0 0 0-.683.627l2.843 7.627a2 2 0 0 1 0 1.396l-2.842 7.627a.498.498 0 0 0 .682.627l18-8.5a.5.5 0 0 0 0-.904z"/>
                        <path d="M6 12h16"/>
                      </svg>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* ✅ Delete Confirmation Dialog */}
      {deleteDialog.show && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <div className="mb-4">
              <h3 className="text-lg font-medium text-gray-900">Delete Quick Order</h3>
              <p className="text-gray-600 mt-2">Do you want to delete this quick order?</p>
            </div>
            <div className="flex justify-end space-x-3">
              <button
                onClick={cancelDelete}
                className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors"
              >
                No
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-2 text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors"
              >
                Yes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default QuickOrdersPage;
