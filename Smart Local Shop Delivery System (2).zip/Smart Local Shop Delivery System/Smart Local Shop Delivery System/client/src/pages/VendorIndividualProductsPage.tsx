import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Store, Package } from 'lucide-react';
import Loading from '../components/common/Loading';
import ProductCard from '../components/products/ProductCard';
import FloatingChatWidget from '../components/chat/FloatingChatWidget';
import api from '../services/api';

interface Product {
  _id: string;
  name: string;
  price: number;
  description: string;
  category: string;
  images: string[];
  vendor: {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone?: string;
  };
  stock?: {
    quantity: number;
  };
}

const VendorIndividualProductsPage: React.FC = () => {
  const { vendorId } = useParams<{ vendorId: string }>();
  const [products, setProducts] = useState<Product[]>([]);
  const [vendor, setVendor] = useState<Product['vendor'] | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeChatUser, setActiveChatUser] = useState<{
    id: string;
    name: string;
  } | undefined>(undefined);

  console.log('🔍 Component mounted, vendorId:', vendorId);

  useEffect(() => {
    const fetchVendorProducts = async () => {
      try {
        setIsLoading(true);
        console.log('🔍 VendorIndividualProductsPage: Starting API call to fetch vendor products...');
        console.log('🔍 VendorIndividualProductsPage: vendorId:', vendorId);
        console.log('🔍 VendorIndividualProductsPage: API endpoint:', `/products/vendor/${vendorId}`);
        
        // Fetch vendor products
        const productsResponse = await api.get(`/products/vendor/${vendorId}`);
        console.log('🔍 VendorIndividualProductsPage: API Response:', productsResponse.data);
        console.log('🔍 VendorIndividualProductsPage: Response status:', productsResponse.status);
        console.log('🔍 VendorIndividualProductsPage: Products data:', productsResponse.data.data);
        
        setProducts(productsResponse.data.data?.products || []);
        console.log('🔍 VendorIndividualProductsPage: Products set:', productsResponse.data.data?.products?.length || 0);
        
        // Fetch vendor info (first product contains vendor details)
        if (productsResponse.data.data?.products && productsResponse.data.data.products.length > 0) {
          setVendor(productsResponse.data.data.products[0].vendor);
          console.log('🔍 VendorIndividualProductsPage: Vendor set:', productsResponse.data.data.products[0].vendor);
        } else {
          console.log('❌ VendorIndividualProductsPage: No products found in response');
        }
      } catch (error) {
        console.error('❌ VendorIndividualProductsPage: Error fetching vendor products:', error);
      } finally {
        setIsLoading(false);
      }
    };

    if (vendorId) {
      console.log('🔍 VendorIndividualProductsPage: vendorId found, calling fetchVendorProducts...');
      fetchVendorProducts();
    } else {
      console.log('❌ VendorIndividualProductsPage: No vendorId found in URL params');
    }
  }, [vendorId]);

  if (isLoading) {
    return <Loading />;
  }

  console.log('🔍 VendorIndividualProductsPage rendering, vendor:', vendor, 'products count:', products.length);
  
  return (
    <div className="px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="mb-6">
        <Link 
          to="/dashboard/products" 
          className="flex items-center text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="h-5 w-5 mr-3" />
          Back to Products
        </Link>
      </div>

      {/* Vendor Info */}
      {vendor && (
        <div className="bg-white shadow-sm rounded-lg p-6 mb-6">
          <div className="flex items-center space-x-4">
            <div className="flex-shrink-0">
              <div className="h-16 w-16 bg-gray-200 rounded-full flex items-center justify-center">
                <Store className="h-8 w-8 text-gray-400" />
              </div>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                {vendor.firstName} {vendor.lastName}
              </h1>
              <p className="text-sm text-gray-500">{vendor.email}</p>
              {vendor.phone && (
                <p className="text-sm text-gray-500">{vendor.phone}</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Products Grid */}
      <div>
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">
            Products {products.length}
          </h2>
          {vendor && (
            <p className="text-gray-600">
              All products listed by {vendor.firstName} {vendor.lastName}
            </p>
          )}
        </div>

        {products.length === 0 ? (
          <div className="text-center py-12">
            <Package className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No products found</h3>
            <p className="text-gray-500">
              {vendor 
                ? `${vendor.firstName} ${vendor.lastName} hasn't listed any products yet.`
                : 'No products available for this vendor.'
              }
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {products.map((product) => (
              <ProductCard key={product._id} product={product} />
            ))}
          </div>
        )}
      </div>
      
      {/* Floating Chat Widget */}
      {vendor && (
        <FloatingChatWidget 
          vendorId={vendorId!} 
          vendorName={`${vendor.firstName} ${vendor.lastName}`}
          activeChatUser={activeChatUser}
        />
      )}
    </div>
  );
};

export default VendorIndividualProductsPage;
