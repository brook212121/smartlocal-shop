import React, { useState, useEffect, FormEvent } from 'react';
import { User, Mail, Phone, Lock, Eye, EyeOff, Camera, Upload, Save, CheckCircle, Key } from 'lucide-react';
import Spinner from '../components/ui/Spinner';
import { useToast } from '../contexts/ToastContext';

interface UserProfile {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  profilePhoto?: string;
  role: string;
  isEmailVerified: boolean;
  createdAt: string;
}

interface ProfileFormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  profilePhoto?: string;
}

interface PasswordFormData {
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}

const UserProfilePage: React.FC = () => {
  const { handleApiResponse, handleApiError } = useToast();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isProfileUpdating, setIsProfileUpdating] = useState(false);
  const [isPasswordUpdating, setIsPasswordUpdating] = useState(false);
  const [profilePhotoPreview, setProfilePhotoPreview] = useState<string>('');
  
  // Profile form state
  const [profileForm, setProfileForm] = useState<ProfileFormData>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    profilePhoto: ''
  });
  
  // Password form state
  const [passwordForm, setPasswordForm] = useState<PasswordFormData>({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      // Load user data from localStorage (for now, until backend API is ready)
      const userData = localStorage.getItem('user');
      if (userData) {
        const parsedUser = JSON.parse(userData);
        setProfile(parsedUser);
        setProfileForm({
          firstName: parsedUser.firstName || '',
          lastName: parsedUser.lastName || '',
          email: parsedUser.email || '',
          phone: parsedUser.phone || '',
          profilePhoto: parsedUser.profilePhoto || ''
        });
        setProfilePhotoPreview(parsedUser.profilePhoto || '');
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
      handleApiError(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleProfileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setProfileForm(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handlePasswordInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPasswordForm(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleProfilePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        handleApiResponse('File size must be less than 5MB', 'error');
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setProfilePhotoPreview(result);
        setProfileForm(prev => ({
          ...prev,
          profilePhoto: result
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const validateProfileForm = (): boolean => {
    if (!profileForm.firstName.trim()) {
      handleApiResponse('First name is required', 'error');
      return false;
    }
    if (!/^[A-Za-z]+$/.test(profileForm.firstName.trim())) {
      handleApiResponse('First name can only contain letters (no spaces allowed)', 'error');
      return false;
    }
    if (!profileForm.lastName.trim()) {
      handleApiResponse('Last name is required', 'error');
      return false;
    }
    if (!/^[A-Za-z]+$/.test(profileForm.lastName.trim())) {
      handleApiResponse('Last name can only contain letters (no spaces allowed)', 'error');
      return false;
    }
    if (!profileForm.email.trim()) {
      handleApiResponse('Email is required', 'error');
      return false;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(profileForm.email)) {
      handleApiResponse('Please enter a valid email address', 'error');
      return false;
    }
    return true;
  };

  const validatePasswordForm = (): boolean => {
    if (!passwordForm.currentPassword) {
      handleApiResponse('Current password is required', 'error');
      return false;
    }
    if (!passwordForm.newPassword) {
      handleApiResponse('New password is required', 'error');
      return false;
    }
    if (passwordForm.newPassword.length < 8) {
      handleApiResponse('New password must be at least 8 characters long', 'error');
      return false;
    }
    if (!passwordForm.confirmPassword) {
      handleApiResponse('Confirm new password is required', 'error');
      return false;
    }
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      handleApiResponse('New password and confirm password must match', 'error');
      return false;
    }
    return true;
  };

  const handleProfileUpdate = async (e: FormEvent) => {
    e.preventDefault();
    
    if (!validateProfileForm()) return;

    setIsProfileUpdating(true);
    try {
      // Update localStorage for now (until backend API is ready)
      const updatedUser = {
        ...profile!,
        ...profileForm
      };
      localStorage.setItem('user', JSON.stringify(updatedUser));
      setProfile(updatedUser);
      
      handleApiResponse('Profile updated successfully', 'success');
    } catch (error) {
      console.error('Error updating profile:', error);
      handleApiError(error);
    } finally {
      setIsProfileUpdating(false);
    }
  };

  const handlePasswordUpdate = async (e: FormEvent) => {
    e.preventDefault();
    
    if (!validatePasswordForm()) return;

    setIsPasswordUpdating(true);
    try {
      // Here you would call the backend API to change password
      // await userService.changePassword({
      //   currentPassword: passwordForm.currentPassword,
      //   newPassword: passwordForm.newPassword
      // });
      
      // Reset password form
      setPasswordForm({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      });
      
      handleApiResponse('Password updated successfully', 'success');
    } catch (error) {
      console.error('Error updating password:', error);
      handleApiError(error);
    } finally {
      setIsPasswordUpdating(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Spinner size="lg" />
      </div>
    );
  }

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      <div className="mb-8">
        <p className="text-gray-600 mt-2">Manage your account information and security settings</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Profile Information Card */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <form onSubmit={handleProfileUpdate} className="space-y-4">
            {/* Profile Photo */}
            <div className="flex items-center space-x-4 mb-6">
              <div className="relative">
                <div className="h-20 w-20 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
                  {profilePhotoPreview ? (
                    <img 
                      src={profilePhotoPreview} 
                      alt="Profile" 
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <User className="h-8 w-8 text-gray-400" />
                  )}
                </div>
                <label 
                  htmlFor="profilePhoto" 
                  className="absolute bottom-0 right-0 bg-green-600 rounded-full p-1 cursor-pointer hover:bg-green-700 transition-colors"
                >
                  <Camera className="h-4 w-4 text-white" />
                </label>
                <input
                  type="file"
                  id="profilePhoto"
                  name="profilePhoto"
                  accept="image/*"
                  onChange={handleProfilePhotoChange}
                  className="hidden"
                />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-900">Profile Photo</p>
                <p className="text-xs text-gray-500">JPG, PNG up to 5MB</p>
              </div>
            </div>

            {/* Name Fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                  First Name
                </label>
                <input
                  type="text"
                  id="firstName"
                  name="firstName"
                  value={profileForm.firstName}
                  onChange={handleProfileInputChange}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                  placeholder="Enter first name"
                />
              </div>
              <div>
                <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">
                  Last Name
                </label>
                <input
                  type="text"
                  id="lastName"
                  name="lastName"
                  value={profileForm.lastName}
                  onChange={handleProfileInputChange}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                  placeholder="Enter last name"
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={profileForm.email}
                  onChange={handleProfileInputChange}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                  placeholder="Enter email address"
                  disabled
                />
              </div>
              <p className="text-xs text-gray-500 mt-1">Email cannot be changed</p>
            </div>

            {/* Phone */}
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                Phone Number (Optional)
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={profileForm.phone}
                  onChange={handleProfileInputChange}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                  placeholder="+2519XXXXXXXX or 09XXXXXXXX"
                />
              </div>
              <p className="text-xs text-gray-500 mt-1">Format: +2519XXXXXXXX or 09XXXXXXXX</p>
            </div>

            {/* Submit Button */}
            <div className="pt-4">
              <button
                type="submit"
                disabled={isProfileUpdating}
                className="w-full bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
              >
                {isProfileUpdating ? (
                  <>
                    <Spinner size="sm" className="mr-2" />
                    Updating...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-2" />
                    Save Changes
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Change Password Card */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-6">
            <Lock className="h-6 w-6 text-green-600 mr-2" />
            <h2 className="text-lg font-semibold text-gray-900">Change Password</h2>
          </div>

          <form onSubmit={handlePasswordUpdate} className="space-y-4">
            {/* Current Password */}
            <div>
              <label htmlFor="currentPassword" className="block text-sm font-medium text-gray-700 mb-1">
                Current Password
              </label>
              <div className="relative">
                <Key className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <input
                  type="password"
                  id="currentPassword"
                  name="currentPassword"
                  value={passwordForm.currentPassword}
                  onChange={handlePasswordInputChange}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                  placeholder="Enter current password"
                />
              </div>
            </div>

            {/* New Password */}
            <div>
              <label htmlFor="newPassword" className="block text-sm font-medium text-gray-700 mb-1">
                New Password
              </label>
              <div className="relative">
                <Key className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <input
                  type="password"
                  id="newPassword"
                  name="newPassword"
                  value={passwordForm.newPassword}
                  onChange={handlePasswordInputChange}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                  placeholder="Enter new password"
                />
              </div>
              <div className="mt-2 space-y-1">
                <p className="text-xs text-gray-500">Password must contain:</p>
                <div className="grid grid-cols-1 gap-1">
                  <div className={`text-xs flex items-center ${passwordForm.newPassword.length >= 8 ? 'text-green-600' : 'text-gray-400'}`}>
                    <span className="mr-1">{passwordForm.newPassword.length >= 8 ? '✓' : '○'}</span>
                    At least 8 characters
                  </div>
                  <div className={`text-xs flex items-center ${/[A-Z]/.test(passwordForm.newPassword) ? 'text-green-600' : 'text-gray-400'}`}>
                    <span className="mr-1">{/[A-Z]/.test(passwordForm.newPassword) ? '✓' : '○'}</span>
                    At least one uppercase letter
                  </div>
                  <div className={`text-xs flex items-center ${/[a-z]/.test(passwordForm.newPassword) ? 'text-green-600' : 'text-gray-400'}`}>
                    <span className="mr-1">{/[a-z]/.test(passwordForm.newPassword) ? '✓' : '○'}</span>
                    At least one lowercase letter
                  </div>
                  <div className={`text-xs flex items-center ${/\d/.test(passwordForm.newPassword) ? 'text-green-600' : 'text-gray-400'}`}>
                    <span className="mr-1">{/\d/.test(passwordForm.newPassword) ? '✓' : '○'}</span>
                    At least one number
                  </div>
                  <div className={`text-xs flex items-center ${/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(passwordForm.newPassword) ? 'text-green-600' : 'text-gray-400'}`}>
                    <span className="mr-1">{/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(passwordForm.newPassword) ? '✓' : '○'}</span>
                    At least one special character
                  </div>
                </div>
              </div>
            </div>

            {/* Confirm New Password */}
            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
                Confirm New Password
              </label>
              <div className="relative">
                <Key className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <input
                  type="password"
                  id="confirmPassword"
                  name="confirmPassword"
                  value={passwordForm.confirmPassword}
                  onChange={handlePasswordInputChange}
                  className={`block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200 ${
                    passwordForm.confirmPassword && passwordForm.newPassword !== passwordForm.confirmPassword
                      ? 'border-red-300 focus:ring-red-500 focus:border-red-500'
                      : passwordForm.confirmPassword && passwordForm.newPassword === passwordForm.confirmPassword
                      ? 'border-green-300 focus:ring-green-500 focus:border-green-500'
                      : ''
                  }`}
                  placeholder="Confirm new password"
                />
              </div>
              {passwordForm.confirmPassword && (
                <div className={`text-xs mt-1 flex items-center ${
                  passwordForm.newPassword === passwordForm.confirmPassword
                    ? 'text-green-600'
                    : 'text-red-600'
                }`}>
                  <span className="mr-1">
                    {passwordForm.newPassword === passwordForm.confirmPassword ? '✓' : '✗'}
                  </span>
                  {passwordForm.newPassword === passwordForm.confirmPassword
                    ? 'Passwords match'
                    : 'Passwords do not match'
                  }
                </div>
              )}
            </div>

            {/* Submit Button */}
            <div className="pt-4">
              <button
                type="submit"
                disabled={isPasswordUpdating}
                className="w-full bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
              >
                {isPasswordUpdating ? (
                  <>
                    <Spinner size="sm" className="mr-2" />
                    Updating...
                  </>
                ) : (
                  <>
                    <Lock className="h-4 w-4 mr-2" />
                    Update Password
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default UserProfilePage;
