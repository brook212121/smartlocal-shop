import { useState, useEffect } from 'react';
import { MessageCircle, User, Calendar, Package, Phone } from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import { getApiUrl } from '../utils/apiConfig';
import { getImageUrl } from '../utils/imageUtils';

interface QuickOrder {
  _id: string;
  description: string;
  image?: string;
  quantity?: number;
  status: 'OPEN' | 'CLOSED' | 'FULFILLED';
  createdAt: string;
  customerId: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
  };
}

const CustomerRequestsPage = () => {
  const [quickOrders, setQuickOrders] = useState<QuickOrder[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { handleApiResponse, handleApiError } = useToast();

  const fetchQuickOrders = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(getApiUrl('/api/quick-orders/open'), {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        credentials: 'include'
      });

      if (response.ok) {
        const data = await response.json();
        setQuickOrders(data.data.quickOrders);
      }
    } catch (error) {
      console.error('Error fetching quick orders:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const createOrderFromQuickOrder = async (quickOrderId: string) => {
    const productName = prompt('Enter product name:');
    const price = prompt('Enter price (ETB):');
    const quantity = prompt('Enter quantity:');
    const deliveryAddress = prompt('Enter delivery address:');

    if (!productName || !price || !quantity) {
      handleApiError(new Error('All fields are required'));
      return;
    }

    try {
      const response = await fetch(getApiUrl(`/api/orders/quick/${quickOrderId}`), {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({
          productName: productName.trim(),
          price: parseFloat(price),
          quantity: parseInt(quantity),
          deliveryAddress: deliveryAddress?.trim() || ''
        })
      });

      if (response.ok) {
        handleApiResponse(response, 'Order created successfully!');
        fetchQuickOrders(); // Refresh quick orders
      } else {
        const errorData = await response.json();
        handleApiError(new Error(errorData.message || 'Failed to create order'));
      }
    } catch (error) {
      console.error('Error creating order:', error);
      handleApiError(error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'OPEN':
        return 'bg-green-100 text-green-800';
      case 'CLOSED':
        return 'bg-yellow-100 text-yellow-800';
      case 'FULFILLED':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  useEffect(() => {
    fetchQuickOrders();
  }, []);

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      <div className="mb-8">
        <div className="flex items-center mb-6">
          <MessageCircle className="h-8 w-8 text-green-600 mr-3" />
          <h1 className="text-2xl font-bold text-gray-900">Customer Requests</h1>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-2">Customer Purchase Requests</h2>
          <p className="text-gray-600">View and respond to customer quick order requests. Create orders when you can fulfill their needs.</p>
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
            <p className="mt-2 text-gray-600">Loading customer requests...</p>
          </div>
        ) : (
          <div className="space-y-4">
            {quickOrders.map(order => (
              <div key={order._id} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                        {order.status}
                      </span>
                      <span className="text-sm text-gray-500 flex items-center">
                        <Calendar className="h-4 w-4 mr-1" />
                        {formatDate(order.createdAt)}
                      </span>
                    </div>
                    <p className="text-gray-900 mb-2">{order.description}</p>
                    {order.quantity && (
                      <div className="flex items-center text-sm text-gray-600 mb-2">
                        <Package className="h-4 w-4 mr-1" />
                        <span>Quantity: {order.quantity}</span>
                      </div>
                    )}
                    <div className="flex items-center text-sm text-gray-600">
                      <User className="h-4 w-4 mr-1" />
                      <span>{order.customerId.firstName} {order.customerId.lastName}</span>
                      <span className="ml-2 text-gray-400">({order.customerId.email})</span>
                    </div>
                    {order.customerId.phone && (
                      <div className="flex items-center text-sm text-gray-600">
                        <Phone className="h-4 w-4 mr-1" />
                        <span>{order.customerId.phone}</span>
                      </div>
                    )}
                  </div>
                  <div className="flex gap-2">
                    {order.image && (
                      <img
                        src={getImageUrl(order.image)}
                        alt="Request image"
                        className="w-40 h-40 object-cover rounded-lg"
                      />
                    )}
                  </div>
                </div>
                <div className="mt-4 flex gap-2">
                  <button
                    onClick={() => createOrderFromQuickOrder(order._id)}
                    className="flex-1 flex items-center justify-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                  >
                    Create Order
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {quickOrders.length === 0 && !isLoading && (
          <div className="text-center py-12">
            <MessageCircle className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No customer requests</h3>
            <p className="text-gray-500">Customer requests will appear here when customers post quick orders</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CustomerRequestsPage;
