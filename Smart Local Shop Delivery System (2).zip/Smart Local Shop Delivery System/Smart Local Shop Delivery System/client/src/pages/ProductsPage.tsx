import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Package, ShoppingCart, Search, Filter, Eye, Star, X, TrendingUp, MapPin, ExternalLink } from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import { useAuth } from '../contexts/AuthContext';
import { useGlobalLocationPermission } from '../hooks/useGlobalLocationPermission';
import api from '../services/api';
import { getImageUrl, getFallbackImageUrl } from '../utils/imageUtils';
import Spinner from '../components/ui/Spinner';
import PriceFilter from '../components/PriceFilter';
import activityService from '../services/activityService';
import recommendationService from '../services/recommendationService';
import ViewOnMap from '../components/ViewOnMap';
interface Product {
  _id: string;
  name: string;
  price: number;
  description: string;
  category: string;
  images: string[];
  vendor: {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
    businessName?: string;
    shopName?: string;
    coordinates?: {
      latitude: number;
      longitude: number;
    };
    shopAddress?: {
      street: string;
      city: string;
      county: string;
      coordinates?: {
        latitude: number;
        longitude: number;
      };
    };
    vendorLocation?: {
      type: string;
      coordinates: [number, number]; // [lng, lat]
    };
    shopCategory?: string;
    rating?: {
      average: number;
      count: number;
    };
  };
  stock?: {
    quantity: number;
  };
  distance?: number; // Distance from user to vendor in meters
}

// Reusable ProductCard component
const ProductCard = ({ 
  product, 
  onAddToCart, 
  userLocation, 
  setMapProduct 
}: { 
  product: Product; 
  onAddToCart: (product: Product) => void;
  userLocation?: { latitude: number; longitude: number } | null;
  setMapProduct: (product: Product) => void;
}) => {
  // Helper function to format distance
  const formatDistance = (distance?: number) => {
    if (!distance) return null;
    
    // Convert meters to kilometers (backend sends distance in meters)
    const distanceInKm = distance / 1000;
    
    if (distanceInKm < 1) {
      // Show in meters for distances less than 1km
      const meters = Math.round(distance);
      return `${meters}m away`;
    } else {
      // Show in km with 2 decimal places
      return `${distanceInKm.toFixed(2)} km away`;
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 flex flex-col border border-gray-100">
      {/* Product Image Container */}
      <div className="relative flex-shrink-0 bg-gradient-to-br from-gray-50 to-gray-100">
        <div className="aspect-w-16 aspect-h-12 relative h-64">
          <img
            src={getImageUrl(product.images?.[0])}
            alt={product.name}
            loading="lazy"
            className="w-full h-full object-contain p-4 transition-transform duration-300 hover:scale-105"
            onClick={() => window.open(`/dashboard/products/${product._id}`, '_blank')}
            onError={(e) => {
              (e.target as HTMLImageElement).src = getFallbackImageUrl();
            }}
          />
        </div>
      </div>
      
      {/* Product Content */}
      <div className="p-5 flex-1 flex flex-col">
        {/* Product Name */}
        <h3 className="text-lg font-bold text-gray-900 mb-2 line-clamp-2 leading-tight">
          {product.name}
        </h3>
        
        {/* Product Description */}
        <p className="text-sm text-gray-600 mb-4 line-clamp-3 flex-1 leading-relaxed">
          {product.description}
        </p>
        
        {/* Distance and Vendor Information */}
        {product.distance && (
          <div className="flex items-center text-xs text-gray-600 mb-3">
            <MapPin className="h-3 w-3 mr-1 text-red-400" />
            <span>{formatDistance(product.distance)}</span>
          </div>
        )}
        
        {/* Vendor Information */}
        <div className="flex items-center text-xs text-gray-500 mb-3">
          <Package className="h-3 w-3 mr-1 text-gray-600" />
          <span>
            {product.vendor.businessName || 
             `${product.vendor.firstName} ${product.vendor.lastName}` ||
             'Unknown Vendor'}
          </span>
        </div>
        
        {/* Price and Stock Section */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-baseline">
              <span className="text-2xl font-bold text-green-600">ETB</span>
              <span className="text-2xl font-bold text-green-600 ml-1">{product.price}</span>
            </div>
          </div>
          
          {/* Stock Display */}
          <div className="flex items-center justify-between">
            <span className={`text-sm font-medium ${
              product.stock?.quantity === 0 
                ? 'text-red-600 bg-red-50 px-2 py-1 rounded' 
                : 'text-gray-600 bg-gray-50 px-2 py-1 rounded'
            }`}>
              {product.stock?.quantity === 0 
                ? 'Out of Stock' 
                : `${product.stock?.quantity} left in stock`
              }
            </span>
          </div>
        </div>
        
        {/* Action Buttons */}
        <div className="flex gap-2 mt-auto">
          <button
            onClick={() => window.open(`/dashboard/products/${product._id}`, '_blank')}
            disabled={product.stock?.quantity === 0}
            className={`flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 shadow-sm ${
              product.stock?.quantity === 0 
                ? 'bg-gray-400 text-gray-200 cursor-not-allowed' 
                : 'bg-green-600 text-white hover:bg-green-700'
            }`}
          >
            <Eye className="h-4 w-4 mr-1" />
            View Details
          </button>
          {(userLocation || true) && (
            <button
              onClick={() => {
                // Extract coordinates properly
                const vendorCoords = product.vendor?.vendorLocation?.coordinates;
                const shopCoords = product.vendor?.coordinates;
                
                if (vendorCoords && Array.isArray(vendorCoords) && vendorCoords.length === 2) {
                  // Using vendorLocation coordinates
                } else if (shopCoords && typeof shopCoords.latitude === 'number' && typeof shopCoords.longitude === 'number') {
                  // Using shop coordinates
                } else {
                  // No valid coordinates found
                }
                
                // Use real location if available, otherwise use fallback
                const finalUserLocation = userLocation || { latitude: 9.0245, longitude: 38.7485 };
                
                setMapProduct(product);
              }}
              className="flex items-center px-3 py-2 text-xs bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 transition-colors flex-shrink-0"
            >
              <ExternalLink className="h-3 w-3 mr-1" />
              View on Map
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

const ProductsPageNew = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const searchContainerRef = useRef<HTMLDivElement>(null);
  const mobileFilterRef = useRef<HTMLDivElement>(null);
  const { showToast } = useToast();
  const { authState } = useAuth();
  
  // Filter out current user's own products
  const filterOutOwnProducts = (products: Product[]) => {
    // Wait for auth to be ready before filtering
    if (authState.isLoading) {
      return products;
    }
    
    const currentUserId = authState.user?._id;
    
    // If user is not authenticated, return all products (no filtering needed)
    if (!currentUserId) {
      return products;
    }
    
    if (products.length === 0) {
      return products;
    }
    
    const filteredProducts = products.filter(product => {
      const vendorId = product.vendor._id;
      const isOwnProduct = vendorId === currentUserId;
      
      return !isOwnProduct;
    });
    
    return filteredProducts;
  };
  
  const handleAddToCart = (product: Product) => {
    activityService.trackAddToCart(product._id, product.name, product.category, product.vendor._id);
    showToast('success', 'Order initiated!');
    // Add to cart logic here
  };
  
  const [searchTerm, setSearchTerm] = useState('');
  // Optimized debounced search with shorter delay for faster response
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState(searchTerm);
  
  // Reduce debounce time from 300ms to 150ms for faster search
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 150); // Faster debounce for better UX

    return () => clearTimeout(timer);
  }, [searchTerm]);
  const [searchSuggestions, setSearchSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isSearchLoading, setIsSearchLoading] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [recommendationFilter, setRecommendationFilter] = useState('nearby');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 0]);
  const [showMobileFilters, setShowMobileFilters] = useState(false);
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  
  // Detect if user is actively typing
  const isTyping = searchTerm !== debouncedSearchTerm;
  const [loading, setLoading] = useState(true);
  const [recommendations, setRecommendations] = useState<any>({
    recommended: [],
    nearby: [],
    trending: []
  });
  const [recommendationsLoading, setRecommendationsLoading] = useState(false);
  
  // Location and Map state
  const locationState = useGlobalLocationPermission();
  const userLocation = locationState.location; // Use the correct variable!
  const [mapProduct, setMapProduct] = useState<Product | null>(null);

  // Add location loading state check
  const isLocationReady = !locationState.isLoading && locationState.location !== null;

  // Unified loading state for better UX
  const isPageLoading = loading || isLoading;

  // Add manual location override for testing
  useEffect(() => {
    // Add manual location function to window for testing
    (window as any).setManualLocation = (lat: number, lng: number) => {
      // This will need to be handled in the location hook
    };
  }, [locationState, userLocation, loading, isLoading, recommendationsLoading, isPageLoading, authState.isLoading, authState.isAuthenticated]);

  // Debug when location becomes available
  useEffect(() => {
    if (locationState.location) {
      // Location is now available
    } else if (locationState.isInitialized && !locationState.isLoading) {
      // Location initialized but null
    }
  }, [locationState.location, locationState.isInitialized, locationState.isLoading, locationState.error]);

  // Re-filter products when auth state changes - Fix dependency
  useEffect(() => {
    if (authState.user?._id && products.length > 0 && !authState.isLoading) {
      const filteredProducts = filterOutOwnProducts(products);
      if (filteredProducts.length !== products.length) {
        setProducts(filteredProducts);
      }
    }
  }, [authState.user?._id, authState.isLoading]); // Only depend on user ID and loading state

  const { handleApiResponse, handleApiError } = useToast();

  // Handle URL search parameters
  useEffect(() => {
    const searchQuery = searchParams.get('search');
    if (searchQuery) {
      setSearchTerm(searchQuery);
    }
  }, [searchParams]);

  // Debounce search term to prevent excessive API calls
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 500);

    return () => clearTimeout(timer);
  }, [searchTerm]);

  // Load recommendations when component mounts and auth is ready
  useEffect(() => {
    if (!authState.isLoading) {
      // Initial fetch will be triggered by debounced effect
      loadRecommendations();
      // Set initial loading to false when data loading starts
      setLoading(false);
    }
  }, [authState.isLoading]); // Only depend on loading state

  // Close mobile filters when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      // Don't close if clicking on filter button
      const filterButton = document.querySelector('[title="Toggle filters"]');
      if (mobileFilterRef.current && !mobileFilterRef.current.contains(event.target as Node) && !filterButton?.contains(event.target as Node)) {
        setShowMobileFilters(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showMobileFilters]);

  // Search suggestions effect - Optimized with caching and faster debouncing
  useEffect(() => {
    if (searchTerm.length >= 2) { // Only trigger after 2 characters
      const debounceTimer = setTimeout(() => {
        const fetchSuggestions = async () => {
          try {
            // Call backend API for suggestions with timeout
            const response = await Promise.race([
              api.get(`/products/suggestions?q=${encodeURIComponent(searchTerm)}`),
              new Promise<never>((_, reject) => 
                setTimeout(() => reject(new Error('Suggestions timeout')), 3000)
              )
            ]) as any;
            
            const suggestions = response.data || [];
            const limited = suggestions.slice(0, 8); // Reduced from 10 to 8 for faster rendering
            setSearchSuggestions(limited);
            setShowSuggestions(limited.length > 0);
          } catch (error) {
            console.error('Error fetching suggestions:', error);
            setSearchSuggestions([]);
            setShowSuggestions(false);
          }
        };

        fetchSuggestions();
      }, 200); // Reduced from 300ms to 200ms for faster response

      return () => clearTimeout(debounceTimer);
    } else {
      setSearchSuggestions([]);
      setShowSuggestions(false);
    }
  }, [searchTerm]); // Only depend on searchTerm

  // Click outside to close suggestions
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const loadRecommendations = async () => {
    try {
      // Wait for auth to be ready
      if (authState.isLoading) {
        setRecommendations({
          nearby: [],
          recommended: [],
          trending: []
        });
        return;
      }
      
      // Check if user is authenticated after loading is complete
      if (!authState.isAuthenticated || !authState.user?._id) {
        setRecommendations({
          nearby: [],
          recommended: [],
          trending: []
        });
        return;
      }

      setRecommendationsLoading(true);
      const userLocation = await getUserLocation();
      const recs = await recommendationService.getRecommendations(userLocation, 10, 50); // 10km radius, 50 products max
      
      // Filter out current user's own products from all recommendation types
      const filteredRecommendations = {
        nearby: filterOutOwnProducts(recs.nearby || []),
        recommended: filterOutOwnProducts(recs.recommended || []),
        trending: filterOutOwnProducts(recs.trending || [])
      };
      
      setRecommendations(filteredRecommendations);
    } catch (error) {
      console.error('Error loading recommendations:', error);
    } finally {
      setRecommendationsLoading(false);
    }
  };

  const getUserLocation = async (): Promise<{ latitude: number; longitude: number } | undefined> => {
    return new Promise((resolve) => {
      if (!navigator.geolocation) {
        resolve(undefined);
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          resolve({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          });
        },
        (error) => {
          resolve(undefined);
        }
      );
    });
  };

  const fetchProducts = async () => {
    try {
      // Optimized loading states - only show loading for initial load
      const shouldShowGlobalLoading = !debouncedSearchTerm || debouncedSearchTerm.length === 0;
      if (shouldShowGlobalLoading) {
        setIsLoading(true);
      } else {
        setIsSearchLoading(true);
      }
      
      // Build optimized parameters
      const params = new URLSearchParams();
      
      // Apply filters efficiently
      if (debouncedSearchTerm) {
        params.append('search', debouncedSearchTerm);
      }
      
      if (selectedCategory !== 'all') {
        params.append('category', selectedCategory);
      }
      
      // Only add price filters if not searching (reduces API load)
      if (!debouncedSearchTerm) {
        if (priceRange[0] > 0) params.append('minPrice', priceRange[0].toString());
        if (priceRange[1] > 0) params.append('maxPrice', priceRange[1].toString());
      }
      
      // Optimized API call with shorter timeout
      const response = await Promise.race([
        api.get(`/products/public?${params.toString()}`),
        new Promise<never>((_, reject) => 
          setTimeout(() => reject(new Error('Request timeout')), 8000) // 8s timeout
        )
      ]) as any;
      
      const data = response.data;
      
      if (data.data?.products && Array.isArray(data.data.products)) {
        const enrichedProducts = data.data.products.map((product: any) => ({
          ...product,
          vendor: product.vendor || {
            _id: 'unknown',
            firstName: 'Unknown',
            lastName: 'Vendor',
            email: 'unknown@example.com'
          }
        }));
        
        setProducts(enrichedProducts);
      } else {
        setProducts([]);
      }
    } catch (error) {
      console.error('Error fetching products:', error);
      handleApiError(error);
    } finally {
      setIsLoading(false);
      setIsSearchLoading(false);
    }
  };

  useEffect(() => {
    // Only fetch if auth is ready and not loading
    if (!authState.isLoading) {
      fetchProducts();
    }
  }, [debouncedSearchTerm, selectedCategory, priceRange, authState.isLoading]);

  const categories = ['all', 'FOOD BEVERAGES', 'GROCERIES', 'BEAUTY', 'HOME GARDEN', 'ELECTRONICS', 'CLOTHING', 'SPORTS OUTDOORS', 'BOOKS MEDIA', 'TOYS GAMES', 'AUTOMOTIVE', 'PHARMACY', 'OTHER'];

  const filteredProducts = products.filter(product => {
    // API handles search filtering, only filter by category on client side
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    return matchesCategory;
  });

  // Optimized memoization for products to display
  const productsToDisplay = useMemo(() => {
    console.log('🔄 Recalculating productsToDisplay - this should be minimized');
    
    let products: Product[] = [];
    
    if (recommendationFilter === "nearby") {
      let nearbyProducts = recommendations.nearby || [];
      // Apply search within nearby products if search term exists
      if (debouncedSearchTerm) {
        nearbyProducts = nearbyProducts.filter((product: Product) => 
          product.name.toLowerCase().includes(debouncedSearchTerm.toLowerCase())
        );
      }
      // Apply category filter to nearby products
      if (selectedCategory !== 'all') {
        nearbyProducts = nearbyProducts.filter((product: Product) => 
          product.category === selectedCategory
        );
      }
      products = nearbyProducts;
    } else if (recommendationFilter === "recommended") {
      let recommendedProducts = recommendations.recommended || [];
      // Apply search within recommended products if search term exists
      if (debouncedSearchTerm) {
        recommendedProducts = recommendedProducts.filter((product: Product) => 
          product.name.toLowerCase().includes(debouncedSearchTerm.toLowerCase())
        );
      }
      // Apply category filter to recommended products
      if (selectedCategory !== 'all') {
        recommendedProducts = recommendedProducts.filter((product: Product) => 
          product.category === selectedCategory
        );
      }
      products = recommendedProducts;
    } else if (recommendationFilter === "trending") {
      let trendingProducts = recommendations.trending || [];
      // Apply search within trending products if search term exists
      if (debouncedSearchTerm) {
        trendingProducts = trendingProducts.filter((product: Product) => 
          product.name.toLowerCase().includes(debouncedSearchTerm.toLowerCase())
        );
      }
      // Apply category filter to trending products
      if (selectedCategory !== 'all') {
        trendingProducts = trendingProducts.filter((product: Product) => 
          product.category === selectedCategory
        );
      }
      products = trendingProducts;
    } else {
      // When "all" filter is selected, use filteredProducts (which already has category filtering applied)
      products = filteredProducts;
    }

    return products;
  }, [recommendationFilter, recommendations, debouncedSearchTerm, filteredProducts, selectedCategory]);

  const handlePlaceOrder = async (product: Product) => {
    try {
      // Get delivery address from user
      const streetAddress = prompt('Street Address:') || '';

      // Validate delivery address
      if (!streetAddress) {
        handleApiError(new Error('Please provide street address'));
        return;
      }

      // GET REAL USER GPS COORDINATES
      const coords = await new Promise<{ latitude: number; longitude: number }>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const userCoords = {
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
            };
            
            // DEBUG LOG: Log real user location
            console.log('REAL USER LOCATION:', userCoords);
            
            resolve(userCoords);
          },
          (error) => {
            console.error('Location error:', error);
            reject(new Error('Location access denied. Please enable location services.'));
          },
          {
            enableHighAccuracy: true
          }
        );
      });

      // VALIDATE COORDINATES EXIST
      if (!coords.latitude || !coords.longitude) {
        throw new Error('User location is required');
      }

      const deliveryAddress = {
        street: streetAddress,
        city: '', // Auto-filled or optional
        state: '', // Auto-filled or optional
        postalCode: '', // Auto-filled or optional
        phone: '', // Auto-filled or optional
        coordinates: coords // ✅ REAL USER COORDINATES
      };

      // DEBUG LOG: Log coordinates being sent
      console.log('Sending coordinates:', coords);

      const response = await api.post('/orders', {
        productId: product._id,
        quantity: 1, // Default quantity, can be made configurable
        deliveryAddress,
        orderNotes: `Order for ${product.name}`
      });

      if (response.data.success) {
        handleApiResponse(response, `Order placed successfully! Order ID: ${response.data.data.order._id}`);
      } else {
        handleApiError(new Error(response.data.message || 'Failed to place order'));
      }
    } catch (error) {
      console.error('Error placing order:', error);
      handleApiError(error);
    }
  };

  if (isPageLoading) return <Spinner size="lg" />;

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      <div className="mb-8">
        {/* Search and Filters */}
        <div className="mb-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex-1 flex items-center gap-3">
              <div className="flex-1 max-w-md relative" ref={searchContainerRef}>
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                {isSearchLoading ? (
                  <Spinner size="sm" />
                ) : (
                  <Search className="h-5 w-5 text-gray-400" />
                )}
              </div>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => {
                  const newSearchTerm = e.target.value;
                  setSearchTerm(newSearchTerm);
                  
                  // Open dropdown if user types at least 2 characters
                  if (newSearchTerm.length >= 2) {
                    setShowSuggestions(true);
                  } else {
                    setShowSuggestions(false);
                  }
                  
                  // Track search activity if user has typed at least 3 characters
                  if (newSearchTerm.length >= 3) {
                    activityService.trackSearch(newSearchTerm);
                  }
                }}
                onFocus={() => {
                  if (searchTerm.trim() && searchSuggestions.length > 0) {
                    setShowSuggestions(true);
                  }
                }}
                onBlur={() => {
                  // Delay hiding to allow click on suggestion
                  setTimeout(() => setShowSuggestions(false), 200);
                }}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    setShowSuggestions(false);
                  }
                }}
                className="block w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200"
                placeholder="Search products..."
                autoComplete="off"
              />
              {searchTerm && (
                <button
                  onClick={() => {
                    setSearchTerm('');
                    navigate('/dashboard/products');
                  }}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600 transition-colors duration-200"
                  title="Clear search"
                >
                  <X className="h-5 w-5" />
                </button>
              )}

              {/* Search Suggestions Dropdown */}
              {showSuggestions && searchSuggestions.length > 0 && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-xl z-[9999] max-h-80 overflow-y-auto w-full">
                  {searchSuggestions.map((suggestion, index) => (
                    <button
                      key={index}
                      onClick={() => {
                        setShowSuggestions(false);
                        // Find the product by name from all available products
                        const allProducts = [...products, ...recommendations.nearby, ...recommendations.recommended, ...recommendations.trending];
                        const product = allProducts.find(p => p.name.toLowerCase() === suggestion.toLowerCase());
                        
                        if (product) {
                          // Open product details in new tab
                          window.open(`/dashboard/products/${product._id}`, '_blank');
                        } else {
                          // Fallback to search if product not found
                          setSearchTerm(suggestion);
                          navigate(`/dashboard/products?search=${encodeURIComponent(suggestion)}`);
                        }
                      }}
                      className="w-full text-left px-4 py-3 hover:bg-gray-50 transition-colors duration-150 text-sm text-gray-700 border-b border-gray-100 last:border-b-0 flex items-center gap-3"
                    >
                      <Search className="h-4 w-4 text-gray-400 flex-shrink-0" />
                      <span className="flex-1 truncate">{suggestion}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
              
              {/* Filter Button - Inline with search */}
              <button
                onClick={() => {
                  console.log('Filter button clicked, current state:', showMobileFilters);
                  setShowMobileFilters(!showMobileFilters);
                }}
                className="sm:hidden flex items-center px-3 py-2 border border-gray-300 rounded-md hover:bg-gray-50 transition-colors duration-200"
                title="Toggle filters"
              >
                <Filter className="h-5 w-5" />
              </button>
            </div>
            
            {/* Desktop Filters */}
            <div className="hidden sm:flex items-center gap-2">
              {/* Recommendation Filter Dropdown */}
              <select
                value={recommendationFilter}
                onChange={(e) => setRecommendationFilter(e.target.value)}
                className="w-full sm:w-auto px-3 py-2 border border-gray-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm transition-colors duration-200"
              >
                <option value="nearby">Nearby Shop Products</option>
                <option value="recommended">What You might like</option>
                <option value="trending">Trending Products</option>
              </select>

              {/* Category Dropdown */}
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm transition-colors duration-200"
              >
                {categories.map(category => (
                  <option key={category} value={category}>
                    {category === 'all' ? 'All Categories' : category}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Mobile Filters Panel */}
        {showMobileFilters && (
          <div className="sm:hidden bg-white border border-gray-200 rounded-lg p-4 mb-6" ref={mobileFilterRef}>
            <div className="flex flex-col gap-4">  
              {/* Horizontal Filter Controls */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Recommendation Filter */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Show</label>
                  <select
                    value={recommendationFilter}
                    onChange={(e) => setRecommendationFilter(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm"
                  >
                    <option value="nearby">Nearby Shop Products</option>
                    <option value="recommended">What You might like</option>
                    <option value="trending">Trending Products</option>
                  </select>
                </div>

                {/* Category Filter */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm"
                  >
                    {categories.map(category => (
                      <option key={category} value={category}>
                        {category === 'all' ? 'All Categories' : category}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Main Content */}
        <div className="max-w-7xl mx-auto">
          {/* Recommendation Sections */}
          {!recommendationsLoading && recommendationFilter === "all" && (
            <>
              {/* Nearby Shop Products */}
              {recommendations.nearby.length > 0 && (
                <div className="mb-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
                    <Package className="h-6 w-6 mr-2 text-green-600" />
                    Nearby Shop Products
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {recommendations.nearby.map((product: Product) => (
                      <ProductCard 
                        key={product._id} 
                        product={product} 
                        onAddToCart={handleAddToCart}
                        userLocation={userLocation}
                        setMapProduct={setMapProduct}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Recommended for You */}
              {recommendations.recommended.length > 0 && (
                <div className="mb-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
                    <Star className="h-6 w-6 mr-2 text-yellow-500" />
                    Recommended for You
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {recommendations.recommended.map((product: Product) => (
                      <ProductCard 
                        key={product._id} 
                        product={product} 
                        onAddToCart={handleAddToCart}
                        userLocation={userLocation}
                        setMapProduct={setMapProduct}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Trending Products */}
              {recommendations.trending.length > 0 && (
                <div className="mb-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
                    <TrendingUp className="h-6 w-6 mr-2 text-red-600" />
                    Trending Products
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {recommendations.trending.map((product: Product) => (
                      <ProductCard 
                        key={product._id} 
                        product={product} 
                        onAddToCart={handleAddToCart}
                        userLocation={userLocation}
                        setMapProduct={setMapProduct}
                      />
                    ))}
                  </div>
                </div>
              )}
            </>
          )}

          {/* Filtered Results Section */}
          {recommendationFilter !== "all" && (
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                {recommendationFilter === "nearby" && "Nearby Shop Products"}
                {recommendationFilter === "recommended" && "Recommended for You"}
                {recommendationFilter === "similar" && "Similar Products"}
                {recommendationFilter === "trending" && "Trending Products"}
              </h2>
              
              {productsToDisplay.length === 0 && !isLoading && !recommendationsLoading && !isTyping && (
                <div className="text-center py-12">
                  <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No products found</h3>
                  <p className="text-gray-600">Try adjusting your filters or search terms.</p>
                </div>
              )}
            </div>
          )}

          {/* Products Display - Grid Only with smooth transitions*/}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 transition-all duration-300 ease-in-out">
            {isLoading ? (
              // Loading skeleton to prevent flickering
              Array.from({ length: 8 }).map((_, index) => (
                <div key={`skeleton-${index}`} className="bg-white rounded-lg shadow-md overflow-hidden animate-pulse">
                  <div className="h-48 bg-gray-200"></div>
                  <div className="p-4">
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  </div>
                </div>
              ))
            ) : (
              productsToDisplay.map((product: Product) => (
                <ProductCard 
                  key={`${product._id}-${recommendationFilter}`} 
                  product={product} 
                  onAddToCart={handleAddToCart}
                  userLocation={userLocation}
                  setMapProduct={setMapProduct}
                />
              ))
            )}
          </div>

          {/* No products found for main grid */}
          {productsToDisplay.length === 0 && !isLoading && !isTyping && recommendationFilter === "all" && (
            <div className="text-center py-12">
              <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No products found</h3>
              <p className="text-gray-600">Try adjusting your filters or search terms.</p>
            </div>
          )}

        {/* Floating Price Filter Overlay - Only shows after search */}
        {searchTerm && searchTerm.trim() && (
          <div className="hidden lg:block fixed right-0 top-24 z-50">
            <PriceFilter
              searchQuery={searchTerm}
              category={selectedCategory}
              onPriceChange={(minPrice, maxPrice) => setPriceRange([minPrice, maxPrice])}
            />
          </div>
        )}
        
        {/* Mobile Price Filter - Shows at bottom of search results */}
        {searchTerm && searchTerm.trim() && (
          <div className="lg:hidden mb-6">
            <PriceFilter
              searchQuery={searchTerm}
              category={selectedCategory}
              onPriceChange={(minPrice, maxPrice) => setPriceRange([minPrice, maxPrice])}
            />
          </div>
        )}
      </div>
    </div>

    {/* View on Map Modal */}
    {(() => {
      // Safety checks before rendering map
      if (!mapProduct) {
        console.log('🗺️ No map product selected');
        return null;
      }
      
      if (!userLocation) {
        console.log('🗺️ No user location available, using fallback');
        // Use fallback location for testing
        const fallbackLocation = { latitude: 9.0245, longitude: 38.7485 };
        console.log('🗺️ Using fallback location:', fallbackLocation);
        // Continue with fallback location instead of returning null
      } else {
        console.log('🗺️ User location available:', userLocation);
      }
      
      // Check if vendor has valid coordinates
      const vendorCoords = mapProduct.vendor?.vendorLocation?.coordinates;
      const shopCoords = mapProduct.vendor?.coordinates;
      const hasValidCoords = 
        (vendorCoords && Array.isArray(vendorCoords) && vendorCoords.length === 2) ||
        (shopCoords && typeof shopCoords.latitude === 'number' && typeof shopCoords.longitude === 'number');
      
      if (!hasValidCoords) {
        console.log('🗺️ No valid vendor coordinates found');
        return null;
      }
      
      console.log('🗺️ All checks passed, rendering map');
      
      return (
        <ViewOnMap
          userLocation={userLocation || { latitude: 9.0245, longitude: 38.7485 }}
          vendorLocation={{
            latitude: (() => {
              // Try vendorLocation first (GeoJSON format: [lng, lat])
              if (vendorCoords && Array.isArray(vendorCoords) && vendorCoords.length === 2) {
                return vendorCoords[1]; // lat is at index 1
              }
              // Fallback to shop coordinates (lat/lng format)
              else if (shopCoords && typeof shopCoords.latitude === 'number') {
                return shopCoords.latitude;
              }
              return 0; // Fallback
            })(),
            longitude: (() => {
              // Try vendorLocation first (GeoJSON format: [lng, lat])
              if (vendorCoords && Array.isArray(vendorCoords) && vendorCoords.length === 2) {
                return vendorCoords[0]; // lng is at index 0
              }
              // Fallback to shop coordinates (lat/lng format)
              else if (shopCoords && typeof shopCoords.longitude === 'number') {
                return shopCoords.longitude;
              }
              return 0; // Fallback
            })()
          }}
          vendorName={mapProduct.vendor?.businessName || mapProduct.vendor?.firstName || 'Unknown Vendor'}
          productName={mapProduct.name}
          distance={mapProduct.distance}
          onClose={() => setMapProduct(null)}
        />
      );
    })()}
  </div>
  );
};

export default ProductsPageNew;
