import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { AuthProvider } from './contexts/AuthContext';
import { ToastProvider } from './contexts/ToastContext';
import {
  publicRoutes,
  dashboardRoutes,
  adminRoutes,
  deliveryRoutes,
  paymentRoutes,
} from './routes';
import { NotFound } from './pages';

// Create QueryClient instance
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      retry: 2,
      retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
    },
  },
});

// React Router future flags to suppress warnings
const routerOptions = {
  future: {
    v7_startTransition: true,
    v7_relativeSplatPath: true,
  },
};

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ToastProvider>
          <Router {...routerOptions}>
            <div className="min-h-screen bg-gray-50">
              <Routes>
                {publicRoutes}
                {dashboardRoutes}
                {adminRoutes}
              {deliveryRoutes}
              {paymentRoutes}
              
              {/* 404 NotFound fallback route */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </div>
        </Router>
      </ToastProvider>
    </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
