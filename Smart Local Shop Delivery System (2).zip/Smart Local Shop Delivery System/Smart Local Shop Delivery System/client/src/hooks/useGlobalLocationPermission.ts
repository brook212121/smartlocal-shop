import { useState, useEffect, useCallback } from 'react';
import { Location, reverseGeocode } from '../utils/mapUtils';

interface LocationState {
  location: Location | null;
  isLoading: boolean;
  error: string | null;
  isInitialized: boolean;
}

export const useGlobalLocationPermission = () => {
  const [locationState, setLocationState] = useState<LocationState>({
    location: null,
    isLoading: false,
    error: null,
    isInitialized: false
  });

  // Manual location override for desktop testing
  const setManualLocation = useCallback((latitude: number, longitude: number) => {
    console.log('🔧 Setting manual location for desktop testing');
    const location: Location = {
      latitude,
      longitude,
      address: `Manual: ${latitude.toFixed(4)}, ${longitude.toFixed(4)}`
    };
    setLocationState({
      location,
      isLoading: false,
      error: null,
      isInitialized: true
    });
  }, []);

  // Add manual location to window for testing
  useEffect(() => {
    if (typeof window !== 'undefined') {
      (window as any).setManualLocation = setManualLocation;
      console.log('🔧 Manual location override available: window.setManualLocation(lat, lng)');
    }
  }, [setManualLocation]);

  const initializeLocation = useCallback(async () => {
    // Prevent multiple initializations
    if (locationState.isInitialized || locationState.isLoading) {
      return;
    }

    console.log('🔍 Initializing global location permission...');
    setLocationState(prev => ({ ...prev, isLoading: true, error: null }));
    
    try {
      // Check if geolocation is supported
      if (!navigator.geolocation) {
        throw new Error('Geolocation is not supported by this browser');
      }

      // Request current position
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          console.log('🌍 GPS POSITION DATA:');
          console.log('📍 Raw GPS Position:', position);
          console.log('📍 Latitude:', position.coords.latitude);
          console.log('📍 Longitude:', position.coords.longitude);
          console.log('📍 Accuracy:', position.coords.accuracy, 'meters');
          console.log('📍 Altitude:', position.coords.altitude);
          console.log('📍 Altitude Accuracy:', position.coords.altitudeAccuracy);
          console.log('📍 Heading:', position.coords.heading);
          console.log('📍 Speed:', position.coords.speed);
          console.log('📍 Timestamp:', new Date(position.timestamp).toISOString());
          
          try {
            const location: Location = {
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
              address: await reverseGeocode(position.coords.latitude, position.coords.longitude) // Real address from coordinates
            };
            
            console.log('🏠 PROCESSED LOCATION DATA:');
            console.log('📍 Final Location:', location);
            console.log('📍 Formatted Coordinates:', `${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}`);
            console.log('📍 Geocoded Address:', location.address);
            
            setLocationState({
              location,
              isLoading: false,
              error: null,
              isInitialized: true
            });
          } catch (error) {
            console.error('❌ Error processing location data:', error);
            // Set location without address if reverse geocoding fails
            const location: Location = {
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
              address: 'Your Location'
            };
            
            console.log('🏠 FALLBACK LOCATION DATA:');
            console.log('📍 Final Location:', location);
            console.log('📍 Formatted Coordinates:', `${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}`);
            console.log('📍 Geocoded Address:', location.address);
            
            setLocationState({
              location,
              isLoading: false,
              error: null,
              isInitialized: true
            });
          }
        },
        (error) => {
          console.error('❌ Geolocation error:', error);
          console.log('🔍 Error Details:', {
            code: error.code,
            message: error.message,
            PERMISSION_DENIED: error.code === 1,
            POSITION_UNAVAILABLE: error.code === 2,
            TIMEOUT: error.code === 3
          });
          
          // Desktop-specific fallback
          if (error.code === 3) { // TIMEOUT
            console.log('🔄 Desktop timeout - trying with lower accuracy...');
            navigator.geolocation.getCurrentPosition(
              async (position) => {
                console.log('🔍 Fallback position obtained:', position);
                const location: Location = {
                  latitude: position.coords.latitude,
                  longitude: position.coords.longitude,
                  address: await reverseGeocode(position.coords.latitude, position.coords.longitude)
                };
                setLocationState({
                  location,
                  isLoading: false,
                  error: null,
                  isInitialized: true
                });
              },
              (fallbackError) => {
                console.error('❌ Fallback also failed:', fallbackError);
                setLocationState({
                  location: null,
                  isLoading: false,
                  error: `Location access denied: ${fallbackError.message}`,
                  isInitialized: true
                });
              },
              {
                enableHighAccuracy: false,  // Lower accuracy for desktop
                timeout: 15000,
                maximumAge: 300000
              }
            );
            return;
          }
          
          setLocationState({
            location: null,
            isLoading: false,
            error: `Location access denied: ${error.message}`,
            isInitialized: true
          });
        },
        {
          enableHighAccuracy: true,
          timeout: 30000,        // Increased timeout for desktop
          maximumAge: 60000     // 1 minute cache
        }
      );
    } catch (error) {
      console.error('❌ Location initialization error:', error);
      setLocationState({
        location: null,
        isLoading: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred',
        isInitialized: true
      });
    }
  }, [locationState.isInitialized, locationState.isLoading]);

  const requestPermission = useCallback(async () => {
    // Reset initialization state to allow re-initialization
    setLocationState(prev => ({ ...prev, isInitialized: false, isLoading: true, error: null }));
    
    try {
      if (!navigator.geolocation) {
        throw new Error('Geolocation is not supported by this browser');
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          const location: Location = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            address: 'Your Location'
          };
          console.log('🔍 Location obtained after permission request:', location);
          setLocationState({
            location,
            isLoading: false,
            error: null,
            isInitialized: true
          });
        },
        (error) => {
          console.error('❌ Geolocation error after permission request:', error);
          setLocationState({
            location: null,
            isLoading: false,
            error: `Location access denied: ${error.message}`,
            isInitialized: true
          });
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 300000
        }
      );
    } catch (error) {
      console.error('❌ Permission request error:', error);
      setLocationState({
        location: null,
        isLoading: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred',
        isInitialized: true
      });
    }
  }, []);

  // Auto-initialize location when hook is first used
  useEffect(() => {
    if (!locationState.isInitialized && !locationState.isLoading) {
      console.log('🔍 Auto-initializing location permission...');
      initializeLocation();
    }
  }, [locationState.isInitialized, locationState.isLoading, initializeLocation]);

  return {
    ...locationState,
    initializeLocation,
    requestPermission,
    setManualLocation
  };
};
