import { useState, useCallback } from 'react';
import { Vendor, vendorService } from '../services/vendorService';
import { Location, haversineDistance, validateCoordinates, formatCoordinates } from '../utils/mapUtils';

export const useGoogleMaps = () => {
  const [isLocationLoading, setIsLocationLoading] = useState(false);
  const [userLocation, setUserLocation] = useState<Location | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Get user's current location
  const getUserLocation = useCallback((): Promise<Location> => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation is not supported by this browser'));
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          resolve({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            address: 'Customer Location' // Default address for customer location
          });
        },
        (error) => {
          reject(new Error(`Geolocation error: ${error.message}`));
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 300000 // 5 minutes
        }
      );
    });
  }, []);

  // Automatically update vendor location (with proper validation and loading state)
  const autoUpdateVendorLocation = useCallback(async (): Promise<void> => {
    setIsLocationLoading(true);
    try {
      console.log('🔍 Starting automatic vendor location detection...');
      
      // Request browser geolocation
      console.log('🎯 DEBUG: Requesting geolocation...');
      console.log('🎯 DEBUG: Geolocation supported:', !!navigator.geolocation);
      
      navigator.geolocation.getCurrentPosition(
        (position) => {
          // Success callback - validate coordinates before sending
          const { latitude, longitude } = position.coords;
          
          console.log('📍 GPS Location detected:', { latitude, longitude });
          console.log('🎯 DEBUG: GPS accuracy:', position.coords.accuracy, 'meters');
          console.log('🎯 DEBUG: GPS timestamp:', new Date(position.timestamp).toISOString());
          
          // Validate coordinates are real numbers
          if (validateCoordinates(latitude, longitude)) {
            const location = {
              ...formatCoordinates(latitude, longitude),
              address: 'Auto-detected location'
            };
            
            console.log('✅ Valid coordinates, sending to backend:', location);
            
            // Send to backend
            vendorService.updateVendorLocation(location)
              .then(() => {
                console.log('🎉 Vendor location updated successfully');
              })
              .catch((error) => {
                console.error('❌ Failed to update vendor location:', error);
              })
              .finally(() => {
                setIsLocationLoading(false);
              });
              
          } else {
            console.warn('⚠️ Invalid GPS coordinates detected:', { latitude, longitude });
            console.log('🚫 Not sending invalid coordinates to backend');
            setIsLocationLoading(false);
          }
        },
        (error) => {
          // Error callback - handle permission denied or other errors
          console.warn('⚠️ Geolocation error:', error);
          setIsLocationLoading(false);
          
          switch(error.code) {
            case error.PERMISSION_DENIED:
              console.log('🚫 Location permission denied by user');
              break;
            case error.POSITION_UNAVAILABLE:
              console.log('🚫 Location information unavailable');
              break;
            case error.TIMEOUT:
              console.log('🚫 Location request timed out');
              break;
            default:
              break;
          }
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 300000 // 5 minutes
        }
      );
      
    } catch (error) {
      console.error('❌ Critical error in location detection:', error);
      setIsLocationLoading(false);
      // Do NOT send any location data
    }
  }, []);

  // Calculate distance between two points using Google Distance Matrix API
  const calculateDistance = useCallback(async (
    origin: Location,
    destination: Location
  ): Promise<{ distance: number; duration: number }> => {
    try {
      // Route through backend to avoid CORS issues
      console.log('🗺️ DEBUG: Calling backend distance API...');
      console.log('🗺️ DEBUG: Origin:', `${origin.latitude},${origin.longitude}`);
      console.log('🗺️ DEBUG: Destination:', `${destination.latitude},${destination.longitude}`);
      
      // Validate coordinates before making API call
      if (!origin.latitude || !origin.longitude || !destination.latitude || !destination.longitude) {
        console.error('❌ Invalid coordinates for distance calculation');
        throw new Error('Invalid coordinates');
      }
      
      // Calculate Haversine distance as verification
      const haversineDist = haversineDistance(origin.latitude, origin.longitude, destination.latitude, destination.longitude);
      console.log('🗺️ DEBUG: Haversine verification distance:', haversineDist.toFixed(3), 'km');
      
      const response = await fetch(`/api/maps/distance-matrix`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          origins: `${origin.latitude},${origin.longitude}`,
          destinations: `${destination.latitude},${destination.longitude}`
        })
      });

      console.log('🗺️ DEBUG: Backend response status:', response.status);

      if (!response.ok) {
        const errorData = await response.json();
        console.error('❌ Backend API error:', errorData);
        
        // Handle timeout specifically
        if (response.status === 408) {
          throw new Error('Request timeout - using Haversine distance as fallback');
        }
        
        throw new Error('Failed to calculate distance');
      }

      const backendResponse = await response.json();
      console.log('🗺️ DEBUG: Backend response:', backendResponse);
      
      if (!backendResponse.success) {
        // Handle timeout specifically
        if (backendResponse.error === 'TIMEOUT') {
          throw new Error('Request timeout - using Haversine distance as fallback');
        }
        
        throw new Error(`Distance Matrix API error: ${backendResponse.message || 'Unknown error'}`);
      }

      const googleMapsData = backendResponse.data;
      console.log('🗺️ DEBUG: Google Maps data:', googleMapsData);

      // Validate Google Maps response structure
      if (!googleMapsData.rows?.[0]?.elements?.[0]) {
        console.error('❌ Invalid Google Maps response structure');
        throw new Error('Invalid response structure');
      }

      const element = googleMapsData.rows[0].elements[0];
      
      if (element.status !== 'OK') {
        console.error('❌ Google Maps API error status:', element.status);
        throw new Error(`Google Maps API error: ${element.status}`);
      }

      // Extract distance and duration with validation
      const distance = element.distance?.value || 0;
      const duration = element.duration?.value || 0;
      
      console.log('🗺️ DEBUG: Extracted distance:', distance, 'meters');
      console.log('🗺️ DEBUG: Extracted duration:', duration, 'seconds');
      
      // Validate distance values
      if (distance < 0 || duration < 0) {
        console.error('❌ Invalid distance/duration values');
        throw new Error('Invalid distance values');
      }
      
      // Compare Google Maps distance with Haversine (should be reasonably close)
      const googleDistanceKm = distance / 1000;
      const difference = Math.abs(googleDistanceKm - haversineDist);
      const tolerance = Math.max(0.5, haversineDist * 0.3); // 30% tolerance or 0.5km minimum
      
      console.log('🗺️ DEBUG: Distance comparison:');
      console.log('🗺️ DEBUG: Google Maps:', googleDistanceKm.toFixed(3), 'km');
      console.log('🗺️ DEBUG: Haversine:', haversineDist.toFixed(3), 'km');
      console.log('🗺️ DEBUG: Difference:', difference.toFixed(3), 'km');
      console.log('🗺️ DEBUG: Tolerance:', tolerance.toFixed(3), 'km');
      
      if (difference > tolerance) {
        console.warn('⚠️ Large difference between Google Maps and Haversine distance');
        console.warn('⚠️ This might indicate an issue with coordinates or API response');
      } else {
        console.log('✅ Distance verification passed - values are consistent');
      }

      console.log('✅ Distance calculation successful:', { distance, duration });

      return {
        distance: distance, // in meters
        duration: duration // in seconds
      };
    } catch (error) {
      console.error('Distance calculation error:', error);
      throw error;
    }
  }, []);

  // Find nearest vendor to customer location (optimized with Haversine + Google API)
  const findNearestVendor = useCallback(async (
    customerLocation: Location,
    vendors: Vendor[],
    currentUserId?: string // Add current user ID to exclude self
  ): Promise<{ vendor: Vendor | null; distance: number; duration: number }> => {
    if (!customerLocation || vendors.length === 0) {
      return { vendor: null, distance: 0, duration: 0 };
    }

    console.log('🎯 DEBUG: Customer coordinates:', customerLocation);
    console.log('🎯 DEBUG: Total vendors available:', vendors.length);
    if (currentUserId) {
      console.log('🎯 DEBUG: Current user ID:', currentUserId);
    }

    // Step 1: Filter vendors with valid coordinates and calculate Haversine distances
    const vendorsWithDistance: Array<Vendor & { haversineDistanceKm: number }> = [];
    
    for (const vendor of vendors) {
      // Requirement 3: Ignore vendors that are offline, missing coordinates, or same user as requester
      if (!vendor.location) {
        console.log(`🎯 DEBUG: Skipping vendor ${vendor._id} - no location`);
        continue;
      }

      const isVendorOnline = vendor.isOnline !== false;
      if (!isVendorOnline) {
        console.log(`🎯 DEBUG: Skipping vendor ${vendor._id} - offline`);
        continue;
      }

      // Exclude current user from vendor assignment
      if (currentUserId && vendor._id === currentUserId) {
        console.log(`🎯 DEBUG: Skipping vendor ${vendor._id} - same user as requester`);
        continue;
      }

      // Validate vendor coordinates
      if (
        vendor.location.latitude === undefined ||
        vendor.location.longitude === undefined ||
        typeof vendor.location.latitude !== 'number' ||
        typeof vendor.location.longitude !== 'number' ||
        !isFinite(vendor.location.latitude) ||
        !isFinite(vendor.location.longitude)
      ) {
        console.warn(`⚠️ Vendor ${vendor._id} has invalid coordinates, skipping`);
        continue;
      }

      // Calculate Haversine distance
      const haversineDistanceKm = haversineDistance(
        customerLocation.latitude,
        customerLocation.longitude,
        vendor.location.latitude,
        vendor.location.longitude
      );

      console.log(`🎯 DEBUG: Vendor ${vendor._id} (${vendor.firstName} ${vendor.lastName})`);
      console.log(`🎯 DEBUG: Vendor coordinates: ${vendor.location.latitude}, ${vendor.location.longitude}`);
      console.log(`🎯 DEBUG: Haversine distance: ${haversineDistanceKm.toFixed(2)}km`);

      vendorsWithDistance.push({
        ...vendor,
        haversineDistanceKm
      });
    }

    console.log(`🎯 DEBUG: Vendors with valid coordinates: ${vendorsWithDistance.length}`);

    // Step 2: Filter vendors within 10km radius
    const nearbyVendors = vendorsWithDistance.filter(vendor => 
      vendor.haversineDistanceKm <= 10
    );

    console.log(`🎯 DEBUG: Vendors within 10km radius: ${nearbyVendors.length}`);

    if (nearbyVendors.length === 0) {
      console.log('🎯 DEBUG: No vendors within 10km radius');
      return { vendor: null, distance: 0, duration: 0 };
    }

    // Step 3: Sort by Haversine distance and take top 5 (increased from 3 for better accuracy)
    nearbyVendors.sort((a, b) => a.haversineDistanceKm - b.haversineDistanceKm);
    const top5Vendors = nearbyVendors.slice(0, 5);

    console.log(`🎯 DEBUG: Top 5 nearest vendors (by Haversine):`);
    top5Vendors.forEach((vendor, index) => {
      console.log(`🎯 DEBUG: ${index + 1}. ${vendor.firstName} ${vendor.lastName} - ${vendor.haversineDistanceKm.toFixed(2)}km`);
    });

    // Step 4: Get accurate driving distances from Google API for top 5 only
    const vendorsWithDrivingDistance = [];
    
    console.log(`🎯 DEBUG: Starting Google API calls for top ${top5Vendors.length} vendors...`);
    
    for (const vendor of top5Vendors) {
      try {
        // Ensure vendor.location is not undefined
        if (!vendor.location) {
          console.warn(`⚠️ Vendor ${vendor._id} has no location data, skipping`);
          continue;
        }

        console.log(`🎯 DEBUG: Calling Google API for vendor ${vendor.firstName} ${vendor.lastName}`);
        console.log(`🎯 DEBUG: Customer location: ${customerLocation.latitude}, ${customerLocation.longitude}`);
        console.log(`🎯 DEBUG: Vendor location: ${vendor.location.latitude}, ${vendor.location.longitude}`);

        const { distance, duration } = await calculateDistance(customerLocation, vendor.location);
        
        console.log(`🎯 DEBUG: Google API result for ${vendor.firstName}:`);
        console.log(`🎯 DEBUG: Raw distance: ${distance} meters`);
        console.log(`🎯 DEBUG: Raw duration: ${duration} seconds`);
        console.log(`🎯 DEBUG: Distance in km: ${(distance / 1000).toFixed(2)}km`);
        console.log(`🎯 DEBUG: Duration in min: ${Math.round(duration / 60)}min`);
        
        vendorsWithDrivingDistance.push({
          ...vendor,
          drivingDistance: distance,
          drivingDuration: duration
        });
        console.log(`🎯 DEBUG: Google API - ${vendor.firstName} ${vendor.lastName}: ${(distance / 1000).toFixed(2)}km (${Math.round(duration / 60)}min)`);
      } catch (error) {
        console.error(`❌ Error getting driving distance for vendor ${vendor._id}:`, error);
        // Fall back to Haversine distance if Google API fails
        const fallbackDistance = vendor.haversineDistanceKm * 1000; // Convert km to meters
        const fallbackDuration = vendor.haversineDistanceKm * 60; // Rough estimate: 1 min per km
        console.log(`🎯 DEBUG: Using fallback for ${vendor.firstName}: ${(fallbackDistance / 1000).toFixed(2)}km (${Math.round(fallbackDuration / 60)}min)`);
        
        vendorsWithDrivingDistance.push({
          ...vendor,
          drivingDistance: fallbackDistance,
          drivingDuration: fallbackDuration
        });
      }
    }

    // Step 5: Find vendor with shortest driving distance (Requirement 4: If equal distance, choose first one)
    vendorsWithDrivingDistance.sort((a, b) => a.drivingDistance - b.drivingDistance);
    const nearestVendor = vendorsWithDrivingDistance[0] || null;

    // Requirement 1: Do not assign order to more than one vendor
    // Requirement 2: Assign order only to nearest available vendor
    if (nearestVendor) {
      console.log(`🎯 DEBUG: Selected nearest vendor: ${nearestVendor.firstName} ${nearestVendor.lastName}`);
      console.log(`🎯 DEBUG: Final driving distance: ${(nearestVendor.drivingDistance / 1000).toFixed(2)}km`);
      console.log(`🎯 DEBUG: Final driving time: ${Math.round(nearestVendor.drivingDuration / 60)}min`);
      
      return {
        vendor: nearestVendor, // Only ONE vendor assigned
        distance: nearestVendor.drivingDistance, // in meters
        duration: nearestVendor.drivingDuration // in seconds
      };
    }

    console.log('🎯 DEBUG: No suitable vendor found');
    return { vendor: null, distance: 0, duration: 0 };
  }, [calculateDistance]);

  // Get location name using reverse geocoding (secure - uses environment variable)
  const getLocationName = useCallback(async (latitude: number, longitude: number): Promise<string> => {
    try {
      const apiKey = (import.meta as any).env.VITE_GOOGLE_MAPS_API_KEY;
      
      if (!apiKey) {
        console.warn('⚠️ Google Maps API key not found in environment variables');
        return 'Unknown location';
      }
      
      const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${apiKey}`;
      
      // Hide API key in logs for security
      console.log('🗺️ DEBUG: Reverse geocoding URL:', apiKey ? url.replace(apiKey, '***API_KEY***') : url.replace('key=', 'key=***API_KEY***'));
      console.log('🗺️ DEBUG: Coordinates:', latitude, longitude);
      
      const response = await fetch(url);
      const data = await response.json();
      
      console.log('🗺️ DEBUG: Geocoding response:', data);
      console.log('🗺️ DEBUG: Response status:', data.status);
      console.log('🗺️ DEBUG: Results count:', data.results?.length || 0);
      
      if (data.status === 'OK' && data.results?.[0]) {
        // Get the most specific address component
        const addressComponents = data.results[0].address_components;
        console.log('🗺️ DEBUG: Address components:', addressComponents);
        
        const neighborhood = addressComponents.find((comp: any) => comp.types.includes('sublocality'))?.long_name;
        const locality = addressComponents.find((comp: any) => comp.types.includes('locality'))?.long_name;
        const route = addressComponents.find((comp: any) => comp.types.includes('route'))?.long_name;
        
        console.log('🗺️ DEBUG: Found components - Route:', route, 'Neighborhood:', neighborhood, 'Locality:', locality);
        
        // Return the most specific available location
        if (route && neighborhood) return `${route}, ${neighborhood}`;
        if (neighborhood) return neighborhood;
        if (locality) return locality;
        
        // Fallback to formatted address
        const formattedAddress = data.results[0].formatted_address.split(',')[0].trim();
        console.log('🗺️ DEBUG: Formatted address fallback:', formattedAddress);
        return formattedAddress;
      }
      
      console.log('🗺️ DEBUG: No valid geocoding results, returning Unknown location');
      return 'Unknown location';
    } catch (error) {
      console.error('🗺️ DEBUG: Error getting location name:', error);
      return 'Unknown location';
    }
  }, []);

  // Get user location and find nearest vendor
  const getNearestVendor = useCallback(async (vendors: Vendor[], currentUserId?: string) => {
    setIsLocationLoading(true);
    setError(null);

    try {
      // Get customer's current location
      console.log('🎯 DEBUG: Getting user location...');
      console.log('🎯 DEBUG: User agent:', navigator.userAgent);
      console.log('🎯 DEBUG: Is secure context:', window.isSecureContext);
      if (currentUserId) {
        console.log('🎯 DEBUG: Current user ID for exclusion:', currentUserId);
      }
      
      let location;
      try {
        location = await getUserLocation();
      } catch (locationError) {
        console.error('🚫 Geolocation failed, using fallback:', locationError);
        
        // Fallback: Use central point of all vendor locations
        if (vendors.length > 0) {
          let totalLat = 0;
          let totalLng = 0;
          let validVendors = 0;
          
          // Calculate average coordinates of all vendors
          for (const vendor of vendors) {
            if (vendor.location && vendor.location.latitude && vendor.location.longitude) {
              totalLat += vendor.location.latitude;
              totalLng += vendor.location.longitude;
              validVendors++;
            }
          }
          
          if (validVendors > 0) {
            location = {
              latitude: totalLat / validVendors,
              longitude: totalLng / validVendors,
              address: 'Central location (average of all vendors)'
            };
            console.log('🎯 DEBUG: Using central location as fallback:', location);
            console.log(`🎯 DEBUG: Calculated from ${validVendors} vendors`);
          } else {
            // Final fallback: Use default coordinates
            location = {
              latitude: 7.690879,
              longitude: 36.818639,
              address: 'Default location (Addis Ababa)'
            };
            console.log('🎯 DEBUG: Using default coordinates as fallback:', location);
          }
        } else {
          // Final fallback: Use default coordinates
          location = {
            latitude: 7.690879,
            longitude: 36.818639,
            address: 'Default location (Addis Ababa)'
          };
          console.log('🎯 DEBUG: Using default coordinates as fallback:', location);
        }
      }
      
      setUserLocation(location);

      console.log('🎯 DEBUG: Customer location:', location);
      console.log('🎯 DEBUG: Available vendors count:', vendors.length);
      
      const result = await findNearestVendor(location, vendors, currentUserId);
      console.log('🎯 DEBUG: Nearest vendor result:', result);
      
      // Explicitly check for valid vendor (including 0 distance case)
      if (result.vendor && result.vendor._id) {
        console.log(`🎯 DEBUG: Selected vendor: ${result.vendor.firstName} ${result.vendor.lastName} at ${result.distance}m`);
      } else {
        console.log('🎯 DEBUG: No valid vendor found - result.vendor:', result.vendor);
        console.log('🎯 DEBUG: No valid vendor found - result.distance:', result.distance);
        setError('No available vendors found in your area');
      }
      
      return result;
    } catch (error) {
      console.error('🎯 DEBUG: Error in getNearestVendor:', error);
      setError(error instanceof Error ? error.message : 'Failed to get your location');
      return { vendor: null, distance: 0, duration: 0 };
    } finally {
      setIsLocationLoading(false);
    }
  }, [getUserLocation, findNearestVendor]);

  return {
    isLocationLoading,
    userLocation,
    setUserLocation,
    error,
    getUserLocation,
    calculateDistance,
    findNearestVendor,
    getNearestVendor,
    autoUpdateVendorLocation,
    getLocationName
  };
};
