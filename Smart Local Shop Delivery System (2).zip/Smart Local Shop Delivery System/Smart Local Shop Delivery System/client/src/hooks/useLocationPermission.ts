import { useState, useEffect, useRef } from 'react';
import { Location } from '../utils/mapUtils'; // ✅ Import consistent Location interface

export type LocationPermissionStatus = 'granted' | 'denied' | 'prompt' | 'not-supported';

// Cache for location results to prevent duplicate API calls
const locationCache = new Map<string, { location: Location; timestamp: number }>();
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

export const useLocationPermission = () => {
  const [permissionStatus, setPermissionStatus] = useState<LocationPermissionStatus | null>(null);
  const [currentLocation, setCurrentLocation] = useState<Location | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const isInitialized = useRef(false);

  const checkPermissionStatus = (): LocationPermissionStatus => {
    if (!navigator.geolocation) {
      return 'not-supported';
    }
    
    // For browsers that don't support permissions API, assume 'prompt'
    if (!navigator.permissions) {
      return 'prompt';
    }
    
    // Note: This is a simplified check - in production you'd want to handle the permissions API properly
    return 'prompt';
  };

  const getCurrentLocation = (): Promise<Location> => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation is not supported by this browser'));
        return;
      }

      // Check cache first
      const cacheKey = 'current-location';
      const cached = locationCache.get(cacheKey);
      if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
        console.log('🔍 Using cached location');
        resolve(cached.location);
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          const location: Location = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            address: 'Current Location'
          };
          
          // Cache the result
          locationCache.set(cacheKey, {
            location,
            timestamp: Date.now()
          });
          
          resolve(location);
        },
        (error) => {
          let status: LocationPermissionStatus = 'denied';
          switch (error.code) {
            case error.PERMISSION_DENIED:
              status = 'denied';
              break;
            case error.POSITION_UNAVAILABLE:
              status = 'not-supported';
              break;
            case error.TIMEOUT:
              status = 'denied';
              break;
          }
          reject(new Error(`Geolocation error: ${error.message}`));
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 300000 // 5 minutes
        }
      );
    });
  };

  const requestPermission = async () => {
    setIsLoading(true);
    try {
      const location = await getCurrentLocation();
      setCurrentLocation(location);
      setPermissionStatus('granted');
    } catch (error) {
      console.error('Permission request error:', error);
      setPermissionStatus('denied');
      setCurrentLocation(null);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isInitialized.current) return; // Prevent duplicate initialization
    
    const initializeLocation = async () => {
      console.log('🔍 Initializing location permission...');
      setIsLoading(true);
      
      try {
        const status = checkPermissionStatus();
        console.log('🔍 Current permission status:', status);
        setPermissionStatus(status);

        if (status === 'not-supported') {
          console.log('🔍 Geolocation not supported');
          setIsLoading(false);
          return;
        }

        // Try to get current location (this will trigger permission prompt if needed)
        try {
          const location = await getCurrentLocation();
          console.log('🔍 Location obtained:', location);
          setCurrentLocation(location);
          setPermissionStatus('granted');
        } catch (error) {
          console.log('🔍 Location access denied or unavailable');
          setPermissionStatus('denied');
          setCurrentLocation(null);
        }
      } catch (error) {
        console.error('❌ Location initialization error:', error);
        setPermissionStatus('not-supported');
        setCurrentLocation(null);
      } finally {
        setIsLoading(false);
      }
    };

    initializeLocation();
    isInitialized.current = true;
  }, []);

  return {
    permissionStatus,
    location: currentLocation,
    isLoading,
    requestPermission
  };
};
