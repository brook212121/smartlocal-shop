import React, { createContext, useContext, useReducer, useEffect, ReactNode, useMemo, useRef } from 'react';
import { User } from 'lucide-react';
import { getApiUrl } from '../utils/apiConfig';
import { safeFetch, isUserOffline, getUserFriendlyErrorMessage } from '../utils/errorHandler';

interface User {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  role: 'VENDOR' | 'DELIVERY' | 'ADMIN';
  profileImage?: string;
  isEmailVerified: boolean;
  isPhoneVerified: boolean;
  isActive: boolean;
  lastLogin?: string;
  createdAt: string;
  updatedAt: string;
  defaultAddress?: {
    street: string;
    city: string;
    county: string;
    coordinates?: {
      latitude: number;
      longitude: number;
    };
  };
}

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

interface AuthContextType {
  authState: AuthState;
  login: (email: string, password: string) => Promise<{
    success: boolean;
    user: any;
    token: any;
    error?: string;
  }>;
  register: (userData: any) => Promise<void>;
  logout: () => void;
  clearError: () => void;
  setUser: (user: any) => void;
  setToken: (token: string | null) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

type AuthAction =
  | { type: 'LOGIN_START' }
  | { type: 'LOGIN_SUCCESS'; payload: { user: User; token: string } }
  | { type: 'LOGIN_FAILURE'; payload: string }
  | { type: 'LOGOUT' }
  | { type: 'CLEAR_ERROR' }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_USER'; payload: User | null }
  | { type: 'SET_TOKEN'; payload: string | null };

const authReducer = (state: AuthState, action: AuthAction): AuthState => {
  switch (action.type) {
    case 'LOGIN_START':
      return {
        ...state,
        isLoading: true,
        error: null
      };
    
    case 'LOGIN_SUCCESS':
      return {
        ...state,
        user: action.payload.user,
        token: action.payload.token,
        isAuthenticated: true,
        isLoading: false,
        error: null
      };
    
    case 'LOGIN_FAILURE':
      return {
        ...state,
        user: null,
        token: null,
        isAuthenticated: false,
        isLoading: false,
        error: action.payload
      };
    
    case 'LOGOUT':
      return {
        ...state,
        user: null,
        token: null,
        isAuthenticated: false,
        isLoading: false,
        error: null
      };
    
    case 'CLEAR_ERROR':
      return {
        ...state,
        error: null
      };
    
    case 'SET_LOADING':
      return {
        ...state,
        isLoading: action.payload
      };
    
    case 'SET_USER':
      return {
        ...state,
        user: action.payload,
        isAuthenticated: !!action.payload
      };
    
    case 'SET_TOKEN':
      return {
        ...state,
        token: action.payload,
        isAuthenticated: !!action.payload
      };
    
    default:
      return state;
  }
};

const initialState: AuthState = {
  user: null,
  token: null,
  isAuthenticated: false,
  isLoading: true, // Start with loading true
  error: null
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [authState, dispatch] = useReducer(authReducer, initialState);
  const [isInitialized, setIsInitialized] = React.useState(false);
  
  // 🔧 PERFORMANCE FIX: Ref to track initialization in StrictMode
  const initializationRef = useRef(false);
  const loginRequestRef = useRef<AbortController | null>(null);

  // Debug auth state changes (without sensitive data)
  useEffect(() => {
    console.log('🔐 AuthContext: State changed:', {
      isLoading: authState.isLoading,
      isAuthenticated: authState.isAuthenticated,
      userId: authState.user?._id,
      userRole: authState.user?.role,
      hasToken: !!authState.token
    });
  }, [authState]);

  // 🔧 PERFORMANCE FIX: Initialize auth state from localStorage (StrictMode safe)
  useEffect(() => {
    // Prevent multiple initializations even in StrictMode
    if (isInitialized || initializationRef.current) return;
    
    initializationRef.current = true;
    console.log('🔐 AuthContext: Initializing auth from localStorage...');
    
    const authData = localStorage.getItem('authData');
    
    if (authData) {
      try {
        const parsed = JSON.parse(authData);
        
        if (parsed.token && parsed.user) {
          // Immediate state restoration
          dispatch({
            type: 'LOGIN_SUCCESS',
            payload: { user: parsed.user, token: parsed.token }
          });
          
          console.log('🔐 AuthContext: Successfully restored auth state');
        } else {
          console.error('🔐 AuthContext: Invalid auth data structure - missing token or user');
          localStorage.removeItem('authData');
        }
      } catch (error) {
        console.error('🔐 AuthContext: Error parsing authData:', error);
        localStorage.removeItem('authData');
      }
    } else {
      console.log('🔐 AuthContext: No authData found in localStorage');
    }
    
    // Set loading to false when initialization is complete
    dispatch({ type: 'SET_LOADING', payload: false });
    setIsInitialized(true);
  }, [isInitialized]);

  // 🔧 PERFORMANCE FIX:// Login with deduplication and AbortController
  const login = async (email: string, password: string) => {
    // Cancel previous login request if still pending
    if (loginRequestRef.current) {
      loginRequestRef.current.abort();
    }
    
    // Create new AbortController for this request
    loginRequestRef.current = new AbortController();
    
    dispatch({ type: 'LOGIN_START' });
    
    try {
      // Check offline status first
      if (isUserOffline()) {
        const friendlyMessage = getUserFriendlyErrorMessage(new Error("NETWORK_ERROR"));
        return { success: false, user: null, token: null, error: friendlyMessage };
      }
      
      const startTime = performance.now();
      
      const response = await safeFetch(getApiUrl('/api/auth/login'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
        signal: loginRequestRef.current.signal
      });

      // Check if request was aborted
      if (loginRequestRef.current.signal.aborted) {
        return { success: false, user: null, token: null, error: 'Request cancelled' };
      }

      let data;
      try {
        data = await response.json();
      } catch (parseError) {
        // Log error only in development
        if (import.meta.env.DEV) {
          console.error('AuthContext: Failed to parse response as JSON:', parseError);
          console.error('AuthContext: Response text:', await response.text());
        }
        
        // Handle HTML error responses
        if (response.status === 503) {
          return { success: false, user: null, token: null, error: 'Service temporarily unavailable' };
        }
        
        return { success: false, user: null, token: null, error: 'Invalid server response' };
      }
      
      if (response.ok) {
        // Handle different response structures
        let user, token;
        
        if (data.user) {
          // Standard response: { user: {...}, token: "..." }
          user = data.user;
          token = data.token;
        } else if (data.data) {
          // Nested response: { data: { user: {...}, token: "..." } }
          user = data.data.user;
          token = data.data.token;
        } else {
          dispatch({
            type: 'LOGIN_FAILURE',
            payload: 'Invalid login response format'
          });
          return { success: false, user: null, token: null, error: 'Invalid login response format' };
        }
        
        // Validate that we have both user and token
        if (!user || !token) {
          dispatch({
            type: 'LOGIN_FAILURE',
            payload: 'Invalid login response - missing user or token'
          });
          return { success: false, user: null, token: null, error: 'Invalid login response - missing user or token' };
        }
        
        const authData = {
          user,
          token
        };
        
        // Store in localStorage
        localStorage.setItem('authData', JSON.stringify(authData));
        
        // Update state
        dispatch({
          type: 'LOGIN_SUCCESS',
          payload: authData
        });
        
        return { success: true, user, token, error: undefined };
      } else {
        // Handle different error types based on status code
        let errorMessage = 'Login failed';
        
        if (response.status === 401) {
          errorMessage = 'Invalid email or password';
        } else if (response.status === 500) {
          errorMessage = 'Server error. Please try again later';
        } else if (response.status === 503) {
          errorMessage = 'Service temporarily unavailable';
        } else if (data.message) {
          errorMessage = data.message;
        }
        
        dispatch({
          type: 'LOGIN_FAILURE',
          payload: errorMessage
        });
        return { success: false, user: null, token: null, error: errorMessage };
      }
    } catch (error: any) {
      // Don't show error for aborted requests
      if (error.name === 'AbortError') {
        return { success: false, user: null, token: null, error: 'Request cancelled' };
      }
      
      // Handle different error types (axios-style error handling)
      let errorMessage = 'Login failed';
      
      if (error.response) {
        // Server responded with error status
        if (error.response.status === 401) {
          errorMessage = 'Invalid email or password';
        } else if (error.response.status === 500) {
          errorMessage = 'Server error. Please try again later';
        } else if (error.response.status === 503) {
          errorMessage = 'Service temporarily unavailable';
        } else {
          errorMessage = error.response.data?.message || 'Login failed';
        }
      } else if (error.request) {
        // No response received (network error)
        errorMessage = 'Unable to login. Please check your connection and try again';
      } else {
        // Other error (request setup, etc.)
        errorMessage = error.message || 'Login failed';
      }
      
      dispatch({
        type: 'LOGIN_FAILURE',
        payload: errorMessage
      });
      return { success: false, user: null, token: null, error: errorMessage };
    } finally {
      loginRequestRef.current = null;
    }
  };

  const register = async (userData: any) => {
    dispatch({ type: 'LOGIN_START' });
    
    try {
      // Check offline status first
      if (isUserOffline()) {
        const friendlyMessage = getUserFriendlyErrorMessage(new Error("NETWORK_ERROR"));
        dispatch({
          type: 'LOGIN_FAILURE',
          payload: friendlyMessage
        });
        return;
      }
      
      const response = await safeFetch(getApiUrl('/api/auth/register'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData)
      });

      const data = await response.json();

      if (response.ok) {
        // Store auth data in localStorage
        const authData = {
          token: data.data.token,
          user: data.data.user
        };
        localStorage.setItem('authData', JSON.stringify(authData));
        
        // Immediate state update
        dispatch({
          type: 'LOGIN_SUCCESS',
          payload: {
            user: data.data.user,
            token: data.data.token
          }
        });
      } else {
        // Use global error handler for user-friendly messages
        const friendlyMessage = getUserFriendlyErrorMessage(new Error(data.message || 'Registration failed'));
        dispatch({
          type: 'LOGIN_FAILURE',
          payload: friendlyMessage
        });
      }
    } catch (error) {
      // Use global error handler for user-friendly messages
      const friendlyMessage = getUserFriendlyErrorMessage(error);
      dispatch({
        type: 'LOGIN_FAILURE',
        payload: friendlyMessage
      });
    }
  };

  const logout = () => {
    localStorage.removeItem('authData');
    dispatch({ type: 'LOGOUT' });
  };

  const clearError = () => {
    dispatch({ type: 'CLEAR_ERROR' });
  };

  const setUser = (user: User | null) => {
    dispatch({ type: 'SET_USER', payload: user });
  };

  const setToken = (token: string | null) => {
    dispatch({ type: 'SET_TOKEN', payload: token });
  };

  const value: AuthContextType = useMemo(() => ({
    authState,
    login,
    register,
    logout,
    clearError,
    setUser,
    setToken
  }), [authState, login, register, logout, clearError, setUser, setToken]);

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Protected Route Component
interface ProtectedRouteProps {
  children: ReactNode;
  requiredRole?: string | string[];
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, requiredRole }) => {
  const { authState } = useAuth();

  if (!authState.isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <User className="mx-auto h-12 w-12 text-gray-400" />
          <h2 className="mt-4 text-2xl font-semibold text-gray-900">Authentication Required</h2>
          <p className="mt-2 text-gray-600">Please sign in to access this page.</p>
          <a
            href="/login"
            className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  if (requiredRole) {
    const userRole = authState.user?.role;
    const allowedRoles = Array.isArray(requiredRole) ? requiredRole : [requiredRole];
    
    if (!userRole || !allowedRoles.includes(userRole)) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <User className="mx-auto h-12 w-12 text-gray-400" />
            <h2 className="mt-4 text-2xl font-semibold text-gray-900">Access Denied</h2>
            <p className="mt-2 text-gray-600">You don't have permission to access this page.</p>
            <a
              href="/"
              className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
            >
              Go Home
            </a>
          </div>
        </div>
      );
    }
  }

  return <>{children}</>;
};
