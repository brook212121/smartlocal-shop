import { Outlet } from 'react-router-dom';
import PublicHeader from '../components/PublicHeader';
import Footer from '../components/Footer';

const PublicLayout = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <PublicHeader />
      <main className="px-2 sm:px-3 lg:px-6">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
};

export default PublicLayout;
