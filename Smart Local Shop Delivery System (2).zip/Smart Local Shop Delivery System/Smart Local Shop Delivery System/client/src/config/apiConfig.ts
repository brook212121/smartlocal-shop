// API Configuration for HTTPS Tunnel
// This file helps switch between localhost and HTTPS tunnel URLs

// Development configurations
const API_CONFIGS = {
  // Local development (HTTP)
  localhost: {
    apiUrl: 'http://localhost:5000/api',
    frontendUrl: 'http://localhost:3000',
    description: 'Local development (HTTP - works on desktop, limited on mobile)'
  },
  
  // HTTPS tunnel (ngrok)
  https: {
    apiUrl: 'https://your-ngrok-url.ngrok.io/api', // Replace with actual ngrok URL
    frontendUrl: 'https://your-ngrok-url.ngrok.io', // Replace with actual ngrok URL
    description: 'HTTPS tunnel (works on mobile and desktop)'
  },
  
  // Production (HTTPS)
  production: {
    apiUrl: 'https://your-domain.com/api',
    frontendUrl: 'https://your-domain.com',
    description: 'Production environment'
  }
};

// Auto-detect environment or set manually
const getApiConfig = () => {
  const hostname = window.location.hostname;
  const protocol = window.location.protocol;
  
  // Auto-detect based on current URL
  if (hostname === 'localhost' || hostname === '127.0.0.1') {
    return API_CONFIGS.localhost;
  } else if (protocol === 'https:') {
    // Check if it's an ngrok URL
    if (hostname.includes('ngrok')) {
      return {
        ...API_CONFIGS.https,
        apiUrl: `${protocol}//${hostname}/api`,
        frontendUrl: `${protocol}//${hostname}`
      };
    }
    return API_CONFIGS.production;
  }
  
  // Default to localhost
  return API_CONFIGS.localhost;
};

// Export current configuration
export const apiConfig = getApiConfig();

// Export all configurations for manual switching
export { API_CONFIGS };

// Helper function to switch configuration
export const switchApiConfig = (configName: keyof typeof API_CONFIGS) => {
  if (API_CONFIGS[configName]) {
    console.log(`🔄 Switching to ${configName} configuration:`, API_CONFIGS[configName]);
    return API_CONFIGS[configName];
  }
  console.error(`❌ Configuration '${configName}' not found`);
  return apiConfig;
};

// Debug information
console.log('🔧 API Configuration:', apiConfig);
console.log('🌐 Current URL:', window.location.href);
console.log('🔒 Secure Context:', window.isSecureContext);
