import api from './api';

export interface VendorComplaint {
  _id: string;
  orderId: string;
  vendorId: string;
  productName: string;
  originalProductImage: string;
  deliveryPhoto: string;
  confidence: number;
  rejectionMessage: string;
  status: 'resolved' | 'pending' | 'under_review';
  createdAt: string;
  customerName?: string;
  customerPhone?: string;
  isRead?: boolean;
}

export interface ComplaintNotification {
  _id: string;
  complaintId: string;
  vendorId: string;
  orderId: string;
  productName: string;
  confidence: number;
  rejectionMessage: string;
  customerName?: string;
  customerPhone?: string;
  createdAt: string;
  isRead: boolean;
  actionTaken?: 'warning' | 'suspended' | 'banned' | 'none';
  complaintCount?: number;
}

class VendorComplaintService {
  // Get all complaints for the current vendor
  async getVendorComplaints(): Promise<VendorComplaint[]> {
    try {
      const response = await api.get('/complain/vendor');
      return response.data.data || response.data;
    } catch (error) {
      console.error('Error fetching vendor complaints:', error);
      throw error;
    }
  }

  // Get unread complaint notifications for the vendor
  async getUnreadComplaintNotifications(): Promise<ComplaintNotification[]> {
    try {
      const response = await api.get('/complain/vendor/notifications');
      console.log('🔍 DEBUG: Vendor notifications response:', response.data);
      
      const notifications = response.data.data || response.data;
      console.log('🔍 DEBUG: Processed notifications:', notifications);
      
      if (notifications && notifications.length > 0) {
        notifications.forEach((notification: any, index: number) => {
          console.log(`🔍 DEBUG: Notification ${index + 1}:`);
          console.log('  - customerName:', notification.customerName);
          console.log('  - customerPhone:', notification.customerPhone);
          console.log('  - orderId:', notification.orderId);
          console.log('  - productName:', notification.productName);
        });
      }
      
      return notifications;
    } catch (error) {
      console.error('Error fetching complaint notifications:', error);
      throw error;
    }
  }

  // Mark complaint notification as read
  async markNotificationAsRead(notificationId: string): Promise<void> {
    try {
      await api.put(`/complain/vendor/notifications/${notificationId}/read`);
    } catch (error) {
      console.error('Error marking notification as read:', error);
      throw error;
    }
  }

  // Get specific complaint details
  async getComplaintDetails(complaintId: string): Promise<VendorComplaint> {
    try {
      const response = await api.get(`/complain/vendor/${complaintId}`);
      return response.data.data || response.data;
    } catch (error) {
      console.error('Error fetching complaint details:', error);
      throw error;
    }
  }

  // Mark all notifications as read
  async markAllNotificationsAsRead(): Promise<void> {
    try {
      await api.put('/complain/vendor/notifications/read-all');
    } catch (error) {
      console.error('Error marking all notifications as read:', error);
      throw error;
    }
  }
}

export default new VendorComplaintService();
