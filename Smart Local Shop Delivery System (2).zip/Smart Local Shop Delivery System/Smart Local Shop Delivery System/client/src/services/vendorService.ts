import api from './api';
import { safeFetch, isUserOffline, getUserFriendlyErrorMessage } from '../utils/errorHandler';

export interface Vendor {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  coordinates?: {  // Updated to match backend 'coordinates' field
    lat: number;
    lng: number;
  };
  vendorLocation?: {
    type: string;
    coordinates: [number, number];
  };
  shopName?: string;
  shopDescription?: string;
  shopCategory?: string;
  businessLicense?: string;
  averageRating?: number;
  totalDeliveries?: number;
  isAvailable?: boolean;
  deliveryRadius?: number;
  isActive?: boolean;
  isVendor?: boolean;
  isDelivery?: boolean;
  isOnline: boolean;  // Added from backend
  rating?: number;
  totalOrders?: number;
}

export interface VendorResponse {
  success: boolean;
  data: {
    vendors: Vendor[];
    total: number;
  };
}

export const vendorService = {
  // Get all available vendors
  getAvailableVendors: async (): Promise<Vendor[]> => {
    try {
      // Check offline status first
      if (isUserOffline()) {
        throw new Error("NETWORK_ERROR");
      }
      
      const response = await api.get('/vendors/available');
      
      if (response.data.success) {
        return response.data.data.vendors;
      } else {
        throw new Error('Unable to load vendors');
      }
    } catch (error) {
      // Log error only in development
      if (import.meta.env.DEV) {
        console.error('Error fetching vendors:', error);
      }
      throw error;
    }
  },

  // Get vendor by ID
  getVendorById: async (vendorId: string): Promise<Vendor | null> => {
    try {
      // Check offline status first
      if (isUserOffline()) {
        throw new Error("NETWORK_ERROR");
      }
      
      const response = await api.get(`/vendors/${vendorId}`);
      
      if (response.data.success) {
        return response.data.data.vendor;
      } else {
        throw new Error('Unable to load vendor details');
      }
    } catch (error) {
      // Log error only in development
      if (import.meta.env.DEV) {
        console.error('Error fetching vendor:', error);
      }
      throw error;
    }
  },

  // Update vendor location automatically
  updateVendorLocation: async (location: { latitude: number; longitude: number }): Promise<void> => {
    try {
      // Check offline status first
      if (isUserOffline()) {
        throw new Error("NETWORK_ERROR");
      }
      
      const response = await api.post('/vendors/location', { location });
      
      if (response.data.success) {
        // Success - no console log for production
      } else {
        throw new Error('Unable to update location');
      }
    } catch (error) {
      // Log error only in development
      if (import.meta.env.DEV) {
        console.error('Error updating vendor location:', error);
      }
      throw error;
    }
  },

  // Check if vendor is available for assignment
  isVendorAvailable: (vendor: Vendor, requestingUserId?: string): boolean => {
    // Don't assign to requesting user if they are also a vendor
    if (requestingUserId && vendor._id === requestingUserId) {
      return false;
    }

    // Check if vendor is online
    if (!vendor.isOnline) {
      return false;
    }

    // Check if vendor has coordinates (not location - backend sends coordinates)
    if (!vendor.coordinates) {
      return false;
    }

    return true;
  },

  // Filter available vendors for assignment
  getAvailableVendorsForAssignment: async (requestingUserId?: string): Promise<Vendor[]> => {
    try {
      const allVendors = await vendorService.getAvailableVendors();
      
      console.log('🔍 FRONTEND DEBUG: All vendors from API:', allVendors);
      console.log('👤 FRONTEND DEBUG: Requesting user ID:', requestingUserId);
      
      const filteredVendors = allVendors.filter(vendor => {
        console.log('👤 FRONTEND DEBUG: Checking vendor:', {
          id: vendor._id,
          name: `${vendor.firstName} ${vendor.lastName}`,
          isOnline: vendor.isOnline,
          hasCoordinates: !!vendor.coordinates,
          coordinates: vendor.coordinates,
          requestingUserId: requestingUserId
        });
        
        const isAvailable = vendorService.isVendorAvailable(vendor, requestingUserId);
        console.log(`✅ FRONTEND DEBUG: Vendor ${vendor.firstName} ${vendor.lastName} available:`, isAvailable);
        
        return isAvailable;
      });
      
      console.log('📤 FRONTEND DEBUG: Final filtered vendors:', filteredVendors);
      return filteredVendors;
    } catch (error) {
      console.error('Error filtering vendors:', error);
      return [];
    }
  },

  // Find nearest vendor using database coordinates
  findNearestVendor: async (customerLocation: { latitude: number; longitude: number }, requestingUserId?: string): Promise<{ vendor: Vendor | null; distance: number }> => {
    try {
      console.log('🏪 Finding nearest vendor using database coordinates...');
      console.log('🔍 DEBUG: Customer location being sent:', customerLocation);
      console.log('🔍 DEBUG: Requesting user ID to exclude:', requestingUserId);
      
      // ✅ Fixed: Remove /api prefix since getApiUrl adds it automatically
      const url = '/vendors/nearest';
      console.log('🔍 DEBUG: Making request to URL:', url);
      
      const response = await api.post(url, {
        customerLocation: {
          latitude: customerLocation.latitude,
          longitude: customerLocation.longitude
        },
        requestingUserId: requestingUserId // ✅ Pass requesting user ID to backend
      });

      console.log('🔍 DEBUG: Vendor API Response status:', response.status);
      console.log('🔍 DEBUG: Vendor API Response data:', response.data);

      if (response.data.success && response.data.data) {
        const { vendor, distance } = response.data.data;
        console.log(`🎯 Nearest vendor found: ${vendor?.firstName} ${vendor?.lastName} (${distance}km away)`);
        console.log('🔍 DEBUG: Vendor object:', vendor);
        return {
          vendor,
          distance: distance * 1000 // Convert km to meters for consistency
        };
      }

      console.log('🔍 DEBUG: No vendor found in response');
      return { vendor: null, distance: 0 };
    } catch (error: any) {
      console.error('Error finding nearest vendor:', error);
      console.error('Error details:', error.response?.data || error.message);
      return { vendor: null, distance: 0 };
    }
  }
};
