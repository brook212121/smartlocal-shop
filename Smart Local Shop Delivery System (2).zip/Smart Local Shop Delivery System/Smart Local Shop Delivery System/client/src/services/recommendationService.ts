import api from './api';

export interface RecommendationResponse {
  success: boolean;
  data: {
    recommended: any[];
    nearby: any[];
    trending: any[];
    similar: any[];
  };
}

class RecommendationService {
  private static instance: RecommendationService;
  private cache: Map<string, { data: RecommendationResponse['data']; timestamp: number }> = new Map();
  private cacheTimeout = 5 * 60 * 1000; // 5 minutes

  static getInstance(): RecommendationService {
    if (!RecommendationService.instance) {
      RecommendationService.instance = new RecommendationService();
    }
    return RecommendationService.instance;
  }

  async getRecommendations(location?: { latitude: number; longitude: number }, radius: number = 10, limit: number = 50): Promise<RecommendationResponse['data']> {
    try {
      // Check cache first
      const cacheKey = JSON.stringify({ location, radius, limit });
      const cached = this.cache.get(cacheKey);
      if (cached && Date.now() - cached.timestamp < this.cacheTimeout) {
        return cached.data;
      }

      const response = await api.post('/recommendations', { 
        location, 
        radius, 
        limit 
      });
      const recommendations = response.data.data;

      // Cache the result
      this.cache.set(cacheKey, {
        data: recommendations,
        timestamp: Date.now()
      });

      return recommendations;

    } catch (error) {
      console.warn('Failed to get recommendations:', error);
      // Return empty recommendations on error
      return {
        recommended: [],
        nearby: [],
        trending: [],
        similar: []
      };
    }
  }

  clearCache(): void {
    this.cache.clear();
  }
}

export default RecommendationService.getInstance();
