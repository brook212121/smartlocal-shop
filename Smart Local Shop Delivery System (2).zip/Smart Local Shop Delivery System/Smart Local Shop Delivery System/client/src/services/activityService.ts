import api from './api';

export interface ActivityPayload {
  action: 'search_product' | 'view_product' | 'like_product' | 'add_to_cart' | 'place_order' | 'view_category';
  productId?: string;
  productName?: string;
  category?: string;
  shopId?: string;
  keyword?: string;
  viewDuration?: number;
}

class ActivityService {
  private static instance: ActivityService;
  private viewStartTime: { [key: string]: number } = {};

  static getInstance(): ActivityService {
    if (!ActivityService.instance) {
      ActivityService.instance = new ActivityService();
    }
    return ActivityService.instance;
  }

  async trackActivity(payload: ActivityPayload): Promise<void> {
    try {
      await api.post('/activity', payload);
    } catch (error) {
      // Silently fail to not disrupt user experience
      console.warn('Failed to track activity:', error);
    }
  }

  // Track when user starts viewing a product
  startProductView(productId: string): void {
    this.viewStartTime[productId] = Date.now();
  }

  // Track when user finishes viewing a product
  async endProductView(productId: string, productName: string, category: string, shopId?: string): Promise<void> {
    const startTime = this.viewStartTime[productId];
    const viewDuration = startTime ? Math.floor((Date.now() - startTime) / 1000) : 0;
    
    delete this.viewStartTime[productId];

    await this.trackActivity({
      action: 'view_product',
      productId,
      productName,
      category,
      shopId,
      viewDuration
    });
  }

  async trackSearch(keyword: string): Promise<void> {
    await this.trackActivity({
      action: 'search_product',
      keyword
    });
  }

  async trackLike(productId: string, productName: string, category: string, shopId?: string): Promise<void> {
    await this.trackActivity({
      action: 'like_product',
      productId,
      productName,
      category,
      shopId
    });
  }

  async trackAddToCart(productId: string, productName: string, category: string, shopId?: string): Promise<void> {
    await this.trackActivity({
      action: 'add_to_cart',
      productId,
      productName,
      category,
      shopId
    });
  }

  async trackOrder(productId: string, productName: string, category: string, shopId?: string): Promise<void> {
    await this.trackActivity({
      action: 'place_order',
      productId,
      productName,
      category,
      shopId
    });
  }

  async trackCategoryView(category: string): Promise<void> {
    await this.trackActivity({
      action: 'view_category',
      category
    });
  }
}

export default ActivityService.getInstance();
