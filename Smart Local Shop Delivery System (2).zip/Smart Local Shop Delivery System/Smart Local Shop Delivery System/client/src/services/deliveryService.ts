import axios from 'axios';
import { DeliveryOrder } from '../delivery/types/delivery';
import { API_BASE_URL } from '../utils/apiConfig';

// Create axios instance with proper baseURL
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  },
  withCredentials: true // Enable credentials for CORS
});

// Add request interceptor for debugging and token management
api.interceptors.request.use(
  (config) => {
    const baseURL = config.baseURL || '';
    const url = config.url || '';
    console.log('🔍 Debug - Request URL:', baseURL + url);
    
    // Get token directly from localStorage (same as main API service)
    const authData = localStorage.getItem('authData');
    console.log('🔍 Delivery Service: Checking localStorage for authData...');
    console.log('🔍 Delivery Service: authData found:', !!authData);
    
    if (authData) {
      try {
        const parsed = JSON.parse(authData);
        console.log('🔍 Delivery Service: Parsed authData:', parsed);
        console.log('🔍 Delivery Service: Token exists:', !!parsed.token);
        
        if (parsed.token) {
          config.headers.Authorization = `Bearer ${parsed.token}`;
          console.log('🔍 Delivery Service: Token added to headers:', parsed.token.substring(0, 20) + '...');
          console.log('🔍 Delivery Service: Full Authorization header:', config.headers.Authorization);
        } else {
          console.log('🔍 Delivery Service: No token found in parsed authData');
        }
      } catch (error) {
        console.error('❌ Error parsing authData in delivery service:', error);
      }
    } else {
      console.log('🔍 Delivery Service: No authData found in localStorage');
      // Try fallback to direct token (legacy support)
      const token = localStorage.getItem('token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
        console.log('🔍 Delivery Service: Using fallback token:', token.substring(0, 20) + '...');
      }
    }
    
    console.log('🔍 Delivery Service: Final headers:', config.headers);
    console.log('🔍 Delivery Service: Authorization header:', config.headers.Authorization || 'NOT SET');
    return config;
  },
  (error) => {
    console.error('❌ API Request Error:', error);
    return Promise.reject(error);
  }
);

export interface DeliveryAgent {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  isOnline: boolean;
  rating?: number;
  totalDeliveries?: number;
  lastLocationUpdate?: string;
}

export interface DeliveryAgentLocation {
  latitude: number;
  longitude: number;
  address: string;
  timestamp: string;
}

export interface DeliveryService {
  getDeliveryStats: () => Promise<{
    assignedOrders: number;
    deliveredOrders: number;
    totalOrders: number;
  }>;
  getAssignedOrders: () => Promise<DeliveryOrder[]>;
  updateDeliveryStatus: (orderId: string, status: 'PICKED_UP' | 'DELIVERED') => Promise<void>;
  getAvailableDeliveryAgents: () => Promise<DeliveryAgent[]>;
  assignDeliveryAgent: (
    orderId: string,
    deliveryAgentId: string,
    vendorLocation: { latitude: number; longitude: number },
    customerLocation: { latitude: number; longitude: number }
  ) => Promise<any>;
  updateDeliveryAgentLocation: (locationData: DeliveryAgentLocation) => Promise<{ success: boolean; message?: string }>;
}

export const deliveryService = {
  // Get delivery statistics
  getDeliveryStats: async (): Promise<{
    assignedOrders: number;
    deliveredOrders: number;
    totalOrders: number;
  }> => {
    try {
      const response = await api.get('delivery/stats');
      return response.data.data || {
        assignedOrders: 0,
        deliveredOrders: 0,
        totalOrders: 0
      };
    } catch (error: any) {
      console.error('Error fetching delivery stats:', error);
      return {
        assignedOrders: 0,
        deliveredOrders: 0,
        totalOrders: 0
      };
    }
  },

  // Get assigned orders for delivery agent
  getAssignedOrders: async (): Promise<any[]> => {
    try {
      // Get token from localStorage
      const authData = localStorage.getItem('authData');
      const token = authData ? JSON.parse(authData).token : null;
      
      console.log('🔍 Delivery Service: Token for authentication:', token ? 'exists' : 'missing');
      console.log('🔍 Delivery Service: Making direct API call to http://localhost:5000/api/delivery/orders');
      
      if (!token) {
        console.error('❌ No authentication token found');
        return [];
      }
      
      // Use direct axios call with full URL and proper authentication
      const response = await axios.get('http://localhost:5000/api/delivery/orders', {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        withCredentials: true
      });
      
      console.log('🔍 Delivery Service: API response received:', response.status);
      return response.data.data.orders || [];
    } catch (error: any) {
      console.error('Error fetching assigned orders:', error);
      if (error.response?.status === 401) {
        console.error('❌ Authentication failed - invalid or expired token');
      }
      return [];
    }
  },

  // Update delivery status
  updateDeliveryStatus: async (orderId: string, status: 'PICKED_UP' | 'DELIVERED'): Promise<void> => {
    try {
      const response = await api.put(`delivery/orders/${orderId}/status`, { status });
      console.log('✅ Delivery status updated:', response.data);
    } catch (error: any) {
      console.error('Error updating delivery status:', error);
      throw error;
    }
  },

  // Get available delivery agents
  getAvailableDeliveryAgents: async (): Promise<DeliveryAgent[]> => {
    try {
      const response = await api.get('delivery-agents/available');
      return response.data.data || [];
    } catch (error: any) {
      console.error('Error fetching delivery agents:', error);
      return [];
    }
  },

  // Assign delivery agent to order
  assignDeliveryAgent: async (
    orderId: string,
    deliveryAgentId: string,
    vendorLocation: { latitude: number; longitude: number },
    customerLocation: { latitude: number; longitude: number }
  ): Promise<any> => {
    try {
      const response = await api.post('delivery/assign', {
        orderId,
        deliveryAgentId,
        vendorLocation,
        customerLocation
      });
      return response.data.data;
    } catch (error: any) {
      console.error('Error assigning delivery agent:', error);
      throw error;
    }
  },

  // Update delivery agent location
  updateDeliveryAgentLocation: async (locationData: DeliveryAgentLocation): Promise<{ success: boolean; message?: string }> => {
    try {
      const response = await api.put('delivery-agents/location', locationData);
      return response.data;
    } catch (error: any) {
      console.error('Error updating delivery agent location:', error);
      throw error;
    }
  },
};
