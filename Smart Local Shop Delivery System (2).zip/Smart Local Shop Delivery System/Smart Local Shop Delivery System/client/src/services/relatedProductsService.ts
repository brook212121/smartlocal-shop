import api from './api';
import { getApiUrl } from '../utils/apiConfig';

export interface RelatedProduct {
  _id: string;
  name: string;
  price: number;
  images: string[];
  category: string;
  brand?: string;
  tags?: string[];
  rating?: number;
}

export const relatedProductsService = {
  getRelatedProducts: async (productId: string): Promise<RelatedProduct[]> => {
    try {
      const apiUrl = getApiUrl(`/products/related/${productId}`);
      console.log('🌐 Making API call to:', `/products/related/${productId}`);
      console.log('🔗 Full URL will be:', apiUrl);
      const response = await api.get(`/products/related/${productId}`);
      console.log('📡 API response:', response);
      return response.data;
    } catch (error) {
      console.error('❌ Error fetching related products:', error);
      throw error;
    }
  }
};
