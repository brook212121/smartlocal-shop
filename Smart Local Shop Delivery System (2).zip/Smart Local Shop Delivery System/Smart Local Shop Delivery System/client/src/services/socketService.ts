import { io, Socket } from 'socket.io-client';
import { API_BASE_URL } from '../utils/apiConfig';

export interface LocationUpdate {
  deliveryAgentId: string;
  orderId: string;
  location: {
    type: "Point";
    coordinates: [number, number]; // [longitude, latitude]
  };
  timestamp: Date;
}

export interface AgentLocationUpdate {
  orderId: string;
  agentId: string;
  agentName?: string;
  location: {
    type: "Point";
    coordinates: [number, number];
  };
  timestamp: Date;
}

class SocketService {
  private socket: Socket | null = null;
  private locationWatchId: number | null = null;
  private isTracking = false;

  connect() {
    if (this.socket?.connected) {
      return this.socket;
    }

    const authData = localStorage.getItem('authData');
    const token = authData ? JSON.parse(authData).token : null;
    if (!token) {
      throw new Error('Authentication token required');
    }

    // Get the correct Socket.IO URL
    const baseUrl = API_BASE_URL;
    let socketUrl = '';
    
    if (baseUrl.includes('ngrok')) {
      // For ngrok, connect directly to ngrok URL
      socketUrl = baseUrl.replace(/\/$/, '');
    } else {
      // For localhost, use relative URL
      socketUrl = '';
    }

    console.log('🔌 Connecting to Socket.IO at:', socketUrl);

    this.socket = io(socketUrl, {
      auth: { token },
      transports: ['websocket', 'polling']
    });

    this.setupEventListeners();
    return this.socket;
  }

  private setupEventListeners() {
    if (!this.socket) return;

    this.socket.on('connect', () => {
      console.log('🔌 Connected to WebSocket server');
    });

    this.socket.on('disconnect', () => {
      console.log('🔌 Disconnected from WebSocket server');
      this.stopLocationTracking();
    });

    this.socket.on('error', (error) => {
      console.error('❌ WebSocket error:', error);
    });

    this.socket.on('agent_location_update', (data: AgentLocationUpdate) => {
      console.log('📍 Received agent location update:', data);
      // Emit custom event for components to listen
      window.dispatchEvent(new CustomEvent('agentLocationUpdate', { detail: data }));
    });

    this.socket.on('tracking_started', (data: { orderId: string }) => {
      console.log('📍 Tracking started for order:', data.orderId);
      window.dispatchEvent(new CustomEvent('trackingStarted', { detail: data }));
    });

    this.socket.on('tracking_stopped', (data: { orderId: string }) => {
      console.log('📍 Tracking stopped for order:', data.orderId);
      window.dispatchEvent(new CustomEvent('trackingStopped', { detail: data }));
    });

    this.socket.on('tracking_active', (data: { orderId: string }) => {
      console.log('📍 Tracking active for order:', data.orderId);
      window.dispatchEvent(new CustomEvent('trackingActive', { detail: data }));
    });
  }

  disconnect() {
    this.stopLocationTracking();
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }
  }

  // Location tracking methods
  async startLocationTracking(orderId: string) {
    if (!this.socket) {
      this.connect();
    }

    if (this.isTracking) {
      console.log('📍 Location tracking already active');
      return;
    }

    if (!navigator.geolocation) {
      throw new Error('Geolocation is not supported by this browser');
    }

    // Check location permission first
    try {
      const permission = await navigator.permissions.query({ name: 'geolocation' });
      if (permission.state === 'denied') {
        throw new Error('Location permission denied. Please enable location access in your browser settings.');
      }
    } catch (error) {
      console.log('📍 Permission API not supported, proceeding anyway...');
    }

    console.log('📍 Starting location tracking for order:', orderId);

    // Get initial position first
    try {
      const position = await this.getCurrentPosition();
      console.log('📍 Initial position obtained:', position.coords);
      
      // Start tracking
      this.locationWatchId = navigator.geolocation.watchPosition(
        (position) => {
          const locationUpdate: LocationUpdate = {
            deliveryAgentId: '', // Will be filled by server
            orderId,
            location: {
              type: 'Point',
              coordinates: [position.coords.longitude, position.coords.latitude]
            },
            timestamp: new Date()
          };

          console.log('📍 Sending location update:', locationUpdate);
          this.socket?.emit('location_update', locationUpdate);
        },
        (error) => {
          console.error('❌ Geolocation error:', error);
          let errorMessage = 'Location error occurred';
          
          switch(error.code) {
            case error.PERMISSION_DENIED:
              errorMessage = 'Location permission denied. Please enable location access in your browser settings.';
              break;
            case error.POSITION_UNAVAILABLE:
              errorMessage = 'Location information unavailable. Please check your GPS/location services.';
              break;
            case error.TIMEOUT:
              errorMessage = 'Location request timed out. Please try again.';
              break;
            default:
              errorMessage = `Location error: ${error.message}`;
              break;
          }
          
          window.dispatchEvent(new CustomEvent('locationError', { detail: { message: errorMessage, code: error.code } }));
        },
        {
          enableHighAccuracy: true,
          maximumAge: 0,
          timeout: 10000
        }
      );

      this.isTracking = true;

      // Notify server to start tracking
      this.socket?.emit('start_tracking', orderId);
      
      return position;
    } catch (error) {
      console.error('❌ Failed to get initial position:', error);
      throw error;
    }
  }

  stopLocationTracking() {
    if (this.locationWatchId) {
      navigator.geolocation.clearWatch(this.locationWatchId);
      this.locationWatchId = null;
    }

    this.isTracking = false;
    console.log('📍 Location tracking stopped');
  }

  // Customer/Vendor tracking methods
  trackOrder(orderId: string) {
    if (!this.socket) {
      this.connect();
    }

    console.log('📍 Requesting to track order:', orderId);
    this.socket?.emit('track_order', orderId);
  }

  stopTrackingOrder(orderId: string) {
    if (!this.socket) return;

    console.log('📍 Stop tracking order:', orderId);
    this.socket?.emit('stop_tracking', orderId);
  }

  // Utility methods
  isConnected(): boolean {
    return this.socket?.connected || false;
  }

  isLocationTrackingActive(): boolean {
    return this.isTracking;
  }

  getCurrentPosition(): Promise<GeolocationPosition> {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation is not supported by this browser'));
        return;
      }

      navigator.geolocation.getCurrentPosition(
        resolve,
        reject,
        {
          enableHighAccuracy: true,
          maximumAge: 0,
          timeout: 10000
        }
      );
    });
  }
}

// Create singleton instance
const socketService = new SocketService();

export default socketService;
