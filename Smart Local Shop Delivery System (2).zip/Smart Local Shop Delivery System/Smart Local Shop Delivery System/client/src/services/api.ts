import axios from 'axios';

// Create axios instance with dynamic base URL
const api = axios.create({
  baseURL: 'http://localhost:5000/api', // Direct localhost API URL
  headers: {
    'Content-Type': 'application/json'
  },
  withCredentials: true // Enable credentials for CORS
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    // Debug logging to see actual URLs being called
    console.log('🔍 API Request Debug:', {
      method: config.method,
      url: config.url,
      baseURL: config.baseURL,
      finalURL: `${config.baseURL}${config.url}`
    });
    
    // Get token directly from auth state to avoid circular dependency
    const authData = localStorage.getItem('authData');
    if (authData) {
      try {
        const parsed = JSON.parse(authData);
        if (parsed.token) {
          config.headers.Authorization = `Bearer ${parsed.token}`;
        }
      } catch (error) {
        console.error('❌ Error parsing authData in interceptor:', error);
      }
    }
    return config;
  },
  (error) => {
    console.error('❌ API Request Error:', error);
    return Promise.reject(error);
  }
);

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid, clear storage
      localStorage.removeItem('authData');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;
