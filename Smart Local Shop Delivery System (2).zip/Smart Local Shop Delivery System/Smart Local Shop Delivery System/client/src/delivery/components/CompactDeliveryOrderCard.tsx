import { Package, User, Eye, MapPin } from 'lucide-react';
import { DeliveryOrder } from '../types/delivery';
import DeliveryStatusBadge from './DeliveryStatusBadge';

interface CompactDeliveryOrderCardProps {
  order: DeliveryOrder;
  onViewDetails: (orderId: string) => void;
}

const CompactDeliveryOrderCard = ({ order, onViewDetails }: CompactDeliveryOrderCardProps) => {
  const formatCurrency = (amount: number, currency: string = 'ETB') => {
    return `${currency} ${amount.toFixed(2)}`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-5 hover:shadow-md transition-shadow cursor-pointer min-h-[200px] flex flex-col">
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-2">
          <Package className="h-5 w-5 text-green-600" />
          <span className="font-semibold text-sm text-gray-900">{order.orderNumber}</span>
        </div>
        <DeliveryStatusBadge status={order.deliveryStatus} />
      </div>

      {/* Product Name */}
      <div className="flex items-center gap-2 mb-3">
        <Package className="h-4 w-4 text-gray-400" />
        <span className="text-sm text-gray-700 font-medium truncate">
          {order.items?.[0]?.product?.name || 'No product'}
        </span>
      </div>

      {/* Customer Name */}
      <div className="flex items-center gap-2 mb-3">
        <User className="h-4 w-4 text-gray-400" />
        <span className="text-sm text-gray-700 font-medium truncate">
          {order.customer?.firstName} {order.customer?.lastName}
        </span>
      </div>

      {/* Time */}
      <div className="flex items-center gap-2 mb-4">
        <MapPin className="h-4 w-4 text-gray-400" />
        <span className="text-sm text-gray-500">{formatDate(order.createdAt)}</span>
      </div>

      {/* View Details Button */}
      <div className="mt-auto">
        <button
          onClick={() => onViewDetails(order._id)}
          className="w-full bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 transition-colors text-sm font-medium flex items-center justify-center gap-2"
        >
          <Eye className="h-4 w-4" />
          View Details
        </button>
      </div>
    </div>
  );
};

export default CompactDeliveryOrderCard;
