import { useState, useEffect, useRef } from 'react';
import { Link, useLocation, useNavigate, Outlet, Navigate } from 'react-router-dom';
import { Menu, User } from 'lucide-react';
import SidebarItem from '../../components/SidebarItem';
import { useAuth } from '../../contexts/AuthContext';

interface DeliveryDashboardLayoutProps {}

const DeliveryDashboardLayout: React.FC<DeliveryDashboardLayoutProps> = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const dropdownRef = useRef<HTMLDivElement>(null);
  
  // Use AuthContext for authentication
  const { authState, logout } = useAuth();
  const user = authState.user;

  // ✅ ALL HOOKS MUST BE CALLED FIRST - BEFORE ANY CONDITIONALS
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  console.log('🔍 DeliveryDashboardLayout: Auth state check:', {
    isAuthenticated: authState.isAuthenticated,
    userRole: authState.user?.role,
    user: authState.user?._id,
    isLoading: authState.isLoading,
    currentPath: location.pathname,
    hookCallCount: 'useLocation, useNavigate, useRef, useAuth, useState x4, useEffect x2'
  });

  // ✅ ALL USEEFFECTS AFTER HOOKS AND CONDITIONALS
  // Detect mobile screen
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };

    // Initial check
    handleResize();

    // Listen for resize
    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setProfileDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Handle navigation with auto-close on mobile
  const handleNavigation = (href: string) => {
    navigate(href);
    // Auto-close sidebar on mobile after navigation
    if (isMobile) {
      setSidebarOpen(false);
    }
  };

  const handleLogout = () => {
    // ✅ Use logout from top level, not useAuth() call inside function
    logout();
    // Navigate to login page using React Router
    navigate('/login');
  };

  // ✅ CONDITIONAL RENDERING INSTEAD OF EARLY RETURNS
  if (authState.isLoading) {
    console.log('🔍 DeliveryDashboardLayout: Auth is loading, showing loading spinner');
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }
  
  if (!authState.isAuthenticated || authState.user?.role !== 'DELIVERY') {
    console.log('🔍 DeliveryDashboardLayout: Access denied, redirecting to login');
    return <Navigate to="/login" state={{ from: location }} replace />;
  }
  
  console.log('🔍 DeliveryDashboardLayout: Access granted, rendering delivery content');

  // Dynamic menu items for delivery agent
  const navigation = [
    {
      name: 'Home',
      href: '/delivery',
      icon: 'home',
      current: location.pathname === '/delivery'
    },
    {
      name: 'Assigned Orders',
      href: '/delivery/assigned-orders',
      icon: 'inventory_2',
      current: location.pathname === '/delivery/assigned-orders'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile sidebar */}
      <div className={`fixed inset-0 z-50 lg:hidden ${sidebarOpen ? 'block' : 'hidden'}`}>
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75" onClick={() => setSidebarOpen(false)} />
        <div className="fixed inset-y-0 left-0 flex flex-col w-64 bg-green-700">
          <div className="flex items-center justify-between h-16 px-4 bg-green-800">
          </div>
          <nav className="flex-1 px-2 py-4 space-y-1">
            {navigation.map((item: any) => (
              <SidebarItem
                key={item.name}
                icon={item.icon}
                label={item.name}
                to={item.href}
                onClick={() => handleNavigation(item.href)}
              />
            ))}
          </nav>
          <div className="p-4 border-t border-green-600">
          </div>
        </div>
      </div>

      {/* Desktop sidebar */}
      <div 
        className="hidden lg:fixed lg:inset-y-0 lg:flex transition-all duration-300 ease-in-out z-50"
        style={{ width: isHovered ? '220px' : '70px' }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div className={`flex flex-col flex-grow bg-green-700 pt-5 pb-4 overflow-y-auto transition-all duration-300 ${isHovered ? 'shadow-2xl' : 'shadow-lg'} relative z-50`}>
          <nav className="mt-5 flex-1 px-2 space-y-1">
            {navigation.map((item: any) => (
              <SidebarItem
                key={item.name}
                icon={item.icon}
                label={isHovered ? item.name : ''}
                to={item.href}
                onClick={() => handleNavigation(item.href)}
                showLabel={isHovered}
              />
            ))}
          </nav>
          <div className="p-4 border-t border-green-800">
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className={`lg:pl-[70px] pl-0`}>
        {/* Desktop header */}
        <div className="sticky top-0 z-30 flex-shrink-0 flex h-16 bg-white border-b border-gray-200">
          <button
            onClick={() => setSidebarOpen(true)}
            className="px-4 border-r border-gray-200 text-gray-500 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-green-500 lg:hidden"
          >
            <Menu className="h-6 w-6" />
          </button>
          
          <div className="flex-1 flex justify-end px-4 lg:px-6">
            
            {/* Profile dropdown */}
            <div className="flex items-center">
              <div className="relative" ref={dropdownRef}>
                <button
                  type="button"
                  className="flex items-center text-sm rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                  onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                >
                  <span className="sr-only">Open user menu</span>
                  <div className="h-8 w-8 rounded-full bg-green-800 flex items-center justify-center">
                    <User className="h-5 w-5 text-white" />
                  </div>
                </button>

                {/* Profile dropdown panel */}
                {profileDropdownOpen && (
                  <div className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-50">
                    <div className="py-1">
                      <div className="px-4 py-2 border-b border-gray-100">
                        <p className="text-sm font-medium text-gray-900">
                          {user?.firstName} {user?.lastName}
                        </p>
                        <p className="text-sm text-gray-500">{user?.email}</p>
                        <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-600 text-green-100 mt-1">
                          {user?.role}
                        </span>
                      </div>
                      <Link
                        to="/delivery/profile"
                        className="flex items-center gap-3 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                        onClick={() => setProfileDropdownOpen(false)}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" className="lucide lucide-user-icon lucide-user"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                        Profile
                      </Link>
                      <button
                        onClick={handleLogout}
                        className="flex items-center gap-3 w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-100 hover:text-red-700"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" className="lucide lucide-log-out-icon lucide-log-out"><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/></svg>
                        Sign out
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
        <main className="flex-1 pt-5">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default DeliveryDashboardLayout;
