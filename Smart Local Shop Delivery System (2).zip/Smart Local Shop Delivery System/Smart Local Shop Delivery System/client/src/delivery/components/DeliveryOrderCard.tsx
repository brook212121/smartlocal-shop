import { Package, MapPin, Clock, Phone, User, Navigation, DollarSign, Square } from 'lucide-react';
import { DeliveryOrder } from '../types/delivery';
import Spinner from '../../components/ui/Spinner';

interface DeliveryOrderCardProps {
  order: DeliveryOrder;
  onUpdateStatus: (orderId: string, status: 'PICKED_UP' | 'DELIVERED') => void;
  onStartNavigation?: (orderId: string) => void;
  onStopNavigation?: (orderId: string) => void;
  isTracking?: boolean;
  updatingStatus?: string | null;
}

const DeliveryOrderCard = ({ order, onUpdateStatus, onStartNavigation, onStopNavigation, isTracking, updatingStatus }: DeliveryOrderCardProps) => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatCurrency = (amount: number, currency: string = 'ETB') => {
    return `${currency} ${amount.toFixed(2)}`;
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      {/* Order Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-2">
          <Package className="h-5 w-5 text-green-600" />
          <span className="font-semibold text-gray-900">{order.orderNumber}</span>
        </div>
      </div>

      {/* Customer Information */}
      <div className="mb-4 p-3 bg-blue-50 rounded-lg">
        <div className="flex items-center gap-2 mb-2">
          <User className="h-4 w-4 text-blue-600" />
          <span className="font-medium text-blue-900">Customer Information</span>
        </div>
        <div className="space-y-1 text-sm">
          <div className="flex items-center gap-2">
            <span className="font-medium text-gray-700">Name:</span>
            <span className="text-gray-900">
              {order.customer?.firstName} {order.customer?.lastName}
            </span>
          </div>
          {order.customer?.phone && (
            <div className="flex items-center gap-2">
              <Phone className="h-3 w-3 text-gray-500" />
              <span className="text-gray-900">{order.customer.phone}</span>
            </div>
          )}
        </div>
      </div>

      {/* Delivery Address */}
      <div className="mb-4 p-3 bg-orange-50 rounded-lg">
        <div className="flex items-center gap-2 mb-2">
          <MapPin className="h-4 w-4 text-orange-600" />
          <span className="font-medium text-orange-900">Delivery Address</span>
        </div>
        <div className="space-y-1 text-sm">
          <div className="text-gray-900">
            {order.delivery?.address?.street && (
              <div>{order.delivery.address.street}</div>
            )}
            {order.delivery?.address?.city && (
              <div>{order.delivery.address.city}</div>
            )}
            {order.delivery?.address?.county && (
              <div>{order.delivery.address.county}</div>
            )}
          </div>
          {order.delivery?.address?.landmark && (
            <div className="text-gray-600 text-xs">
              <strong>Landmark:</strong> {order.delivery.address.landmark}
            </div>
          )}
          {order.delivery?.address?.instructions && (
            <div className="text-gray-600 text-xs mt-1">
              <strong>Instructions:</strong> {order.delivery.address.instructions}
            </div>
          )}
        </div>
      </div>

      {/* Vendor Information */}
      <div className="mb-4 p-3 bg-purple-50 rounded-lg">
        <div className="flex items-center gap-2 mb-2">
          <Package className="h-4 w-4 text-purple-600" />
          <span className="font-medium text-purple-900">Pickup Location</span>
        </div>
        <div className="space-y-1 text-sm">
          <div className="text-gray-900">
            {order.vendor?.firstName} {order.vendor?.lastName}
          </div>
          {order.vendor?.phone && (
            <div className="flex items-center gap-2">
              <Phone className="h-3 w-3 text-gray-500" />
              <span className="text-gray-900">{order.vendor.phone}</span>
            </div>
          )}
        </div>
      </div>

      {/* Order Details */}
      <div className="mb-4 p-3 bg-gray-50 rounded-lg">
        <div className="flex items-center gap-2 mb-3">
          <Package className="h-4 w-4 text-gray-600" />
          <span className="font-medium text-gray-900">Order Items</span>
        </div>
        <div className="space-y-3">
          {order.items?.map((item: any, index: number) => (
            <div key={index} className="flex flex-col md:flex-row md:items-center md:justify-between gap-8 p-3 bg-white rounded-lg border border-gray-200">
              {/* Product Image */}
              <div className="flex-shrink-0 w-48 h-48 bg-gray-100 rounded-lg overflow-hidden shadow-sm">
                {item.product?.images?.length > 0 ? (
                  <img 
                    src={item.product.images[0]} 
                    alt={item.product?.name || 'Product'}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-200"
                    onError={(e) => {
                      e.currentTarget.src = '/api/placeholder/192/192';
                    }}
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-gray-200">
                    <Package className="h-16 w-16 text-gray-400" />
                  </div>
                )}
              </div>
              
              {/* Product Details */}
              <div className="flex-1 min-w-0 md:text-right">
                <div className="text-sm font-medium text-gray-900 truncate mb-1">
                  {item.product?.name || 'Product'}
                </div>
                <div className="text-xs text-gray-500 space-y-1">
                  <div>Quantity: {item.quantity}</div>
                </div>
              </div>
            </div>
          ))}
          
          {/* Order Total */}
          {order.pricing?.total && (
            <div className="pt-2 border-t border-gray-200">
              <div className="flex justify-between items-center text-sm">
                <span className="font-medium text-gray-900">Total Amount:</span>
                <span className="font-bold text-gray-900">
                  {formatCurrency(order.pricing.total, order.pricing?.currency)}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Delivery Information */}
      <div className="mb-4 p-3 bg-green-50 rounded-lg">
        <div className="flex items-center gap-2 mb-2">
          <Navigation className="h-4 w-4 text-green-600" />
          <span className="font-medium text-green-900">Delivery Information</span>
        </div>
        <div className="space-y-1 text-sm">
          <div className="flex items-center gap-2">
            <Clock className="h-3 w-3 text-gray-500" />
            <span className="text-gray-900">Ordered: {formatDate(order.createdAt)}</span>
          </div>
          {order.delivery?.distance && (
            <div className="flex items-center gap-2">
              <Navigation className="h-3 w-3 text-gray-500" />
              <span className="text-gray-900">
                Distance: {order.delivery.distance.toFixed(1)} km
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Payment Information */}
      <div className="mb-4 p-3 bg-yellow-50 rounded-lg">
        <div className="flex items-center gap-2 mb-2">
          <DollarSign className="h-4 w-4 text-yellow-600" />
          <span className="font-medium text-yellow-900">Payment Information</span>
        </div>
        <div className="space-y-1 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-600">Order Total:</span>
            <span className="font-medium text-gray-900">
              {formatCurrency(order.pricing?.total || 0, order.pricing?.currency)}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Delivery Fee:</span>
            <span className="font-medium text-gray-900">
              {formatCurrency(order.pricing?.deliveryFee || order.delivery?.deliveryFee || 0, order.pricing?.currency)}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Payment Status:</span>
            <span className={`font-medium ${
              order.payment?.status === 'PAID' ? 'text-green-600' : 'text-orange-600'
            }`}>
              {order.payment?.status || 'PENDING'}
            </span>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-2">
        {order.deliveryStatus === 'ASSIGNED' && (
          <button
            onClick={() => onUpdateStatus(order._id, 'PICKED_UP')}
            disabled={updatingStatus === order._id}
            className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {updatingStatus === order._id ? (
              <>
                <Spinner size="sm" className="mr-2" />
                Updating...
              </>
            ) : (
              <>
                Mark as Picked Up
              </>
            )}
          </button>
        )}
        {order.deliveryStatus === 'PICKED_UP' && (
          <button
            onClick={() => onUpdateStatus(order._id, 'DELIVERED')}
            disabled={updatingStatus === order._id}
            className="flex-1 bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 transition-colors text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {updatingStatus === order._id ? (
              <>
                <Spinner size="sm" className="mr-2" />
                Updating...
              </>
            ) : (
              <>
                Mark as Delivered
              </>
            )}
          </button>
        )}
        {/* Navigation Button with Real-time Tracking */}
        <button
          className={`flex-1 py-2 px-4 rounded-md transition-colors text-sm font-medium flex items-center justify-center gap-2 ${
            isTracking 
              ? 'bg-red-600 text-white hover:bg-red-700' 
              : 'bg-blue-600 text-white hover:bg-blue-700'
          }`}
          onClick={() => {
            if (isTracking && onStopNavigation) {
              onStopNavigation(order._id);
            } else if (!isTracking && onStartNavigation) {
              onStartNavigation(order._id);
            }
          }}
        >
          {isTracking ? (
            <>
              <Square className="h-4 w-4" />
              Stop Tracking
            </>
          ) : (
            <>
              <Navigation className="h-4 w-4" />
              Start Navigation
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default DeliveryOrderCard;
