import { CheckCircle, Clock, Package, Truck } from 'lucide-react';

interface DeliveryStatusBadgeProps {
  status?: 'ASSIGNED' | 'PICKED_UP' | 'DELIVERED';
  className?: string;
}

const DeliveryStatusBadge = ({ status, className = '' }: DeliveryStatusBadgeProps) => {
  const getStatusConfig = (status?: string) => {
    switch (status) {
      case 'ASSIGNED':
        return {
          color: 'bg-blue-100 text-blue-800',
          icon: <Truck className="h-3 w-3 mr-1" />,
          label: 'Assigned'
        };
      case 'PICKED_UP':
        return {
          color: 'bg-orange-100 text-orange-800',
          icon: <Package className="h-3 w-3 mr-1" />,
          label: 'Picked Up'
        };
      case 'DELIVERED':
        return {
          color: 'bg-green-100 text-green-800',
          icon: <CheckCircle className="h-3 w-3 mr-1" />,
          label: 'Delivered'
        };
      default:
        return {
          color: 'bg-gray-100 text-gray-800',
          icon: <Clock className="h-3 w-3 mr-1" />,
          label: 'Pending'
        };
    }
  };

  const config = getStatusConfig(status);

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.color} ${className}`}>
      {config.icon}
      {config.label}
    </span>
  );
};

export default DeliveryStatusBadge;
