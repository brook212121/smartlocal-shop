import { MapPin, Loader2, AlertCircle, Smartphone, Settings } from 'lucide-react';
import { LocationPermissionStatus } from '../../services/locationService';

interface LocationPermissionCardProps {
  permissionStatus: LocationPermissionStatus | null;
  locationLoading: boolean;
  currentLocation: any;
  requestPermission: () => void;
}

const LocationPermissionCard = ({ 
  permissionStatus, 
  locationLoading, 
  currentLocation, 
  requestPermission 
}: LocationPermissionCardProps) => {
  return (
    <div className="mb-6">
      {permissionStatus === 'granted' && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-3 flex items-center gap-2">
          <MapPin className="h-5 w-5 text-green-600" />
          <span className="text-sm text-green-800">
            Location tracking enabled - You can receive delivery assignments
          </span>
        </div>
      )}
      
      {permissionStatus === 'denied' && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 flex items-center gap-2">
          <MapPin className="h-5 w-5 text-yellow-600" />
          <span className="text-sm text-yellow-800">
            Location access required to receive delivery assignments
          </span>
          <button
            onClick={requestPermission}
            className="ml-auto bg-yellow-600 text-white px-3 py-1 rounded text-sm hover:bg-yellow-700"
          >
            Enable Location
          </button>
        </div>
      )}
      
      {permissionStatus === 'prompt' && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 flex items-center gap-2">
          <MapPin className="h-5 w-5 text-blue-600" />
          <span className="text-sm text-blue-800">
             Enable location to receive delivery assignments
          </span>
          <button
            onClick={requestPermission}
            className="ml-auto bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700"
          >
            Enable Location
          </button>
        </div>
      )}
      {permissionStatus === 'not_supported' && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3">
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className="h-5 w-5 text-red-600" />
            <span className="text-sm text-red-800 font-medium">
              Location not supported
            </span>
          </div>
          <div className="text-xs text-red-700">
            <p className="mb-2">To enable location tracking:</p>
            <ol className="list-decimal list-inside space-y-1 ml-4">
              <li>Update your browser to the latest version</li>
              <li>Try using Chrome, Firefox, or Safari</li>
              <li>Ensure location services are enabled in your device settings</li>
              <li>Check browser location permissions in settings</li>
              <li>Try using HTTPS instead of HTTP</li>
              <li>Restart your browser and try again</li>
              <li>Check if your device has GPS hardware</li>
              <li>Try moving outdoors for better GPS signal</li>
            </ol>
          </div>
        </div>
      )}
      
      {locationLoading && (
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 flex items-center gap-2">
          <Loader2 className="h-5 w-5 text-gray-600 animate-spin" />
          <span className="text-sm text-gray-800">
            🔄 Getting your location...
          </span>
        </div>
      )}
      
      {currentLocation && permissionStatus === 'granted' && (
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 flex items-center gap-2">
          <MapPin className="h-5 w-5 text-gray-600" />
          <span className="text-sm text-gray-800">
            Current location: {currentLocation.latitude.toFixed(4)}, {currentLocation.longitude.toFixed(4)}
          </span>
        </div>
      )}
    </div>
  );
};

export default LocationPermissionCard;
