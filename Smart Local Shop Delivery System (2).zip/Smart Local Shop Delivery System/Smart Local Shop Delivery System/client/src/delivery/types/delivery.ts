export interface DeliveryOrder {
  _id: string;
  orderNumber: string;
  customer: {
    firstName: string;
    lastName: string;
    phone: string;
  };
  vendor: {
    firstName: string;
    lastName: string;
    phone: string;
  };
  items: Array<{
    product: {
      name: string;
      images: string[];
    };
    quantity: number;
    price: number;
  }>;
  delivery: {
    address: {
      street: string;
      city: string;
      county: string;
      landmark?: string;
      instructions?: string;
      coordinates?: {
        latitude: number;
        longitude: number;
      };
    };
    estimatedTime: string;
    deliveryFee: number;
    distance?: number;
  };
  pricing: {
    total: number;
    currency: string;
    deliveryFee?: number;
  };
  payment?: {
    status: 'PENDING' | 'PAID' | 'FAILED' | 'REFUNDED';
    method?: string;
    transactionId?: string;
  };
  status: 'PENDING' | 'CONFIRMED' | 'PREPARING' | 'READY_FOR_PICKUP' | 'OUT_FOR_DELIVERY' | 'DELIVERED' | 'CANCELLED';
  deliveryStatus?: 'ASSIGNED' | 'PICKED_UP' | 'DELIVERED';
  deliveryOTP?: string;
  otpSent?: boolean;
  otpVerified?: boolean;
  createdAt: string;
  deliveryAgentId?: string;
}

export interface DeliveryStats {
  assignedOrders: number;
  deliveredOrders: number;
  totalOrders: number;
}
