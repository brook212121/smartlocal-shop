import axios from 'axios';
import { DeliveryOrder } from '../types/delivery';
import { getApiUrl } from '../../utils/apiConfig';
import { safeFetch, isUserOffline, getUserFriendlyErrorMessage } from '../../utils/errorHandler';

// Helper function to get auth token
const getAuthToken = () => {
  // Try to get token from authData (new AuthContext format)
  const authData = localStorage.getItem('authData');
  if (authData) {
    try {
      const parsed = JSON.parse(authData);
      if (parsed.token) {
        return parsed.token;
      }
    } catch (error) {
      // Log error only in development
      if (import.meta.env.DEV) {
        console.error('Error parsing authData in delivery service:', error);
      }
    }
  }
  
  // Fallback to direct token (legacy support)
  const token = localStorage.getItem('token');
  if (token) {
    return token;
  }
  
  return null;
};

export const deliveryService = {
  // Get orders assigned to delivery agent
  getAssignedOrders: async (): Promise<DeliveryOrder[]> => {
    // Check offline status first
    if (isUserOffline()) {
      throw new Error("NETWORK_ERROR");
    }
    
    const token = getAuthToken();
    if (!token) {
      throw new Error('No authentication token available');
    }
    
    const response = await axios.get(getApiUrl('delivery/orders'), {
      headers: {
        Authorization: `Bearer ${token}`
      },
      timeout: 12000 // 12 seconds timeout at axios level
    });
    return response.data.data.orders;
  },

  // Update delivery status
  updateDeliveryStatus: async (orderId: string, status: 'PICKED_UP' | 'DELIVERED'): Promise<void> => {
    // Check offline status first
    if (isUserOffline()) {
      throw new Error("NETWORK_ERROR");
    }
    
    const token = getAuthToken();
    if (!token) {
      throw new Error('No authentication token available');
    }
    
    await axios.put(getApiUrl(`delivery/orders/${orderId}/status`), 
      { deliveryStatus: status },
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    );
  },

  // Get delivery statistics
  getDeliveryStats: async (): Promise<{
    assignedOrders: number;
    deliveredOrders: number;
    totalOrders: number;
  }> => {
    // Check offline status first
    if (isUserOffline()) {
      return {
        assignedOrders: 0,
        deliveredOrders: 0,
        totalOrders: 0
      };
    }
    
    const token = getAuthToken();
    if (!token) {
      return {
        assignedOrders: 0,
        deliveredOrders: 0,
        totalOrders: 0
      };
    }
    
    const response = await axios.get(getApiUrl('delivery/stats'), {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    return response.data.data || {
      assignedOrders: 0,
      deliveredOrders: 0,
      totalOrders: 0
    };
  },

  // Get available delivery agents
  getAvailableDeliveryAgents: async (): Promise<any[]> => {
    // Check offline status first
    if (isUserOffline()) {
      return [];
    }
    
    const token = getAuthToken();
    if (!token) {
      return [];
    }
    
    const response = await axios.get(getApiUrl('delivery-agents/available'), {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    return response.data.data || [];
  },

  // Assign delivery agent to order
  assignDeliveryAgent: async (
    orderId: string,
    deliveryAgentId: string,
    vendorLocation: { latitude: number; longitude: number },
    customerLocation: { latitude: number; longitude: number }
  ): Promise<any> => {
    // Check offline status first
    if (isUserOffline()) {
      throw new Error("NETWORK_ERROR");
    }
    
    const token = getAuthToken();
    if (!token) {
      throw new Error('No authentication token available');
    }
    
    const response = await axios.post(getApiUrl('delivery/assign'), {
      orderId,
      deliveryAgentId,
      vendorLocation,
      customerLocation
    }, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    return response.data.data;
  },

  // Update delivery agent location
  updateDeliveryAgentLocation: async (locationData: { latitude: number; longitude: number; address: string }): Promise<{ success: boolean; message?: string }> => {
    // Check offline status first
    if (isUserOffline()) {
      throw new Error("NETWORK_ERROR");
    }
    
    const token = getAuthToken();
    if (!token) {
      return { success: false, message: 'No authentication token available' };
    }
    
    // Use correct backend route path
    const url = getApiUrl('delivery/delivery-agents/location');
    
    try {
      const response = await axios.put(url, locationData, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      return response.data;
    } catch (error) {
      return { success: false, message: getUserFriendlyErrorMessage(error) };
    }
  }
};
