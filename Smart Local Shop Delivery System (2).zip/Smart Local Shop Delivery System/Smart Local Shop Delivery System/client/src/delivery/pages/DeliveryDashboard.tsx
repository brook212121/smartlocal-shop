import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Truck, 
  Package, 
  CheckCircle, 
  TrendingUp
} from 'lucide-react';
import { deliveryService } from '../services/deliveryService';
import { DeliveryStats } from '../types/delivery';
import { useLocationPermission } from '../../hooks/useLocationPermission';
import { useAuth } from '../../contexts/AuthContext';
import { safeFetch, isUserOffline } from '../../utils/errorHandler';

const DeliveryDashboard = () => {
  const navigate = useNavigate();
  const { authState } = useAuth();
  const [stats, setStats] = useState<DeliveryStats>({
    assignedOrders: 0,
    deliveredOrders: 0,
    totalOrders: 0
  });
  const [isLoading, setIsLoading] = useState(true);
  
  // Performance optimization refs
  const lastLocationUpdateRef = useRef<number>(0);
  const locationWatchIdRef = useRef<number | null>(null);
  const statsCacheRef = useRef<{ data: DeliveryStats; timestamp: number } | null>(null);
  const CACHE_DURATION = 60000; // 60 seconds
  const LOCATION_UPDATE_INTERVAL = 60000; // 60 seconds
  
  // Location permission hook for delivery agent GPS tracking
  const { 
    permissionStatus, 
    location: currentLocation, 
    requestPermission 
  } = useLocationPermission();

  // Remove debug logs to reduce console noise - only log errors

  // Update delivery agent location when available (throttled)
  useEffect(() => {
    if (currentLocation && permissionStatus === 'granted') {
      const now = Date.now();
      if (now - lastLocationUpdateRef.current >= LOCATION_UPDATE_INTERVAL) {
        updateAgentLocationInDatabase(currentLocation);
        lastLocationUpdateRef.current = now;
      }
    }
  }, [currentLocation, permissionStatus]);

  // Update delivery agent location in database (with timeout)
  const updateAgentLocationInDatabase = useCallback(async (location: any) => {
    try {
      // Create timeout promise
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('Location update timeout')), 8000);
      });
      
      // Make direct API call to update delivery agent location
      const response = await Promise.race([
        (deliveryService as any).updateDeliveryAgentLocation({
          latitude: location.latitude,
          longitude: location.longitude,
          address: location.address || 'Unknown location',
        }),
        timeoutPromise
      ]);
      
      if (response.success) {
        // Success - no console log for performance
      } else {
        console.error('❌ Failed to update location:', response.message);
      }
    } catch (error: any) {
      console.error('❌ Error updating delivery agent location:', error);
    }
  }, []);

  // Start continuous location tracking when permission is granted (delayed start)
  useEffect(() => {
    // Only start location tracking after dashboard data has loaded
    if (permissionStatus === 'granted' && !isLoading) {
      // Start watching position for real-time updates
      const watchId = navigator.geolocation.watchPosition(
        (position) => {
          const location = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            address: 'Detected via browser GPS'
          };
          updateAgentLocationInDatabase(location);
        },
        (error) => {
          console.error('❌ Location watch error:', error);
        },
        {
          enableHighAccuracy: true,
          timeout: 15000, // Increased timeout for better reliability
          maximumAge: 600000 // 10 minutes cache for better performance
        }
      );

      locationWatchIdRef.current = watchId;

      // Cleanup watch position on unmount
      return () => {
        if (locationWatchIdRef.current !== null) {
          navigator.geolocation.clearWatch(locationWatchIdRef.current);
        }
      };
    }
  }, [permissionStatus, isLoading, updateAgentLocationInDatabase]);

  // Fetch delivery stats with caching
  const fetchStats = useCallback(async () => {
    try {
      if (!authState.isAuthenticated) return;
      
      // Check offline status first
      if (isUserOffline()) {
        console.log('Offline - skipping stats fetch');
        return;
      }
      
      // Check cache first
      const now = Date.now();
      if (statsCacheRef.current && (now - statsCacheRef.current.timestamp < CACHE_DURATION)) {
        setStats(statsCacheRef.current.data);
        return;
      }
      
      // Create timeout promise
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('Stats fetch timeout')), 8000);
      });
      
      // Fetch with timeout
      const statsData = await Promise.race([
        deliveryService.getDeliveryStats(),
        timeoutPromise
      ]) as DeliveryStats;
      
      // Update cache
      statsCacheRef.current = { data: statsData, timestamp: now };
      setStats(statsData);
    } catch (error) {
      // Log error for debugging but don't show toast for stats
      if (import.meta.env.DEV) {
        console.error('Error fetching stats:', error);
      }
    }
  }, [authState.isAuthenticated]);
  
  // Simplified fetchDashboardData - only fetch stats
  const fetchDashboardData = useCallback(async () => {
    try {
      // Prevent API calls if user is not authenticated
      if (!authState.isAuthenticated) {
        return;
      }

      // Fetch only stats
      await fetchStats();
      setIsLoading(false);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      setIsLoading(false);
    }
  }, [authState.isAuthenticated, fetchStats]);

  useEffect(() => {
    fetchDashboardData();
  }, [fetchDashboardData]);

  const handleViewDetails = (orderId: string) => {
    navigate(`/delivery/order/${orderId}`);
  };

  const StatCard = ({ 
    title, 
    value, 
    icon: Icon, 
    color, 
    trend,
    subtitle
  }: { 
    title: string; 
    value: number; 
    icon: any; 
    color: string; 
    trend?: string;
    subtitle?: string;
  }) => (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-center justify-between mb-4">
        <div className={`p-3 rounded-lg ${color}`}>
          <Icon className="h-6 w-6 text-white" />
        </div>
        {trend && (
          <div className="flex items-center text-sm text-green-600">
            <TrendingUp className="h-4 w-4 mr-1" />
            {trend}
          </div>
        )}
      </div>
      <div>
        <h3 className="text-2xl font-bold text-gray-900">{value}</h3>
        <p className="text-sm text-gray-600 mt-1">{title}</p>
        {subtitle && (
          <p className="text-xs text-gray-500 mt-1">{subtitle}</p>
        )}
      </div>
    </div>
  );

  // Improved loading UX - show stats immediately, orders load separately
  if (isLoading) {
    return (
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
            <p className="text-gray-600">Loading your delivery overview...</p>
          </div>
          
          {/* Stats skeleton */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="bg-white rounded-lg shadow-md p-6">
                <div className="animate-pulse">
                  <div className="h-12 bg-gray-200 rounded mb-4"></div>
                  <div className="h-8 bg-gray-200 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      <div className="mb-8">  
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <p className="text-gray-600">Here's your delivery overview. Stay safe on the road!</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Assigned Orders"
            value={stats.assignedOrders}
            icon={Package}
            color="bg-blue-500"
            trend="Active"
            subtitle="Ready for pickup"
          />
          <StatCard
            title="Delivered Today"
            value={stats.deliveredOrders}
            icon={CheckCircle}
            color="bg-green-500"
            trend="Completed"
            subtitle="Successfully delivered"
          />
          <StatCard
            title="Total Orders"
            value={stats.totalOrders}
            icon={Truck}
            color="bg-purple-500"
            subtitle="All time deliveries"
          />
          <StatCard
            title="Completion Rate"
            value={stats.totalOrders > 0 ? Math.round((stats.deliveredOrders / stats.totalOrders) * 100) : 0}
            icon={TrendingUp}
            color="bg-orange-500"
            trend="Performance"
            subtitle="% delivered"
          />
        </div>
        {/* Performance Metrics */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Performance Overview</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600 mb-2">
                {stats.deliveredOrders}
              </div>
              <div className="text-sm text-gray-600">Total Deliveries</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">
                {stats.assignedOrders}
              </div>
              <div className="text-sm text-gray-600">Pending Orders</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 mb-2">
                {stats.totalOrders > 0 ? Math.round((stats.deliveredOrders / stats.totalOrders) * 100) : 0}%
              </div>
              <div className="text-sm text-gray-600">Success Rate</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeliveryDashboard;
