import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Package, MapPin, Phone, Clock, ArrowLeft, CheckCircle, Truck } from 'lucide-react';
import { deliveryService } from '../services/deliveryService';
import { DeliveryOrder } from '../types/delivery';
import DeliveryStatusBadge from '../components/DeliveryStatusBadge';

const OrderDetailsPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [order, setOrder] = useState<DeliveryOrder | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (id) {
      fetchOrderDetails(id);
    }
  }, [id]);

  const fetchOrderDetails = async (orderId: string) => {
    try {
      const orders = await deliveryService.getAssignedOrders();
      const foundOrder = orders.find(o => o._id === orderId);
      setOrder(foundOrder || null);
    } catch (error) {
      console.error('Error fetching order details:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateStatus = async (status: 'PICKED_UP' | 'DELIVERED') => {
    if (!order) return;
    
    try {
      await deliveryService.updateDeliveryStatus(order._id, status);
      // Refresh order details
      await fetchOrderDetails(order._id);
    } catch (error) {
      console.error('Error updating delivery status:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-sm p-12 text-center">
          <Package className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Order not found</h3>
          <p className="text-gray-500 mb-4">The order you're looking for doesn't exist or isn't assigned to you.</p>
          <button
            onClick={() => navigate('/delivery/assigned-orders')}
            className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700"
          >
            Back to Orders
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      <div className="mb-8">
        {/* Header */}
        <div className="flex items-center mb-6">
          <button
            onClick={() => navigate('/delivery/assigned-orders')}
            className="mr-4 p-2 text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <Package className="h-8 w-8 text-green-600 mr-3" />
          <h1 className="text-2xl font-bold text-gray-900">Order Details</h1>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          {/* Order Header */}
          <div className="flex items-start justify-between mb-6">
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-2">{order.orderNumber}</h2>
              <div className="flex items-center gap-4 text-sm text-gray-600">
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  <span>{new Date(order.createdAt).toLocaleDateString()}</span>
                </div>
                <DeliveryStatusBadge status={order.deliveryStatus} />
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-green-600">
                {order.pricing.currency} {order.pricing.total}
              </div>
              <div className="text-sm text-gray-600">Total Amount</div>
            </div>
          </div>

          {/* Order Items */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Order Items</h3>
            <div className="space-y-4">
              {order.items.map((item, index) => (
                <div key={index} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                  {item.product.images?.[0] && (
                    <img
                      src={item.product.images?.[0] ? (item.product.images[0].startsWith('http') ? item.product.images[0] : `http://localhost:5000${item.product.images[0]}`) : '/placeholder-product.jpg'}
                      alt={item.product.name}
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                  )}
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900">{item.product.name}</h4>
                    <div className="text-sm text-gray-600">
                      Quantity: {item.quantity} × {order.pricing.currency} {item.price}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium text-gray-900">
                      {order.pricing.currency} {item.price * item.quantity}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Delivery Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            {/* Pickup Information */}
            <div className="bg-blue-50 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-3">
                <Truck className="h-5 w-5 text-blue-600" />
                <h3 className="font-semibold text-gray-900">Pickup Information</h3>
              </div>
              <div className="space-y-2 text-sm">
                <div className="font-medium">{order.vendor.firstName} {order.vendor.lastName}</div>
                <div className="flex items-center gap-1 text-gray-600">
                  <Phone className="h-4 w-4" />
                  <span>{order.vendor.phone}</span>
                </div>
                <div className="flex items-start gap-1 text-gray-600">
                  <MapPin className="h-4 w-4 mt-0.5" />
                  <span>
                    {order.delivery.address.street}<br />
                    {order.delivery.address.city}, {order.delivery.address.county}
                  </span>
                </div>
              </div>
            </div>

            {/* Delivery Information */}
            <div className="bg-green-50 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-3">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <h3 className="font-semibold text-gray-900">Delivery Information</h3>
              </div>
              <div className="space-y-2 text-sm">
                <div className="font-medium">{order.customer.firstName} {order.customer.lastName}</div>
                <div className="flex items-center gap-1 text-gray-600">
                  <Phone className="h-4 w-4" />
                  <span>{order.customer.phone}</span>
                </div>
                <div className="flex items-start gap-1 text-gray-600">
                  <MapPin className="h-4 w-4 mt-0.5" />
                  <span>
                    {order.delivery.address.street}<br />
                    {order.delivery.address.city}, {order.delivery.address.county}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Delivery Instructions */}
          {order.delivery.address.instructions && (
            <div className="mb-6">
              <h3 className="font-semibold text-gray-900 mb-2">Delivery Instructions</h3>
              <p className="text-gray-600 bg-gray-50 p-3 rounded-lg">
                {order.delivery.address.instructions}
              </p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="border-t pt-6">
            <h3 className="font-semibold text-gray-900 mb-4">Update Delivery Status</h3>
            <div className="flex gap-3">
              {order.deliveryStatus !== 'PICKED_UP' && order.deliveryStatus !== 'DELIVERED' && (
                <button
                  onClick={() => handleUpdateStatus('PICKED_UP')}
                  className="bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 transition-colors font-medium"
                >
                  Mark as Picked Up
                </button>
              )}
              {order.deliveryStatus === 'PICKED_UP' && (
                <button
                  onClick={() => handleUpdateStatus('DELIVERED')}
                  className="bg-green-600 text-white px-6 py-3 rounded-md hover:bg-green-700 transition-colors font-medium"
                >
                  Mark as Delivered
                </button>
              )}
              {order.deliveryStatus === 'DELIVERED' && (
                <div className="bg-green-100 text-green-800 px-6 py-3 rounded-md font-medium">
                  ✓ Order Delivered
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderDetailsPage;
