import { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  Package, 
  User, 
  Navigation, 
  ArrowLeft,
  Square,
  Phone,
  MapPin,
  Clock,
  Compass
} from 'lucide-react';
import { useToast } from '../../contexts/ToastContext';
import { useAuth } from '../../contexts/AuthContext';
import { deliveryService } from '../services/deliveryService';
import { DeliveryOrder } from '../types/delivery';
import Spinner from '../../components/ui/Spinner';
import DeliveryStatusBadge from '../components/DeliveryStatusBadge';
import { GoogleMap, useJsApiLoader, Marker, DirectionsRenderer } from '@react-google-maps/api';
import { safeFetch, isUserOffline } from '../../utils/errorHandler';

const DeliveryOrderDetailsPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [order, setOrder] = useState<DeliveryOrder | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [updatingStatus, setUpdatingStatus] = useState<string | null>(null);
  const [isTracking, setIsTracking] = useState(false);
  const { handleApiError } = useToast();
  const { authState } = useAuth();
  
  // Performance optimization refs
  const orderCacheRef = useRef<{ data: DeliveryOrder; timestamp: number } | null>(null);
  const CACHE_DURATION = 60000; // 60 seconds

  // Google Maps state
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY || 'YOUR_API_KEY_HERE'
  });

  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [directions, setDirections] = useState<google.maps.DirectionsResult | null>(null);
  const [routeInfo, setRouteInfo] = useState<{
    distance: string;
    duration: string;
    eta: string;
  } | null>(null);
  const [locationError, setLocationError] = useState<string | null>(null);
  const mapRef = useRef<google.maps.Map | null>(null);

  useEffect(() => {
    if (id) {
      fetchOrderDetails(id);
    }
  }, [id]);

  const fetchOrderDetails = useCallback(async (orderId: string) => {
    try {
      setIsLoading(true);
      
      // Check offline status first
      if (isUserOffline()) {
        handleApiError(new Error("NETWORK_ERROR"));
        setIsLoading(false);
        return;
      }
      
      // Check cache first
      const now = Date.now();
      if (orderCacheRef.current && (now - orderCacheRef.current.timestamp < CACHE_DURATION)) {
        setOrder(orderCacheRef.current.data);
        setIsLoading(false);
        return;
      }
      
      // Create timeout promise
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('Order fetch timeout')), 8000);
      });
      
      // Fetch with timeout and safe fetch
      const response = await Promise.race([
        safeFetch(`/api/delivery/orders/${orderId}`, {
          headers: {
            'Authorization': `Bearer ${authState.token}`
          }
        }),
        timeoutPromise
      ]) as Response;
      
      if (!response.ok) {
        throw new Error(`Failed to fetch order: ${response.status}`);
      }
      
      const apiResponse = await response.json();
      
      if (!apiResponse.success || !apiResponse.data) {
        throw new Error('Order not found or invalid response');
      }
      
      // Update cache
      orderCacheRef.current = { data: apiResponse.data, timestamp: now };
      setOrder(apiResponse.data);
    } catch (error) {
      handleApiError(error);
    } finally {
      setIsLoading(false);
    }
  }, [authState.token, handleApiError]);

  const handleUpdateStatus = useCallback(async (orderId: string, status: 'PICKED_UP' | 'DELIVERED') => {
    try {
      setUpdatingStatus(orderId);
      
      // Instant UI update: Update status immediately when action starts
      if (order && order._id === orderId) {
        setOrder({
          ...order,
          deliveryStatus: status,
          otpSent: status === 'PICKED_UP' // Set OTP sent for PICKED_UP
        });
      }
      
      // Check offline status first
      if (isUserOffline()) {
        handleApiError(new Error("NETWORK_ERROR"));
        // Revert UI update if offline
        if (order && order._id === orderId) {
          setOrder(order);
        }
        return;
      }
      
      // Safety check for token
      if (!authState.token) {
        throw new Error('No authentication token found. Please log in again.');
      }
      
      // Create timeout promise
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('Status update timeout')), 8000);
      });
      
      // If marking as picked up, generate OTP first
      if (status === 'PICKED_UP') {
        // Generate OTP with timeout and safe fetch
        const generateResponse = await Promise.race([
          safeFetch('/api/orders/generate-otp', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${authState.token}`
            },
            body: JSON.stringify({ orderId })
          }),
          timeoutPromise
        ]) as Response;
        
        if (!(generateResponse instanceof Response)) {
          throw new Error('Invalid response type');
        }
        const generateResult = await generateResponse.json();
        
        if (!generateResult.success) {
          throw new Error(generateResult.message || 'Failed to generate OTP');
        }
      }
      
      // Update delivery status with timeout
      await Promise.race([
        deliveryService.updateDeliveryStatus(orderId, status),
        timeoutPromise
      ]);
      
      // Background refresh (non-blocking)
      fetchOrderDetails(orderId).catch(() => {
        // Silently fail background refresh, UI already updated
      });
    } catch (error) {
      handleApiError(error);
      // Revert UI update on error
      if (order && order._id === orderId) {
        setOrder(order);
      }
    } finally {
      setUpdatingStatus(null);
    }
  }, [authState.token, fetchOrderDetails, handleApiError, order]);

  const handleConfirmDelivery = useCallback(async (orderId: string) => {
    try {
      setUpdatingStatus(orderId);
      
      // Instant UI update: Show delivered status immediately when action starts
      if (order && order._id === orderId) {
        setOrder({
          ...order,
          deliveryStatus: 'DELIVERED'
        });
      }
      
      // Check offline status first
      if (isUserOffline()) {
        handleApiError(new Error("NETWORK_ERROR"));
        // Revert UI update if offline
        if (order && order._id === orderId) {
          setOrder(order);
        }
        return;
      }
      
      // Safety check for token
      if (!authState.token) {
        throw new Error('No authentication token found. Please log in again.');
      }
      
      // Create timeout promise
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('Delivery confirmation timeout')), 8000);
      });
      
      // Call confirm delivery API (no OTP input needed) with timeout and safe fetch
      const response = await Promise.race([
        safeFetch('/api/orders/confirm-delivery', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${authState.token}`
          },
          body: JSON.stringify({ orderId })
        }),
        timeoutPromise
      ]) as Response;
      
      if (!(response instanceof Response)) {
        throw new Error('Invalid response type');
      }
      const result = await response.json();
      
      if (result.success) {
        // Background refresh (non-blocking)
        fetchOrderDetails(orderId).catch(() => {
          // Silently fail background refresh, UI already updated
        });
      } else {
        handleApiError(new Error(result.message));
        // Revert UI update on API error
        if (order && order._id === orderId) {
          setOrder(order);
        }
      }
    } catch (error) {
      handleApiError(error);
      // Revert UI update on error
      if (order && order._id === orderId) {
        setOrder(order);
      }
    } finally {
      setUpdatingStatus(null);
    }
  }, [authState.token, fetchOrderDetails, handleApiError, order]);

  const handleNavigation = () => {
    if (!isTracking) {
      // Start navigation
      startNavigation();
    } else {
      // Stop navigation
      stopNavigation();
    }
  };

  const getCurrentLocation = (): Promise<{ lat: number; lng: number }> => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation is not supported by this browser'));
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          resolve({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          reject(new Error(`Unable to retrieve location: ${error.message}`));
        },
        {
          enableHighAccuracy: true,
          timeout: 15000,
          maximumAge: 600000 // 10 minutes cache for better performance
        }
      );
    });
  };

  const calculateRoute = async () => {
    if (!order) {
      setLocationError('Order information not available');
      return;
    }

    try {
      // Removed debug logs for performance - only log errors
      
      // FRONTEND SAFETY FIX: Validate coordinates exist
      if (!order?.delivery?.address?.coordinates?.latitude || 
          !order?.delivery?.address?.coordinates?.longitude) {
        setLocationError('Customer location not available. This order may not have saved location coordinates.');
        return;
      }

      // Get current location
      const agentLocation = await getCurrentLocation();
      setCurrentLocation(agentLocation);

      // Check if customer coordinates exist
      const customerLocation = order.delivery?.address?.coordinates;

      if (!customerLocation) {
        setLocationError('Customer location coordinates are missing');
        return;
      }

      // Create DirectionsService
      const directionsService = new google.maps.DirectionsService();

      // Calculate route: Agent -> Customer (direct route since vendor coordinates not available)
      const result = await directionsService.route({
        origin: agentLocation,
        destination: {
          lat: customerLocation.latitude,
          lng: customerLocation.longitude
        },
        travelMode: google.maps.TravelMode.DRIVING
      });

      if (result.routes && result.routes.length > 0) {
        setDirections(result);
        
        // Extract route information
        const route = result.routes[0];
        const leg = route.legs[0]; // Total route
        const totalDistance = leg.distance?.text || 'Unknown';
        const totalDuration = leg.duration?.text || 'Unknown';
        
        // Calculate ETA
        const now = new Date();
        const eta = new Date(now.getTime() + (leg.duration?.value || 0) * 1000);
        const etaString = eta.toLocaleTimeString('en-US', {
          hour: '2-digit',
          minute: '2-digit'
        });

        setRouteInfo({
          distance: totalDistance,
          duration: totalDuration,
          eta: etaString
        });

        setLocationError(null);
        // Route calculated successfully
        if (import.meta.env.DEV) {
          console.log('Route calculated successfully:', {
            distance: totalDistance,
            duration: totalDuration,
            eta: etaString
          });
        }
      } else {
        setLocationError('Unable to calculate route: No routes found');
      }
    } catch (error) {
      console.error('Error calculating route:', error);
      setLocationError('Failed to calculate route. Please try again.');
    }
  };

  const startNavigation = async () => {
    try {
      setIsTracking(true);
      await calculateRoute();
      
      // Start location tracking updates
      const locationInterval = setInterval(async () => {
        try {
          await calculateRoute();
        } catch (error) {
          console.error('Error updating route:', error);
        }
      }, 30000); // Update every 30 seconds

      // Store interval ID for cleanup
      (window as any).navigationInterval = locationInterval;
      
      // Navigation started
    } catch (error) {
      setIsTracking(false);
      setLocationError('Failed to start navigation');
    }
  };

  const stopNavigation = () => {
    setIsTracking(false);
    setDirections(null);
    setRouteInfo(null);
    
    // Clear location tracking interval
    if ((window as any).navigationInterval) {
      clearInterval((window as any).navigationInterval);
      delete (window as any).navigationInterval;
    }
  };

  const formatDate = (dateString: string | Date) => {
    const date = typeof dateString === 'string' ? new Date(dateString) : dateString;
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatCurrency = (amount: number, currency: string = 'ETB') => {
    return `${currency} ${amount.toFixed(2)}`;
  };

  if (isLoading) {
    return (
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
            <p className="text-gray-600">Loading order details...</p>
          </div>
          
          {/* Order skeleton */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="animate-pulse">
              <div className="h-8 bg-gray-200 rounded mb-4"></div>
              <div className="h-32 bg-gray-200 rounded mb-4"></div>
              <div className="h-24 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-center">
          <Package className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Order not found</h3>
          <p className="text-gray-500 mb-4">The order you're looking for doesn't exist.</p>
          <button
            onClick={() => navigate('/delivery/assigned-orders')}
            className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700"
          >
            Back to Orders
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Order Images */}
          <div className="space-y-4">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              {order?.items?.length > 0 && order.items[0].product?.images?.length > 0 ? (
                <img
                  src={order.items[0].product.images[0]}
                  alt={order.items[0].product?.name || 'Product'}
                  className="w-full h-96 object-cover"
                  onError={(e) => {
                    e.currentTarget.src = '/api/placeholder/400/400';
                  }}
                />
              ) : (
                <div className="w-full h-96 bg-gray-200 flex items-center justify-center">
                  <Package className="h-16 w-16 text-gray-400" />
                </div>
              )}
            </div>
            
            {/* Thumbnail Gallery */}
            {order?.items?.length > 1 && (
              <div className="grid grid-cols-4 gap-2">
                {order.items.map((item: any, index: number) => (
                  item.product?.images?.length > 0 && (
                    <button
                      key={index}
                      className="relative overflow-hidden rounded-lg border-2 border-gray-200 transition-colors hover:border-green-500"
                    >
                      <img
                        src={item.product.images[0]}
                        alt={`${item.product?.name || 'Product'} ${index + 1}`}
                        className="w-full h-20 object-cover"
                      />
                    </button>
                  )
                ))}
              </div>
            )}
          </div>

          {/* Order Information */}
          <div className="space-y-6">
            {/* Order Header */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{order?.orderNumber || 'N/A'}</h3>
                </div>
                <DeliveryStatusBadge status={order?.deliveryStatus} />
              </div>

              <p className="text-gray-600 leading-relaxed mb-4">
                Order placed on {formatDate(order?.createdAt || new Date())}
              </p>
            </div>

            {/* Navigation Section */}
            {order?.deliveryStatus === 'ASSIGNED' && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  <Compass className="h-5 w-5 mr-2 text-green-600" />
                  Delivery Navigation
                </h3>

                {/* Navigation Button */}
                <button
                  className={`w-full py-3 px-4 rounded-md transition-colors font-medium text-lg flex items-center justify-center ${
                    isTracking 
                      ? 'bg-red-600 text-white hover:bg-red-700' 
                      : 'bg-green-600 text-white hover:bg-green-700'
                  }`}
                  onClick={handleNavigation}
                >
                  {isTracking ? (
                    <>
                      <Square className="h-5 w-5 mr-2" />
                      Stop Navigation
                    </>
                  ) : (
                    <>
                      <Navigation className="h-5 w-5 mr-2" />
                      Start Navigation
                    </>
                  )}
                </button>

                {/* Route Information */}
                {routeInfo && (
                  <div className="mt-4 p-4 bg-green-50 rounded-lg border border-green-200">
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <div className="text-2xl font-bold text-green-600">{routeInfo.distance}</div>
                        <div className="text-sm text-gray-600">Total Distance</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-green-600">{routeInfo.duration}</div>
                        <div className="text-sm text-gray-600">Est. Duration</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-green-600">{routeInfo.eta}</div>
                        <div className="text-sm text-gray-600">ETA</div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {locationError && (
                  <div className="mt-4 p-4 bg-red-50 rounded-lg border border-red-200">
                    <div className="flex items-center">
                      <MapPin className="h-5 w-5 mr-2 text-red-600" />
                      <span className="text-red-800">{locationError}</span>
                    </div>
                  </div>
                )}

                {/* Google Map */}
                {isLoaded && (isTracking || directions) && (
                  <div className="mt-4">
                    <div className="h-96 bg-gray-100 rounded-lg overflow-hidden">
                      <GoogleMap
                        mapContainerStyle={{ width: '100%', height: '100%' }}
                        center={currentLocation || { lat: 9.1450, lng: 40.4897 }} // Default to Addis Ababa
                        zoom={14}
                        onLoad={(map) => {
                          mapRef.current = map;
                          // Google Map loaded successfully
                          if (import.meta.env.DEV) {
                            console.log('Google Map loaded successfully');
                            console.log('Customer coordinates:', order.delivery.address.coordinates);
                          }
                        }}
                      >
                        {/* Current Location Marker */}
                        {currentLocation && (
                          <Marker
                            position={currentLocation}
                            title="Your Location"
                            icon={{
                              url: 'data:image/svg+xml;base64,PH2BAAAAC0lEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg==',
                              scaledSize: new google.maps.Size(40, 40)
                            }}
                          />
                        )}

                        {/* Customer Location Marker */}
                        {order?.delivery?.address?.coordinates && (
                          <Marker
                            position={{
                              lat: order.delivery.address.coordinates.latitude,
                              lng: order.delivery.address.coordinates.longitude
                            }}
                            title="Customer Delivery Location"
                            icon={{
                              url: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMjAiIGN5PSIyMCIgcj0iMTgiIGZpbGw9IiMxMEI5ODEiLz4KPHN2ZyB4PSIxMCIgeT0iMTAiIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJ3aGl0ZSI+CjxwYXRoIGQ9Ik0xMiAyQzE1LjMxIDIgMTggNC42OSAxOCA4QzE4IDExLjMxIDE1LjMxIDE0IDEyIDE0QzguNjkgMTQgNiAxMS4zMSA2IDhDNiA0LjY5IDguNjkgMiAxMiAyWk0xMiA0QzkuNzkgNCA4IDUuNzkgOCA4QzggMTAuMjEgOS43OSAxMiAxMiAxMUMxNC4yMSAxMiAxNiAxMC4yMSAxNiA4QzE2IDUuNzkgMTQuMjEgNCAxMiA0WiIgZmlsbD0id2hpdGUiLz4KPC9zdmc+Cjwvc3ZnPgo=',
                              scaledSize: new google.maps.Size(40, 40)
                            }}
                          />
                        )}

                        {/* Route Directions */}
                        {directions && (
                          <DirectionsRenderer
                            directions={directions}
                            options={{
                              suppressMarkers: true, // We use custom markers
                              polylineOptions: {
                                strokeColor: '#10B981',
                                strokeWeight: 4,
                                strokeOpacity: 0.8
                              }
                            }}
                          />
                        )}
                      </GoogleMap>
                    </div>
                  </div>
                )}

                {/* Navigation Status */}
                {isTracking && (
                  <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Clock className="h-5 w-5 mr-2 text-blue-600 animate-pulse" />
                        <span className="text-blue-800 font-medium">Navigation Active</span>
                      </div>
                      <span className="text-sm text-blue-600">Route updates every 30 seconds</span>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Customer Information */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Customer Information</h3>
              <div className="space-y-3">
                <div className="flex items-center">
                  <User className="h-5 w-5 text-gray-400 mr-3" />
                  <div>
                    <div className="font-medium text-gray-900">
                      {order?.customer?.firstName || ''} {order?.customer?.lastName || 'N/A'}
                    </div>
                  </div>
                </div>
                {order?.customer?.phone && (
                  <div className="flex items-center">
                    <Phone className="h-5 w-5 text-gray-400 mr-3" />
                    <span className="text-gray-900">{order.customer.phone}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Pickup Location */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Pickup Location</h3>
              <div className="space-y-3">
                <div className="flex items-center">
                  <Package className="h-5 w-5 text-gray-400 mr-3" />
                  <div>
                    <div className="font-medium text-gray-900">
                      {order?.vendor?.firstName || ''} {order?.vendor?.lastName || 'N/A'}
                    </div>
                  </div>
                </div>
                {order?.vendor?.phone && (
                  <div className="flex items-center">
                    <Phone className="h-5 w-5 text-gray-400 mr-3" />
                    <span className="text-gray-900">{order.vendor.phone}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Order Items */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Order Items</h3>
              <div className="space-y-4">
                {order?.items?.map((item: any, index: number) => (
                  <div key={index} className="flex gap-4 p-4 bg-gray-50 rounded-lg">        
                    {/* Product Details */}
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">{item.product?.name || 'Product'}</h4>
                      <p className="text-sm text-gray-500">Quantity: {item.quantity || 0}</p>
                    </div>
                  </div>
                ))}
                {(!order?.items || order.items.length === 0) && (
                  <p className="text-gray-500">No items found</p>
                )}
              </div>
            </div>

            {/* Delivery Actions - Hide for delivered orders */}
            {order?.deliveryStatus !== 'DELIVERED' && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Delivery Actions</h3>
                
                <div className="space-y-4">
                  {order?.deliveryStatus === 'ASSIGNED' && (
                    <button
                      onClick={() => handleUpdateStatus(order._id, 'PICKED_UP')}
                      disabled={updatingStatus === order._id}
                      className="w-full bg-green-600 text-white py-3 px-4 rounded-md hover:bg-green-700 transition-colors font-medium text-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                    >
                      {updatingStatus === order._id ? (
                        <>
                          <Spinner size="sm" />
                          Generating OTP...
                        </>
                      ) : (
                        <>
                          <Package className="h-5 w-5 mr-2" />
                          Mark as Delivered
                        </>
                      )}
                    </button>
                  )}
                
                {order?.deliveryStatus === 'PICKED_UP' && (
                  <>
                    {/* OTP Status Display */}
                    <div className="mb-4 p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="font-medium text-gray-900">
                            {order.otpSent === false ? (
                              <span className="text-yellow-600">Waiting for customer confirmation</span>
                            ) : (
                              <span className="text-green-600">Ready to confirm delivery</span>
                            )}
                          </div>
                          <div className="text-sm text-gray-500">
                            {order.otpSent === false 
                              ? 'Buyer needs to click "Send OTP" first' 
                              : 'OTP has been sent to buyer'
                            }
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Confirm Delivery Button - NO OTP INPUT */}
                    <button
                      onClick={() => handleConfirmDelivery(order._id)}
                      disabled={updatingStatus === order._id || order.otpSent !== true}
                      className={`w-full py-3 px-4 rounded-md transition-colors font-medium text-lg flex items-center justify-center gap-2 ${
                        updatingStatus === order._id || order.otpSent !== true
                          ? 'bg-gray-400 text-gray-200 cursor-not-allowed' 
                          : 'bg-green-600 text-white hover:bg-green-700'
                      }`}
                    >
                      {updatingStatus === order._id ? (
                        <>
                          <Spinner size="sm" />
                          Confirming...
                        </>
                      ) : (
                        <>
                          <Package className="h-5 w-5 mr-2" />
                          Confirm Delivery
                        </>
                      )}
                    </button>
                  </>
                )}  
              </div>
            </div>
            )}

            {/* Back Button */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <button
                onClick={() => navigate('/delivery/assigned-orders')}
                className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
              >
                <ArrowLeft className="h-3 w-3" />
                Back to Orders
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeliveryOrderDetailsPage;
