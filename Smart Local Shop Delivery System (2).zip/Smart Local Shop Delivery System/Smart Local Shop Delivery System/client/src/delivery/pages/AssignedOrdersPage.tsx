import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Package, Search, Filter } from 'lucide-react';
import { deliveryService } from '../../services/deliveryService';
import { DeliveryOrder } from '../types/delivery';
import CompactDeliveryOrderCard from '../components/CompactDeliveryOrderCard';
import Spinner from '../../components/ui/Spinner';
import { safeFetch, isUserOffline } from '../../utils/errorHandler';

const AssignedOrdersPage = () => {
  const navigate = useNavigate();
  const [orders, setOrders] = useState<DeliveryOrder[]>([]);
  const [filteredOrders, setFilteredOrders] = useState<DeliveryOrder[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ASSIGNED' | 'PICKED_UP' | 'DELIVERED'>('ALL');
  const [showFilters, setShowFilters] = useState(false);
  
  // Performance optimization refs
  const ordersCacheRef = useRef<{ data: DeliveryOrder[]; timestamp: number } | null>(null);
  const CACHE_DURATION = 60000; // 60 seconds

  useEffect(() => {
    fetchOrders();
  }, []);

  useEffect(() => {
    filterOrders();
  }, [orders, searchTerm, statusFilter]);

  const handleViewDetails = (orderId: string) => {
    navigate(`/delivery/order/${orderId}`);
  };

  const fetchOrders = useCallback(async () => {
    try {
      // Check offline status first
      if (isUserOffline()) {
        setIsLoading(false);
        return;
      }
      
      // Check cache first
      const now = Date.now();
      if (ordersCacheRef.current && (now - ordersCacheRef.current.timestamp < CACHE_DURATION)) {
        setOrders(ordersCacheRef.current.data);
        setIsLoading(false);
        return;
      }
      
      // Create timeout promise
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('Orders fetch timeout')), 15000); // Increased to 15 seconds
      });
      
      // Fetch with timeout
      const assignedOrders = await Promise.race([
        deliveryService.getAssignedOrders(),
        timeoutPromise
      ]) as DeliveryOrder[];
      
      // Update cache
      ordersCacheRef.current = { data: assignedOrders, timestamp: now };
      setOrders(assignedOrders);
    } catch (error) {
      // Log error for debugging but don't show toast for orders list
      if (import.meta.env.DEV) {
        console.error('Error fetching assigned orders:', error);
      }
    } finally {
      setIsLoading(false);
    }
  }, []);

  const filterOrders = useCallback(() => {
    let filtered = orders;

    // Filter by status
    if (statusFilter !== 'ALL') {
      filtered = filtered.filter(order => order.deliveryStatus === statusFilter);
    }

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(order =>
        order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.customer?.firstName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.customer?.lastName?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredOrders(filtered);
  }, [orders, searchTerm, statusFilter]);

  if (isLoading) {
    return (
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
            <p className="text-gray-600">Loading your assigned orders...</p>
          </div>
          
          {/* Orders skeleton */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="bg-white rounded-lg shadow-md p-6">
                <div className="animate-pulse">
                  <div className="h-4 bg-gray-200 rounded mb-4"></div>
                  <div className="h-20 bg-gray-200 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      <div className="mb-8">
        {/* Search and Filter */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">

            {/* Search + Filter Button */}
            <div className="flex-1 flex items-center gap-3">

              {/* Search Input */}
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search orders..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-3 py-2 border border-green-300 rounded-md focus:outline-none focus:border-2 focus:border-green-600 text-sm"
                />
              </div>

              {/* Mobile Filter Button */}
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="sm:hidden flex items-center px-3 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
              >
                <Filter className="h-5 w-5" />
              </button>
            </div>

            {/* Desktop Filter */}
            <div className="hidden sm:flex items-center gap-2">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="px-3 py-2 border border-gray-300 rounded-md text-sm"
              >
                <option value="ALL">All Orders</option>
                <option value="ASSIGNED">Assigned</option>
                <option value="PICKED_UP">Picked Up</option>
                <option value="DELIVERED">Delivered</option>
              </select>
            </div>

          </div>

          {/* Mobile Filter Panel */}
          {showFilters && (
            <div className="sm:hidden bg-white border rounded-lg p-4 mt-4">
              <label className="block text-sm font-medium mb-1">Status</label>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="w-full px-3 py-2 border rounded-md text-sm"
              >
                <option value="ALL">All Orders</option>
                <option value="ASSIGNED">Assigned</option>
                <option value="PICKED_UP">Picked Up</option>
                <option value="DELIVERED">Delivered</option>
              </select>
            </div>
          )}
        </div>

        {/* Orders Grid */}
        {filteredOrders.length === 0 ? (
          <div className="bg-white rounded-lg shadow-sm p-12 text-center">
            <Package className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No orders found</h3>
            <p className="text-gray-500">
              {orders.length === 0 
                ? "You don't have any assigned orders yet." 
                : "No orders match your current filters."
              }
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredOrders.map(order => (
              <CompactDeliveryOrderCard
                key={order._id}
                order={order}
                onViewDetails={handleViewDetails}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AssignedOrdersPage;
