import React, { useState, useEffect } from 'react';
import { Star, Package } from 'lucide-react';
import { relatedProductsService, RelatedProduct } from '../services/relatedProductsService';
import { getImageUrl, getFallbackImageUrl } from '../utils/imageUtils';

interface RelatedProductsProps {
  productId: string;
}

const RelatedProducts: React.FC<RelatedProductsProps> = ({ productId }) => {
  const [relatedProducts, setRelatedProducts] = useState<RelatedProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchRelatedProducts = async () => {
      try {
        console.log('🔄 Fetching related products for productId:', productId);
        setLoading(true);
        const products = await relatedProductsService.getRelatedProducts(productId);
        console.log('📦 Received related products:', products);
        setRelatedProducts(products);
        setError(null);
      } catch (err) {
        console.error('❌ Error fetching related products:', err);
        setError('Failed to load related products');
      } finally {
        setLoading(false);
      }
    };

    if (productId) {
      fetchRelatedProducts();
    }
  }, [productId]);

  const handleProductClick = (productId: string) => {
    window.open(`/dashboard/products/${productId}`, '_blank');
  };

  const renderStars = (rating?: number) => {
    if (!rating) return null;
    
    return (
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`h-4 w-4 ${
              star <= rating
                ? 'text-yellow-400 fill-yellow-400'
                : 'text-gray-300'
            }`}
          />
        ))}
        <span className="text-sm text-gray-600 ml-1">({rating})</span>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="mb-8">
        <h2 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4">Related Items</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {[...Array(6)].map((_, index) => (
            <div key={index} className="animate-pulse">
              <div className="bg-gray-200 rounded-lg h-32 mb-2"></div>
              <div className="h-4 bg-gray-200 rounded mb-1"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (error || relatedProducts.length === 0) {
    return null; // Don't show section if no related products
  }

  return (
    <div className="mb-8">
      <h2 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4">Related Items</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {relatedProducts.map((product) => (
          <div
            key={product._id}
            onClick={() => handleProductClick(product._id)}
            className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 flex flex-col border border-gray-100 cursor-pointer group"
          >
            {/* Product Image Container */}
            <div className="relative flex-shrink-0 bg-gradient-to-br from-gray-50 to-gray-100">
              <div className="aspect-w-16 aspect-h-12 relative h-64">
                <img
                  src={getImageUrl(product.images?.[0])}
                  alt={product.name}
                  loading="lazy"
                  className="w-full h-full object-contain p-4 transition-transform duration-300 hover:scale-105"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = getFallbackImageUrl();
                  }}
                />
              </div>
            </div>
            
            {/* Product Content */}
            <div className="p-5 flex-1 flex flex-col">
              {/* Product Name */}
              <h3 className="text-lg font-bold text-gray-900 mb-2 line-clamp-2 leading-tight">
                {product.name}
              </h3>
              
              {/* Rating */}
              <div className="flex items-center gap-2 mb-2">
                {renderStars(product.rating)}
              </div>
              
              {/* Brand */}
              {product.brand && (
                <p className="text-xs text-gray-500 mt-1">
                  {product.brand}
                </p>
              )}
              
              {/* Price Section */}
              <div className="flex items-center justify-between mb-4 mt-auto">
                <div className="flex items-baseline">
                  <span className="text-2xl font-bold text-green-600">ETB</span>
                  <span className="text-2xl font-bold text-green-600 ml-1">{product.price}</span>
                </div>
              </div>
              
              {/* Action Button */}
              <button
                onClick={() => handleProductClick(product._id)}
                className="flex items-center px-3 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-colors duration-200 shadow-sm w-full"
              >
                <Package className="h-4 w-4 mr-1" />
                View Details
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RelatedProducts;
