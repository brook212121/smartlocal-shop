import { useState, useRef, useEffect } from 'react';
import { Bell, X, MessageCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import api from '../../services/api';

interface Notification {
  id: string;
  vendorName: string;
  message: string;
  timestamp: Date;
  vendorId: string;
}

interface NotificationBellProps {
  notifications: Notification[];
  onNotificationClick?: (notification: Notification) => void;
}

const NotificationBell = ({ notifications, onNotificationClick }: NotificationBellProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const unreadCount = notifications.length;

  const handleNotificationClick = async (notification: Notification) => {
    try {
      console.log('🔍 NotificationBell: Notification clicked:', notification);
      console.log('🔍 NotificationBell: Current path:', window.location.pathname);
      
      // Close dropdown
      setIsOpen(false);
      
      // Mark notification as read
      console.log('🔍 NotificationBell: Marking notification as read...');
      const markReadResponse = await api.patch(`/messages/read/${notification.id}`);
      console.log('🔍 NotificationBell: Mark read response:', markReadResponse);
      
      // Check if we're already on vendor page
      const currentPath = window.location.pathname;
      const vendorPath = `/dashboard/vendor/${notification.vendorId}`;
      console.log('🔍 NotificationBell: Target path:', vendorPath);
      console.log('🔍 NotificationBell: Current path matches target:', currentPath === vendorPath);
      
      if (currentPath === vendorPath) {
        console.log('🔍 NotificationBell: Already on vendor page, just reload');
        // Already on vendor page, just reload to trigger conversation load
        window.location.reload();
      } else {
        console.log('🔍 NotificationBell: Navigating to vendor page');
        // Navigate to vendor page
        navigate(vendorPath);
      }
      
      // Call parent callback if provided
      onNotificationClick?.(notification);
      
    } catch (error) {
      console.error('❌ NotificationBell: Error handling notification click:', error);
      // Still navigate even if marking as read fails
      const vendorPath = `/dashboard/vendor/${notification.vendorId}`;
      navigate(vendorPath);
    }
  };

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Bell Icon */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 text-gray-600 hover:text-gray-900 transition-colors"
        title="Notifications"
      >
        <Bell className="h-5 w-5" />
        
        {/* Red Badge for Unread Count */}
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
            {unreadCount > 99 ? '99+' : unreadCount}
          </span>
        )}
      </button>

      {/* Dropdown Panel */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
          {/* Header */}
          <div className="px-4 py-3 border-b border-gray-200 flex items-center justify-between">
            <h3 className="font-semibold text-gray-900">Notifications</h3>
            <button
              onClick={() => setIsOpen(false)}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* Notifications List */}
          <div className="max-h-96 overflow-y-auto">
            {notifications.length === 0 ? (
              <div className="px-4 py-8 text-center">
                <MessageCircle className="h-8 w-8 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500 text-sm">No notifications yet</p>
                <p className="text-gray-400 text-xs mt-1">Chat messages will appear here</p>
              </div>
            ) : (
              <div className="divide-y divide-gray-100">
                {notifications.map((notification) => (
                  <div
                    key={notification.id}
                    onClick={() => handleNotificationClick(notification)}
                    className="px-4 py-3 hover:bg-gray-50 cursor-pointer transition-colors"
                  >
                    <div className="flex items-start space-x-3">
                      {/* Vendor Avatar */}
                      <div className="flex-shrink-0">
                        <div className="h-8 w-8 bg-gray-200 rounded-full flex items-center justify-center">
                          <MessageCircle className="h-4 w-4 text-gray-400" />
                        </div>
                      </div>
                      
                      {/* Message Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className="font-medium text-gray-900 text-sm">
                            {notification.vendorName}
                          </p>
                          <span className="text-xs text-gray-500">
                            {new Date(notification.timestamp).toLocaleTimeString([], { 
                              hour: '2-digit', 
                              minute: '2-digit' 
                            })}
                          </span>
                        </div>
                        <p className="text-gray-600 text-sm truncate">
                          {notification.message}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer */}
          {notifications.length > 0 && (
            <div className="px-4 py-2 border-t border-gray-200 bg-gray-50">
              <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">
                Mark all as read
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default NotificationBell;
