const PublicHeader = () => {
  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex items-center">
              <img 
                src="/logo.svg" 
                alt="Smart Local Shop Delivery" 
                className="h-7 w-7 mr-2"
              />
              <h1 className="text-base sm:text-lg lg:text-xl font-semibold text-gray-900">
                Smart Local Shop Delivery
              </h1>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default PublicHeader;
