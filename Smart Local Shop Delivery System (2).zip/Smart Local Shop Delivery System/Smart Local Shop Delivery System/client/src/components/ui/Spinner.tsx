import React from 'react';

interface SpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  color?: string;
}

const Spinner: React.FC<SpinnerProps> = ({
  size = 'md',
  className = '',
  color = 'currentColor'
}) => {
  const sizeClasses = {
    sm: 'h-4 w-4',
    md: 'h-8 w-8',
    lg: 'h-12 w-12'
  };

  const thicknessMap = {
    sm: 2,
    md: 3,
    lg: 3
  };

  const thickness = thicknessMap[size];

  // Large spinner always green, smaller ones inherit color
  const spinnerColor = size === 'lg' ? '#16a34a' : color;

  const spinnerElement = (
    <div
      className={`${sizeClasses[size]} rounded-full animate-spin ${className}`}
      style={{
        color: spinnerColor,
        background: `conic-gradient(${spinnerColor} 0% 79%, transparent 25% 100%)`,
        WebkitMask: `radial-gradient(farthest-side, transparent calc(100% - ${thickness}px), black 0)`,
        mask: `radial-gradient(farthest-side, transparent calc(100% - ${thickness}px), black 0)`,
      }}
    />
  );

  // Center large spinner on full screen
  if (size === 'lg') {
    return (
      <div className="fixed inset-0 flex items-center justify-center z-50">
        {spinnerElement}
      </div>
    );
  }

  return spinnerElement;
};

export default Spinner;