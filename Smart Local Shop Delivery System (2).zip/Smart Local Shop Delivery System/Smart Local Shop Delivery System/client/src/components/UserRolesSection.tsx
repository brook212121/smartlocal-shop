import { Link } from 'react-router-dom';
import { User, Store, Truck as DeliveryIcon } from 'lucide-react';

const UserRolesSection = () => {
  const roles = [
    {
      icon: User,
      title: "Customer",
      description: "Browse products from local shops, place orders, track deliveries, and enjoy secure payment options with AI-verified authentic products.",
      benefits: [
        "Wide selection of local products",
        "Real-time order tracking",
        "Secure payment methods",
        "AI product verification"
      ]
    },
    {
      icon: Store,
      title: "Vendor",
      description: "Showcase your products to local customers, manage orders efficiently, and grow your business with our delivery network.",
      benefits: [
        "Increased customer reach",
        "Order management tools",
        "Delivery coordination",
        "Business analytics"
      ]
    },
    {
      icon: DeliveryIcon,
      title: "Delivery Agent",
      description: "Join our delivery network, earn flexible income, and help connect local businesses with customers in your community.",
      benefits: [
        "Flexible work schedule",
        "Competitive earnings",
        "Route optimization",
        "Community impact"
      ]
    }
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Join Our Community
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Whether you're a customer, vendor, or delivery agent, there's a place for you in our ecosystem
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {roles.map((role, index) => (
            <div 
              key={index}
              className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow duration-300 border border-gray-100"
            >
              <div className="w-16 h-16 bg-green-100 rounded-lg flex items-center justify-center mb-6">
                <role.icon className="w-8 h-8 text-green-600" />
              </div>
              
              <h3 className="text-2xl font-semibold text-gray-900 mb-4">
                {role.title}
              </h3>
              
              <p className="text-gray-600 leading-relaxed mb-6">
                {role.description}
              </p>
              
              <ul className="space-y-3">
                {role.benefits.map((benefit, benefitIndex) => (
                  <li key={benefitIndex} className="flex items-start">
                    <div className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 text-sm">{benefit}</span>
                  </li>
                ))}
              </ul>
              
              <Link 
                to="/register" 
                className="mt-6 w-full bg-green-600 hover:bg-green-700 text-white font-medium py-3 px-6 rounded-lg transition-colors duration-200 inline-block text-center"
              >
                Join as {role.title}
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default UserRolesSection;
