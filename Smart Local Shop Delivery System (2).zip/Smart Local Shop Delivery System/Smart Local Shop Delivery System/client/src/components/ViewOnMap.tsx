import React, { useState, useEffect, useCallback } from 'react';
import { GoogleMap, useJsApiLoader, Marker, DirectionsRenderer } from '@react-google-maps/api';
import Spinner from '../components/ui/Spinner';

// Static libraries array to prevent re-renders
const GOOGLE_MAPS_LIBRARIES = ['geometry', 'places'];

interface ViewOnMapProps {
  userLocation: {
    latitude: number;
    longitude: number;
  };
  vendorLocation: {
    latitude: number;
    longitude: number;
  };
  vendorName: string;
  productName: string;
  distance?: number;
  onClose: () => void;
}

// Responsive map container style
const mapContainerStyle: React.CSSProperties = {
  width: '100%',
  height: '100%',
  minHeight: '400px',
  borderRadius: '0 0 0.75rem 0.75rem',
  overflow: 'hidden'
};

const ViewOnMap: React.FC<ViewOnMapProps> = ({
  userLocation,
  vendorLocation,
  vendorName,
  productName,
  distance,
  onClose
}) => {
  const [directions, setDirections] = useState<google.maps.DirectionsResult | null>(null);
  const [mapCenter, setMapCenter] = useState<google.maps.LatLngLiteral | null>(null);
  const [mapZoom, setMapZoom] = useState(15);

  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY || import.meta.env.REACT_APP_GOOGLE_MAPS_API_KEY || '',
    libraries: GOOGLE_MAPS_LIBRARIES
  });

  const calculateRoute = useCallback(async () => {
    if (!isLoaded || !userLocation || !vendorLocation) return;

    const directionsService = new google.maps.DirectionsService();

    try {
      const result = await directionsService.route({
        origin: {
          lat: userLocation.latitude,
          lng: userLocation.longitude
        },
        destination: {
          lat: vendorLocation.latitude,
          lng: vendorLocation.longitude
        },
        travelMode: google.maps.TravelMode.DRIVING
      });

      if (result.routes && result.routes.length > 0) {
        setDirections(result);
        
        // Calculate bounds to fit both markers and route
        const bounds = new google.maps.LatLngBounds();
        bounds.extend({ lat: userLocation.latitude, lng: userLocation.longitude });
        bounds.extend({ lat: vendorLocation.latitude, lng: vendorLocation.longitude });
        
        // Add route points to bounds
        if (result.routes[0] && result.routes[0].overview_path) {
          result.routes[0].overview_path.forEach(point => {
            bounds.extend(point);
          });
        }
        
        setMapCenter(bounds.getCenter().toJSON());
        setMapZoom(12); // Zoom out to show full route
      }
    } catch (error) {
      console.error("ViewOnMap Route Error:", error);
      // Map will gracefully fallback to showing just markers
    }
  }, [isLoaded, userLocation, vendorLocation]);

  // Initialize map center and calculate route when loaded
  useEffect(() => {
    if (isLoaded && userLocation && vendorLocation) {
      // Initial center between user and vendor
      const centerLat = (userLocation.latitude + vendorLocation.latitude) / 2;
      const centerLng = (userLocation.longitude + vendorLocation.longitude) / 2;
      
      setMapCenter({ lat: centerLat, lng: centerLng });
      calculateRoute();
    }
  }, [isLoaded, userLocation, vendorLocation, calculateRoute]);

  if (!isLoaded) {
    return (
      <div className="fixed inset-0 bg-white z-50 flex items-center justify-center">
        <div className="text-center">
          <Spinner size="lg" />
          <p className="text-gray-600 mt-4">Loading map...</p>
        </div>
      </div>
    );
  }

  if (!mapCenter) {
    return (
      <div className="fixed inset-0 bg-white z-50 flex items-center justify-center">
        <div className="text-center">
          <Spinner size="lg" />
          <p className="text-gray-600 mt-4">Initializing map...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-white z-50 flex flex-col">
      {/* Header - Responsive Design */}
      <div className="bg-gradient-to-r from-green-600 to-green-700 text-white p-4 shadow-lg relative">
        {/* Close Button - Top Right Corner */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 bg-white bg-opacity-20 hover:bg-opacity-30 text-white p-2 rounded-lg transition-all duration-200 backdrop-blur-sm border border-white border-opacity-20"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        {/* Product Info - Centered */}
        <div className="max-w-7xl mx-auto text-center pr-12">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-center gap-2 text-sm text-green-100">
            <span className="flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-store-icon lucide-store w-4 h-4 mr-1">
                <path d="M15 21v-5a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v5"/>
                <path d="M17.774 10.31a1.12 1.12 0 0 0-1.549 0 2.5 2.5 0 0 1-3.451 0 1.12 1.12 0 0 0-1.548 0 2.5 2.5 0 0 1-3.452 0 1.12 1.12 0 0 0-1.549 0 2.5 2.5 0 0 1-3.77-3.248l2.889-4.184A2 2 0 0 1 7 2h10a2 2 0 0 1 1.653.873l2.895 4.192a2.5 2.5 0 0 1-3.774 3.244"/>
                <path d="M4 10.95V19a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8.05"/>
              </svg>
              {vendorName}
            </span>
            {distance && (
              <span className="bg-white bg-opacity-20 px-3 py-1 rounded-full text-xs font-semibold backdrop-blur-sm border border-white border-opacity-20">
                {distance < 1000 ? `${Math.round(distance)}m` : `${(distance / 1000).toFixed(1)}km`}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Map Container - Responsive */}
      <div className="flex-1 relative bg-gray-100">
        {/* Loading Overlay */}
        {!isLoaded && (
          <div className="absolute inset-0 bg-white bg-opacity-90 flex items-center justify-center z-10">
            <div className="text-center">
              <div className="animate-spin rounded-full h-16 w-16 border-4 border-blue-600 border-t-transparent mx-auto mb-4"></div>
              <p className="text-gray-700 font-medium">Loading map...</p>
            </div>
          </div>
        )}
        
        {/* Map */}
        <GoogleMap
          mapContainerStyle={mapContainerStyle}
          center={mapCenter}
          zoom={mapZoom}
          options={{
            zoomControl: true,
            streetViewControl: true,
            mapTypeControl: true,
            fullscreenControl: false,
            gestureHandling: 'cooperative',
            styles: [
              {
                featureType: 'poi',
                elementType: 'labels',
                stylers: [{ visibility: 'off' }]
              }
            ]
          }}
        >
          {/* User Location Marker */}
          <Marker
            position={{
              lat: userLocation.latitude,
              lng: userLocation.longitude
            }}
            icon={{
              url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="12" cy="12" r="8" fill="#3B82F6" stroke="#ffffff" strokeWidth="2"/>
                  <circle cx="12" cy="12" r="3" fill="#ffffff"/>
                </svg>
              `),
              scaledSize: new google.maps.Size(32, 32),
              anchor: new google.maps.Point(16, 16)
            }}
            title="Your Location"
          />

          {/* Vendor Location Marker */}
          <Marker
            position={{
              lat: vendorLocation?.latitude ?? 0,
              lng: vendorLocation?.longitude ?? 0
            }}
            icon={{
              url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" fill="#EF4444"/>
                </svg>
              `),
              scaledSize: new google.maps.Size(32, 32),
              anchor: new google.maps.Point(16, 32)
            }}
            title={`${vendorName} - ${productName}`}
          />

          {/* Directions */}
          {directions && (
            <DirectionsRenderer
              directions={directions}
              options={{
                suppressMarkers: true, // We use custom markers
                polylineOptions: {
                  strokeColor: '#3B82F6',
                  strokeWeight: 4,
                  strokeOpacity: 0.7
                }
              }}
            />
          )}
        </GoogleMap>

        {/* Distance and Time Info */}
        {directions && directions.routes[0] && directions.routes[0].legs[0] && (
          <div className="absolute bottom-4 left-4 bg-white rounded-lg shadow-lg p-4 max-w-xs">
            <h3 className="font-semibold text-gray-900 mb-2">Route Information</h3>
            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Distance:</span>
                <span className="font-medium">
                  {directions.routes[0].legs[0].distance?.text}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Duration:</span>
                <span className="font-medium">
                  {directions.routes[0].legs[0].duration?.text}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">From:</span>
                <span className="font-medium">Your Location</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">To:</span>
                <span className="font-medium">{vendorName}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ViewOnMap;
