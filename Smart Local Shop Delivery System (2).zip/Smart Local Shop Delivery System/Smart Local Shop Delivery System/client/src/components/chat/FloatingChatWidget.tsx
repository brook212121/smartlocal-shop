import { useState, useRef, useEffect } from 'react';
import { Bell, X, MessageCircle, Send } from 'lucide-react';
import api from '../../services/api';

interface FloatingChatWidgetProps {
  vendorId: string;
  vendorName: string;
  activeChatUser?: {
    id: string;
    name: string;
  } | undefined;
}

const FloatingChatWidget = ({ vendorId, vendorName, activeChatUser }: FloatingChatWidgetProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Array<{
    id: string;
    text: string;
    sender: 'customer' | 'vendor';
    timestamp: Date;
  }>>([]);

  // Auto-open chat if activeChatUser is provided
  useEffect(() => {
    if (activeChatUser) {
      setIsOpen(true);
      loadConversation(activeChatUser.id);
    }
  }, [activeChatUser]);

  // Load conversation history
  const loadConversation = async (senderId: string) => {
    try {
      console.log('🔍 FloatingChatWidget: Loading conversation with sender:', senderId);
      const userStr = localStorage.getItem('user');
      if (userStr) {
        const user = JSON.parse(userStr);
        console.log('🔍 FloatingChatWidget: Current user:', user);
        const response = await api.get(`/messages/conversation/${user.id}/${senderId}`);
        console.log('🔍 FloatingChatWidget: Conversation API response:', response);
        
        if (response.data.success) {
          const conversationMessages = response.data.data.messages.map((msg: any) => ({
            id: msg._id,
            text: msg.message,
            sender: msg.senderId._id === user.id ? 'customer' : 'vendor',
            timestamp: new Date(msg.createdAt)
          }));
          
          console.log('🔍 FloatingChatWidget: Processed conversation messages:', conversationMessages);
          setMessages(conversationMessages);
          console.log('🔍 FloatingChatWidget: Messages state updated, count:', conversationMessages.length);
        } else {
          console.error('❌ FloatingChatWidget: Failed to load conversation:', response.data);
        }
      } else {
        console.log('❌ FloatingChatWidget: No user found in localStorage');
      }
    } catch (error) {
      console.error('❌ FloatingChatWidget: Error loading conversation:', error);
    }
  };

  const handleSendMessage = async () => {
    if (message.trim()) {
      try {
        console.log('🔍 FloatingChatWidget: Starting message send...');
        console.log('🔍 FloatingChatWidget: Message text:', message.trim());
        console.log('🔍 FloatingChatWidget: vendorId prop:', vendorId);
        console.log('🔍 FloatingChatWidget: vendorId type:', typeof vendorId);
        
        // Get current user from localStorage or auth context
        const userStr = localStorage.getItem('user');
        const user = userStr ? JSON.parse(userStr) : null;
        
        console.log('🔍 FloatingChatWidget: Current user:', user);
        
        if (!user) {
          console.error('❌ FloatingChatWidget: No user found for sending message');
          return;
        }

        // Ensure vendorId is a string
        const receiverId = typeof vendorId === 'string' ? vendorId : (vendorId as any)?.id || (vendorId as any)?._id || vendorId;
        console.log('🔍 FloatingChatWidget: Final receiverId:', receiverId);
        console.log('🔍 FloatingChatWidget: receiverId type:', typeof receiverId);

        const requestBody = {
          senderId: user.id,
          receiverId: receiverId,
          message: message.trim()
        };
        
        console.log('🔍 FloatingChatWidget: Request body:', requestBody);
        console.log('🔍 FloatingChatWidget: Sending POST request to /messages...');

        const response = await api.post('/messages', requestBody);
        
        console.log('🔍 FloatingChatWidget: Response received:', response);
        console.log('🔍 FloatingChatWidget: Response data:', response.data);

        if (response.data.success) {
          const newMessage = {
            id: response.data.data.message._id,
            text: response.data.data.message.message,
            sender: 'customer' as const,
            timestamp: new Date()
          };
          
          setMessages([...messages, newMessage]);
          setMessage('');
          console.log('✅ Message sent successfully');
        } else {
          console.error('❌ Failed to send message:', response.data.message);
        }
      } catch (error) {
        console.error('❌ Error sending message:', error);
      }
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <>
      {/* Floating Chat Icon */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-50 bg-green-600 hover:bg-green-700 text-white rounded-full p-4 shadow-lg transition-all duration-300 hover:scale-110"
        title="Chat with vendor"
      >
        <MessageCircle className="h-6 w-6" />
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 z-50 w-80 h-96 bg-white rounded-lg shadow-2xl flex flex-col border border-gray-200">
          {/* Header */}
          <div className="bg-green-600 text-white p-4 rounded-t-lg flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-lg">{vendorName}</h3>
              <p className="text-sm opacity-90">Chat with vendor</p>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="hover:bg-green-700 rounded-full p-1 transition-colors"
              title="Close chat"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 p-4 overflow-y-auto bg-gray-50">
            {messages.length === 0 ? (
              <div className="text-center text-gray-500 mt-8">
                <MessageCircle className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                <p className="text-sm">Start a conversation with {vendorName}</p>
                <p className="text-xs mt-1">They'll respond as soon as possible</p>
              </div>
            ) : (
              <div className="space-y-3">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.sender === 'customer' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-xs px-3 py-2 rounded-lg text-sm ${
                        msg.sender === 'customer'
                          ? 'bg-green-600 text-white'
                          : 'bg-gray-200 text-gray-800'
                      }`}
                    >
                      <p>{msg.text}</p>
                      <p className={`text-xs mt-1 ${
                        msg.sender === 'customer' ? 'text-green-100' : 'text-gray-500'
                      }`}>
                        {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Message Input */}
          <div className="p-4 border-t border-gray-200 bg-white rounded-b-lg">
            <div className="flex items-center space-x-2">
              <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type your message..."
                className="flex-1 px-3 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent text-sm"
              />
              <button
                onClick={handleSendMessage}
                disabled={!message.trim()}
                className="bg-green-600 hover:bg-green-700 disabled:bg-gray-300 text-white rounded-full p-2 transition-colors"
                title="Send message"
              >
                <Send className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default FloatingChatWidget;
