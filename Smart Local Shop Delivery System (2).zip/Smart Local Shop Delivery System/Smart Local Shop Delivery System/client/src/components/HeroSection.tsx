import { Link } from 'react-router-dom';
import { ArrowRight, Play, ShoppingBag } from 'lucide-react';

const HeroSection = () => {
  const scrollToHowItWorks = () => {
    const element = document.getElementById('how-it-works');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative bg-gradient-to-br from-green-50 to-white py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
            Connecting Local Shops to Your
            <span className="text-green-600"> Doorstep</span>
          </h1>
          <p className="text-xl sm:text-2xl text-gray-600 mb-10 max-w-3xl mx-auto">
            Experience fast, reliable delivery from trusted local vendors with AI-powered 
            product verification and seamless payment integration
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/register"
              className="bg-green-600 hover:bg-green-700 text-white font-semibold py-4 px-8 rounded-lg transition-colors duration-200 flex items-center justify-center gap-2"
            >
              <ShoppingBag className="w-5 h-5" />
              Get Started
            </Link>
            <Link
              to="/login"
              className="border-2 border-green-600 text-green-600 font-semibold py-4 px-8 rounded-lg hover:bg-green-50 hover:text-green-600 transition-colors duration-200 flex items-center justify-center gap-2"
            >
              <ArrowRight className="w-5 h-5" />
              Sign In
            </Link>
            <button
              onClick={scrollToHowItWorks}
              className="bg-white hover:bg-gray-50 text-green-600 font-semibold py-4 px-8 rounded-lg border-2 border-green-600 transition-colors duration-200 flex items-center justify-center"
            >
              <Play className="mr-2 w-5 h-5" />
              How It Works
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
