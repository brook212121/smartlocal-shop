import React, { useState, useEffect, useRef } from 'react';

interface VerticalPriceSliderProps {
  min: number;
  max: number;
  value: [number, number];
  onChange: (value: [number, number]) => void;
  className?: string;
}

const VerticalPriceSlider: React.FC<VerticalPriceSliderProps> = ({
  min,
  max,
  value,
  onChange,
  className = ''
}) => {
  const sliderRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState<'min' | 'max' | null>(null);

  const height = 300; // Fixed height for the slider
  const range = max - min;
  const minPercent = range > 0 ? ((max - value[1]) / range) * 100 : 0;
  const maxPercent = range > 0 ? ((max - value[0]) / range) * 100 : 100;

  const handleMouseDown = (handle: 'min' | 'max') => (e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(handle);
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!isDragging || !sliderRef.current) return;

    const rect = sliderRef.current.getBoundingClientRect();
    const y = rect.bottom - e.clientY; // Invert Y coordinate (top = max, bottom = min)
    const percent = Math.max(0, Math.min(100, (y / rect.height) * 100));
    const newValue = min + (percent / 100) * range;

    if (isDragging === 'min') {
      onChange([Math.min(newValue, value[1]), value[1]]);
    } else {
      onChange([value[0], Math.max(newValue, value[0])]);
    }
  };

  const handleMouseUp = () => {
    setIsDragging(null);
  };

  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, min, max, range]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-ET', {
      style: 'currency',
      currency: 'ETB',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(price);
  };

  return (
    <div className={`relative ${className}`}>
      {/* Price Display */}
      <div className="mb-4 text-center">
        <div className="text-sm font-medium text-gray-900 mb-2">Price</div>
        <div className="text-sm text-gray-600">
          {formatPrice(value[0])} – {value[1] === max ? `${formatPrice(value[1])}+` : formatPrice(value[1])}
        </div>
      </div>

      {/* Slider Container */}
      <div className="relative">
        {/* Track */}
        <div
          ref={sliderRef}
          className="relative w-2 bg-gray-200 rounded-full mx-auto"
          style={{ height: `${height}px` }}
        >
          {/* Active Range */}
          <div
            className="absolute left-0 right-0 bg-green-500 rounded-full"
            style={{
              top: `${minPercent}%`,
              height: `${maxPercent - minPercent}%`
            }}
          />

          {/* Min Handle (Bottom) */}
          <div
            className="absolute left-1/2 transform -translate-x-1/2 w-6 h-6 bg-white border-2 border-green-500 rounded-full cursor-pointer shadow-md hover:shadow-lg transition-shadow"
            style={{ bottom: `${minPercent}%` }}
            onMouseDown={handleMouseDown('min')}
          />

          {/* Max Handle (Top) */}
          <div
            className="absolute left-1/2 transform -translate-x-1/2 w-6 h-6 bg-white border-2 border-green-500 rounded-full cursor-pointer shadow-md hover:shadow-lg transition-shadow"
            style={{ top: `${maxPercent}%` }}
            onMouseDown={handleMouseDown('max')}
          />

          {/* Price Labels */}
          <div className="absolute -right-12 top-0 text-xs text-gray-500 whitespace-nowrap">
            {formatPrice(max)}
          </div>
          <div className="absolute -right-12 bottom-0 text-xs text-gray-500 whitespace-nowrap">
            {formatPrice(min)}
          </div>
        </div>
      </div>
    </div>
  );
};

export default VerticalPriceSlider;
