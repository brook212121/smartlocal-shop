import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

interface AdminProtectedRouteProps {
  children: React.ReactNode;
}

const AdminProtectedRoute: React.FC<AdminProtectedRouteProps> = ({ children }) => {
  const location = useLocation();
  
  // Use AuthContext instead of localStorage
  const { authState } = useAuth();
  
  console.log('🔍 AdminProtectedRoute: Auth state check:', {
    isAuthenticated: authState.isAuthenticated,
    userRole: authState.user?.role,
    user: authState.user?._id,
    isLoading: authState.isLoading,
    currentPath: location.pathname
  });
  
  // Show loading while auth is initializing
  if (authState.isLoading) {
    console.log('🔍 AdminProtectedRoute: Auth is loading, showing loading spinner');
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }
  
  // Check if user is authenticated and has ADMIN role
  if (!authState.isAuthenticated || authState.user?.role !== 'ADMIN') {
    console.log('🔍 AdminProtectedRoute: Access denied, redirecting to login');
    // Redirect to login with return URL
    return <Navigate to="/login" state={{ from: location }} replace />;
  }
  
  console.log('🔍 AdminProtectedRoute: Access granted, rendering admin content');
  return <>{children}</>;
};

export default AdminProtectedRoute;
