import React from 'react';
import { Link } from 'react-router-dom';
import { getImageUrl } from '../../utils/imageUtils';

interface Product {
  _id: string;
  name: string;
  price: number;
  description: string;
  category: string;
  images: string[];
  vendor: {
    _id: string;
    firstName: string;
    lastName: string;
  };
  stock?: {
    quantity: number;
  };
}

interface ProductCardProps {
  product: Product;
}

const ProductCard = React.memo(({ product }: ProductCardProps) => {
  const imageUrl = product.images?.length > 0 
    ? getImageUrl(product.images[0])
    : '/api/placeholder/300x200';

  return (
    <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden group">
      {/* Product Image */}
      <div className="relative h-48 overflow-hidden bg-gray-100">
        <img
          src={imageUrl}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          onError={(e) => {
            e.currentTarget.src = '/api/placeholder/300x200';
          }}
        />
      </div>

      {/* Product Info */}
      <div className="p-4">
        {/* Vendor Name */}
        <div className="flex items-center text-sm text-gray-500 mb-2">
          <span className="font-medium">
            {product.vendor.firstName} {product.vendor.lastName}
          </span>
        </div>

        {/* Product Name */}
        <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">
          {product.name}
        </h3>

        {/* Price */}
        <div className="flex items-center justify-between mb-3">
          <div className="text-2xl font-bold text-green-600">
            {product.price.toLocaleString()} birr
          </div>
        </div>

        {/* Category */}
        <div className="text-sm text-gray-500">
          Category: <span className="font-medium text-gray-700">{product.category}</span>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-4 pb-4">
        <Link
          to={`/products/${product._id}`}
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors duration-200 font-medium text-center"
        >
          View Details
        </Link>
      </div>
    </div>
  );
}, (prevProps, nextProps) => {
  // Custom comparison function for optimal re-rendering
  return (
    prevProps.product._id === nextProps.product._id &&
    prevProps.product.name === nextProps.product.name &&
    prevProps.product.price === nextProps.product.price &&
    prevProps.product.category === nextProps.product.category &&
    prevProps.product.images?.length === nextProps.product.images?.length
  );
});

export default ProductCard;
