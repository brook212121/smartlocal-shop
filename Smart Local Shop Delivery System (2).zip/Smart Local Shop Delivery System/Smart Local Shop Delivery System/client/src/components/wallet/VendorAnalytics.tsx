import React, { useEffect, useState } from 'react';
import { TrendingUp } from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer
} from 'recharts';

import { getApiUrl } from '../../utils/apiConfig';
import { useAuth } from '../../contexts/AuthContext';

interface Product {
  name: string;
  count: number;
}

interface WeeklyData {
  name: string;
  revenue: number;
}

interface AnalyticsData {
  weeklyTransactions: WeeklyData[];
  totalSalesOrders: number;
  totalPurchaseOrders: number;
  topProducts: Product[];
  leastProducts: Product[];
}

const VendorAnalytics: React.FC = () => {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);

  const { authState } = useAuth();
  const { token } = authState;

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    try {
      console.log('🔍 Fetching vendor analytics...');
      const res = await fetch(getApiUrl('/api/analytics/vendor'), {
        headers: {
          Authorization: `Bearer ${token}` 
        }
      });

      if (!res.ok) {
        console.error('❌ Analytics fetch failed:', res.status, res.statusText);
        setLoading(false);
        return;
      }

      const result = await res.json();
      console.log('✅ Analytics data received:', result.data);
      setData(result.data);
    } catch (err) {
      console.error('❌ Analytics error:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="bg-white shadow-lg rounded-lg p-6 border border-gray-200">
        <h2 className="text-xl font-bold mb-6 flex items-center">
          <TrendingUp className="mr-2" />
          Vendor Analytics
        </h2>
        <div className="flex items-center justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-gray-600">Loading analytics data...</span>
        </div>
      </div>
    );
  }
  
  if (!data) {
    console.log('❌ No analytics data available');
    return null;
  }

  console.log('🎯 Rendering VendorAnalytics with data:', data);
  return (
    <div className="bg-white shadow-lg rounded-lg p-6 border border-gray-200">
      <h2 className="text-xl font-bold mb-6 flex items-center">
        <TrendingUp className="mr-2" />
        Vendor Analytics
      </h2>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-3 gap-4 mb-6">
        <div className="p-4 bg-blue-50 rounded-lg">
          <p className="text-sm text-gray-600">Orders Received</p>
          <p className="text-xl font-bold">{data.totalSalesOrders}</p>
        </div>

        <div className="p-4 bg-green-50 rounded-lg">
          <p className="text-sm text-gray-600">Orders Purchased</p>
          <p className="text-xl font-bold">{data.totalPurchaseOrders}</p>
        </div>

        <div className="p-4 bg-purple-50 rounded-lg">
          <p className="text-sm text-gray-600">Total Weekly Revenue</p>
          <p className="text-xl font-bold">
            {data.weeklyTransactions.reduce((sum, item) => sum + item.revenue, 0)} ETB
          </p>
        </div>
      </div>

      {/* 🔥 LINE CHART */}
      <div className="mb-8">
        <p className="font-semibold mb-4">Weekly Revenue Trend</p>

        <ResponsiveContainer width="100%" height={250}>
          <LineChart data={data.weeklyTransactions}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />

            <Line
              type="monotone"
              dataKey="revenue"
              stroke="#3b82f6"
              strokeWidth={3}
              dot={{ r: 4 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default VendorAnalytics;
