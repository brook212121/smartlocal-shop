import React, { useState, useEffect } from 'react';
import VerticalPriceSlider from './VerticalPriceSlider';

interface PriceFilterProps {
  searchQuery?: string;
  category?: string;
  onPriceChange: (minPrice: number, maxPrice: number) => void;
}

const PriceFilter: React.FC<PriceFilterProps> = ({
  searchQuery,
  category,
  onPriceChange
}) => {
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 0]);
  const [currentRange, setCurrentRange] = useState<[number, number]>([0, 0]);
  const [loading, setLoading] = useState(true);

  // Fetch price range from API
  useEffect(() => {
    // Only fetch price range if there's a specific search term
    if (searchQuery && searchQuery.trim()) {
      fetchPriceRange();
    } else {
      // Reset price range if no search term
      setPriceRange([0, 0]);
      setCurrentRange([0, 0]);
      onPriceChange(0, 0);
    }
  }, [searchQuery, category]);

  const fetchPriceRange = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (searchQuery) params.append('search', searchQuery);
      if (category && category !== 'all') params.append('category', category);
      
      const response = await fetch(`/api/products/public?${params.toString()}&limit=1`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      const data = await response.json();
      
      if (data.success && data.data.priceRange) {
        const { minPrice, maxPrice } = data.data.priceRange;
        setPriceRange([minPrice, maxPrice]);
        setCurrentRange([minPrice, maxPrice]);
        onPriceChange(minPrice, maxPrice);
      }
    } catch (error) {
      console.error('Error fetching price range:', error);
    } finally {
      setLoading(false);
    }
  };

  const handlePriceChange = (newRange: [number, number]) => {
    setCurrentRange(newRange);
    onPriceChange(newRange[0], newRange[1]);
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-ET', {
      style: 'currency',
      currency: 'ETB',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(price);
  };

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-md p-4 w-64">
        <div className="animate-pulse">
          <div className="h-4 bg-gray-200 rounded mb-4"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  // Don't show price filter if no search term or no price range
  if (!searchQuery || !searchQuery.trim() || (priceRange[0] === 0 && priceRange[1] === 0)) {
    return null;
  }

  return (
    <div className="bg-white rounded-lg shadow-xl p-4 w-64 border border-gray-100">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Filter by Price</h3>
      
      <VerticalPriceSlider
        min={priceRange[0]}
        max={priceRange[1]}
        value={currentRange}
        onChange={handlePriceChange}
      />

      <div className="mt-4 pt-4 border-t border-gray-200">
        <div className="text-xs text-gray-500 text-center">
          Range: {formatPrice(currentRange[0])} – {currentRange[1] === priceRange[1] ? `${formatPrice(currentRange[1])}+` : formatPrice(currentRange[1])}
        </div>
      </div>
    </div>
  );
};

export default PriceFilter;
