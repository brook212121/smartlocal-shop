import React from 'react';
import { Link, useLocation } from 'react-router-dom';

interface SidebarItemProps {
  icon: string;
  label: string;
  to: string;
  onClick?: () => void;
  showLabel?: boolean;
}

const SidebarItem: React.FC<SidebarItemProps> = ({ icon, label, to, onClick, showLabel = true }) => {
  const location = useLocation();
  const isActive = location.pathname === to;

  const handleClick = () => {
    if (onClick) {
      onClick();
    }
  };

  const content = (
    <div
      className={`flex items-center gap-3 px-3 py-3 text-base font-medium rounded-md transition-all duration-200 ${
        isActive
          ? 'bg-green-700 text-white shadow-sm'
          : 'text-green-100 hover:bg-green-600 hover:text-white'
      }`}
      onClick={handleClick}
    >
      <span className="material-icons font-normal">{icon}</span>
      {showLabel && <span className="truncate">{label}</span>}
    </div>
  );

  if (to) {
    return <Link to={to}>{content}</Link>;
  }

  return content;
};

export default SidebarItem;
