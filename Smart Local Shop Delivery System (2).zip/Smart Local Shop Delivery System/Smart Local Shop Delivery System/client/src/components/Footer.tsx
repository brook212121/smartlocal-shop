import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Home, 
  Package, 
  ClipboardList, 
  Mail, 
  Phone, 
  MapPin, 
  Facebook, 
  Twitter, 
  Instagram 
} from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-gray-300 py-10 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          
          {/* Brand Section */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3 mb-4">
              <img 
                src="/logo.svg" 
                alt="Smart Local Shop Delivery" 
                className="w-8 h-8"
              />
              <h3 className="text-xl font-bold text-white">
                Smart Local Shop Delivery
              </h3>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              Fast and reliable local delivery service
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-white mb-4">Quick Links</h4>
            <div className="space-y-2">
              <Link 
                to="/" 
                className="text-gray-300 hover:text-white transition-colors duration-200 flex items-center space-x-2"
              >
                <Home className="w-4 h-4" />
                <span>Home</span>
              </Link>
              <Link 
                to="/products" 
                className="text-gray-300 hover:text-white transition-colors duration-200 flex items-center space-x-2"
              >
                <Package className="w-4 h-4" />
                <span>Shopping</span>
              </Link>
              <Link 
                to="/orders" 
                className="text-gray-300 hover:text-white transition-colors duration-200 flex items-center space-x-2"
              >
                <ClipboardList className="w-4 h-4" />
                <span>Orders</span>
              </Link>
              <Link 
                to="/my-products" 
                className="text-gray-300 hover:text-white transition-colors duration-200 flex items-center space-x-2"
              >
                <Package className="w-4 h-4" />
                <span>My Products</span>
              </Link>
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-white mb-4">Contact Info</h4>
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4 text-green-500" />
                <a 
                  href="mailto:support@smartshop.com" 
                  className="text-gray-300 hover:text-white transition-colors duration-200"
                >
                  support@smartshop.com
                </a>
              </div>
              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4 text-green-500" />
                <span className="text-gray-300">+251 123 4567</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="w-4 h-4 text-green-500" />
                <span className="text-gray-300">Ethiopia</span>
              </div>
            </div>
          </div>

          {/* Social Links */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-white mb-4">Follow Us</h4>
            <div className="flex space-x-4">
              <a 
                href="https://facebook.com/smartshop" 
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gray-800 hover:bg-gray-700 rounded-full flex items-center justify-center transition-colors duration-200"
              >
                <Facebook className="w-5 h-5 text-white" />
              </a>
              <a 
                href="https://twitter.com/smartshop" 
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gray-800 hover:bg-gray-700 rounded-full flex items-center justify-center transition-colors duration-200"
              >
                <Twitter className="w-5 h-5 text-white" />
              </a>
              <a 
                href="https://instagram.com/smartshop" 
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gray-800 hover:bg-gray-700 rounded-full flex items-center justify-center transition-colors duration-200"
              >
                <Instagram className="w-5 h-5 text-white" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-800 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2026 Smart Local Shop Delivery. All rights reserved.
            </p>
            <div className="flex items-center space-x-4 mt-4 md:mt-0">
              <span className="text-gray-400 text-sm">Made with ❤️ in Ethiopia</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
