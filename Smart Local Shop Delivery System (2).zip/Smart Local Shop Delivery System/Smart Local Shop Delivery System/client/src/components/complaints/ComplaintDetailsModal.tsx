import React, { useState, useEffect } from 'react';
import { X, Package, AlertTriangle, Image as ImageIcon } from 'lucide-react';
import vendorComplaintService from '../../services/vendorComplaintService';
import { VendorComplaint } from '../../services/vendorComplaintService';

interface ComplaintDetailsModalProps {
  complaintId: string;
  onClose: () => void;
}

const ComplaintDetailsModal: React.FC<ComplaintDetailsModalProps> = ({
  complaintId,
  onClose
}) => {
  const [complaint, setComplaint] = useState<VendorComplaint | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<'original' | 'delivery'>('original');

  useEffect(() => {
    const fetchComplaintDetails = async () => {
      try {
        setIsLoading(true);
        setError(null);
        const details = await vendorComplaintService.getComplaintDetails(complaintId);
        setComplaint(details);
      } catch (error) {
        console.error('Error fetching complaint details:', error);
        setError('Failed to load complaint details');
      } finally {
        setIsLoading(false);
      }
    };

    fetchComplaintDetails();
  }, [complaintId]);

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 80) return 'text-green-600 bg-green-100';
    if (confidence >= 60) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getConfidenceLabel = (confidence: number) => {
    if (confidence >= 80) return 'High Confidence';
    if (confidence >= 60) return 'Medium Confidence';
    return 'Low Confidence';
  };

  if (isLoading) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg p-4 w-full max-w-2xl mx-4">
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-green-600"></div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !complaint) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg p-4 w-full max-w-2xl mx-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-base font-semibold text-gray-900">Complaint Details</h3>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="text-center py-6">
            <AlertTriangle className="w-10 h-10 text-red-500 mx-auto mb-3" />
            <p className="text-sm text-gray-600">{error || 'Complaint not found'}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Package className="w-4 h-4 text-red-500" />
              <h3 className="text-base font-semibold text-gray-900">Complaint Details</h3>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="p-4">
          {/* Flexible Info Row */}
          <div className="flex flex-wrap gap-3 mb-4">
            <div className="bg-gray-50 rounded p-3 flex-shrink-0">
              <p className="text-xs text-gray-600">Product Name:</p>
              <p className="text-sm font-medium text-gray-900 truncate max-w-[150px]">{complaint.productName}</p>
            </div>
            <div className="bg-gray-50 rounded p-3 flex-shrink-0">
              <p className="text-xs text-gray-600">Date:</p>
              <p className="text-sm font-medium text-gray-900 whitespace-nowrap">
                {new Date(complaint.createdAt).toLocaleDateString('en-GB', { 
                  day: 'numeric', 
                  month: 'long', 
                  year: 'numeric' 
                })}
              </p>
            </div>
            <div className="bg-gray-50 rounded p-3 flex-grow min-w-[120px]">
              <p className="text-xs text-gray-600">Customer:</p>
              <p className="text-sm font-medium text-gray-900 truncate">
                {complaint.customerPhone && complaint.customerPhone !== 'Not provided' 
                  ? `${complaint.customerPhone} • ${complaint.customerName || 'Not provided'}`
                  : (complaint.customerName || 'Not provided')
                }
              </p>
            </div>
          </div>

          {/* Complaint Reason */}
          <div className="bg-yellow-50 border border-yellow-200 rounded p-3 mb-4">
            <p className="text-xs font-semibold text-yellow-800 mb-1">Complaint Reason</p>
            <p className="text-sm text-yellow-700">{complaint.rejectionMessage}</p>
          </div>

          {/* Side-by-Side Images */}
          <div className="mb-4">
            <p className="text-sm font-semibold text-gray-900 mb-2">Product Comparison</p>
            <div className="grid grid-cols-2 gap-3">
              {/* Original Product */}
              <div className="bg-gray-100 rounded p-2">
                <p className="text-xs font-medium text-gray-700 mb-2">Original Product</p>
                <div className="bg-white rounded border border-gray-200 p-2 min-h-[150px] flex items-center justify-center">
                  {complaint.originalProductImage ? (
                    <img
                      src={complaint.originalProductImage}
                      alt="Original Product"
                      className="max-w-full max-h-[120px] rounded object-contain"
                    />
                  ) : (
                    <div className="text-center">
                      <ImageIcon className="w-8 h-8 text-gray-400 mx-auto" />
                      <p className="text-xs text-gray-500 mt-1">No image</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Delivered Product */}
              <div className="bg-gray-100 rounded p-2">
                <p className="text-xs font-medium text-gray-700 mb-2">Delivered Product</p>
                <div className="bg-white rounded border border-gray-200 p-2 min-h-[150px] flex items-center justify-center">
                  {complaint.deliveryPhoto ? (
                    <img
                      src={complaint.deliveryPhoto}
                      alt="Delivered Product"
                      className="max-w-full max-h-[120px] rounded object-contain"
                    />
                  ) : (
                    <div className="text-center">
                      <ImageIcon className="w-8 h-8 text-gray-400 mx-auto" />
                      <p className="text-xs text-gray-500 mt-1">No image</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Notice */}
          <div className="bg-blue-50 border border-blue-200 rounded p-3">
            <div className="flex items-start space-x-2">
              <AlertTriangle className="w-4 h-4 text-blue-600 mt-0.5" />
              <div>
                <p className="text-xs font-semibold text-blue-800">Automated Processing</p>
                <p className="text-xs text-blue-700">
                  This complaint was processed automatically. Contact support with order ID if this is an error.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ComplaintDetailsModal;
