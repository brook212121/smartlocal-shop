import React, { useState, useEffect, useRef } from 'react';
import { Bell, Package, AlertTriangle, X } from 'lucide-react';
import vendorComplaintService from '../../services/vendorComplaintService';
import ComplaintDetailsModal from './ComplaintDetailsModal';
import { ComplaintNotification } from '../../services/vendorComplaintService';

interface VendorComplaintNotificationBellProps {
  className?: string;
}

const VendorComplaintNotificationBell: React.FC<VendorComplaintNotificationBellProps> = ({ 
  className = '' 
}) => {
  const [notifications, setNotifications] = useState<ComplaintNotification[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [selectedComplaint, setSelectedComplaint] = useState<string | null>(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const pollingIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Fetch notifications
  const fetchNotifications = async () => {
    try {
      setIsLoading(true);
      
      // Debug: Check if user is authenticated and is a vendor
      const authData = localStorage.getItem('authData');
      console.log('🔍 VendorComplaintNotificationBell: Auth data from localStorage:', authData ? 'exists' : 'none');
      
      if (authData) {
        try {
          const parsed = JSON.parse(authData);
          console.log('🔍 VendorComplaintNotificationBell: User role:', parsed.user?.role);
          console.log('🔍 VendorComplaintNotificationBell: User authenticated:', !!parsed.token);
          
          if (parsed.user?.role !== 'VENDOR') {
            console.log('🔍 VendorComplaintNotificationBell: User is not a vendor, skipping notifications');
            setNotifications([]);
            setIsLoading(false);
            return;
          }
        } catch (error) {
          console.error('🔍 VendorComplaintNotificationBell: Error parsing auth data:', error);
        }
      }
      
      const vendorNotifications = await vendorComplaintService.getUnreadComplaintNotifications();
      console.log('🔍 VendorComplaintNotificationBell: Fetched notifications:', vendorNotifications.length);
      setNotifications(vendorNotifications);
    } catch (error) {
      console.error('Error fetching complaint notifications:', error);
      // Don't show error to user, just log it
    } finally {
      setIsLoading(false);
    }
  };

  // Initial fetch and polling
  useEffect(() => {
    // Check if user is a vendor before setting up polling
    const authData = localStorage.getItem('authData');
    if (authData) {
      try {
        const parsed = JSON.parse(authData);
        if (parsed.user?.role === 'VENDOR') {
          fetchNotifications();
          pollingIntervalRef.current = setInterval(fetchNotifications, 60000);
        }
      } catch (error) {
        console.error('Error parsing auth data:', error);
      }
    }
    
    return () => {
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current);
      }
    };
  }, []);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Handle notification click - just open details, don't mark as read
  const handleNotificationClick = (notification: ComplaintNotification) => {
    setSelectedComplaint(notification.complaintId);
    setShowDetailsModal(true);
    setIsOpen(false);
    // Note: Not marking as read automatically - vendor can review anytime
  };

  // Manual mark as read for individual notification
  const handleMarkAsRead = async (notificationId: string, event: React.MouseEvent) => {
    event.stopPropagation(); // Prevent opening details
    
    try {
      await vendorComplaintService.markNotificationAsRead(notificationId);
      // Remove from local state
      setNotifications(prev => prev.filter(n => n._id !== notificationId));
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };

  // Mark all as read
  const handleMarkAllAsRead = async () => {
    try {
      await vendorComplaintService.markAllNotificationsAsRead();
      setNotifications([]);
    } catch (error) {
      console.error('Error marking all as read:', error);
    }
  };

  // Get notification icon based on action taken
  const getNotificationIcon = (actionTaken?: string) => {
    switch (actionTaken) {
      case 'warning':
        return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      case 'suspended':
        return <X className="w-4 h-4 text-red-500" />;
      case 'banned':
        return <X className="w-4 h-4 text-red-600" />;
      default:
        return <Package className="w-4 h-4 text-blue-500" />;
    }
  };

  // Get notification color based on action taken
  const getNotificationColor = (actionTaken?: string) => {
    switch (actionTaken) {
      case 'warning':
        return 'border-yellow-200 bg-yellow-50';
      case 'suspended':
        return 'border-red-200 bg-red-50';
      case 'banned':
        return 'border-red-300 bg-red-100';
      default:
        return 'border-gray-200 bg-white';
    }
  };

  const unreadCount = notifications.length;

  return (
    <>
      <div className="relative" ref={dropdownRef}>
        {/* Notification Bell */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={`relative p-2 text-gray-600 hover:text-gray-900 focus:outline-none ${className}`}
        >
          <div>
            <Bell className="w-5 h-5" />
          </div>
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 flex items-center justify-center min-w-[20px] h-5 text-xs font-bold text-white bg-red-500 rounded-full">
              {unreadCount > 99 ? '99+' : unreadCount}
            </span>
          )}
        </button>

        {/* Notification Dropdown */}
        {isOpen && (
          <div className="absolute right-0 mt-2 w-96 bg-white rounded-xl shadow-2xl border border-gray-100 z-50 max-h-96 overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 bg-gradient-to-r from-gray-50 to-gray-100 border-b border-gray-200">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                <h3 className="text-sm font-semibold text-gray-900">
                  Complaint Notifications
                </h3>
                {unreadCount > 0 && (
                  <span className="px-2 py-1 text-xs font-bold text-white bg-blue-600 rounded-full">
                    {unreadCount > 99 ? '99+' : unreadCount}
                  </span>
                )}
              </div>
              {unreadCount > 0 && (
                <button
                  onClick={handleMarkAllAsRead}
                  className="text-xs font-medium text-blue-600 hover:text-blue-800 hover:bg-blue-50 px-2 py-1 rounded-md"
                >
                  Mark all read
                </button>
              )}
            </div>

            {/* Notifications List */}
            <div className="max-h-80 overflow-y-auto">
              {isLoading ? (
                <div className="flex items-center justify-center py-12">
                  <div className="flex flex-col items-center space-y-3">
                    <div className="animate-spin rounded-full h-8 w-8 border-2 border-gray-300 border-t-blue-600"></div>
                    <p className="text-sm text-gray-500">Loading notifications...</p>
                  </div>
                </div>
              ) : notifications.length === 0 ? (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Package className="w-8 h-8 text-gray-400" />
                  </div>
                  <h4 className="text-sm font-medium text-gray-900 mb-1">No new complaints</h4>
                  <p className="text-xs text-gray-500">You're all caught up!</p>
                </div>
              ) : (
                <div className="divide-y divide-gray-100">
                  {notifications.map((notification) => (
                    <div
                      key={notification._id}
                      onClick={() => handleNotificationClick(notification)}
                      className={`group relative p-4 cursor-pointer ${
                        getNotificationColor(notification.actionTaken)
                      } hover:shadow-md hover:z-10`}
                    >
                      {/* Unread indicator */}
                      <div className="absolute top-4 right-4 w-2 h-2 bg-blue-500 rounded-full opacity-0 group-hover:opacity-100"></div>
                      
                      <div className="flex items-start space-x-4">
                        {/* Icon */}
                        <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${
                          notification.actionTaken === 'warning' ? 'bg-yellow-100' :
                          notification.actionTaken === 'suspended' ? 'bg-red-100' :
                          notification.actionTaken === 'banned' ? 'bg-red-200' :
                          'bg-blue-100'
                        }`}>
                          {getNotificationIcon(notification.actionTaken)}
                        </div>

                        {/* Content */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex-1">
                              <p className="text-sm font-semibold text-gray-900 leading-tight">
                                {notification.productName}
                              </p>
                            </div>
                            <span className="text-xs text-gray-400 whitespace-nowrap ml-2">
                              {new Date(notification.createdAt).toLocaleDateString('en-GB', { 
                                day: 'numeric', 
                                month: 'long', 
                                year: 'numeric' 
                              })}
                            </span>
                          </div>

                          {/* Complaint Reason */}
                          <p className="text-xs text-red-600 line-clamp-2 mb-3 leading-relaxed font-medium">
                            {notification.rejectionMessage}
                          </p>

                          {/* Action Badge */}
                          {notification.actionTaken && (
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${
                                  notification.actionTaken === 'warning' ? 'bg-yellow-100 text-yellow-800 border border-yellow-200' :
                                  notification.actionTaken === 'suspended' ? 'bg-red-100 text-red-800 border border-red-200' :
                                  notification.actionTaken === 'banned' ? 'bg-red-200 text-red-900 border border-red-300' :
                                  'bg-gray-100 text-gray-800 border border-gray-200'
                                }`}>
                                  {notification.actionTaken === 'warning' ? '⚠️ Warning' :
                                   notification.actionTaken === 'suspended' ? '🚫 Suspended' :
                                   notification.actionTaken === 'banned' ? '❌ Banned' :
                                   '📋 Filed'}
                                </span>
                                {notification.complaintCount && (
                                  <span className="text-xs text-gray-500 font-medium">
                                    {notification.complaintCount}/5
                                  </span>
                                )}
                              </div>
                              
                              {/* Confidence Badge */}
                              <div className="flex items-center space-x-1">
                                <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                                  notification.confidence >= 80 ? 'bg-green-100 text-green-700' :
                                  notification.confidence >= 60 ? 'bg-yellow-100 text-yellow-700' :
                                  'bg-red-100 text-red-700'
                                }`}>
                                  {notification.confidence}% confidence
                                </span>
                              </div>
                            </div>
                          )}

                          {/* Customer Info */}
                          {(notification.customerName !== 'Not provided' || notification.customerPhone !== 'Not provided') && (
                            <div className="mt-3 pt-3 border-t border-gray-200">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-2 text-xs text-gray-500">
                                  <div className="w-4 h-4 bg-gray-200 rounded-full flex items-center justify-center">
                                    <span className="text-gray-600 text-[8px]">👤</span>
                                  </div>
                                  <span>
                                    {notification.customerName !== 'Not provided' ? notification.customerName : 'Customer'}
                                    {notification.customerPhone !== 'Not provided' && ` • ${notification.customerPhone}`}
                                  </span>
                                </div>
                                
                                {/* Manual Mark as Read Button */}
                                <button
                                  onClick={(e) => handleMarkAsRead(notification._id, e)}
                                  className="text-xs text-gray-400 hover:text-gray-600 hover:bg-gray-100 px-2 py-1 rounded-md"
                                  title="Mark as read"
                                >
                                  ✓ Read
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            {notifications.length > 0 && (
              <div className="px-4 py-3 bg-gray-50 border-t border-gray-200">
                <button
                  onClick={() => setIsOpen(false)}
                  className="w-full text-center text-xs font-medium text-gray-600 hover:text-gray-800"
                >
                  Close notifications
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Complaint Details Modal */}
      {showDetailsModal && selectedComplaint && (
        <ComplaintDetailsModal
          complaintId={selectedComplaint}
          onClose={() => {
            setShowDetailsModal(false);
            setSelectedComplaint(null);
          }}
        />
      )}
    </>
  );
};

export default VendorComplaintNotificationBell;
