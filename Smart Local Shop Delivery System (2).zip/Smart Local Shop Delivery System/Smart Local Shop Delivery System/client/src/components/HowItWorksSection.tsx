import React from 'react';
import { Search, Package, Truck, CheckCircle, ArrowRight } from 'lucide-react';

const HowItWorksSection = () => {
  const steps = [
    {
      icon: Search,
      title: "Browse Local Shops",
      description: "Explore products from verified local vendors in your area. Filter by category, price, and location.",
      color: "blue"
    },
    {
      icon: Package,
      title: "Place Order",
      description: "Add items to cart and checkout securely. Choose delivery time that works for you.",
      color: "green"
    },
    {
      icon: Truck,
      title: "Track Delivery",
      description: "Monitor your order in real-time. Get notified when your delivery is on the way.",
      color: "orange"
    }
  ];

  const getColorClasses = (color: string) => {
    const colorMap = {
      blue: "bg-blue-100 text-blue-600",
      green: "bg-green-100 text-green-600", 
      orange: "bg-orange-100 text-orange-600"
    };
    return colorMap[color as keyof typeof colorMap] || "bg-gray-100 text-gray-600";
  };

  return (
    <section id="how-it-works" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            How It Works
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Simple steps to get your local products delivered to your doorstep
          </p>
        </div>
        
        {/* Desktop Layout */}
        <div className="hidden lg:block">
          <div className="flex items-center justify-center space-x-8">
            {steps.map((step, index) => (
              <React.Fragment key={index}>
                <div className="flex-1 text-center max-w-sm">
                  {/* Icon */}
                  <div className={`w-20 h-20 ${getColorClasses(step.color)} rounded-xl flex items-center justify-center mx-auto mb-6 shadow-sm`}>
                    <step.icon className="w-10 h-10" />
                  </div>
                  
                  {/* Content */}
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">
                    {step.title}
                  </h3>
                  
                  <p className="text-gray-600 leading-relaxed">
                    {step.description}
                  </p>
                </div>
                
                {/* Arrow between steps */}
                {index < steps.length - 1 && (
                  <ArrowRight className="w-8 h-8 text-green-600 flex-shrink-0" />
                )}
              </React.Fragment>
            ))}
          </div>
        </div>
        
        {/* Mobile Layout */}
        <div className="lg:hidden space-y-8">
          {steps.map((step, index) => (
            <div key={index} className="flex items-start space-x-4">
              {/* Content */}
              <div className="flex-1">
                {/* Icon */}
                <div className={`w-16 h-16 ${getColorClasses(step.color)} rounded-lg flex items-center justify-center mb-4`}>
                  <step.icon className="w-8 h-8" />
                </div>
                
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {step.title}
                </h3>
                
                <p className="text-gray-600 leading-relaxed">
                  {step.description}
                </p>
              </div>
              
              {/* Arrow for mobile */}
              {index < steps.length - 1 && (
                <div className="flex-shrink-0 flex items-center pt-8">
                  <ArrowRight className="w-6 h-6 text-green-600" />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;
