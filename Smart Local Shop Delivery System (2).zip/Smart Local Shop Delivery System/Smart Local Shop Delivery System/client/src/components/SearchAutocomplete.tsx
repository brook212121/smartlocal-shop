import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { Search, X } from 'lucide-react';

// Generic types for autocomplete
interface AutocompleteItem {
  _id: string;
  [key: string]: any;
}

interface SearchAutocompleteProps<T extends AutocompleteItem> {
  items: T[];
  searchKeys: (keyof T)[];
  placeholder?: string;
  onSelect: (item: T) => void;
  onSearch?: (term: string) => void;
  value?: string;
  className?: string;
  inputClassName?: string;
  dropdownClassName?: string;
  disabled?: boolean;
}

const SearchAutocomplete = <T extends AutocompleteItem>({
  items,
  searchKeys,
  placeholder = 'Search...',
  onSelect,
  onSearch,
  value = '',
  className = '',
  inputClassName = '',
  dropdownClassName = '',
  disabled = false
}: SearchAutocompleteProps<T>) => {
  const [inputValue, setInputValue] = useState(value);
  const [isOpen, setIsOpen] = useState(false);
  const [highlightedIndex, setHighlightedIndex] = useState(-1);
  const [searchTerm, setSearchTerm] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const debounceTimerRef = useRef<NodeJS.Timeout>();

  // Memoized filtered items with optimized search
  const filteredItems = useMemo(() => {
    if (!searchTerm.trim()) {
      return [];
    }

    const searchLower = searchTerm.toLowerCase();
    
    // Optimized filtering with limit
    return items.filter(item => {
      return searchKeys.some(key => {
        const itemValue = item[key];
        return itemValue && itemValue.toString().toLowerCase().includes(searchLower);
      });
    }).slice(0, 10); // Limit to top 10 results for performance
  }, [items, searchKeys, searchTerm]);

  // Debounced search handler
  const debouncedSearch = useCallback((term: string) => {
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    
    debounceTimerRef.current = setTimeout(() => {
      setSearchTerm(term);
      setIsOpen(term.trim().length > 0);
      
      // Call onSearch if provided
      if (onSearch) {
        onSearch(term);
      }
    }, 300); // 300ms debounce delay
  }, [onSearch]);

  // Handle input change with debouncing
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setInputValue(newValue);
    debouncedSearch(newValue);
    setHighlightedIndex(-1);
  };

  // Handle item selection
  const handleSelectItem = (item: T) => {
    setInputValue(item[searchKeys[0]]?.toString() || '');
    setIsOpen(false);
    setHighlightedIndex(-1);
    onSelect(item);
  };

  // Cleanup debounce timer on unmount
  useEffect(() => {
    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
  }, []);

  // Handle keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!isOpen) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setHighlightedIndex(prev => 
          prev < filteredItems.length - 1 ? prev + 1 : 0
        );
        break;
      case 'ArrowUp':
        e.preventDefault();
        setHighlightedIndex(prev => 
          prev > 0 ? prev - 1 : filteredItems.length - 1
        );
        break;
      case 'Enter':
        e.preventDefault();
        if (highlightedIndex >= 0 && highlightedIndex < filteredItems.length) {
          handleSelectItem(filteredItems[highlightedIndex]);
        }
        break;
      case 'Escape':
        setIsOpen(false);
        setHighlightedIndex(-1);
        break;
    }
  };

  // Handle outside click
  const handleClickOutside = useCallback((event: MouseEvent) => {
    if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
      setIsOpen(false);
      setHighlightedIndex(-1);
    }
  }, []);

  // Add click outside listener
  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [handleClickOutside]);

  // Handle highlighted index changes
  useEffect(() => {
    if (highlightedIndex >= 0 && dropdownRef.current) {
      const highlightedElement = dropdownRef.current.querySelector(`[data-index="${highlightedIndex}"]`);
      if (highlightedElement) {
        highlightedElement.scrollIntoView({ block: 'nearest' });
      }
    }
  }, [highlightedIndex]);

  return (
    <div className={`relative ${className}`}>
      {/* Input */}
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          ref={inputRef}
          type="text"
          value={inputValue}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          onFocus={() => setIsOpen(true)}
          placeholder={placeholder}
          disabled={disabled}
          className={`w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm transition-colors duration-200 ${inputClassName}`}
        />
        {inputValue && (
          <button
            type="button"
            onClick={() => {
              setInputValue('');
              setSearchTerm('');
              setIsOpen(false);
              setHighlightedIndex(-1);
              
              // Call onSearch if provided
              if (onSearch) {
                onSearch('');
              }
            }}
            className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600 transition-colors duration-200"
            title="Clear search"
          >
            <X className="h-5 w-5" />
          </button>
        )}
      </div>

      {/* Dropdown */}
      {isOpen && filteredItems.length > 0 && (
        <div
          ref={dropdownRef}
          className={`absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-lg max-h-60 overflow-y-auto ${dropdownClassName}`}
        >
          {filteredItems.map((item, index) => {
            const isSelected = highlightedIndex === index;
            const displayText = item[searchKeys[0]]?.toString() || '';
            
            return (
              <div
                key={item._id}
                data-index={index}
                onClick={() => handleSelectItem(item)}
                className={`px-4 py-3 cursor-pointer transition-colors duration-200 ${
                  isSelected
                    ? 'bg-green-100 text-green-800'
                    : 'hover:bg-gray-100 text-gray-900'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className="flex-1">
                    <div className="text-sm font-medium text-gray-900">
                      {displayText}
                    </div>
                    {item.email && (
                      <div className="text-xs text-gray-500">
                        {item.email}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default SearchAutocomplete;
