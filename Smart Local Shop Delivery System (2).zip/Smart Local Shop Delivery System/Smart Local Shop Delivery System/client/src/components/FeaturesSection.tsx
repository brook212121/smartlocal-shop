import { 
  Package, 
  Shield, 
  Clock, 
  MapPin
} from 'lucide-react';

const FeaturesSection = () => {
  const features = [
    {
      icon: Package,
      title: "Wide Product Selection",
      description: "Browse through thousands of products from local shops in your area. From groceries to electronics, find everything you need."
    },
    {
      icon: Shield,
      title: "AI-Powered Verification",
      description: "Our advanced AI system verifies product authenticity, ensuring you receive genuine items from trusted vendors."
    },
    {
      icon: Clock,
      title: "Fast Delivery",
      description: "Quick and reliable delivery service with real-time tracking. Get your items delivered within hours."
    }
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Why Choose Smart Local Shop Delivery?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We connect you with trusted local vendors and ensure fast, secure delivery
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="p-8 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors duration-300"
            >
              <div className="w-16 h-16 bg-green-100 rounded-lg flex items-center justify-center mb-6">
                <feature.icon className="w-8 h-8 text-green-600" />
              </div>
              
              <h3 className="text-xl font-semibold text-gray-900 mb-4">
                {feature.title}
              </h3>
              
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
