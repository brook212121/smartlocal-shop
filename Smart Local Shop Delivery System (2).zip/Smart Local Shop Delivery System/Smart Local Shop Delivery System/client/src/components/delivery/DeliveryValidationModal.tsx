import React, { useState, useRef, useEffect } from 'react';
import { X, AlertCircle } from 'lucide-react';
import api from '../../services/api';
import Spinner from '../ui/Spinner';
import ComplaintModal from './ComplaintModal';

interface DeliveryValidationModalProps {
  isOpen: boolean;
  onClose: () => void;
  orderId: string;
  productName: string;
  productImage: string;
  initialValidationState?: {
    validated: boolean;
    validatedAt?: string;
    match?: boolean;
    confidence?: number;
    reason?: string;
    deliveryImage?: string;
  };
}

interface ValidationResult {
  match: boolean;
  confidence: number;
  message: string;
}

const DeliveryValidationModal: React.FC<DeliveryValidationModalProps> = ({
  isOpen,
  onClose,
  orderId,
  productName,
  productImage,
  initialValidationState
}) => {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [validationResult, setValidationResult] = useState<ValidationResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [cameraState, setCameraState] = useState<'idle' | 'preview' | 'captured'>('idle');
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [isCameraReady, setIsCameraReady] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isComplaintModalOpen, setIsComplaintModalOpen] = useState(false);
  const [orderVendorId, setOrderVendorId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Fetch order details to get vendorId
  useEffect(() => {
    const fetchOrderDetails = async () => {
      if (orderId) {
        try {
          const response = await api.get(`/orders/${orderId}`);
          if (response.data.success) {
            const orderData = response.data.data.order;
            // Use the correct vendor ID extraction as specified
            const vendorId = orderData.vendorId || orderData.vendor?._id;
            console.log('DEBUG: Order data:', orderData);
            console.log('DEBUG: Extracted vendorId:', vendorId);
            
            if (vendorId) {
              setOrderVendorId(vendorId);
            } else {
              console.error('Vendor ID not found in order response:', orderData);
            }
          }
        } catch (error) {
          console.error('Error fetching order details:', error);
        }
      }
    };

    fetchOrderDetails();
  }, [orderId]);

  // 🔒 Initialize validation state from props
  useEffect(() => {
    if (initialValidationState?.validated && initialValidationState.match !== undefined) {
      setValidationResult({
        match: initialValidationState.match,
        confidence: initialValidationState.confidence || 0,
        message: initialValidationState.reason || 'Already validated'
      });
    } else {
      setValidationResult(null);
    }
  }, [initialValidationState]);

  // ================= Upload =================
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Enhanced file type validation
    const validImageTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp', 'image/bmp'];
    if (!validImageTypes.includes(file.type)) {
      setError('Only image files (JPEG, PNG, GIF, WebP, BMP) are allowed');
      return;
    }

    // File size validation (max 10MB)
    const maxSize = 10 * 1024 * 1024; // 10MB in bytes
    if (file.size > maxSize) {
      setError('Image file size must be less than 10MB');
      return;
    }

    setIsUploading(true);
    setError(null);

    const reader = new FileReader();
    reader.onload = (ev) => {
      setUploadedImage(ev.target?.result as string);
      setIsUploading(false);
      setValidationResult(null);
    };
    reader.onerror = () => {
      setError('Failed to read image');
      setIsUploading(false);
    };

    reader.readAsDataURL(file);
  };

  // ================= Cleanup =================
  useEffect(() => {
    return () => {
      if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
      }
    };
  }, [cameraStream]);

  // ================= Camera =================
  const handleStartCamera = async () => {
    try {
      setError(null);
      setCameraState('preview');
      setIsCameraReady(false);

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false
      });

      setCameraStream(stream);

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          setIsCameraReady(true);
          videoRef.current?.play();
        };
      }
    } catch {
      setError('Unable to access camera');
      handleStopCamera();
    }
  };

  const handleCapturePhoto = () => {
    if (!videoRef.current || !cameraStream || !isCameraReady) {
      setError('Camera not ready');
      return;
    }

    const canvas = document.createElement('canvas');
    const video = videoRef.current;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0);

    const imageData = canvas.toDataURL('image/jpeg', 0.8);

    setCapturedImage(imageData);
    setValidationResult(null);
    setCameraState('captured');

    cameraStream.getTracks().forEach(track => track.stop());
    setCameraStream(null);
  };

  const handleStopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
    }

    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }

    setIsCameraReady(false);
    setCameraState('idle');
  };

  // ================= Validate =================
  const handleValidate = async () => {
    if (!uploadedImage) {
      setError('Please upload or capture an image');
      return;
    }

    setIsValidating(true);
    setError(null);

    try {
      const res = await api.post(`/delivery-validation/${orderId}/validate-delivery`, {
        uploadedDeliveryImage: uploadedImage
      });

      if (res.data.success) {
        const d = res.data.data;
        setValidationResult({
          match: d.match,
          confidence: d.confidence,
          message: d.message
        });
      } else {
        // 🔒 Handle already validated case
        if (res.data.alreadyValidated) {
          setError('This order has already been validated');
          // Set the previous validation result to show the user
          if (res.data.previousResult) {
            setValidationResult({
              match: res.data.previousResult.match,
              confidence: res.data.previousResult.confidence,
              message: res.data.previousResult.reason
            });
          }
        } else {
          setError(res.data.message || 'Validation failed');
        }
      }
    } catch (err: any) {
      // 🔒 Handle already validated case from error response
      if (err.response?.data?.alreadyValidated) {
        setError('This order has already been validated');
        if (err.response?.data?.previousResult) {
          setValidationResult({
            match: err.response.data.previousResult.match,
            confidence: err.response.data.previousResult.confidence,
            message: err.response.data.previousResult.reason
          });
        }
      } else {
        setError(err.response?.data?.message || 'Validation error');
      }
    } finally {
      setIsValidating(false);
    }
  };

  const handleClose = () => {
    handleStopCamera();
    setUploadedImage(null);
    setCapturedImage(null);
    setValidationResult(null);
    setError(null);
    setCameraState('idle');
    onClose();
  };

  if (!isOpen) return null;

  const resultStyles = validationResult?.match
    ? 'bg-green-50 border-green-200 text-green-800'
    : 'bg-red-50 border-red-200 text-red-800';

  return (
    <>
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-xl w-full max-w-3xl max-h-[90vh] overflow-y-auto">

          {/* Header */}
          <div className="flex justify-between items-center p-6 border-b">
            <h2 className="text-xl font-bold">Delivery Validation</h2>
            <button onClick={handleClose}><X /></button>
          </div>

          {/* Content */}
          <div className="p-6 space-y-6">

            {/* 🔒 ALREADY VALIDATED STATE */}
            {initialValidationState?.validated ? (
              <div className="text-center space-y-6">
                {/* Success Message */}
                <div className="bg-green-50 border border-green-200 rounded-xl p-6">
                  <div className="flex justify-center mb-4">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                      {/* Approved icon */}
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-green-800 mb-2">
                    Order Already Validated
                  </h3>
                  <p className="text-green-700">
                    This order has been successfully validated on {new Date(initialValidationState.validatedAt || '').toLocaleDateString()}
                  </p>
                  {initialValidationState.match && (
                    <div className="mt-3 text-sm text-green-600">
                      <span className="font-semibold">Result:</span> Approved with {initialValidationState.confidence}% confidence
                    </div>
                  )}
                  {!initialValidationState.match && (
                    <div className="mt-3 text-sm text-red-600">
                      <span className="font-semibold">Result:</span> Rejected - {initialValidationState.reason}
                    </div>
                  )}
                </div>

                {/* Side by Side Images */}
                <div className="flex flex-col md:flex-row gap-6">
                  {/* LEFT: PRODUCT */}
                  <div className="flex-1 text-left">
                    <h4 className="font-semibold mb-3 text-gray-700">Original Product</h4>
                    <div className="flex justify-center items-center h-64 bg-gray-50 rounded-lg border p-4">
                      <img
                        src={productImage}
                        className="max-w-full max-h-full object-contain"
                        alt="Original product"
                      />
                    </div>
                  </div>

                  {/* RIGHT: DELIVERY PROOF */}
                  <div className="flex-1 text-left">
                    <h4 className="font-semibold mb-3 text-gray-700">Delivery Proof</h4>
                    {initialValidationState.deliveryImage ? (
                      <div className="flex justify-center items-center h-64 bg-gray-50 rounded-lg border p-4">
                        <img
                          src={initialValidationState.deliveryImage}
                          className="max-w-full max-h-full object-contain"
                          alt="Delivery proof"
                        />
                      </div>
                    ) : (
                      <div className="flex justify-center items-center h-64 bg-gray-50 rounded-lg border p-4">
                        <p className="text-gray-500">Delivery proof image not available</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Close Button Only */}
                <div className="flex justify-center">
                  <button onClick={handleClose} className="bg-gray-600 text-white px-8 py-3 rounded-lg hover:bg-gray-700 transition-colors">
                    Close
                  </button>
                </div>
              </div>
            ) : (
              // Regular validation flow for non-validated orders
              <>
                {/* ✅ SIDE BY SIDE SECTION */}
                <div className="flex flex-col md:flex-row gap-6">

                  {/* LEFT: PRODUCT */}
                  <div className="flex-1 text-left">
                    <h3 className="font-semibold mb-3">Original Product</h3>
                    <div className="flex justify-center items-center h-64 bg-gray-50 rounded-lg border p-4">
                      <img
                        src={productImage}
                        className="max-w-full max-h-full object-contain"
                        alt="Original product"
                      />
                    </div>
                  </div>

                  {/* RIGHT: DELIVERY */}
                  <div className="flex-1 text-left">
                    <h3 className="font-semibold mb-3">Delivery Photo</h3>

                    {/* IDLE */}
                    {cameraState === 'idle' && !uploadedImage && !capturedImage && (
                      <>
                        <input ref={fileInputRef} type="file" accept="image/jpeg,image/jpg,image/png,image/gif,image/webp,image/bmp" className="hidden" onChange={handleImageUpload} />

                        <button onClick={() => fileInputRef.current?.click()} className="bg-blue-600 text-white px-4 py-2 rounded mr-2">
                          Upload
                        </button>

                        <button onClick={handleStartCamera} className="bg-gray-800 text-white px-4 py-2 rounded">
                          Camera
                        </button>
                      </>
                    )}

                    {/* PREVIEW */}
                    {cameraState === 'preview' && (
                      <>
                        <div className="flex justify-center items-center h-64 bg-gray-50 rounded-lg border overflow-hidden">
                          <video ref={videoRef} autoPlay className="max-w-full max-h-full object-contain" />
                        </div>

                        <div className="mt-3 space-x-2">
                          <button onClick={handleCapturePhoto} disabled={!isCameraReady} className="bg-blue-600 text-white px-4 py-2 rounded">
                            Capture
                          </button>

                          <button onClick={handleStopCamera} className="bg-gray-600 text-white px-4 py-2 rounded">
                            Cancel
                          </button>
                        </div>
                      </>
                    )}

                    {/* CAPTURED */}
                    {cameraState === 'captured' && capturedImage && (
                      <>
                        <div className="flex justify-center items-center h-64 bg-gray-50 rounded-lg border p-4">
                          <img src={capturedImage} className="max-w-full max-h-full object-contain" alt="Captured delivery photo" />
                        </div>

                        <div className="space-x-2">
                          <button onClick={handleStartCamera} className="bg-gray-600 text-white px-4 py-2 rounded">
                            Retake
                          </button>

                          <button
                            onClick={() => {
                              setUploadedImage(capturedImage);
                              setCameraState('idle');
                            }}
                            className="bg-blue-600 text-white px-4 py-2 rounded"
                          >
                            Use Photo
                          </button>
                        </div>
                      </>
                    )}

                    {/* UPLOADED */}
                    {uploadedImage && (
                      <div className="flex justify-center items-center h-64 bg-gray-50 rounded-lg border p-4">
                        <img src={uploadedImage} className="max-w-full max-h-full object-contain" alt="Uploaded delivery photo" />
                      </div>
                    )}
                  </div>
                </div>

                {/* Error */}
                {error && (
                  <div className="bg-red-50 border p-3 rounded flex gap-2">
                    <AlertCircle />
                    {error}
                  </div>
                )}

                {/* Result */}
                {validationResult && (
                  <div className={`p-4 border rounded text-center ${resultStyles}`}>
                    <h4 className="font-bold">
                      {validationResult.match ? 'Approved' : 'Rejected'}
                    </h4>
                    <p>{validationResult.confidence}%</p>
                    <p>{validationResult.message}</p>
                  </div>
                )}

                {/* Actions */}
                <div className="flex justify-center gap-3">
                  {/* 🔒 Show validation button only if not already validated */}
                  {!validationResult && !initialValidationState?.validated && (
                    <button onClick={handleValidate} disabled={!uploadedImage || isValidating} className="bg-green-600 text-white px-6 py-2 rounded">
                      {isValidating ? <Spinner size="sm" /> : 'Validate'}
                    </button>
                  )}

                  {/* 🔒 Show "Already Validated" button if order was validated before */}
                  {initialValidationState?.validated && !validationResult && (
                    <button disabled className="bg-gray-400 text-white px-6 py-2 rounded cursor-not-allowed">
                      {/* Already validated icon */}
                      Already Validated
                    </button>
                  )}

                  {/* Show complaint button only for rejected validations */}
                  {validationResult && !validationResult.match && (
                    <button
                      onClick={() => setIsComplaintModalOpen(true)}
                      className="bg-yellow-600 text-white px-6 py-2 rounded"
                    >
                      Make a Complaint
                    </button>
                  )}

                  <button onClick={handleClose} className="bg-gray-600 text-white px-6 py-2 rounded">
                    Close
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      <ComplaintModal
        isOpen={!!(validationResult && !validationResult.match && isComplaintModalOpen)}
        onClose={() => setIsComplaintModalOpen(false)}
        orderId={orderId}
        productName={productName}
        productImage={productImage}
        deliveryPhoto={uploadedImage}
        confidence={validationResult?.confidence || 0}
        rejectionMessage={validationResult?.message || ''}
        vendorId={orderVendorId || ''}
      />
    </>
  );
};

export default DeliveryValidationModal;