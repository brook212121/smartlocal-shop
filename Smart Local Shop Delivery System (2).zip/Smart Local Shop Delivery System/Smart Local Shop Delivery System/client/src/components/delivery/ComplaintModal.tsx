import React, { useState } from 'react';
import { X, AlertCircle } from 'lucide-react';
import api from '../../services/api';
import Spinner from '../ui/Spinner';
import { useAuth } from '../../contexts/AuthContext';

interface ComplaintModalProps {
  isOpen: boolean;
  onClose: () => void;
  orderId: string;
  productName: string;
  productImage: string;
  deliveryPhoto: string | null;
  confidence: number;
  rejectionMessage: string;
  vendorId: string;
}

const ComplaintModal: React.FC<ComplaintModalProps> = ({
  isOpen,
  onClose,
  orderId,
  productName,
  productImage,
  deliveryPhoto,
  confidence,
  rejectionMessage,
  vendorId
}) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState<{type: 'success' | 'error', text: string} | null>(null);
  const { authState } = useAuth();

  const handleSubmit = async () => {
    if (isSubmitting) return;

    setIsSubmitting(true);
    setMessage(null);

    try {
      // First, fetch order details to get actual customer information
      let orderCustomerInfo = {
        customerName: 'Not provided',
        customerPhone: 'Not provided'
      };

      try {
        const orderResponse = await api.get(`/orders/${orderId}`);
        console.log('DEBUG: Full order response:', orderResponse.data);
        
        const orderData = orderResponse.data.order; // Access nested order data
        console.log('DEBUG: Extracted order data:', orderData);
        
        // Check if customer data is populated
        if (orderData.customer) {
          console.log('DEBUG: Customer object found:', orderData.customer);
          console.log('DEBUG: Customer type:', typeof orderData.customer);
          console.log('DEBUG: Customer keys:', Object.keys(orderData.customer));
          console.log('DEBUG: Customer firstName:', orderData.customer.firstName);
          console.log('DEBUG: Customer lastName:', orderData.customer.lastName);
          console.log('DEBUG: Customer phone:', orderData.customer.phone);
          
          // Customer is populated from backend
          orderCustomerInfo = {
            customerName: orderData.customer.firstName && orderData.customer.lastName
              ? `${orderData.customer.firstName} ${orderData.customer.lastName}`
              : orderData.customer.firstName || 'Not provided',
            customerPhone: orderData.customer.phone || 'Not provided'
          };
        } else {
          console.log('DEBUG: No customer object found in order data');
        }
        
        console.log('DEBUG: Final order customer info:', orderCustomerInfo);
      } catch (orderError) {
        console.log('DEBUG: Could not fetch order details, using auth state fallback');
        console.log('DEBUG: Order error:', orderError);
        
        // Fallback to auth state if order fetch fails
        const userData = authState.user;
        console.log('DEBUG: Auth state user data:', userData);
        
        orderCustomerInfo = {
          customerName: userData?.firstName && userData?.lastName 
            ? `${userData.firstName} ${userData.lastName}` 
            : userData?.firstName || 'Not provided',
          customerPhone: userData?.phone || 'Not provided'
        };
        
        console.log('DEBUG: Fallback customer info:', orderCustomerInfo);
      }
      
      const complaintData = {
        orderId,
        productName,
        originalProductImage: productImage,
        deliveryPhoto: deliveryPhoto || '',
        vendorId,
        confidence,
        rejectionMessage,
        ...orderCustomerInfo // Use actual customer info from order
      };

      console.log('DEBUG: Final complaint data:', complaintData);

      const response = await api.post('/complain', complaintData);

      if (response.data.success) {
        let successMessage = 'Complaint processed successfully!';
        
        if (response.data.actionTaken === 'warning') {
          successMessage = `Warning issued to vendor (${response.data.complaintCount}/5). Vendor remains active.`;
        } else if (response.data.actionTaken === 'suspended') {
          successMessage = `Vendor suspended after ${response.data.complaintCount} verified complaints.`;
        } else if (response.data.actionTaken === 'banned') {
          successMessage = `Vendor banned after ${response.data.complaintCount} verified complaints.`;
        } else if (response.data.confidenceWarning) {
          successMessage = 'Complaint recorded. Low confidence - no action taken against vendor.';
        }
        
        setMessage({ type: 'success', text: successMessage });
        setTimeout(() => {
          onClose();
        }, 3000); // Longer delay to read the detailed message
      } else {
        setMessage({ type: 'error', text: response.data.message || 'Failed to send complaint' });
      }
    } catch (error: any) {
      console.error('Error sending complaint:', error);
      setMessage({ 
        type: 'error', 
        text: error.response?.data?.message || 'Network error. Please try again.' 
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black bg-opacity-50" onClick={onClose} />
      
      {/* Modal Content */}
      <div className="relative bg-white rounded-lg shadow-xl max-w-md w-full mx-4 p-6 z-10">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="mb-4">
          <div className="flex items-center mb-2">
            <AlertCircle className="w-6 h-6 text-yellow-600 mr-2" />
            <h3 className="text-lg font-semibold text-gray-900">Delivery Validation Issue</h3>
          </div>
          <p className="text-sm text-gray-600">
            If you believe this is an error, you can submit a complaint for automatic review.
          </p>
          <div className="mt-2 p-2 bg-blue-50 rounded text-xs text-blue-700">
            <p className="font-medium">Fair Vendor Protection:</p>
            <ul className="mt-1 space-y-1">
              <li>• 1-2 complaints: Warning only (vendor stays active)</li>
              <li>• 5 complaints: Automatic suspension</li>
              <li>• 10+ complaints: Permanent ban</li>
              <li>• Low confidence (&lt;70%) complaints don't count</li>
            </ul>
          </div>
        </div>

        {/* Message Display */}
        {message && (
          <div className={`mb-4 p-3 rounded-md ${
            message.type === 'success' 
              ? 'bg-green-50 text-green-800 border border-green-200' 
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}>
            <p className="text-sm font-medium">{message.text}</p>
          </div>
        )}

        {/* Submit Button */}
        <button
          onClick={handleSubmit}
          disabled={isSubmitting}
          className="w-full flex items-center justify-center px-4 py-3 border border-transparent text-sm font-medium rounded-md text-white bg-yellow-600 hover:bg-yellow-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {isSubmitting ? (
            <>
              <Spinner className="w-4 h-4 mr-2" />
              Processing complaint...
            </>
          ) : (
            'Submit for Automatic Review'
          )}
        </button>
      </div>
    </div>
  );
};

export default ComplaintModal;
