import React from 'react';
import Spinner from '../ui/Spinner';

interface LoadingProps {
  fullScreen?: boolean;
}

const Loading: React.FC<LoadingProps> = ({ fullScreen = false }) => {
  return (
    <div className={fullScreen ? "fixed inset-0 flex items-center justify-center bg-white z-50" : "p-6"}>
      <div className="flex items-center justify-center py-12">
        <Spinner size="lg" />
      </div>
    </div>
  );
};

export default Loading;
