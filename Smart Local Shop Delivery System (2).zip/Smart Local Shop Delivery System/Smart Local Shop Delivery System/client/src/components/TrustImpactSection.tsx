import { Link } from 'react-router-dom';
import { Heart, Briefcase, Shield, Users, TrendingUp, Award, Store } from 'lucide-react';

const TrustImpactSection = () => {
  const stats = [
    {
      icon: Store,
      value: "500+",
      label: "Local Shops Supported"
    },
    {
      icon: Users,
      value: "10,000+",
      label: "Happy Customers"
    },
    {
      icon: Briefcase,
      value: "200+",
      label: "Delivery Jobs Created"
    },
    {
      icon: Shield,
      value: "99.9%",
      label: "Secure Deliveries"
    }
  ];

  const impacts = [
    {
      icon: Heart,
      title: "Support Local Businesses",
      description: "We empower local shops by connecting them with more customers and providing tools to grow their business in digital age."
    },
    {
      icon: Briefcase,
      title: "Create Job Opportunities",
      description: "Our platform creates flexible employment opportunities for delivery agents, contributing to local economic growth and community development."
    },
    {
      icon: Shield,
      title: "Secure & Reliable System",
      description: "Built with security and reliability at our core, ensuring safe transactions, authentic products, and dependable delivery services."
    },
    {
      icon: TrendingUp,
      title: "Economic Growth",
      description: "Driving local economic growth by facilitating commerce between customers and businesses, creating a thriving local marketplace."
    }
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Trust & Community Impact
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Building a trusted ecosystem that benefits everyone in our community
          </p>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-20">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <stat.icon className="w-8 h-8 text-green-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-2">
                {stat.value}
              </div>
              <div className="text-gray-600">
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Impact Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {impacts.map((impact, index) => (
            <div 
              key={index}
              className="flex items-start space-x-4 p-6 bg-gray-50 rounded-lg"
            >
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <impact.icon className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  {impact.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {impact.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrustImpactSection;
