from typing import Dict, Any
from models import DeliveryPredictionRequest, DeliveryPredictionResponse

class DeliveryPredictor:
    def predict_delivery_time(self, request: DeliveryPredictionRequest) -> DeliveryPredictionResponse:
        """Predict delivery time based on various factors"""
        try:
            # Base delivery time calculation
            base_time = self._calculate_base_time(request.distance)
            
            # Apply modifiers based on conditions
            time_modifier = self._get_time_modifier(request.time_of_day)
            traffic_modifier = self._get_traffic_modifier(request.traffic_conditions)
            weather_modifier = self._get_weather_modifier(request.weather_conditions)
            vehicle_modifier = self._get_vehicle_modifier(request.vehicle_type)
            
            # Calculate final estimated time
            estimated_time = base_time * time_modifier * traffic_modifier * weather_modifier * vehicle_modifier
            
            # Calculate confidence score (placeholder logic)
            confidence = max(0.1, 1.0 - (abs(estimated_time - base_time) / 100))
            
            # Determine recommended route (placeholder)
            recommended_route = "fastest_route" if request.traffic_conditions in ["light", "moderate"] else "alternative_route"
            
            return DeliveryPredictionResponse(
                estimated_time_minutes=max(15, int(estimated_time)),
                confidence_score=confidence,
                recommended_route=recommended_route
            )
            
        except Exception as e:
            raise Exception(f"Error in delivery prediction: {str(e)}")

    def _calculate_base_time(self, distance: float) -> float:
        """Calculate base delivery time based on distance"""
        # Base formula: 5 minutes + 3 minutes per km
        return 5 + (distance * 3)

    def _get_time_modifier(self, time_of_day: str) -> float:
        """Get time-based modifier"""
        modifiers = {
            "morning": 1.0,      # Normal traffic
            "afternoon": 1.2,    # Rush hour
            "evening": 1.1,      # Moderate traffic
            "night": 0.9         # Light traffic
        }
        return modifiers.get(time_of_day, 1.0)

    def _get_traffic_modifier(self, traffic_conditions: str) -> float:
        """Get traffic-based modifier"""
        modifiers = {
            "light": 0.9,
            "moderate": 1.0,
            "heavy": 1.3,
            "congested": 1.5
        }
        return modifiers.get(traffic_conditions, 1.0)

    def _get_weather_modifier(self, weather_conditions: str) -> float:
        """Get weather-based modifier"""
        modifiers = {
            "clear": 1.0,
            "cloudy": 1.0,
            "rain": 1.2,
            "snow": 1.4,
            "fog": 1.3,
            "storm": 1.5
        }
        return modifiers.get(weather_conditions, 1.0)

    def _get_vehicle_modifier(self, vehicle_type: str) -> float:
        """Get vehicle-based modifier"""
        modifiers = {
            "motorcycle": 0.8,    # Fastest
            "car": 1.0,           # Standard
            "van": 1.1,           # Slower
            "truck": 1.3          # Slowest
        }
        return modifiers.get(vehicle_type, 1.0)
