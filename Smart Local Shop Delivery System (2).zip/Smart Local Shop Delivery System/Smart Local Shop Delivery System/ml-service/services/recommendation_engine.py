import math
from typing import List, Dict, Any, Optional
from collections import defaultdict
from database import db
from models import RecommendationResponse

class RecommendationEngine:
    def __init__(self):
        self.db = db

    def calculate_hybrid_recommendations(
        self, 
        user_id: str, 
        user_activities: List[Dict], 
        products: List[Dict], 
        location: Optional[Dict[str, float]]
    ) -> RecommendationResponse:
        """Hybrid recommendation algorithm combining collaborative, content-based, popularity, and distance"""
        
        # Extract user preferences from activities
        user_categories = [a["category"] for a in user_activities if "category" in a]
        user_products = [a["productId"] for a in user_activities if "productId" in a]
        viewed_products = [a["productId"] for a in user_activities if a["action"] == "view_product"]
        
        # Calculate scores for each product
        product_scores = {}
        
        for product in products:
            if product["id"] in user_products:
                continue  # Skip products user already interacted with
                
            score = 0.0
            
            # 1. Collaborative Score (30%)
            collaborative_score = self._calculate_collaborative_score(product, user_activities, products)
            score += 0.30 * collaborative_score
            
            # 2. Content Similarity (25%)
            content_score = self._calculate_content_similarity(product, user_categories, user_activities)
            score += 0.25 * content_score
            
            # 3. Popularity Score (20%)
            popularity_score = self._calculate_popularity_score(product, user_activities)
            score += 0.20 * popularity_score
            
            # 4. Distance Score (25%)
            distance_score = self._calculate_distance_score(product, location)
            score += 0.25 * distance_score
            
            product_scores[product["id"]] = score
        
        # Sort products by score
        sorted_products = sorted(product_scores.items(), key=lambda x: x[1], reverse=True)
        
        # Categorize recommendations
        recommended = [pid for pid, score in sorted_products[:5]]
        nearby = self._get_nearby_products(products, location, 7)
        trending = self._get_trending_products(products, 4)
        similar = self._get_similar_products(products, user_categories, 6)
        
        return RecommendationResponse(
            recommended=recommended,
            nearby=nearby,
            trending=trending,
            similar=similar
        )

    def _calculate_collaborative_score(self, product: Dict, activities: List[Dict], all_products: List[Dict]) -> float:
        """Collaborative filtering based on similar users"""
        # Simplified collaborative scoring
        product_category = product["category"]
        category_activities = [a for a in activities if a.get("category") == product_category]
        return min(1.0, len(category_activities) / 10.0)

    def _calculate_content_similarity(self, product: Dict, user_categories: List[str], activities: List[Dict]) -> float:
        """Content-based similarity based on product attributes"""
        if product["category"] in user_categories:
            return 0.8
        return 0.2

    def _calculate_popularity_score(self, product: Dict, activities: List[Dict]) -> float:
        """Popularity based on views, likes, and orders"""
        product_id = product["id"]
        
        # Filter activities that have productId field
        product_activities = [a for a in activities if "productId" in a]
        
        views = len([a for a in product_activities if a["productId"] == product_id and a["action"] == "view_product"])
        orders = len([a for a in product_activities if a["productId"] == product_id and a["action"] == "place_order"])
        likes = len([a for a in product_activities if a["productId"] == product_id and a["action"] == "like_product"])
        
        # Popularity formula: 0.6 * orders + 0.3 * views + 0.1 * likes
        score = (0.6 * orders + 0.3 * views + 0.1 * likes) / 10.0
        return min(1.0, score)

    def _calculate_distance_score(self, product: Dict, user_location: Optional[Dict[str, float]]) -> float:
        """Distance-based scoring"""
        if not user_location:
            return 0.5  # Neutral score if no location
        
        product_location = product.get("location")
        if not product_location:
            return 0.5  # Neutral score if no product location
        
        # Handle different location formats
        if isinstance(product_location, dict):
            if "coordinates" in product_location:
                # GeoJSON format: {"type": "Point", "coordinates": [lng, lat]}
                coords = product_location["coordinates"]
                if len(coords) >= 2:
                    product_lat = coords[1]  # GeoJSON is [lng, lat]
                    product_lng = coords[0]
                else:
                    return 0.5
            elif "lat" in product_location and "lng" in product_location:
                # Standard format: {"lat": ..., "lng": ...}
                product_lat = product_location["lat"]
                product_lng = product_location["lng"]
            else:
                return 0.5  # Unknown format
        else:
            return 0.5  # Not a dict
        
        # Simple distance calculation (in km)
        lat_diff = product_lat - user_location["lat"]
        lng_diff = product_lng - user_location["lng"]
        distance = math.sqrt(lat_diff**2 + lng_diff**2) * 111  # Approximate km per degree
        
        # Distance score: 1 / (1 + distance)
        return 1.0 / (1.0 + distance)

    def _get_nearby_products(self, products: List[Dict], location: Optional[Dict[str, float]], limit: int) -> List[str]:
        """Get products from nearby shops"""
        if not location:
            # If no location, return first products by ID
            return [p["id"] for p in products[:limit]]
        
        # Sort by distance and return closest
        products_with_distance = []
        for product in products:
            product_location = product.get("location")
            if not product_location:
                # Skip products without location or use default distance
                products_with_distance.append((product["id"], 1000.0))  # Very far
                continue
            
            # Handle different location formats
            try:
                if isinstance(product_location, dict):
                    if "coordinates" in product_location:
                        # GeoJSON format: {"type": "Point", "coordinates": [lng, lat]}
                        coords = product_location["coordinates"]
                        if len(coords) >= 2:
                            product_lat = coords[1]  # GeoJSON is [lng, lat]
                            product_lng = coords[0]
                        else:
                            products_with_distance.append((product["id"], 1000.0))
                            continue
                    elif "lat" in product_location and "lng" in product_location:
                        # Standard format: {"lat": ..., "lng": ...}
                        product_lat = product_location["lat"]
                        product_lng = product_location["lng"]
                    else:
                        products_with_distance.append((product["id"], 1000.0))
                        continue
                else:
                    products_with_distance.append((product["id"], 1000.0))
                    continue
                
                lat_diff = product_lat - location["lat"]
                lng_diff = product_lng - location["lng"]
                distance = math.sqrt(lat_diff**2 + lng_diff**2) * 111
                products_with_distance.append((product["id"], distance))
            except:
                products_with_distance.append((product["id"], 1000.0))
        
        products_with_distance.sort(key=lambda x: x[1])
        return [pid for pid, _ in products_with_distance[:limit]]

    def _get_trending_products(self, products: List[Dict], limit: int) -> List[str]:
        """Get trending products based on global activity data"""
        # Get all activities from database for trending calculations
        all_activities = self.db.get_all_activities(limit=1000)
        
        # Count recent activities per product
        product_counts = defaultdict(int)
        for activity in all_activities:
            if "productId" in activity:
                product_counts[activity["productId"]] += 1
        
        # Sort by count and return top trending
        trending = sorted(product_counts.items(), key=lambda x: x[1], reverse=True)
        return [pid for pid, _ in trending[:limit]]

    def _get_similar_products(self, products: List[Dict], user_categories: List[str], limit: int) -> List[str]:
        """Get products similar to user's preferred categories"""
        similar_products = [p for p in products if p["category"] in user_categories]
        # Return first similar products by ID
        return [p["id"] for p in similar_products[:limit]]
