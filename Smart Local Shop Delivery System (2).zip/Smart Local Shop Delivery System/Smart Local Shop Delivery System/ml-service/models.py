from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any

# Delivery Prediction Models
class DeliveryPredictionRequest(BaseModel):
    distance: float = Field(..., description="Distance in kilometers")
    traffic_conditions: str = Field(..., description="Current traffic conditions")
    weather_conditions: str = Field(..., description="Current weather conditions")
    time_of_day: str = Field(..., description="Time of day (morning, afternoon, evening, night)")
    vehicle_type: str = Field(..., description="Type of delivery vehicle")

class DeliveryPredictionResponse(BaseModel):
    estimated_time_minutes: int = Field(..., description="Estimated delivery time in minutes")
    confidence_score: float = Field(..., description="Confidence score of the prediction (0-1)")
    recommended_route: Optional[str] = Field(None, description="Recommended route for optimal delivery")

# Legacy Product Recommendation Models (keeping for compatibility)
class ProductRecommendationRequest(BaseModel):
    user_preferences: List[str] = Field(..., description="User's preferred categories")
    browsing_history: List[str] = Field(..., description="Products user has recently viewed")
    location: str = Field(..., description="User's location")
    time_of_day: str = Field(..., description="Current time of day")
    weather_conditions: str = Field(..., description="Current weather conditions")

class ProductRecommendationResponse(BaseModel):
    recommended_products: List[str] = Field(..., description="List of recommended product IDs")
    recommendation_scores: List[float] = Field(..., description="Confidence scores for each recommendation")
    personalization_factors: List[str] = Field(..., description="Factors influencing recommendations")

# New Recommendation System Models
class RecommendationRequest(BaseModel):
    userId: str = Field(..., description="User ID")
    location: Optional[Dict[str, float]] = Field(None, description="User location with latitude and longitude")

class RecommendationResponse(BaseModel):
    recommended: List[str] = Field(..., description="Recommended product IDs")
    nearby: List[str] = Field(..., description="Nearby product IDs")
    trending: List[str] = Field(..., description="Trending product IDs")
    similar: List[str] = Field(..., description="Similar product IDs")
