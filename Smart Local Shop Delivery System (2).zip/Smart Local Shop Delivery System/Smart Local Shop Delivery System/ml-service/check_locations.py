import os
from dotenv import load_dotenv
from pymongo import MongoClient

load_dotenv()

def check_vendor_locations():
    print("🌍 Checking Vendor Locations...")
    
    try:
        uri = os.getenv('MONGODB_URI', 'mongodb://localhost:27017/final_project')
        client = MongoClient(uri)
        db = client[os.getenv('DB_NAME', 'final_project')]
        
        # Check users collection for vendors
        if 'users' in db.list_collection_names():
            vendors = list(db.users.find({'role': 'VENDOR', 'location': {'$exists': True}}).limit(5))
            print(f"✅ Found {len(vendors)} vendors with locations:")
            
            for vendor in vendors:
                location = vendor.get('location', {})
                print(f"  📍 {vendor.get('firstName', '')} {vendor.get('lastName', '')}: {location}")
                
                # Handle different location formats
                if location:
                    if isinstance(location, dict):
                        if 'coordinates' in location and len(location['coordinates']) >= 2:
                            lat, lng = location['coordinates']
                            print(f"     Coordinates: {lat}, {lng}")
                        elif 'lat' in location and 'lng' in location:
                            lat, lng = location['lat'], location['lng']
                            print(f"     Coordinates: {lat}, {lng}")
                        else:
                            print(f"     Location format: {location}")
                    else:
                        print(f"     Location: {location}")
            
            # Also check vendors without locations
            vendors_no_location = list(db.users.find({'role': 'VENDOR', 'location': {'$exists': False}}).limit(3))
            print(f"\n⚠️  Found {len(vendors_no_location)} vendors without locations:")
            
            for vendor in vendors_no_location:
                print(f"  📍 {vendor.get('firstName', '')} {vendor.get('lastName', '')}: No location set")
        else:
            print("❌ No users collection found")
        
        # Check products with vendor locations
        if 'products' in db.list_collection_names():
            products = list(db.products.find({}).limit(3))
            print(f"\n📦 Sample products:")
            
            for product in products:
                vendor_id = product.get('vendor')
                print(f"  📦 {product.get('name')} - Vendor: {vendor_id}")
                
                # Get vendor location
                if vendor_id:
                    vendor = db.users.find_one({'_id': vendor_id, 'role': 'VENDOR'})
                    if vendor and 'location' in vendor:
                        location = vendor['location']
                        print(f"     📍 Location: {location}")
                    else:
                        print(f"     📍 Location: Not found for vendor {vendor_id}")
        
        client.close()
        
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    check_vendor_locations()
