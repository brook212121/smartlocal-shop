import os
from dotenv import load_dotenv
from pymongo import MongoClient
from bson import ObjectId
from typing import Dict, Any, List

# Load environment variables
load_dotenv()

MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "final_project")

class Database:
    _instance = None
    _client = None
    _db = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if self._client is None:
            self._client = MongoClient(MONGODB_URI)
            self._db = self._client[DB_NAME]

    @property
    def db(self):
        return self._db

    def get_user_activities(self, user_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        """Get user activity data from database"""
        try:
            # Convert string userId to ObjectId for query
            try:
                user_obj_id = ObjectId(user_id)
            except:
                # If invalid ObjectId, try string search as fallback
                user_obj_id = user_id
            
            activities = list(self.db.user_activities.find(
                {"userId": user_obj_id},
                {"_id": 0}
            ).sort("createdAt", -1).limit(limit))
            
            # Convert ObjectId to string for consistency
            for activity in activities:
                if "productId" in activity and activity["productId"]:
                    activity["productId"] = str(activity["productId"])
                if "shopId" in activity and activity["shopId"]:
                    activity["shopId"] = str(activity["shopId"])
                if "userId" in activity and activity["userId"]:
                    activity["userId"] = str(activity["userId"])
            
            return activities
        except Exception as e:
            print(f"Error fetching user activities: {e}")
            return []

    def get_all_products(self) -> List[Dict[str, Any]]:
        """Get all products from database"""
        try:
            products = list(self.db.products.find(
                {"isActive": True}
            ))
            
            # Convert ObjectId to string and add id field
            for product in products:
                if "_id" in product:
                    product["id"] = str(product.pop("_id"))
                if "vendor" in product and product["vendor"]:
                    product["vendor"] = str(product["vendor"])
            
            return products
        except Exception as e:
            print(f"Error fetching products: {e}")
            return []

    def get_all_activities(self, limit: int = 1000) -> List[Dict[str, Any]]:
        """Get all user activities for trending calculations"""
        try:
            activities = list(self.db.user_activities.find(
                {},
                {"_id": 0, "productId": 1, "action": 1, "createdAt": 1}
            ).sort("createdAt", -1).limit(limit))
            
            # Convert ObjectId to string for consistency
            for activity in activities:
                if "productId" in activity and activity["productId"]:
                    activity["productId"] = str(activity["productId"])
            
            return activities
        except Exception as e:
            print(f"Error fetching all activities: {e}")
            return []

    def close(self):
        """Close database connection"""
        if self._client:
            self._client.close()

# Singleton instance
db = Database()
