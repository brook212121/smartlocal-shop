from fastapi import APIRouter, HTTPException
from models import DeliveryPredictionRequest, DeliveryPredictionResponse
from services.delivery_predictor import DeliveryPredictor

router = APIRouter()
delivery_predictor = DeliveryPredictor()

@router.post("/predict/delivery", response_model=DeliveryPredictionResponse)
async def predict_delivery(request: DeliveryPredictionRequest):
    """Predict delivery time based on various factors"""
    try:
        prediction = delivery_predictor.predict_delivery_time(request)
        return prediction
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error in delivery prediction: {str(e)}"
        )
