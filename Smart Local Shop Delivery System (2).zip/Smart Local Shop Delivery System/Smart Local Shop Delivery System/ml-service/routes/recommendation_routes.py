from fastapi import APIRouter, HTTPException
from models import RecommendationRequest, RecommendationResponse
from services.recommendation_engine import RecommendationEngine
from database import db

router = APIRouter()
recommendation_engine = RecommendationEngine()

@router.post("/recommend", response_model=RecommendationResponse)
async def get_recommendations(request: RecommendationRequest):
    """Get personalized product recommendations"""
    try:
        user_id = request.userId
        user_location = request.location
        
        # Load user activity from database
        user_activities = db.get_user_activities(user_id)
        
        # Load all products from database
        all_products = db.get_all_products()
        
        # Calculate recommendations using hybrid approach
        recommendations = recommendation_engine.calculate_hybrid_recommendations(
            user_id, 
            user_activities, 
            all_products, 
            user_location
        )
        
        return recommendations
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error in recommendation: {str(e)}"
        )
