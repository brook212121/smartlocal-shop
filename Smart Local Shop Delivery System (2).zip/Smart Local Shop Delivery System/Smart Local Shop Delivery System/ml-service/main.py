import os
import uvicorn
from fastapi import FastAPI, HTTPException
from dotenv import load_dotenv
from routes.recommendation_routes import router as recommendation_router
from routes.delivery_routes import router as delivery_router
from database import db
from services.recommendation_engine import RecommendationEngine
from models import (
    DeliveryPredictionRequest, 
    DeliveryPredictionResponse,
    ProductRecommendationRequest, 
    ProductRecommendationResponse,
    RecommendationRequest, 
    RecommendationResponse
)

# Load environment variables
load_dotenv()

# Initialize FastAPI app
app = FastAPI(
    title="Smart Local Shop Delivery ML Service",
    description="Machine Learning service for delivery predictions and product recommendations",
    version="1.0.0"
)

# Initialize recommendation engine
recommendation_engine = RecommendationEngine()

# CORS middleware
@app.middleware("http")
async def add_cors_header(request, call_next):
    response = await call_next(request)
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "*"
    return response

# Health check endpoint
@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "timestamp": "2025-03-21T12:00:00Z",
        "version": "1.0.0"
    }

# Info endpoint
@app.get("/info")
async def get_info():
    return {
        "name": "Smart Local Shop Delivery ML Service",
        "version": "1.0.0",
        "description": "Machine Learning service for delivery predictions and product recommendations",
        "endpoints": {
            "health": "/health",
            "info": "/info",
            "predict_delivery": "/predict/delivery",
            "recommend_products": "/recommend/products",
            "recommend": "/recommend"
        },
        "models": {
            "Delivery Prediction": "Predicts optimal delivery time based on various factors",
            "Product Recommendation": "Recommends products based on user behavior and preferences"
        }
    }

# Legacy product recommendation endpoint (keeping for compatibility)
@app.post("/recommend/products", response_model=ProductRecommendationResponse)
async def recommend_products_legacy(request: ProductRecommendationRequest):
    """Legacy product recommendation endpoint - kept for compatibility"""
    # Placeholder implementation for backward compatibility
    return ProductRecommendationResponse(
        recommended_products=["product_1", "product_2", "product_3"],
        recommendation_scores=[0.9, 0.8, 0.7],
        personalization_factors=["user_preferences", "browsing_history", "time_of_day"]
    )

# Main recommendation endpoint (for Node.js integration)
@app.post("/recommend", response_model=RecommendationResponse)
async def get_recommendations(request: RecommendationRequest):
    """Get personalized product recommendations"""
    try:
        user_id = request.userId
        user_location = request.location
        
        # Load user activity from database
        user_activities = db.get_user_activities(user_id)
        
        # Load all products from database
        all_products = db.get_all_products()
        
        # Calculate recommendations using hybrid approach
        recommendations = recommendation_engine.calculate_hybrid_recommendations(
            user_id, 
            user_activities, 
            all_products, 
            user_location
        )
        
        return recommendations
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error in recommendation: {str(e)}"
        )

# Include routes
app.include_router(recommendation_router, prefix="/api")
app.include_router(delivery_router, prefix="/api")

# Root endpoint
@app.get("/")
async def root():
    return {
        "message": "Smart Local Shop Delivery ML Service",
        "version": "1.0.0",
        "endpoints": {
            "health": "/health",
            "info": "/info",
            "predict_delivery": "/api/predict/delivery",
            "recommend_products": "/recommend/products",
            "recommend": "/api/recommend"
        }
    }

if __name__ == "__main__":
    port = int(os.getenv("PORT", 8000))
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=port,
        reload=True if os.getenv("ENVIRONMENT") == "development" else False
    )
